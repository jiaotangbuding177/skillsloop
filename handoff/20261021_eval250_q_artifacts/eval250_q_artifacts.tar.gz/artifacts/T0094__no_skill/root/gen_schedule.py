# -*- coding: utf-8 -*-
import json
from docx import Document
from docx.shared import Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, PatternFill
from openpyxl.utils import get_column_letter

specs = json.load(open('/workspace/inputs/event_specs.json', encoding='utf-8'))
roles = [l.rstrip('\n').split(',') for l in open('/workspace/inputs/team_roles.csv', encoding='utf-8') if l.strip()]

# ---------- schedule model ----------
def mm(t):
    h, m = t.split(':'); return int(h)*60+int(m)
def ts(m):
    return f"{m//60:02d}:{m%60:02d}"

start = mm(specs['window'][0])
P, Q, C = specs['presentation_min'], specs['qa_min'], specs['change_min']
B1, B2 = specs['mandatory_breaks_min']
OPEN, CLOSE = specs['opening_min'], specs['closing_min']

# timeline: (start, dur, segment, owner, notes)
tl = []
cur = start
opening_end = cur + OPEN
tl.append((cur, OPEN, "开幕与规则说明", "主持", "70名观众入场就座；主持人宣读流程、评分规则与安全须知；技术组完成投影/音响最终联调；场务引导各队候场区就位"))
cur = opening_end

def add_block(gids, cur):
    for g in gids:
        p0 = cur; p1 = p0+P; q1 = p1+Q; c1 = q1+C
        tl.append((p0, P, f"第{g}组 展示", f"第{g}组+评委", "6分钟成果展示（单舞台，一次过，不重放）"))
        tl.append((p1, Q, f"第{g}组 问答", "评委", "3分钟评委提问与现场打分"))
        tl.append((q1, C, f"第{g}组换场", "场务", "1分钟上台/下台、切换设备；组联络提交该组材料"))
        cur = c1
    return cur

# Block A: groups 1-4
cur = add_block([1,2,3,4], cur)
tl.append((cur, B1, "休息① + 迟到处置窗口①", "全体", "10分钟休息；技术组巡检设备；迟到组在此窗口顺延补位，不挤占他人时段")); cur += B1
# Block B: groups 5-9
cur = add_block([5,6,7,8,9], cur)
tl.append((cur, B2, "休息② + 设备检查②", "技术/场务", "10分钟休息；技术组第二次设备检查（备用翻页笔、备用HDMI、话筒电池）")); cur += B2
# Block C: groups 10-13
cur = add_block([10,11,12,13], cur)
tl.append((cur, 15, "设备终检 + 评审快速合议", "技术/评委", "15分钟：技术组最后一次全链路检查；评委快速合议前13组分数")); cur += 15
# G14
cur = add_block([14], cur)
tl.append((cur, 15, "评审终议", "评委", "15分钟评委终议与排名确认；组联络核对各组材料归档")); cur += 15
tl.append((cur, CLOSE, "闭幕、颁奖与合影", "主持", f"20分钟：宣布结果、颁奖、合影、致谢")); cur += CLOSE
remaining = mm(specs['window'][1]) - cur
tl.append((cur, remaining, "机动缓冲 / 撤场与疏散说明", "安全负责人/场务", f"{remaining}分钟机动：迟到组最终补位窗口；结束后场务引导撤场，安全负责人确认疏散通道"))

# ---------- run_of_show.xlsx ----------
wb = Workbook()
ws = wb.active; ws.title = "现场时间表"
headers = ["时间", "时长(分钟)", "环节", "负责角色", "内容要点"]
ws.append(headers)
hdr_fill = PatternFill('solid', fgColor='1F4E79')
for c in range(1, len(headers)+1):
    cell = ws.cell(row=1, column=c)
    cell.font = Font(bold=True, color='FFFFFF', size=11)
    cell.fill = hdr_fill
    cell.alignment = Alignment(horizontal='center', vertical='center')
row_fill = PatternFill('solid', fgColor='DDEBF7')
for (s, d, seg, owner, note) in tl:
    ws.append([f"{ts(s)}–{ts(s+d)}", d, seg, owner, note])
for r in range(2, ws.max_row+1):
    seg = ws.cell(row=r, column=3).value or ""
    if "休息" in seg or "缓冲" in seg or "机动" in seg:
        for c in range(1, len(headers)+1):
            ws.cell(row=r, column=c).fill = row_fill
    ws.cell(row=r, column=1).alignment = Alignment(horizontal='center')
    ws.cell(row=r, column=2).alignment = Alignment(horizontal='center')
widths = [16, 11, 26, 14, 66]
for i, w in enumerate(widths, 1):
    ws.column_dimensions[get_column_letter(i)].width = w
ws.freeze_panes = "A2"

ws2 = wb.create_sheet("核对参数")
params = [
    ["日期", specs['date']], ["参与人数", specs['participants']], ["展示组数", specs['groups']],
    ["每组人数", specs['group_size']], ["时间窗口", f"{specs['window'][0]}–{specs['window'][1]}"],
    ["每组展示", f"{P}分钟"], ["每组问答", f"{Q}分钟"], ["换场", f"{C}分钟"],
    ["强制休息", f"2×{B1}分钟"], ["开幕", f"{OPEN}分钟"], ["闭幕", f"{CLOSE}分钟"],
    ["场地容量", f"{specs['room_capacity']}人（70人观众+工作团队，单舞台）"],
    ["总占用", "15+140(组)+20(休息)+15(终检)+15(终议)+20(闭幕)+15(机动)=240分钟"],
]
for p in params: ws2.append(p)
ws2.column_dimensions['A'].width = 14
ws2.column_dimensions['B'].width = 50
wb.save('/workspace/outputs/run_of_show.xlsx')

# ---------- event_runbook.docx ----------
doc = Document()
style = doc.styles['Normal']; style.font.name = 'Noto Sans CJK SC'; style.font.size = Pt(10.5)

def h(text, lvl=1):
    doc.add_heading(text, level=lvl)
def p(text):
    doc.add_paragraph(text)
def table(headers_, rows):
    t = doc.add_table(rows=1, cols=len(headers_)); t.style = 'Light Grid Accent 1'
    for i, x in enumerate(headers_): t.rows[0].cells[i].text = x
    for row in rows:
        cells = t.add_row().cells
        for i, x in enumerate(row): cells[i].text = str(x)
    return t

title = doc.add_heading("70人企业创新展演 · 现场执行手册 (Event Runbook)", level=0)
title.alignment = WD_ALIGN_PARAGRAPH.CENTER
p(f"日期：{specs['date']}　时间：{specs['window'][0]}–{specs['window'][1]}（240分钟）　参与人数：{specs['participants']}人　展示组数：{specs['groups']}组×{specs['group_size']}人")
p(f"场地：单舞台会场，登记容量 {specs['room_capacity']} 人（≥70人，满足承载要求；本手册不超出该登记容量安排活动）")

h("一、总体安排")
p("全部14组展示在单舞台依次进行。每组展示6分钟＋问答3分钟＋换场1分钟，共10分钟/组，合计140分钟。")
p("时间预算：开幕15分钟＋展示140分钟＋强制休息2×10分钟＋设备终检/评审快速合议15分钟＋评审终议15分钟＋闭幕20分钟＋机动缓冲15分钟＝240分钟，恰好覆盖13:00–17:00，无超时风险。")

h("二、人员分工（依据 team_roles.csv）")
table(["角色", "人数", "责任"], [r for r in roles[1:]])
p("提示：14名组联络分别对接第1–14组，负责提前30分钟收取演示材料（U盘或共享文件夹），并在该组换场时当场交接。")

h("三、总时间表")
table(["时间", "时长", "环节", "负责角色"], [[f"{ts(s)}–{ts(s+d)}", f"{d}分钟", seg, owner] for (s,d,seg,owner,_) in tl])
p("分秒级时刻表（含每组的展示/问答/换场切分）见附件 run_of_show.xlsx。")

h("四、换场流程（每组1分钟）")
for step in [
    "上一组问答结束即下台，场务同时引导下一组自候场区上台，两侧同时进行；",
    "技术组在该1分钟内完成翻页/HDMI/话筒切换；",
    "组联络向主持与评委递交该组纸质评分表与材料清单；",
    "主持报幕并开始计时，展示计时6分钟整。",
]:
    doc.add_paragraph(step, style='List Bullet')
p("换场超时处理：换场占用超过1分钟的部分，从该组展示时间中扣除，不向后顺延。")

h("五、休息与设备检查")
for step in [
    "休息①（13:55–14:05）：观众休息10分钟；技术组巡检投影/音响/翻页笔；场务整理候场区秩序。",
    "休息②（14:55–15:05）：第二次设备检查——更换话筒电池、测试备用HDMI线与备用翻页笔、确认备用笔记本热备。",
    "设备终检（15:45–15:55）：第14组上场前的全链路最后检查，同时评委快速合议前13组分数。",
]:
    doc.add_paragraph(step, style='List Bullet')

h("六、迟到处置")
for step in [
    "候场要求：组联络须在该组开始前15分钟确认全员到场并向主持报告；未确认即进入预警状态。",
    "迟到≤5分钟：压缩该组展示时间为（6分钟−迟到分钟数），问答保持3分钟，不向后顺延。",
    "迟到>5分钟：该组顺延至最近的机动缓冲窗口（13:55–14:05 或 16:45–17:00）补位展示，其原时段由后续组依序前移填补。",
    "缓冲窗口结束仍未到场：视为弃权，不保留席位；主持现场公示，评委按实际完成组数评分。",
    "全程不因个别迟到压缩其他组的展示、问答或休息时间。",
]:
    doc.add_paragraph(step, style='List Bullet')

h("七、场地与安全")
for step in [
    f"容量控制：会场登记容量{specs['room_capacity']}人，现场70人（含观众与工作人员）未超载；入场后不再临时增发席位。",
    "安全负责人（1人）开场宣读疏散路线，全场保持两条疏散通道畅通，换场与休息时段在场务通道口值守。",
    "单舞台规则：任一时刻舞台上仅有一组，候场区最多容纳1个候补组，其余在观众席后排就座。",
    "紧急情况：安全负责人发出疏散指令后，主持立即中止流程，场务按排引导离场，技术组断电保护设备。",
]:
    doc.add_paragraph(step, style='List Bullet')

h("八、交付物与归档")
p("各组材料由组联络在换场时收齐（演示文件＋评分表），评审终议阶段完成核对归档；当日17:00前由主持汇总成绩并公示。")

doc.save('/workspace/outputs/event_runbook.docx')
print('done')
