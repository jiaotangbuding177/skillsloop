# -*- coding: utf-8 -*-
from docx import Document
from docx.shared import Pt
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, PatternFill
import os

os.makedirs('/workspace/outputs', exist_ok=True)

# ---------- weekly_report.docx ----------
doc = Document()
style = doc.styles['Normal']
style.font.name = 'Noto Sans CJK SC'
style.font.size = Pt(11)

doc.add_heading('周报（2026-10-05 至 2026-10-09）', level=0)
p = doc.add_paragraph('口径说明：本报告依据内部工作日志整理，非第三方审计。各事项以最新明确记录为当前状态；完成仅对应已验证事实，待确认/受阻状态不升格为完成。A3 的完成指缺陷修复经内部独立复核验证，不代表项目整体验收。')

# 一、本周成果
doc.add_heading('一、本周成果（按工作结果）', level=1)
results = [
    ('A3 研发｜跨组资料可见缺陷修复并完成独立复核（完成）',
     '修复包1.8.2提交并通过12个隔离用例，主管批准后完成部署（回滚包已存），10-09 QA独立复核12/12用例及3个角色，未发现越权。约定日10-09当周达成。',
     'W08（修复包1.8.2）、W13（QA隔离用例12/12通过）、W18（主管批准后部署）、W23（复核12/12及3角色，未发现越权）',
     '王工'),
    ('A2 交付｜青林项目接口映射与文档导入（阶段性结果）',
     '收到客户ID字典v1.2（18字段，接口只读）后，完成沙箱18字段映射（集成日志I207）；50份文档导入核对，47份通过。',
     'W07（字典v1.2含18字段）、W12（集成日志I207）、W17（47份通过、3份扫描PDF无OCR）',
     '赵琪'),
    ('A4 培训｜40人培训组织与实施（阶段性结果）',
     '确认40人名单（销售16/交付12/管理12），完成三组脱敏案例（15邮件、30故障、6费用规则）与90分钟教师演练（投影离线可用）；培训37人到场（签到T404），37份任务产物中31份一次通过。',
     'W04（名单T401构成）、W09（脱敏案例已审权限）、W14（90分钟演练）、W19（37人到场，签到T404）、W24（31份一次通过）',
     '何清'),
    ('A5 行政｜项目成果目录盘点与归档（阶段性结果）',
     '完成14份成果文件索引与权限核对（索引A503），归档12份批准资料；识别出2份额外文件为风险表及变更审批，保留不删除。',
     'W05（登记12份实为14份）、W10（2份为风险表及变更审批）、W15（索引A503）、W20（归档12份）',
     '陈宁'),
    ('A1 销售｜澄峰客户需求推进（阶段性结果）',
     '客户会议确认离线检索需求；获采购邮件回复12万元预算上限（未签采购）；提交一期报价Q106（平台8万、对接3万、培训1万）。',
     'W01（会议确认离线检索）、W06（采购邮件12万元上限）、W11（报价Q106构成）',
     '李宁'),
]
for title, body, ev, owner in results:
    doc.add_heading(title, level=2)
    doc.add_paragraph(body)
    doc.add_paragraph('证据：' + ev)
    doc.add_paragraph('负责人：' + owner)

# 二、风险与受阻
doc.add_heading('二、风险与受阻', level=1)
risks = [
    ('A1 销售｜报价受阻，待确认',
     '安全部门要求本地模型，现报价未含服务器；主管已同意补做硬件报价，但客户未同意增加预算。状态：待确认（不作为完成）。',
     'W16（安全要求本地模型，报价无服务器）、W21（主管同意补报价，客户未同意加预算）',
     '李宁', '2026-10-12'),
    ('A2 交付｜验收受阻',
     '3份扫描PDF无OCR，客户须补3份可搜索PDF后方可签验收；沙箱映射未获生产授权，无法验证生产环境。状态：受阻。',
     'W17（3份无OCR）、W12（未获生产授权）、W22（客户须补3份，验收未签）',
     '赵琪', '2026-10-13'),
    ('A5 行政｜待批准清单未获回复',
     '2份文件（风险表、变更审批）待负责人确认现行状态；待批准清单已发送但负责人未回复，14份并非全部现行。状态：受阻。',
     'W10（2份待确认）、W15（2份待负责人确认）、W25（负责人未回复，14份并非全部现行）',
     '陈宁', '2026-10-12'),
    ('A4 培训｜收尾缺口',
     '6份任务产物待辅导，3名缺席人员补课未排期。状态：进行中。',
     'W19（3人缺席）、W24（31份通过、6份待辅导，3缺席补课未排）',
     '何清', '2026-10-14'),
]
for title, body, ev, owner, due in risks:
    doc.add_heading(title, level=2)
    doc.add_paragraph(body)
    doc.add_paragraph('证据：' + ev)
    doc.add_paragraph('负责人：' + owner + '｜约定日：' + due)

# 三、下周重点
doc.add_heading('三、下周重点（均来自已记录缺口）', level=1)
nexts = [
    'A1（李宁，约定10-12）：跟进硬件补报价进展与客户反馈，获得明确答复前报价状态保持待确认。',
    'A2（赵琪，约定10-13）：跟进客户补交3份可搜索PDF；获生产授权后再对沙箱映射做生产验证，验收签署前不算完成。',
    'A5（陈宁，约定10-12）：跟进负责人对待批准清单的回复，确认2份文件的现行状态并完成归档闭环。',
    'A4（何清，约定10-14）：安排6份待辅导产物的辅导与3名缺席人员补课排期（补课目前未排）。',
    'A3（王工）：缺陷修复已内部验证完成，无已记录遗留缺口。',
]
for t in nexts:
    doc.add_paragraph(t, style='List Number')
doc.save('/workspace/outputs/weekly_report.docx')

# ---------- actions.xlsx ----------
wb = Workbook()
ws = wb.active
ws.title = '未完事项'
headers = ['事项ID', '事项名称', '类别', '负责人', '最新状态', '状态日期', '约定日', '最新证据事实', '历史关键证据', '缺口/下一步']
ws.append(headers)
rows = [
    ['A1', '澄峰客户需求推进（离线检索/报价）', '销售', '李宁', '待确认', '2026-10-09', '2026-10-12',
     '主管同意补做硬件报价，客户未同意增加预算（W21）',
     'W01会议确认离线检索；W06采购邮件12万元上限未签采购；W11报价Q106（平台8万/对接3万/培训1万）；W16安全部门要求本地模型，现报价无服务器',
     '跟进硬件补报价与客户反馈；获明确答复前报价保持待确认，不按完成处理'],
    ['A2', '青林项目接口资料核对与文档导入', '交付', '赵琪', '受阻', '2026-10-09', '2026-10-13',
     '客户须补3份可搜索PDF，验收未签（W22）',
     'W02缺客户ID字典受阻；W07字典v1.2含18字段；W12沙箱18字段映射（集成日志I207）未获生产授权；W17 47/50通过，3份扫描PDF无OCR',
     '跟进客户补交3份可搜索PDF；获生产授权后验证映射，验收签署前不视为完成'],
    ['A4', '40人培训组织与实施', '培训', '何清', '进行中', '2026-10-09', '2026-10-14',
     '37份任务产物中31份一次通过、6份待辅导，3人缺席补课未排（W24）',
     'W04名单T401（销售16/交付12/管理12）；W09三组脱敏案例已审权限；W14 90分钟教师演练；W19 37人到场签到T404',
     '安排6份产物辅导与3名缺席人员补课排期（补课未排）'],
    ['A5', '项目成果目录盘点与归档', '行政', '陈宁', '受阻', '2026-10-09', '2026-10-12',
     '待批准清单发出后负责人未回复，14份并非全部现行（W25）',
     'W05登记12份实为14份；W10多出2份为风险表及变更审批不删除；W15索引A503、2份待负责人确认；W20归档12份，另2份放待批准区',
     '跟进负责人回复，确认2份文件现行状态并完成归档闭环'],
]
for r in rows:
    ws.append(r)

ws2 = wb.create_sheet('已完成事项')
ws2.append(['事项ID', '事项名称', '类别', '负责人', '状态', '状态日期', '约定日', '完成证据', '说明'])
ws2.append(['A3', '跨组资料可见缺陷修复', '研发', '王工', '完成', '2026-10-09', '2026-10-09',
            'QA独立复核12/12用例及3角色，未发现越权（W23）',
            '内部工作日志口径：完成指缺陷修复经内部独立复核验证，不代表项目整体验收'])

header_fill = PatternFill('solid', fgColor='DDEBF7')
bold = Font(bold=True)
for sheet in (ws, ws2):
    for cell in sheet[1]:
        cell.font = bold
        cell.fill = header_fill
        cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
    sheet.freeze_panes = 'A2'
    for col_idx, col_cells in enumerate(sheet.columns, 1):
        letter = sheet.cell(row=1, column=col_idx).column_letter
        if sheet.title == '未完事项' and col_idx in (8, 9, 10):
            width = 40
        elif sheet.title == '已完成事项' and col_idx in (8, 9):
            width = 40
        else:
            width = 14
        sheet.column_dimensions[letter].width = width
    for row in sheet.iter_rows(min_row=2):
        for c in row:
            c.alignment = Alignment(vertical='top', wrap_text=True)

wb.save('/workspace/outputs/actions.xlsx')
print('done')
