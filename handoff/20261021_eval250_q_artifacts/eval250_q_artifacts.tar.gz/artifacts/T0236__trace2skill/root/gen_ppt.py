# -*- coding: utf-8 -*-
"""生成 客户知识库阶段验收.pptx：5页，16:9，白底蓝色商务风。"""
from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.chart.data import CategoryChartData
from pptx.enum.chart import XL_CHART_TYPE, XL_LEGEND_POSITION

DARK = RGBColor(0x1F, 0x4E, 0x79)   # 深蓝
MID = RGBColor(0x2E, 0x75, 0xB6)    # 中蓝
LIGHT = RGBColor(0xDE, 0xEB, 0xF7)  # 浅蓝底
GREY = RGBColor(0x59, 0x59, 0x59)
WHITE = RGBColor(0xFF, 0xFF, 0xFF)
FONT = "Noto Sans CJK SC"

prs = Presentation()
prs.slide_width = Inches(13.333)
prs.slide_height = Inches(7.5)
blank = prs.slide_layouts[6]


def add_slide():
    s = prs.slides.add_slide(blank)
    # 白底
    bg = s.background
    bg.fill.solid()
    bg.fill.fore_color.rgb = WHITE
    return s


def txt(slide, x, y, w, h, text, size=18, color=DARK, bold=False,
        align=PP_ALIGN.LEFT, anchor=MSO_ANCHOR.TOP, line_spacing=1.15):
    box = slide.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    tf = box.text_frame
    tf.word_wrap = True
    tf.vertical_anchor = anchor
    lines = text.split("\n")
    for i, line in enumerate(lines):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.text = line
        p.alignment = align
        p.line_spacing = line_spacing
        for r in p.runs:
            r.font.name = FONT
            r.font.size = Pt(size)
            r.font.color.rgb = color
            r.font.bold = bold
    return box


def header(slide, title, subtitle=None):
    bar = slide.shapes.add_shape(1, Inches(0), Inches(0), prs.slide_width, Inches(0.16))
    bar.fill.solid(); bar.fill.fore_color.rgb = DARK; bar.line.fill.background()
    txt(slide, 0.55, 0.35, 11.5, 0.7, title, size=28, bold=True)
    strip = slide.shapes.add_shape(1, Inches(0.57), Inches(1.02), Inches(1.6), Inches(0.06))
    strip.fill.solid(); strip.fill.fore_color.rgb = MID; strip.line.fill.background()
    if subtitle:
        txt(slide, 0.55, 1.14, 12.2, 0.4, subtitle, size=13, color=GREY)
    return slide


def card(slide, x, y, w, h, fill=LIGHT, line=None):
    sh = slide.shapes.add_shape(1, Inches(x), Inches(y), Inches(w), Inches(h))
    sh.fill.solid(); sh.fill.fore_color.rgb = fill
    if line:
        sh.line.color.rgb = line; sh.line.width = Pt(1)
    else:
        sh.line.fill.background()
    sh.shadow.inherit = False
    return sh


def set_cell(cell, text, size=13, bold=False, color=DARK, fill=None, align=PP_ALIGN.CENTER):
    cell.margin_left = Inches(0.06); cell.margin_right = Inches(0.06)
    cell.margin_top = Inches(0.03); cell.margin_bottom = Inches(0.03)
    cell.vertical_anchor = MSO_ANCHOR.MIDDLE
    if fill is not None:
        cell.fill.solid(); cell.fill.fore_color.rgb = fill
    tf = cell.text_frame
    tf.word_wrap = True
    p = tf.paragraphs[0]
    p.text = text
    p.alignment = align
    for r in p.runs:
        r.font.name = FONT; r.font.size = Pt(size)
        r.font.bold = bold; r.font.color.rgb = color


# ============ 第1页 封面 ============
s = add_slide()
band = s.shapes.add_shape(1, Inches(0), Inches(2.6), prs.slide_width, Inches(0.05))
band.fill.solid(); band.fill.fore_color.rgb = MID; band.line.fill.background()
txt(s, 0.9, 1.55, 11.5, 1.0, "客户知识库阶段验收", size=44, bold=True)
txt(s, 0.9, 2.85, 11.5, 0.6, "现状 · 问题 · 计划", size=22, color=MID)
txt(s, 0.9, 4.15, 11.0, 1.2,
    "汇报对象：客户项目经理\n口径：仅使用已确认事实；缺失数据如实标注，未完成状态不予美化",
    size=15, color=GREY)
txt(s, 0.9, 6.55, 11.0, 0.5, "供应商项目组 · 2026年10月", size=13, color=GREY)

# ============ 第2页 现状：材料与样本 ============
s = add_slide()
header(s, "一、现状｜合同材料与测试样本",
       "系统仅基于已提交资料运行；未提交资料不计验证失败，也不得假称支持")

# 表格：材料分布
rows, cols = 6, 4
tbl = s.shapes.add_table(rows, cols, Inches(0.55), Inches(1.75), Inches(6.6), Inches(3.1)).table
tbl.columns[0].width = Inches(2.1)
for i in (1, 2, 3):
    tbl.columns[i].width = Inches(1.5)
heads = ["资料类型", "总数（份）", "已提交（份）", "待提交（份）"]
for j, h in enumerate(heads):
    set_cell(tbl.cell(0, j), h, bold=True, color=WHITE, fill=DARK)
data = [
    ("产品手册", "90", "72", "18"),
    ("维修说明", "40", "32", "8"),
    ("流程指南", "20", "16", "4"),
    ("合计", "150", "120", "30"),
]
for i, row in enumerate(data, start=1):
    bold = (i == 4)
    fill = LIGHT if i < 4 else RGBColor(0xBD, 0xD7, 0xEE)
    for j, v in enumerate(row):
        set_cell(tbl.cell(i, j), v, bold=bold, fill=fill)

txt(s, 0.55, 5.05, 6.6, 0.4, "测试样本：40条 = 30条答案双方已确认 ＋ 10条待客户核认", size=14, bold=True, color=MID)
txt(s, 0.55, 5.5, 6.6, 1.6,
    "· 待提交30份为待新版资料，由客户数据管理员确认最新版本\n· 40条样本未给出实际通过率，本次不补\"全部PASS\"\n· 未提交资料不能计入测试失败",
    size=13, color=GREY)

# 图表：堆积柱状图（单位：份）
chart_data = CategoryChartData()
chart_data.categories = ["产品手册", "维修说明", "流程指南"]
chart_data.add_series("已提交（份）", (72, 32, 16))
chart_data.add_series("待提交（份）", (18, 8, 4))
gf = s.shapes.add_chart(XL_CHART_TYPE.COLUMN_STACKED, Inches(7.5), Inches(1.75),
                        Inches(5.3), Inches(3.9), chart_data)
chart = gf.chart
chart.has_title = True
cchart = chart.chart_title.text_frame.paragraphs[0]
cchart.text = "合同材料提交情况（单位：份）"
for r in cchart.runs:
    r.font.size = Pt(14); r.font.name = FONT; r.font.color.rgb = DARK; r.font.bold = True
chart.has_legend = True
chart.legend.position = XL_LEGEND_POSITION.BOTTOM
chart.legend.include_in_layout = False
for ser, col in zip(chart.series, (MID, RGBColor(0xB4, 0xC7, 0xE7))):
    ser.format.fill.solid(); ser.format.fill.fore_color.rgb = col
chart.plots[0].gap_width = 80
for axis in (chart.category_axis, chart.value_axis):
    axis.tick_labels.font.size = Pt(12)
    axis.tick_labels.font.name = FONT
    axis.tick_labels.font.color.rgb = GREY
chart.value_axis.has_major_gridlines = True

txt(s, 7.5, 5.75, 5.3, 1.2,
    "口径说明：30份待新版材料在客户确认版本前不进入验收范围。",
    size=12, color=GREY)

# ============ 第3页 现状：已完成工作 ============
s = add_slide()
header(s, "二、现状｜已完成工作", "预发布环境运行；尚未取得最终验收签字")
items = [
    ("材料目录登记", "按文件名、日期、版号和所属产品逐份登记，形成可追溯目录"),
    ("版本去重", "已提交120份完成去重，发现14组同产品旧新版本；旧版保留为历史，默认检索新版"),
    ("权限分配", "按客户产品组分配查询权限"),
    ("运行环境", "当前为预发布环境，10月8日验收范围为已提交的120份"),
]
y = 1.85
for i, (t, d) in enumerate(items, start=1):
    card(s, 0.55, y, 12.2, 1.05, fill=LIGHT)
    num = s.shapes.add_shape(1, Inches(0.8), Inches(y + 0.22), Inches(0.6), Inches(0.6))
    num.fill.solid(); num.fill.fore_color.rgb = MID; num.line.fill.background()
    ntf = num.text_frame; ntf.word_wrap = False
    np_ = ntf.paragraphs[0]; np_.text = str(i); np_.alignment = PP_ALIGN.CENTER
    for r in np_.runs:
        r.font.name = FONT; r.font.size = Pt(18); r.font.bold = True; r.font.color.rgb = WHITE
    txt(s, 1.65, y + 0.1, 10.9, 0.45, t, size=16, bold=True)
    txt(s, 1.65, y + 0.53, 10.9, 0.45, d, size=13, color=GREY)
    y += 1.25

txt(s, 0.55, y + 0.05, 12.2, 0.5,
    "限制：预发布环境结论不代表生产验收；最终验收签字尚未取得。",
    size=13, bold=True, color=DARK)

# ============ 第4页 问题与限制 ============
s = add_slide()
header(s, "三、问题与限制", "以下事项均未关闭，按实际状态列示")
rows, cols = 6, 3
tbl = s.shapes.add_table(rows, cols, Inches(0.55), Inches(1.8), Inches(12.2), Inches(4.1)).table
tbl.columns[0].width = Inches(2.6)
tbl.columns[1].width = Inches(7.0)
tbl.columns[2].width = Inches(2.6)
for j, h in enumerate(["事项", "现状", "当前状态"]):
    set_cell(tbl.cell(0, j), h, bold=True, color=WHITE, fill=DARK)
rows_data = [
    ("30份材料待提交", "待新版资料，客户数据管理员负责确认最新版本", "待客户确认"),
    ("10条样本待核认", "40条样本中30条答案双方确认，10条仍需客户核", "待客户核认"),
    ("通过率未统计", "未给出实际通过率；报告保留题目、依据文件版号、结果及未确认状态", "如实呈现"),
    ("样本覆盖要求", "样本需包含：同名不同版、缺参数应说明、跨文件组合三类", "纳入报告"),
    ("OCR追加费", "扫描件OCR追加费用待商定，不计入已确认合同服务", "待商定"),
]
for i, (a, b, c) in enumerate(rows_data, start=1):
    fill = LIGHT if i % 2 == 1 else WHITE
    set_cell(tbl.cell(i, 0), a, bold=True, fill=fill, align=PP_ALIGN.LEFT)
    set_cell(tbl.cell(i, 1), b, size=12, fill=fill, color=GREY, align=PP_ALIGN.LEFT)
    set_cell(tbl.cell(i, 2), c, size=12, bold=True, color=MID, fill=fill)

txt(s, 0.55, 6.15, 12.2, 0.9,
    "边界重申：未提交资料不计验证失败，也不能假称支持；问答答案不得以训练/演示答案代替；\n未交材料、问答答案与权限确认分别记录为外部依赖。",
    size=13, color=DARK)

# ============ 第5页 计划与责任 ============
s = add_slide()
header(s, "四、下一步计划与责任", "关键决策：验收范围与补件计划由双方负责人确定")
plan = [
    ("9月26日", "客户", "提交30份补件目录"),
    ("9月27日", "供应商", "导出版本与已提交范围结果"),
    ("10月8日", "双方", "验收第一范围（已提交的120份）"),
    ("11月5日", "双方", "培训两场，各90分钟"),
]
y = 1.85
for d, who, what in plan:
    card(s, 0.55, y, 7.6, 0.95, fill=LIGHT)
    txt(s, 0.8, y + 0.22, 1.7, 0.5, d, size=17, bold=True, color=MID)
    txt(s, 2.6, y + 0.12, 0.9, 0.4, who, size=13, bold=True)
    txt(s, 2.6, y + 0.5, 5.4, 0.4, what, size=13, color=GREY)
    y += 1.13
txt(s, 0.55, y + 0.05, 7.6, 0.6,
    "补件何时正式纳入验收，视质量核查结果再确认。",
    size=13, bold=True, color=DARK)

# 右侧责任卡
rc = card(s, 8.55, 1.85, 4.2, 4.6, fill=RGBColor(0xEF, 0xF5, 0xFB), line=MID)
txt(s, 8.85, 2.05, 3.6, 0.5, "责任与决策点", size=17, bold=True, color=DARK)
txt(s, 8.85, 2.6, 3.65, 3.7,
    "· 负责人需决定验收范围与补件计划，而非在会上宣称所有业务均已完成\n· 未交材料、问答答案与权限确认分别记录为依赖项\n· OCR追加费待商定，不计入已确认合同服务\n· 验收结论以书面签字为准",
    size=12.5, color=GREY)

prs.save("/workspace/outputs/客户知识库阶段验收.pptx")
print("PPTX saved")
