# -*- coding: utf-8 -*-
"""生成 客户知识库阶段验收讲稿.docx：约5分钟讲解稿，与PPT页面事实一致。"""
from docx import Document
from docx.shared import Pt, RGBColor, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn

DARK = RGBColor(0x1F, 0x4E, 0x79)
GREY = RGBColor(0x59, 0x59, 0x59)
FONT = "Noto Sans CJK SC"

doc = Document()
style = doc.styles["Normal"]
style.font.name = FONT
style.font.size = Pt(11)
style.element.rPr.rFonts.set(qn("w:eastAsia"), FONT)


def para(text, size=11, bold=False, color=None, align=None, space_after=6, indent=None):
    p = doc.add_paragraph()
    r = p.add_run(text)
    r.font.name = FONT
    r.font.size = Pt(size)
    r.font.bold = bold
    if color:
        r.font.color.rgb = color
    r.element.rPr.rFonts.set(qn("w:eastAsia"), FONT)
    if align:
        p.alignment = align
    p.paragraph_format.space_after = Pt(space_after)
    if indent:
        p.paragraph_format.left_indent = Cm(indent)
    return p


def heading(text):
    para(text, size=14, bold=True, color=DARK, space_after=8)


# 标题
para("客户知识库阶段验收 · 讲稿", size=18, bold=True, color=DARK,
     align=WD_ALIGN_PARAGRAPH.CENTER, space_after=4)
para("（面向客户项目经理，全文约900字，正常语速约5分钟；与演示稿5页一一对应）",
     size=10, color=GREY, align=WD_ALIGN_PARAGRAPH.CENTER, space_after=14)

heading("开场（对应第1页 封面）")
para("各位好，今天向各位项目经理汇报客户知识库项目的阶段验收情况。汇报按现状、问题、计划三部分展开。先说明口径：本次汇报只使用双方已确认的事实，缺失的数据如实标注，未完成的状态不做美化，请各位以这份材料为准进行验收判断。")

heading("第一部分：现状——合同材料与测试样本（对应第2页）")
para("先看合同材料。全部资料共150份：产品手册90份、维修说明40份、流程指南20份。目前已提交120份，对应72、32、16；尚有30份待提交，对应18、8、4。这30份是待新版资料，需要由客户数据管理员确认最新版本后才能提交。")
para("测试样本共40条，其中30条答案已由双方确认，剩余10条仍待客户核认。这里强调两点：第一，40条样本没有给出实际通过率，本次不补\u201c全部PASS\u201d的说法；第二，未提交的资料不能计入测试失败，系统也只基于已提交资料运行，不能假称支持未提供的资料。")

heading("第二部分：现状——已完成工作（对应第3页）")
para("目前已完成四项工作。一是材料目录登记，按文件名、日期、版号和所属产品逐份登记，形成可追溯目录。二是版本去重，已提交的120份完成去重，发现14组同产品的旧新版本，旧版保留为历史，默认检索新版。三是权限分配，按客户产品组分配查询权限。四是运行环境，当前系统在预发布环境运行，10月8日验收范围为已提交的120份。")
para("需要说明的限制是：预发布环境的结论不代表生产验收，最终验收签字尚未取得。")

heading("第三部分：问题与限制（对应第4页）")
para("目前有五项事项处于未关闭状态：")
para("一、30份材料待提交，等待客户数据管理员确认最新版本；二、10条样本待客户核认；三、通过率未统计，验收报告将保留题目、依据文件版号、结果及未确认状态，不能用训练或演示答案代替；四、样本覆盖要求，样本需包含同名不同版、缺参数应说明、跨文件组合三类，已纳入报告；五、扫描件OCR追加费用待商定，不计入已确认的合同服务。", indent=0.5)
para("边界再重申一次：未提交资料不计验证失败，也不能假称支持；未交材料、问答答案与权限确认分别记录为外部依赖。")

heading("第四部分：下一步计划与责任（对应第5页）")
para("时间安排如下：9月26日，客户提交30份补件目录；9月27日，供应商导出版本和已提交范围结果；10月8日，双方对已提交的120份进行第一范围验收；11月5日安排培训两场，每场90分钟。补件何时正式纳入验收，视质量核查结果再确认。")
para("最后是责任与决策点：负责人需要决定的是验收范围和补件计划，而不是在会上宣称所有业务均已完成。验收结论以书面签字为准。")

heading("结束语")
para("以上就是阶段验收的全部内容。请各位重点关注30份补件和10条样本的确认进度，这两项直接决定后续验收节奏。谢谢，下面进入讨论。")

doc.save("/workspace/outputs/客户知识库阶段验收讲稿.docx")
print("DOCX saved")
