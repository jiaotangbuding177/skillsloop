# -*- coding: utf-8 -*-
import json, os
from docx import Document
from docx.shared import Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
import openpyxl
from openpyxl.styles import Font, Alignment, PatternFill
from openpyxl.utils import get_column_letter

os.makedirs('/workspace/outputs', exist_ok=True)

# ---------------- weather_brief.docx ----------------
doc = Document()
style = doc.styles['Normal']
style.font.name = 'Noto Sans CJK SC'
style.font.size = Pt(10.5)

h = doc.add_heading('园区活动天气简报（10月13日）', level=0)

p = doc.add_paragraph()
r = p.add_run('数据性质声明：本简报依据 inputs/weather_messages.json 模拟消息快照编写，来源机构均为模拟，内容不代表现实实时天气预报或真实官方预警。')
r.font.color.rgb = RGBColor(0xB0, 0x00, 0x00)
r.bold = True

# 1. 范围说明
doc.add_heading('一、筛选范围与分类原则', level=1)
doc.add_paragraph('仅纳入与活动当天（10月13日）及活动所在地区（青岸园区）相关的消息；对已失效的预警与邻市（非青岸）情况单独分列，不与当天有效信息混排；未经核实的消息单独标注，不作为决策依据。')

# 2. 当天相关消息
doc.add_heading('二、与活动当天相关的消息（青岸）', level=1)
tbl = doc.add_table(rows=1, cols=4)
tbl.style = 'Table Grid'
hdr = tbl.rows[0].cells
for i, t in enumerate(['编号', '时间', '来源 / 类型', '要点']):
    hdr[i].text = t
rows = [
    ('M01', '10-12 18:00', '青岸气象服务 / 预警', '模拟青岸市10月13日08-18时暴雨橙色预警，低洼区域注意（覆盖活动全天主要时段）。'),
    ('M02', '10-13 07:00', '青岸气象服务 / 更新', '降雨高峰10-14时，预警持续；与10-12时户外设备演示（60人）时段重叠。'),
    ('M04', '10-13 08:10', '园区物业 / 场地观察', '户外草坪有积水；A室80人可用，B室40人可用；低区停车位关闭。'),
    ('M05', '10-13 08:30', '活动承包方 / 建议', '建议将户外设备演示改为室内视频，设备不进室内。'),
]
for a, b, c, d in rows:
    cells = tbl.add_row().cells
    cells[0].text, cells[1].text, cells[2].text, cells[3].text = a, b, c, d

doc.add_paragraph()
p = doc.add_paragraph()
r = p.add_run('另有一条未经核实消息：M06（10-13 09:00，二手群消息）称“活动全部取消”，未经任何官方或园区渠道确认，不得据此决策，需先行核实。')
r.bold = True

# 3. 风险要点
doc.add_heading('三、主要风险要点', level=1)
for t in [
    '10-12时户外设备演示（60人）恰与模拟降雨高峰10-14时重叠，且户外草坪已积水，户外环节不宜照原计划进行。',
    '低区停车位关闭，禁止引导车辆前往；需要另行安排停车引导。',
    '全天总人数上限60人；A室可用80人，可容纳上午演示与下午培训，B室仅40人不满足60人需求。',
]:
    doc.add_paragraph(t, style='List Bullet')

# 4. 失效预警
doc.add_heading('四、失效预警（不作为当天依据）', level=1)
doc.add_paragraph('M07（10-12 09:00，青岸气象服务）：前一天黄色预警已解除。该解除仅针对10月12日的黄色预警，不代表当天（10月13日）橙色预警解除；不可引用为“天气已好转”的依据。')

# 5. 邻市情况
doc.add_heading('五、邻市情况（非青岸，仅供参考）', level=1)
doc.add_paragraph('M03（10-13 07:20，邻市花岭）：花岭10月13日大风预警。花岭非活动所在地区，此消息与青岸园区当天安排无关，不据此调整活动。')

# 6. 需园区确认的动作
doc.add_heading('六、需园区确认的动作', level=1)
acts = doc.add_table(rows=1, cols=3)
acts.style = 'Table Grid'
hdr = acts.rows[0].cells
for i, t in enumerate(['事项', '具体动作', '确认人/方式']):
    hdr[i].text = t
for a, b, c in [
    ('A1 户外改室内', '确认是否采纳承包方建议：10-12时设备演示改为室内视频演示，设备不进室内。', '安全负责人许清审批'),
    ('A2 场地占用', '若上午演示占用A室，确认与14-16时A室培训的衔接、布置转换时间及座位安排。', '许清 + 园区物业'),
    ('A3 停车引导', '确认低区停车位关闭后的替代停车与引导方案，通知中明确禁止前往低区。', '园区物业'),
    ('A4 取消谣言核实', '通过园区官方渠道核实“活动全部取消”传言（M06），确认真实安排后再对外口径统一。', '园区管理方'),
    ('A5 通知发布', '审核调整通知草稿；本题仅准备草稿，不发送。', '园区管理方'),
]:
    cells = acts.add_row().cells
    cells[0].text, cells[1].text, cells[2].text = a, b, c

# 7. 建议调整摘要
doc.add_heading('七、建议的当天安排调整（待批准）', level=1)
doc.add_paragraph('10-12时：设备户外演示60人 → 改为A室室内视频演示（A室80人可用，可容纳60人）。')
doc.add_paragraph('14-16时：室内培训60人维持A室原安排，需确认与上午环节的衔接。')
doc.add_paragraph('全部调整以许清批准为生效前提；批准前维持原计划并做好雨中应急准备。')

doc.save('/workspace/outputs/weather_brief.docx')

# ---------------- event_changes.xlsx ----------------
wb = openpyxl.Workbook()

ws = wb.active
ws.title = '调整建议'
headers = ['编号', '原安排', '建议调整', '依据消息', '影响人数', '审批要求', '状态']
ws.append(headers)
data = [
    ('A1', '10-12时 设备户外演示（60人，户外草坪）', '改为A室室内视频演示；设备不进室内', 'M01、M02、M05', 60, '安全负责人许清批准', '待确认'),
    ('A2', '10-12时 演示场地为户外', '若采用A1，确认A室布置与14-16时培训的场地衔接', 'M04', 60, '许清 + 园区物业', '待确认'),
    ('A3', '车辆引导（原方案含低区停车位）', '禁止引导车辆去低区关闭停车位，改用其他停车区域并在通知中说明', 'M04', '—', '园区物业确认', '待确认'),
    ('A4', '14-16时 室内培训60人（A室）', '维持A室；A室80人可用，满足60人；上午如占用需预留转换时间', 'M04', 60, '许清确认衔接', '待确认'),
    ('A5', '对外信息口径', '核实“活动全部取消”传言（M06，未经核实）；准备调整通知草稿，本题不发送', 'M06', '—', '园区管理方', '待确认'),
]
for row in data:
    ws.append(row)

# styling
hfill = PatternFill('solid', fgColor='DDEBF7')
for c in ws[1]:
    c.font = Font(bold=True)
    c.fill = hfill
    c.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
widths = [6, 34, 44, 14, 10, 18, 10]
for i, w in enumerate(widths, 1):
    ws.column_dimensions[get_column_letter(i)].width = w
for row in ws.iter_rows(min_row=2):
    for c in row:
        c.alignment = Alignment(vertical='top', wrap_text=True)
ws.freeze_panes = 'A2'

ws2 = wb.create_sheet('消息分类')
ws2.append(['编号', '时间', '来源 / 类型', '内容要点', '分类', '处理'])
msg_rows = [
    ('M01', '10-12 18:00', '青岸气象服务 / 预警', '模拟10月13日08-18时暴雨橙色，低洼区域注意', '当天相关（青岸）', '作为当天主要风险依据'),
    ('M02', '10-13 07:00', '青岸气象服务 / 更新', '降雨高峰10-14时，预警持续', '当天相关（青岸）', '与户外演示时段重叠，据此调整'),
    ('M04', '10-13 08:10', '园区物业 / 场地观察', '草坪积水；A室80人、B室40人可用；低区停车位关闭', '当天相关（青岸）', '场地与停车安排依据'),
    ('M05', '10-13 08:30', '活动承包方 / 建议', '户外演示转室内视频，设备不进室内', '当天相关（青岸）', '建议采纳，需许清批准'),
    ('M06', '10-13 09:00', '二手群消息 / 未经核实', '称活动全部取消', '当天相关但未经核实', '仅核实，不作为决策依据'),
    ('M07', '10-12 09:00', '青岸气象服务 / 解除', '前一天黄色预警解除', '失效预警', '不作为当天依据；不代表当天橙色解除'),
    ('M03', '10-13 07:20', '邻市花岭 / 预警', '花岭10月13日大风，非青岸', '邻市情况', '与本次活动无关，不据此调整'),
]
for row in msg_rows:
    ws2.append(row)
for c in ws2[1]:
    c.font = Font(bold=True)
    c.fill = hfill
    c.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
for i, w in enumerate([6, 14, 22, 44, 20, 32], 1):
    ws2.column_dimensions[get_column_letter(i)].width = w
for row in ws2.iter_rows(min_row=2):
    for c in row:
        c.alignment = Alignment(vertical='top', wrap_text=True)
ws2.freeze_panes = 'A2'

wb.save('/workspace/outputs/event_changes.xlsx')
print('saved')
