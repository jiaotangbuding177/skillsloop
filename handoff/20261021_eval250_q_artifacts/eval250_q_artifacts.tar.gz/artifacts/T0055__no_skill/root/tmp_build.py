import csv, io
from decimal import Decimal, ROUND_HALF_UP
from openpyxl import Workbook

rows = list(csv.DictReader(open('/workspace/inputs/roster.csv', encoding='utf-8-sig')))
wb = Workbook()
ws = wb.active
ws.title = '成绩'
ws.append(['学员ID','组','调研','原型','展示','总分','等级'])

notes = []
for r in rows:
    sid, grp = r['学员ID'], r['组']
    res, proto, pres = int(r['调研']), int(r['原型']), r['展示']
    submitted = r['展示已交'] == '是'
    vals = [sid, grp, res, proto]
    if not submitted:
        vals.append('缺失')
        vals.extend([None, None])
        notes.append(f"{sid}（{grp}组）展示未提交，展示成绩按缺失处理，总分留空，不计等级，不推断已有数字有效。")
    else:
        vals.append(int(pres))
        vals.append(f"=ROUND(C{ws.max_row+1}*0.3+D{ws.max_row+1}*0.4+E{ws.max_row+1}*0.3,1)")
        total = Decimal(res*30 + proto*40 + int(pres)*30) / Decimal(100)
        total = total.quantize(Decimal('0.1'), rounding=ROUND_HALF_UP)
        if total >= 90: g='优秀'
        elif total >= 80: g='良好'
        elif total >= 60: g='合格'
        else: g='需补修'
        vals.append(g)
    ws.append(vals)

wb.save('/workspace/outputs/final_grades.xlsx')

from docx import Document
doc = Document()
doc.add_heading('成绩评定说明（grading notes）', level=1)
doc.add_paragraph('依据 inputs/roster.csv 与 inputs/grading_rules.md 评定。权重：调研30%、原型40%、展示30%；总分=ROUND(调研*0.3+原型*0.4+展示*0.3, 1)，四舍五入保留1位小数。等级：≥90优秀，80–89.9良好，60–79.9合格，<60需补修。组别不影响个人评分，表中仅列学员ID，不含姓名。')
doc.add_heading('异常记录', level=1)
for n in notes:
    doc.add_paragraph(n, style='List Bullet')
doc.add_heading('处理原则', level=1)
doc.add_paragraph('S11 展示未提交：不使用名单中残留的展示数字，不补成绩，不记0，总分留空、等级留空，待补交后另行评定。', style='List Bullet')
other = [f"{r['学员ID']}" for r in rows if not (0<=int(r['调研'])<=100 and 0<=int(r['原型'])<=100 and (r['展示已交']=='否' or 0<=int(r['展示'])<=100))]
doc.add_paragraph('其余学员三项成绩均在0–100范围内，无其他异常。' if not other else '其他异常：'+', '.join(other))
doc.save('/workspace/outputs/grading_notes.docx')
print('rows:', ws.max_row)
