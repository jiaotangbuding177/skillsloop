from docx import Document
from docx.shared import RGBColor, Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH

RED = RGBColor(0xC0, 0x00, 0x00)
doc = Document()

def para(text, bold=False, red=False, size=None, align=None):
    p = doc.add_paragraph()
    r = p.add_run(text)
    r.bold = bold
    if red:
        r.font.color.rgb = RED
    if size:
        r.font.size = Pt(size)
    if align:
        p.alignment = align
    return p

# 标题
para('项目服务合同校对修正稿', bold=True, size=16, align=WD_ALIGN_PARAGRAPH.CENTER)
para('稿件状态：待业务与法务确认，所有日期及金额以正文为本次拟签条件，不表示已经履约。', size=9)
para('图例：红字=本次校对修正内容；【核】=需法务核确认后再定稿。校对依据：业务正确事实.md。', size=9, red=True)

# 1
para('1 合同主体与目的', bold=True)
para('甲方为澄川设备公司，乙方为云衡技术公司。双方联系人使用职务称谓，签署人授权待公司确认。本协议仅用于60份设备材料的整理服务，不得扩大为与本项目无关的业务。')

# 2
para('2 范围、版本与材料', bold=True)
para('项目资料以附件清单及双方确认版本为准。双方收到资料后记录文件名称、日期与版号；发现缺失或冲突时书面确认，不能把未知资料当已提供。业务范围或交付要求变更须有双方书面变更单。')

# 3
para('3 费用与结算', bold=True)
p = doc.add_paragraph()
r1 = p.add_run('服务费120000元；首款60000元、尾款60000元；')
r2 = p.add_run('附件费用合计与总价一致，为120000元')
r2.bold = True; r2.font.color.rgb = RED
p.add_run('。金额单位人民币元。付款按正文约定，收款以实际到账为准，发票、验收、付款分别留凭据，不能以单方完成声明替代。')
p2 = doc.add_paragraph()
r = p2.add_run('【核】附件三价格表中总额150000元系误写，附件三正文未随稿附上，签署前需补齐附件并核对总额为120000元（首尾各60000元）。')
r.font.color.rgb = RED

# 4
para('4 周期与协作', bold=True)
p = doc.add_paragraph()
r1 = p.add_run('自材料齐备起6周')
r1.bold = True; r1.font.color.rgb = RED
p.add_run('。双方各指定一名项目负责人，书面通知渠道为企业工作邮箱；私人联系方式不写入本稿。每次会议记录明确决定、未决事项和责任期限。')
p2 = doc.add_paragraph()
r = p2.add_run('（原稿正文另写8周与业务事实不符，已统一为6周；附件二时间安排6周与此一致。）')
r.font.color.rgb = RED; r.font.size = Pt(9)

# 5
para('5 交付', bold=True)
para('5.1交付材料目录、DOCX说明、PDF报告；5.2交付物编号为A01-A03。')
p = doc.add_paragraph()
r1 = p.add_run('5.3')
r2 = p.add_run('验收按交付及双方确认验收附件办理')
r2.bold = True; r2.font.color.rgb = RED
p.add_run('。')
p2 = doc.add_paragraph()
r = p2.add_run('（原稿引用“第14条”，本合同不存在第14条；按业务事实改为指向交付及双方确认验收附件，不增设第14条，不在本次校对中新增赔偿责任条款。）')
r.font.color.rgb = RED; r.font.size = Pt(9)

# 6
para('6 付款', bold=True)
p = doc.add_paragraph()
p.add_run('6.1验收通过后支付尾款；6.2')
r = p.add_run('乙方在收到甲方付款后交付')
r.bold = True; r.font.color.rgb = RED
p.add_run('。')
p2 = doc.add_paragraph()
r = p2.add_run('（原稿6.2写为“甲方收到乙方付款后交付”，付款主体颠倒；按业务事实更正为甲方付款、乙方交付。）')
r.font.color.rgb = RED; r.font.size = Pt(9)

# 7
para('7 保密', bold=True)
p = doc.add_paragraph()
p.add_run('甲乙双方保密，')
r = p.add_run('保密义务主体仅为甲方与乙方，本合同没有丙方，保密条款中“丙方”均更正为“乙方”')
r.bold = True; r.font.color.rgb = RED
p.add_run('。')
p2 = doc.add_paragraph()
r = p2.add_run('【核】原稿保密条款第三段误将乙方写成丙方，该段原文未随稿附上，无法定位具体文字；修正规则已按业务事实写入，具体段落待法务核对原稿后确认。')
r.font.color.rgb = RED

# 8
para('8 违约', bold=True)
para('按双方最终法务条款，不在本次校对调整责任。')

# 9
para('9 附件', bold=True)
p = doc.add_paragraph()
p.add_run('附件一为60份目录，附件二时间安排6周，附件三价格写首尾各60000、')
r = p.add_run('总额120000')
r.bold = True; r.font.color.rgb = RED
p.add_run('。')
p2 = doc.add_paragraph()
r = p2.add_run('【核】附件一、二、三正文均未随本稿附上，属缺失附件；签署前需补齐全部附件并核对：附件一为60份目录、附件二为6周时间安排、附件三总额为120000元。')
r.font.color.rgb = RED

# 10
para('10 资料与既有知识产权', bold=True)
para('双方各自已有资料、软件和技术归原权利人。资料提供仅授权为本项目使用，未经授权不得向无关第三方披露。联合成果归属以专章约定，不因付款自动转让所有既有权利。')

# 11
para('11 通知、争议与文本', bold=True)
para('书面通知由项目负责人保存，涉及价款、范围和责任变更须由授权人确认。争议先由双方管理层协调；未解决时按双方最终确认的争议条款办理。附件与正文冲突以双方书面确认文件为准，不自动把较晚文件认作已获双方同意。')

# 12
para('12 生效与签署', bold=True)
para('本稿需双方法定代表人或授权代表签署后生效；本次文稿中的空白签署位只用于待签安排，不表示已经签署。合同正文、业务条件、附件和版本记录应当一并保存。')
para('甲方授权代表：______  日期：______')
para('乙方授权代表：______  日期：______')

# 校对记录
para('附：本次校对修正记录（依据：业务正确事实.md）', bold=True)
records = [
    '修正1（第3条/附件三）：金额合计150000元更正为120000元；总价120000元，首尾各60000元。',
    '修正2（第4条）：周期正文8周更正为6周，自材料齐备起6周。',
    '修正3（第5.3条）：删除对不存在“第14条”的引用，改为按交付及双方确认验收附件验收；未增设第14条，未新增赔偿责任。',
    '修正4（第6.2条）：付款主体颠倒更正为甲方付款、乙方交付。',
    '修正5（第7条）：保密条款“丙方”更正为“乙方”；本合同仅甲乙两方。误写段落原文未随稿附上，待法务核。',
    '保留说明：第8条违约条款按双方最终法务条款保留原文，本次未改动；未为补不存在条款新增重大权利。',
    '待法务核清单：①保密条款误写“丙方”第三段原文定位；②附件一、二、三正文补齐及金额、周期核对。',
]
for t in records:
    para(t, size=9)

doc.save('/workspace/outputs/合同校对修正.docx')
print('docx saved')

# 错误定位.xlsx
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, PatternFill

wb = Workbook()
ws = wb.active
ws.title = '错误定位'
headers = ['序号', '位置', '错误类型', '原稿表述', '正确内容（依据：业务正确事实.md）', '处理方式', '状态']
rows = [
    [1, '第3条 费用与结算 / 附件三', '金额合计错误', '附件费用合计150000元；附件三总额150000元', '总价120000元，首尾各60000元，附件费用合计与总价一致为120000元', '正文已按120000元表述并标注修正；附件三正文未随稿附上，更正值已注明', '已修正（附件待法务核）'],
    [2, '第4条 周期与协作', '周期错误', '正文另写8周', '自材料齐备起6周（附件二时间安排6周一致）', '删除8周表述，统一为6周', '已修正'],
    [3, '第5.3条 交付-验收', '不存在条款引用', '验收按第14条，但本合同没有第14条', '验收按交付及双方确认验收附件办理', '删除第14条引用，改为指向交付及双方确认验收附件；不增设第14条、不新增赔偿责任', '已修正'],
    [4, '第6.2条 付款', '付款主体颠倒', '甲方收到乙方付款后交付', '甲方付款、乙方交付（乙方在收到甲方付款后交付）', '更正付款方向，6.1尾款支付安排不变', '已修正'],
    [5, '第7条 保密', '错误方名', '第三段将乙方误写成丙方', '本合同仅甲乙两方，应为乙方', '修正规则已写入（“丙方”均更正为“乙方”）；误写段原文未随稿附上，无法定位具体文字', '待法务核'],
    [6, '第9条 附件', '缺失附件', '附件一、二、三正文未随稿附上', '附件一为60份目录，附件二为6周时间安排，附件三总价120000元（首尾各60000元）', '列为签署前置条件：补齐全部附件并逐项核对', '待补齐/待法务核'],
    [7, '第8条 违约', '未授权修改项', '按双方最终法务条款，不在本次校对调整责任', '同左（保留原文）', '未授权法务原文，本次不改动；未新增重大权利条款', '保留原文'],
]
for c, h in enumerate(headers, 1):
    cell = ws.cell(row=1, column=c, value=h)
    cell.font = Font(bold=True, color='FFFFFF')
    cell.fill = PatternFill('solid', fgColor='4472C4')
    cell.alignment = Alignment(horizontal='center', vertical='center')
for r, row in enumerate(rows, 2):
    for c, v in enumerate(row, 1):
        cell = ws.cell(row=r, column=c, value=v)
        cell.alignment = Alignment(wrap_text=True, vertical='top')
        if row[-1].startswith('待'):
            cell.fill = PatternFill('solid', fgColor='FFF2CC')
widths = [6, 22, 14, 30, 38, 38, 18]
for i, w in enumerate(widths, 1):
    ws.column_dimensions[chr(64+i)].width = w
ws.freeze_panes = 'A2'
wb.save('/workspace/outputs/错误定位.xlsx')
print('xlsx saved')
