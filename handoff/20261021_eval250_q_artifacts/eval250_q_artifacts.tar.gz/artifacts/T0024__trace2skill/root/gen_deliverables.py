# -*- coding: utf-8 -*-
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
from openpyxl.utils import get_column_letter
from docx import Document
from docx.shared import Pt, RGBColor
import os

os.makedirs('/workspace/outputs', exist_ok=True)

GUARD = "口径：不承诺实时生产数据接入（仅50份脱敏故障单离线使用）；不承诺任何折扣（正式价8万元/站点，无折扣权限）"

# ============ 1. account_plan.xlsx ============
wb = Workbook()
ws = wb.active
ws.title = "30天推进计划"

headers = ["序号", "决策角色", "已知需求/顾虑", "接触状态", "下一步行动", "负责人", "截止日期", "口径与边界"]
rows = [
    [1, "信息经理", "内网检索；日志权限", "10月6日安排联调",
     "10月5日前完成50份脱敏故障单的权限核验；10月6日按计划联调，验证离线检索与历史故障复用效果（不含实时生产数据接入）",
     "售前王工", "2026-10-05", "仅使用客户已授权的50份脱敏故障单，实时接入需另行授权"],
    [2, "车间主管", "历史故障复用；顾虑操作麻烦", "愿意2周试用",
     "启动2周离线免费试点（14天），简化操作流程演示，每周收集使用反馈",
     "售前王工", "2026-10-10", "试点免费14天；范围仅限脱敏数据，不接入生产系统"],
    [3, "运营总监", "设备停机缩短；顾虑投资回报", "9月25日已访",
     "回访汇报试点方案与投资回报测算（停机缩短收益 vs 8万元/站点正式价），约定试点中期复盘",
     "销售李宁", "2026-10-12", "报价口径：8万元/站点，无折扣权限，不做降价承诺"],
    [4, "安全经理", "无自动设备控制；顾虑数据导出", "需审查",
     "提交安全审查材料：数据脱敏方案、导出边界说明、无自动设备控制声明，配合审查排期",
     "售前王工", "2026-10-16", "数据导出仅限已授权脱敏数据，未经审查不扩大范围"],
    [5, "财务经理", "费用分摊；顾虑预算冻结", "尚未交流",
     "首次拜访：介绍费用分摊方式与正式报价（8万元/站点），说明客户预算11月释放、签约窗口在11月",
     "销售李宁", "2026-10-20", "仅传达价格与预算节奏，不承诺折扣或分期优惠"],
    [6, "采购", "合同流程；两家比价", "需技术方案",
     "提交比价用技术方案（功能清单、试点结果、报价单），走客户合同流程",
     "销售李宁", "2026-10-23", "技术方案与报价单一并提交，价格统一8万元/站点"],
    [7, "车间主管+运营总监", "试点效果确认", "试点进行中",
     "试点中期复盘：演示离线检索效果，确认是否延长试点或进入商务阶段",
     "销售李宁", "2026-10-24", "以脱敏数据试点结果为依据，不预设续约承诺"],
    [8, "全体干系人", "汇总推进", "—",
     "30天总结：汇总试点结论与各方反馈，形成11月预算释放后的签约推进建议（含合同流程时间表）",
     "销售李宁", "2026-10-30", "签约动作安排在11月预算释放后，30天内不签署承诺"],
]

ws.append(headers)
for r in rows:
    ws.append(r)
ws.append([])
ws.append(["统一口径", GUARD])

# 里程碑 sheet
ws2 = wb.create_sheet("关键里程碑")
ws2.append(["日期", "里程碑", "负责人"])
miles = [
    ["2026-10-05", "信息经理完成权限核验（50份脱敏故障单）", "售前王工"],
    ["2026-10-06", "按客户安排完成联调", "售前王工"],
    ["2026-10-10", "2周离线试点启动", "售前王工"],
    ["2026-10-16", "安全审查材料提交", "售前王工"],
    ["2026-10-20", "财务经理首次交流完成", "销售李宁"],
    ["2026-10-23", "比价技术方案提交采购", "销售李宁"],
    ["2026-10-24", "试点中期复盘", "销售李宁"],
    ["2026-10-30", "30天总结与11月签约推进建议", "销售李宁"],
]
for m in miles:
    ws2.append(m)

thin = Side(style='thin', color='BFBFBF')
border = Border(left=thin, right=thin, top=thin, bottom=thin)
hfill = PatternFill('solid', fgColor='2F5597')
for sheet, widths in ((ws, [6, 16, 20, 16, 46, 10, 12, 40]), (ws2, [14, 44, 12])):
    for i, w in enumerate(widths, 1):
        sheet.column_dimensions[get_column_letter(i)].width = w
    for cell in sheet[1]:
        cell.font = Font(bold=True, color='FFFFFF', size=11)
        cell.fill = hfill
        cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
        cell.border = border
    for row in sheet.iter_rows(min_row=2):
        for cell in row:
            cell.alignment = Alignment(vertical='top', wrap_text=True)
            cell.border = border
            if cell.font.size is None or not cell.font.bold:
                cell.font = Font(size=10)
    sheet.freeze_panes = 'A2'
ws.merge_cells('A10:H10')
ws['A10'].font = Font(size=10, italic=True, color='C00000')
ws['A10'].alignment = Alignment(wrap_text=True, vertical='center')
ws.row_dimensions[10].height = 30

wb.save('/workspace/outputs/account_plan.xlsx')

# ============ 2. agenda.docx ============
doc = Document()
style = doc.styles['Normal']
style.font.name = 'Noto Sans CJK SC'
style.font.size = Pt(11)

doc.add_heading('客户推进会议议程', level=0)
sub = doc.add_paragraph()
sub.add_run('时间：2026年10月9日 14:00–15:30　|　地点：客户会议室（或线上）　|　主持：销售李宁').font.size = Pt(10)

doc.add_heading('一、参会人', level=1)
doc.add_paragraph('客户方：运营总监、信息经理、财务经理、车间主管、安全经理、采购')
doc.add_paragraph('我方：销售李宁、售前王工')

doc.add_heading('二、议程安排', level=1)
table = doc.add_table(rows=1, cols=4)
table.style = 'Light Grid Accent 1'
hdr = table.rows[0].cells
for i, h in enumerate(['时间', '议题', '主讲', '说明']):
    hdr[i].text = h
    for p in hdr[i].paragraphs:
        for r in p.runs:
            r.font.bold = True
            r.font.size = Pt(10.5)
items = [
    ('14:00–14:05', '开场与背景回顾', '销售李宁', '9月25日拜访以来的进展回顾'),
    ('14:05–14:25', '离线试点方案说明', '售前王工', '试点范围：仅限客户已授权的50份脱敏故障单，14天免费；不含实时生产数据接入（该事项需客户另行授权，本次不作为承诺）'),
    ('14:25–14:35', '车间试用流程与操作演示', '售前王工', '回应车间主管“操作麻烦”顾虑，简化流程演示'),
    ('14:35–14:45', '安全与数据导出说明', '售前王工', '脱敏方案、导出边界、无自动设备控制声明；提请安全经理安排审查时间'),
    ('14:45–14:55', '商务信息说明', '销售李宁', '正式价8万元/站点（无折扣权限）；客户预算11月释放，签约安排在11月'),
    ('14:55–15:10', '待决策事项讨论', '全体', '① 试点启动时间确认　② 安全审查排期　③ 比价技术方案提交要求'),
    ('15:10–15:30', '下一步行动与截止日期确认', '销售李宁', '按30天推进计划逐项确认责任人与时间'),
]
for row in items:
    cells = table.add_row().cells
    for i, v in enumerate(row):
        cells[i].text = v
        for p in cells[i].paragraphs:
            for r in p.runs:
                r.font.size = Pt(10)

doc.add_heading('三、会议口径边界（重要）', level=1)
for line in [
    '数据接入：客户仅授权50份脱敏故障单用于离线试点，未允许实时接入生产数据；会议中不将实时数据接入表述为已承诺内容。',
    '价格：正式价8万元/站点，我方无折扣权限；不向客户承诺任何折扣或降价。',
    '试点：免费14天，离线运行；试点结果作为11月预算释放后商务推进的依据。',
]:
    doc.add_paragraph(line, style='List Bullet')

doc.add_heading('四、会前准备', level=1)
for line in [
    '王工：10月5日前完成权限核验，10月6日联调结果摘要（会议输入）。',
    '李宁：投资回报测算初稿、报价说明页（8万元/站点，无折扣表述）。',
    '李宁：会前与运营总监确认参会名单与会议室。',
]:
    doc.add_paragraph(line, style='List Bullet')

note = doc.add_paragraph()
note.add_run('附注：' + GUARD).font.size = Pt(9)
note.runs[0].font.color.rgb = RGBColor(0xC0, 0x00, 0x00)

doc.save('/workspace/outputs/agenda.docx')
print('done')
