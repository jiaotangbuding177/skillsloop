# -*- coding: utf-8 -*-
"""社保基数调整：测算计算 + 生成 xlsx 与 docx"""
import csv, os
from decimal import Decimal, ROUND_HALF_UP

OUT = "/workspace/outputs"
os.makedirs(OUT, exist_ok=True)

people = []
with open("/workspace/inputs/人员基数明细.csv", encoding="utf-8-sig") as f:
    for row in csv.DictReader(f):
        people.append({
            "id": row["员工编号"].strip(),
            "name": row["称谓"].strip(),
            "avg": int(row["上年度月均工资元"]),
            "old_base": int(row["原缴费基数元"]),
            "status": row["状态"].strip(),
        })

LOWER, UPPER = 6200, 31000
PERSONAL = [("养老保险", "0.08"), ("医疗保险", "0.02"), ("失业保险", "0.005")]
UNIT = [("养老保险", "0.16"), ("医疗保险", "0.09"), ("失业保险", "0.005"), ("工伤保险", "0.004")]

def new_base(avg):
    b = avg
    if b < LOWER: b = LOWER
    elif b > UPPER: b = UPPER
    return b

def amt(base, rate):
    return float((Decimal(str(base)) * Decimal(rate)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))

def calc(base):
    p = {n: amt(base, r) for n, r in PERSONAL}
    u = {n: amt(base, r) for n, r in UNIT}
    p["个人合计"] = round(sum(p.values()), 2)
    u["单位合计"] = round(sum(u.values()), 2)
    return p, u

active, resigned = [], []
for pe in people:
    pe["nb"] = new_base(pe["avg"])
    if pe["avg"] < LOWER:
        pe["limit_note"] = "低于下限6200，按下限6200执行"
    elif pe["avg"] > UPPER:
        pe["limit_note"] = "高于上限31000，按上限31000执行"
    else:
        pe["limit_note"] = "实际月均工资（在上下限内）"
    pe["oldp"], pe["oldu"] = calc(pe["old_base"])
    if pe["status"] == "在岗":
        active.append(pe)
        pe["newp"], pe["newu"] = calc(pe["nb"])
        pe["d_person"] = round(pe["newp"]["个人合计"] - pe["oldp"]["个人合计"], 2)
        pe["d_unit"] = round(pe["newu"]["单位合计"] - pe["oldu"]["单位合计"], 2)
        pe["d_total"] = round(pe["d_person"] + pe["d_unit"], 2)
    else:
        resigned.append(pe)

def tot(items, fn):
    return round(sum(fn(i) for i in items), 2)

sums = {
    "old_person": tot(active, lambda i: i["oldp"]["个人合计"]),
    "old_unit": tot(active, lambda i: i["oldu"]["单位合计"]),
    "new_person": tot(active, lambda i: i["newp"]["个人合计"]),
    "new_unit": tot(active, lambda i: i["newu"]["单位合计"]),
}
sums["d_person"] = round(sums["new_person"] - sums["old_person"], 2)
sums["d_unit"] = round(sums["new_unit"] - sums["old_unit"], 2)
sums["old_total"] = round(sums["old_person"] + sums["old_unit"], 2)
sums["new_total"] = round(sums["new_person"] + sums["new_unit"], 2)
sums["d_total"] = round(sums["new_total"] - sums["old_total"], 2)

# ---------- xlsx ----------
import openpyxl
from openpyxl.styles import Font, Alignment, Border, Side, PatternFill
from openpyxl.utils import get_column_letter

wb = openpyxl.Workbook()
thin = Side(style="thin", color="000000")
border = Border(left=thin, right=thin, top=thin, bottom=thin)
hdr_font = Font(name="宋体", size=10, bold=True)
body_font = Font(name="宋体", size=10)
hdr_fill = PatternFill("solid", fgColor="D9E2F3")
center = Alignment(horizontal="center", vertical="center", wrap_text=True)

ws = wb.active
ws.title = "在岗人员测算明细"
headers = ["员工编号", "称谓", "在岗状态", "上年度月均工资(元)", "原缴费基数(元)", "调整后基数(元)", "基数上下限适用情况",
           "个人-养老(8%)", "个人-医疗(2%)", "个人-失业(0.5%)", "个人合计(原)", "个人合计(新)", "个人差额",
           "单位-养老(16%)", "单位-医疗(9%)", "单位-失业(0.5%)", "单位-工伤(0.4%)", "单位合计(原)", "单位合计(新)", "单位差额", "合计差额"]
ws.append(headers)
for pe in active:
    ws.append([pe["id"], pe["name"], pe["status"], pe["avg"], pe["old_base"], pe["nb"], pe["limit_note"],
               pe["newp"]["养老保险"], pe["newp"]["医疗保险"], pe["newp"]["失业保险"],
               pe["oldp"]["个人合计"], pe["newp"]["个人合计"], pe["d_person"],
               pe["newu"]["养老保险"], pe["newu"]["医疗保险"], pe["newu"]["失业保险"], pe["newu"]["工伤保险"],
               pe["oldu"]["单位合计"], pe["newu"]["单位合计"], pe["d_unit"], pe["d_total"]])
ws.append(["合计", f"{len(active)}名在岗", "", "", "", "", "",
           None, None, None, sums["old_person"], sums["new_person"], sums["d_person"],
           None, None, None, None, sums["old_unit"], sums["new_unit"], sums["d_unit"], sums["d_total"]])
for row in ws.iter_rows(min_row=1, max_row=ws.max_row, max_col=len(headers)):
    for c in row:
        c.border = border
        c.font = hdr_font if c.row == 1 else body_font
        c.alignment = center if c.row == 1 else Alignment(vertical="center", wrap_text=True)
for c in ws[ws.max_row]:
    c.font = Font(name="宋体", size=10, bold=True)
    c.fill = hdr_fill
for i in range(1, len(headers) + 1):
    col = get_column_letter(i)
    w = 13 if i <= 6 else (24 if i == 7 else 12)
    ws.column_dimensions[col].width = w
ws.freeze_panes = "A2"

ws2 = wb.create_sheet("离职人员单列")
ws2.append(["员工编号", "称谓", "在岗状态", "上年度月均工资(元)", "原缴费基数(元)", "处理方式"])
for pe in resigned:
    ws2.append([pe["id"], pe["name"], pe["status"], pe["avg"], pe["old_base"], "已离职，不纳入本次基数调整，不参与测算"])
ws2.append(["合计", f"{len(resigned)}名离职", "", "", "", "不纳入调整，不计入费用变化"])
for row in ws2.iter_rows(min_row=1, max_row=ws2.max_row, max_col=6):
    for c in row:
        c.border = border
        c.font = hdr_font if c.row == 1 else body_font
        c.alignment = center if c.row == 1 else Alignment(vertical="center", wrap_text=True)
for c in ws2[ws2.max_row]:
    c.font = Font(name="宋体", size=10, bold=True)
    c.fill = hdr_fill
for i, w in enumerate([13, 13, 11, 18, 16, 40], 1):
    ws2.column_dimensions[get_column_letter(i)].width = w

ws3 = wb.create_sheet("调整前后汇总")
rows3 = [
    ["项目", "调整前(元/月)", "调整后(元/月)", "差额(元/月)"],
    ["参调人数（人）", len(active), len(active), ""],
    ["个人缴费合计", sums["old_person"], sums["new_person"], sums["d_person"]],
    ["单位缴费合计", sums["old_unit"], sums["new_unit"], sums["d_unit"]],
    ["缴费总额", sums["old_total"], sums["new_total"], sums["d_total"]],
    ["离职人员（不参与）", len(resigned), "—", "—"],
]
for r in rows3:
    ws3.append(r)
for row in ws3.iter_rows(min_row=1, max_row=ws3.max_row, max_col=4):
    for c in row:
        c.border = border
        c.font = hdr_font if c.row == 1 else body_font
        c.alignment = center if c.row == 1 else Alignment(horizontal="center", vertical="center")
for i, w in enumerate([22, 16, 16, 16], 1):
    ws3.column_dimensions[get_column_letter(i)].width = w

xlsx_path = os.path.join(OUT, "社保调整测算.xlsx")
for sheet in (ws, ws2, ws3):
    sheet.page_setup.orientation = "landscape"
    sheet.page_setup.fitToWidth = 1
    sheet.page_setup.fitToHeight = 0
    from openpyxl.worksheet.properties import PageSetupProperties
    sheet.sheet_properties.pageSetUpPr = PageSetupProperties(fitToPage=True)
wb.save(xlsx_path)

# ---------- docx ----------
from docx import Document
from docx.shared import Pt, Cm
from docx.enum.text import WD_LINE_SPACING
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn

doc = Document()

def set_font(run, name, size, bold=False):
    run.font.name = "Times New Roman"
    run.font.size = Pt(size)
    run.font.bold = bold
    run._element.rPr.rFonts.set(qn("w:eastAsia"), name)

def add_title(text):
    p = doc.add_paragraph()
    p.alignment = 1
    set_font(p.add_run(text), "黑体", 16, True)
    return p

def add_heading(text):
    p = doc.add_paragraph()
    set_font(p.add_run(text), "黑体", 16, True)
    p.paragraph_format.space_before = Pt(12)
    p.paragraph_format.space_after = Pt(6)
    return p

def add_body(text):
    p = doc.add_paragraph()
    set_font(p.add_run(text), "宋体", 12)
    pf = p.paragraph_format
    pf.line_spacing_rule = WD_LINE_SPACING.ONE_POINT_FIVE
    pf.first_line_indent = Pt(24)
    return p

def add_table(headers, rows, widths=None):
    t = doc.add_table(rows=1 + len(rows), cols=len(headers))
    t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    for j, h in enumerate(headers):
        cell = t.rows[0].cells[j]
        cell.paragraphs[0].alignment = 1
        set_font(cell.paragraphs[0].add_run(h), "黑体", 10.5, True)
    for i, row in enumerate(rows, 1):
        for j, v in enumerate(row):
            cell = t.rows[i].cells[j]
            cell.paragraphs[0].alignment = 1 if j else 0
            set_font(cell.paragraphs[0].add_run(str(v)), "宋体", 10.5)
    if widths:
        for j, w in enumerate(widths):
            for row in t.rows:
                row.cells[j].width = Cm(w)
    return t

fmt2 = lambda v: f"{v:,.2f}"

add_title("公司2026年10月社保基数调整汇报")
add_body("依据《公司2026年10月社保基数调整实施通知》及人员基数明细，现将本次社保基数调整的口径、责任流程、人数与费用变化及逐人测算情况汇报如下。数字均按公司给定口径计算，不涉及地方政策判断。")

add_heading("一、调整口径")
add_table(["项目", "口径内容"], [
    ["适用范围", "员工明细中的在岗人员，2026年10月起执行；离职人员单列，不纳入本次调整"],
    ["基数基础", "上年度月平均工资"],
    ["基数上下限", "低于6200元按6200元，高于31000元按31000元，其余按实际月平均工资"],
    ["保留精度", "基数统一保留整数元；每人每险种费用先计算并四舍五入到分，再按个人/单位合计"],
    ["个人费率", "养老8%、医疗2%、失业0.5%"],
    ["单位费率", "养老16%、医疗9%、失业0.5%、工伤0.4%"],
    ["不含事项", "不含住房公积金；不计算补缴；不按工资当月变化自动变更基数"],
], widths=[3.2, 12.3])

add_heading("二、责任流程")
add_table(["步骤", "责任方", "工作内容"], [
    ["1", "HR", "核对上年度工资和在岗状态"],
    ["2", "薪酬专员", "出具测算表"],
    ["3", "财务", "复核测算结果"],
    ["4", "负责人", "审批后再录入"],
], widths=[1.5, 3.5, 10.5])
add_body("本次仅整理报告与测算，不实际申报。")

add_heading("三、人数与费用变化")
add_table(["项目", "调整前（元/月）", "调整后（元/月）", "差额（元/月）"], [
    ["参调在岗人数（人）", f"{len(active)}", f"{len(active)}", "—"],
    ["个人缴费合计", fmt2(sums["old_person"]), fmt2(sums["new_person"]), fmt2(sums["d_person"])],
    ["单位缴费合计", fmt2(sums["old_unit"]), fmt2(sums["new_unit"]), fmt2(sums["d_unit"])],
    ["缴费总额", fmt2(sums["old_total"]), fmt2(sums["new_total"]), fmt2(sums["d_total"])],
    ["离职人员（不参与）", f"{len(resigned)}", "—", "—"],
], widths=[4.5, 3.7, 3.7, 3.6])
add_body(f"以上财务总额均与附件人员测算表合计一致：调整后个人合计{fmt2(sums['new_person'])}元、单位合计{fmt2(sums['new_unit'])}元、缴费总额{fmt2(sums['new_total'])}元/月，较调整前每月增加{fmt2(sums['d_total'])}元。")

add_heading("四、附件说明")
resig_str = "、".join(pe["id"] + " " + pe["name"] for pe in resigned)
add_body("附件《社保调整测算.xlsx》逐人列示在岗状态、基数上下限适用情况、个人及单位各险种计算金额、调整前后个人/单位合计与差额；离职人员（" + resig_str + "）单列于“离职人员单列”工作表，不纳入调整与费用变化。")

docx_path = os.path.join(OUT, "社保调整汇报.docx")
doc.save(docx_path)

print("active", len(active), "resigned", len(resigned))
print(sums)
print("saved:", xlsx_path, docx_path)
