# -*- coding: utf-8 -*-
import pandas as pd
import numpy as np
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
from openpyxl.utils import get_column_letter
from docx import Document
from docx.shared import Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn

DIMS = ['AI认知', 'AI应用', 'AI教学', 'AI评估', 'AI伦理', 'AI发展']
ACTIONS = {'AI认知': '任务拆解训练', 'AI应用': '文件实训', 'AI教学': '情景演示',
           'AI评估': '验收清单', 'AI伦理': '权限案例', 'AI发展': '每月复盘'}

df = pd.read_csv('/workspace/inputs/survey.csv')
for c in DIMS:
    df[c] = pd.to_numeric(df[c], errors='coerce')

def score(vals):
    v = vals.dropna()
    if len(v) == 0:
        return np.nan, 0
    return round((v.mean() - 1) / 4 * 100, 1), len(v)

overall = {}
for c in DIMS:
    s, n = score(df[c])
    overall[c] = {'均分(1-5)': f"{df[c].mean():.2f}", '维度分(0-100)': s, '有效样本': n, '缺失数': int(df[c].isna().sum())}
ov_df = pd.DataFrame(overall).T.reset_index().rename(columns={'index': '维度'})

rows = []
for dept, g in df.groupby('部门'):
    row = {'部门': dept, '部门样本数': len(g)}
    for c in DIMS:
        s, n = score(g[c])
        row[c + '_分'] = s
        row[c + '_n'] = n
        row[c + '_可比'] = '是' if n >= 5 else '否(n<5)'
    rows.append(row)
dept_df = pd.DataFrame(rows).sort_values('部门').reset_index(drop=True)

rank = ov_df.sort_values('维度分(0-100)').reset_index(drop=True)

wb = pd.ExcelWriter('/workspace/outputs/survey_analysis.xlsx', engine='openpyxl')
df.to_excel(wb, sheet_name='原始数据', index=False)
ov_df.to_excel(wb, sheet_name='总体维度分', index=False)
dept_df.to_excel(wb, sheet_name='部门差异', index=False)
meta = pd.DataFrame({
    '项目': ['计分口径', '缺失处理', '部门比较门槛', '样本量', '抽样方式', '用途声明'],
    '说明': [
        '各题1-5分，高分=自评较熟练；维度分=(均分-1)/4*100，映射到0-100',
        '缺失按维度剔除该条记录后计算，不填0；本次缺失：T08-AI教学、T19-AI伦理，各维有效样本见对应表',
        '某部门某维度有效样本少于5时不参与部门比较（表中标注为否）',
        '48份（T01-T48）',
        '内部便捷抽样，非随机抽样，结果不代表全体员工',
        '分数仅为培训需求自评参考，不构成能力认证'
    ]
})
meta.to_excel(wb, sheet_name='口径与局限', index=False)
wb.close()

from openpyxl import load_workbook
wb2 = load_workbook('/workspace/outputs/survey_analysis.xlsx')
header_fill = PatternFill('solid', fgColor='2F5496')
header_font = Font(color='FFFFFF', bold=True)
thin = Border(*[Side(style='thin', color='BFBFBF')]*4)
for ws in wb2.worksheets:
    ws.freeze_panes = 'A2'
    for cell in ws[1]:
        cell.fill = header_fill; cell.font = header_font
        cell.alignment = Alignment(horizontal='center', vertical='center')
    for col in ws.columns:
        letter = get_column_letter(col[0].column)
        maxlen = max(len(str(c.value)) if c.value is not None else 0 for c in col)
        cjk = sum(1 for c in col if c.value and any(ord(ch) > 127 for ch in str(c.value)))
        ws.column_dimensions[letter].width = min(max(maxlen + cjk * 0.8 + 2, 8), 40)
    for row in ws.iter_rows(min_row=2):
        for cell in row:
            cell.border = thin
wb2.save('/workspace/outputs/survey_analysis.xlsx')

doc = Document()
style = doc.styles['Normal']
style.font.name = 'Noto Sans CJK SC'
style.font.size = Pt(11)
style.element.rPr.rFonts.set(qn('w:eastAsia'), 'Noto Sans CJK SC')

def set_cjk(p):
    for r in p.runs:
        r.font.name = 'Noto Sans CJK SC'
        r.element.rPr.rFonts.set(qn('w:eastAsia'), 'Noto Sans CJK SC')
    return p

def h(text, level=1):
    return set_cjk(doc.add_heading(text, level=level))

def para(text, bold=False):
    p = doc.add_paragraph()
    r = p.add_run(text); r.bold = bold
    return set_cjk(p)

def add_table(header, data):
    t = doc.add_table(rows=1, cols=len(header))
    t.style = 'Table Grid'; t.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i, x in enumerate(header):
        c = t.rows[0].cells[i]; c.text = ''
        c.paragraphs[0].add_run(str(x)).bold = True
    for row in data:
        cells = t.add_row().cells
        for i, x in enumerate(row):
            cells[i].text = str(x)
    for row in t.rows:
        for cell in row.cells:
            for p in cell.paragraphs:
                set_cjk(p)
    return t

title = set_cjk(doc.add_heading('员工AI能力自评问卷调查分析报告', level=0))
p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
p.add_run('面向培训组织方 · 2026年10月15日')
set_cjk(p)

h('一、调查概况', 1)
para('本次调查共回收问卷48份（T01–T48），覆盖研发、销售、交付、管理4个部门（各12人）。问卷含AI认知、AI应用、AI教学（本题指对同事的知识传授）、AI评估、AI伦理、AI发展共6个维度，每题1–5分自评，高分表示自评较熟练。')
para('计分口径：维度分=(均分-1)/4×100，映射到0–100分。')
para('缺失处理：缺失值按维度剔除该条记录后计算，不填0。本次共2处缺失：T08的AI教学题、T19的AI伦理题；受影响维度的有效样本相应减1，其余维度有效样本为48。')
para('部门差异口径：某部门某维度有效样本少于5时不参与部门比较。本次各部门每维度有效样本均为12（缺失项所在维度为11），全部满足比较门槛。')

h('二、总体维度得分', 1)
data = [[r['维度'], r['均分(1-5)'], r['维度分(0-100)'], r['有效样本'], r['缺失数']] for _, r in ov_df.iterrows()]
data.sort(key=lambda x: x[2])
add_table(['维度', '均分(1-5)', '维度分(0-100)', '有效样本', '缺失数'], data)
p = doc.add_paragraph()
r = p.add_run('注：表按维度分从低到高排序。AI教学维度因T08缺失、AI伦理维度因T19缺失，有效样本均为47。'); r.italic = True
set_cjk(p)

h('三、部门差异', 1)
hdr = ['部门'] + DIMS + ['可比性']
data = []
for _, r in dept_df.iterrows():
    row = [r['部门']]
    for c in DIMS:
        row.append(f"{r[c+'_分']:.0f}" if r[c+'_可比'] == '是' else '—')
    row.append('全部维度可比(n≥5)')
    data.append(row)
add_table(hdr, data)
p = doc.add_paragraph()
r = p.add_run('注：表中"—"表示该部门该维度有效样本少于5，按口径不参与比较（本次未出现该情况）。'); r.italic = True
set_cjk(p)

low1, low2 = rank.iloc[0]['维度'], rank.iloc[1]['维度']
s1, s2 = rank.iloc[0]['维度分(0-100)'], rank.iloc[1]['维度分(0-100)']

h('四、最需改进的两个维度及行动建议', 1)
para(f'按总体维度分从低到高排序，最需改进的两个维度为：{low1}（{s1:.0f}分）和{low2}（{s2:.0f}分）。', bold=True)

h(f'建议1：{low1}（{s1:.0f}分）', 2)
para(f'对应行动：{ACTIONS[low1]}。建议以部门为单位开展，用小步任务练习把抽象概念落到具体工作步骤，4–6周后用同口径问卷复测该维度分。')

h(f'建议2：{low2}（{s2:.0f}分）', 2)
para(f'对应行动：{ACTIONS[low2]}。建议结合实际工作文件开展实操训练，每两周一次练习与讲评，复测方式同上。')
para('跟进方式：将上述两维作为下期培训重点，其余维度纳入常规课程；复测沿用同一计分口径与缺失处理规则，便于前后对比。')

h('五、样本局限与使用声明', 1)
para('1. 抽样局限：本次48份为内部便捷抽样，非随机抽样，可能存在自选偏差，结果仅反映参评者自评情况，不宜外推至全体员工。')
para('2. 自评局限：各题为自评熟练度，与实际能力可能存在偏差；维度分仅用于培训需求识别。')
para('3. 缺失情况：共2处缺失（T08-AI教学、T19-AI伦理），已按维度剔除处理，对总体结论影响很小。')
para('4. 重要声明：本问卷分数不构成任何形式的能力认证、岗位资格或绩效评价依据，仅作为培训组织方安排课程的参考。', bold=True)
para('5. 数据与明细：全部计算明细见配套文件 survey_analysis.xlsx（含原始数据、总体维度分、部门差异、口径与局限四个工作表）。')

doc.save('/workspace/outputs/survey_report.docx')
print('overall:')
print(ov_df.to_string(index=False))
print('dept:')
print(dept_df.to_string(index=False))
print('DONE')
