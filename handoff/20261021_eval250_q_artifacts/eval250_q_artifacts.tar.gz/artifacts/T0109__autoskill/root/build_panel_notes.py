# -*- coding: utf-8 -*-
from docx import Document
from docx.shared import Pt, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH
import os

projects = [
    {
        "name": "云栖巡检（轨道运维 · 南京 · 联络人1）",
        "questions": [
            "两个封闭场的试用，场方有没有验收指标和时间表？什么条件下转成正式采购？",
            "联合试点您希望对方出什么——现场数据、检修人员配合，还是钱？出钱的是铁路局、集成商还是维护外包商？",
            "已授权的那项专利是算法还是整机结构？权属是否完全在公司，高校有无留权？",
        ],
        "comment": "原型与试用配置齐全，方向实在；短板是试用尚未变成付费承诺，试点诉求偏宽泛。若能锁定一家愿出钱的场方，把验收指标写进协议，转化路径就清晰了。",
    },
    {
        "name": "澄镜感知（机器视觉 · 苏州 · 联络人2）",
        "questions": [
            "12家付费客户里，续费或复购的有几家？客单价大概什么量级？",
            "1500万打算怎么花？18个月后希望拿出什么可核查的里程碑？",
            "3项公司专利是否覆盖对手绕不开的检测环节？有没有从高校受让带来的遗留权属问题？",
        ],
        "comment": "六个项目里商业化最扎实：小批生产加12家付费验证了交付能力。风险在融资叙事——若讲不清复购结构与毛利，1500万容易被看成信心价而非估值逻辑。",
    },
    {
        "name": "苔源材料（低碳/隔热材料 · 常州 · 联络人3）",
        "questions": [
            "3份测试报告出自哪些机构？送检样品与中试线产品是否同一批次工艺？",
            "高校非排他授权的期限和费用怎么定？代工厂进来后，专利与产品品牌归谁？",
            "工艺移植到代工线的最大难点是什么？目前有没有已接触的候选代工厂？",
        ],
        "comment": "中试加第三方测试是实打实的进展，但代工对接是材料转化最难一跳。非排他授权利于放开产能，也埋下同质竞争隐患；试样一致性与工艺移植是下一步成败关键。",
    },
    {
        "name": "光谱微测（科学仪器 · 上海 · 联络人4）",
        "questions": [
            "30万概念验证打算做哪几件事？多久出结果，判定成功的指标是什么？",
            "从实验室原型到能交给用户测试的样机，还缺哪些环节？首用户想找谁？",
            "高校专利将来是转让还是许可？团队与院系的权属分成谈过吗？",
        ],
        "comment": "处于最早期，无客户但诉求与阶段匹配，30万概念验证要价合理。关键是把概念验证定成可判定的指标，并提前想清权属与首用户，避免样机做完没处试。",
    },
    {
        "name": "医途导航（医院物流 · 杭州 · 联络人5）",
        "questions": [
            "1院试点是免费试用还是签了科研合作协议？医院信息科和采购部门介入到什么程度？",
            "院内路径数据和电梯对接由谁授权？进入患者活动区域如何过合规与院感关？",
            "下一阶段可验证目标是什么——几台、哪家医院、多长时间跑通闭环？",
        ],
        "comment": "医院物流场景真实，但单院试点深度存疑。院内数据与设备对接授权是隐形门槛，比样机数量更决定进度；先把一院跑成标杆，再谈多场景复制更稳妥。",
    },
    {
        "name": "衡算工艺（工业软件 · 无锡 · 联络人6）",
        "questions": [
            "5家续约工厂的续费条件一样吗？客户最认可和最抱怨的功能各是什么？",
            "渠道合作想借对方什么——行业客户名单还是实施交付团队？分成与责任怎么划？",
            "客户工艺数据沉淀在谁手里？数据归属写进合同了吗？",
        ],
        "comment": "5厂续约是六项目里最硬的商业验证信号，说明软件价值成立。渠道诉求合理，但要防交付责任稀释口碑；数据归属条款早定清楚，对后续融资并购都有利。",
    },
]

doc = Document()
style = doc.styles["Normal"]
style.font.name = "Noto Sans CJK SC"
style.font.size = Pt(11)
from docx.oxml.ns import qn
style.element.rPr.rFonts.set(qn("w:eastAsia"), "Noto Sans CJK SC")

title = doc.add_heading("评审提问与点评材料", level=0)
sub = doc.add_paragraph("30万元概念验证支持（非股权投资）· 每项目问答4分钟 · 提问聚焦客户、验证与转化路径")
sub.runs[0].font.size = Pt(10)
sub.alignment = WD_ALIGN_PARAGRAPH.CENTER

doc.add_paragraph("使用说明：每个项目3个口头提问＋约100字点评；提问不重复申报材料已写明的事实，直指下一阶段可验证目标、受益者、权属与资源。")

for i, p in enumerate(projects, 1):
    doc.add_heading(f"{i}. {p['name']}", level=1)
    doc.add_paragraph("现场提问：")
    for q in p["questions"]:
        para = doc.add_paragraph(q, style="List Number")
        para.paragraph_format.space_after = Pt(4)
    doc.add_paragraph("点评（约100字）：")
    cp = doc.add_paragraph(p["comment"])
    cp.paragraph_format.space_after = Pt(10)

doc.add_paragraph("—— 记录区 ——")
for _ in range(3):
    doc.add_paragraph("_" * 60)

os.makedirs("/workspace/outputs", exist_ok=True)
doc.save("/workspace/outputs/panel_notes.docx")
print("saved")
