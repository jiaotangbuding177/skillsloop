# -*- coding: utf-8 -*-
import openpyxl
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
from docx import Document
from docx.shared import Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
import os

os.makedirs('/workspace/outputs', exist_ok=True)

# ---------- 读取源数据 ----------
fb_wb = openpyxl.load_workbook('/workspace/inputs/用户反馈.xlsx')
feedbacks = []
for row in fb_wb['用户反馈'].iter_rows(min_row=2, values_only=True):
    if row[0] is None: continue
    feedbacks.append(dict(zip(['反馈编号','填写日期','用户编码','原分类','问题描述','场景','影响','反馈状态'], row)))

wi_wb = openpyxl.load_workbook('/workspace/inputs/研发工作项.xlsx')
workitems = {}
for row in wi_wb['研发工作项'].iter_rows(min_row=2, values_only=True):
    if row[0] is None: continue
    d = dict(zip(['工作项编码','模块','标题','具体范围','验收条件','明确不涉及','状态','预计完成日期'], row))
    workitems[d['工作项编码']] = d

# ---------- 逐问题组的匹配结论（依据问题事实+任务范围判断） ----------
GROUPS = {
 '离职成员仍能看到共享目录': {
   'matched': ['W001'], 'degree': '完全覆盖',
   'basis': {'W001': 'W001任务范围为“成员标离职后撤销项目共享授权、检索及目录访问”，验收条件“离职测试账号不能打开历史共享目录或检索该项目”，与反馈问题事实（离职成员仍可见共享目录）直接对应。'},
   'gap': '无未覆盖内容。注意：同模块的W007（共享权限预览页面）在“明确不涉及”中写明“不撤销离职成员权限，不改变访问控制”，不构成对本反馈的覆盖，仅可作配套管理页面。'},
 '检索50页文件超过30秒': {
   'matched': ['W002'], 'degree': '完全覆盖',
   'basis': {'W002': 'W002任务范围为“优化50页及以上PDF检索后端”，验收条件“固定50页样本查询小于8秒”，与反馈问题事实（50页文件检索超30秒）直接对应。'},
   'gap': '无未覆盖内容。注意：同模块的W008（搜索结果前端分页）在“明确不涉及”中写明“不优化后端检索耗时”，仅提升结果列表滚动体验，不解决检索耗时，不构成覆盖。'},
 'PDF导出表格最后一列被截掉': {
   'matched': ['W003'], 'degree': '完全覆盖',
   'basis': {'W003': 'W003任务范围为“按可用页宽处理全部列、长表头与跨页重复表头”，验收条件“12列样表导出PDF无列截断、所有金额与源表一致”，与反馈问题事实（PDF导出最后一列被截）直接对应。'},
   'gap': '无未覆盖内容。注意：同模块的W009（DOCX标题样式统一）在“明确不涉及”中写明“不涉及PDF表格列宽或分页”，不构成覆盖。'},
 '剩余额度未及时更新，重复购买': {
   'matched': ['W004','W010'], 'degree': '部分覆盖（两项目组合）',
   'basis': {'W004': 'W004任务范围为“模型请求完成后更新剩余额度并显示更新时间”，验收条件“请求结束3秒内显示余额与账务读回一致”，覆盖反馈前半问题“剩余额度未及时更新”。',
             'W010': 'W010任务范围为“重复点击使用同一订单键，不重复扣费并显示原订单”，覆盖反馈后半问题“重复购买”中因短时重复点击/提交导致的重复下单扣费。'},
   'gap': 'W004“明确不涉及”写明不处理重复购买交易幂等，W010“明确不涉及”写明不更新模型用量余额显示——两项目各自均不完整，须组合才能覆盖该反馈。需上会澄清：用户实际发生的“重复购买”是否均为短时重复点击（W010可防）；若因余额长时间未刷新导致用户间隔较久后再次购买，W010的同一订单键机制是否生效需研发确认。'},
 '移动端操作按钮被软键盘遮住': {
   'matched': ['W005'], 'degree': '完全覆盖',
   'basis': {'W005': 'W005任务范围为“输入框激活时底部操作滚动到键盘以上”，验收条件“iOS/Android输入后保存按钮可点击，提交内容不丢”，与反馈问题事实（按钮被软键盘遮挡）直接对应。'},
   'gap': '无未覆盖内容。注意：同模块的W011（移动端对比度优化）在“明确不涉及”中写明“不处理软键盘避让”，不构成覆盖。'},
 'XLSX上传后金额列变成文本，无法求和': {
   'matched': ['W006'], 'degree': '完全覆盖',
   'basis': {'W006': 'W006任务范围为“导入金额列识别数值并保留空值、负数，原文件不改”，验收条件“含负金额、空值、两位小数的样本可正确求和并逐值核对”，与反馈问题事实（金额列变文本无法求和）直接对应。'},
   'gap': '无未覆盖内容。注意：同模块的W012（附件容量上限调整）在“明确不涉及”中写明“不处理XLSX字段类型、金额解析”，不构成覆盖。'},
}

DISTRACTOR_NOTE = {
 'W007': '同属权限/共享主题但“明确不涉及”排除撤销离职成员权限，不覆盖任何反馈',
 'W008': '同属性能/检索主题但“明确不涉及”排除后端检索耗时优化，不覆盖任何反馈',
 'W009': '同属导出模块但“明确不涉及”排除PDF表格列宽分页，不覆盖任何反馈',
 'W011': '同属体验模块但“明确不涉及”排除软键盘避让，不覆盖任何反馈',
 'W012': '同属上传模块但“明确不涉及”排除XLSX字段类型与金额解析，不覆盖任何反馈',
}

# ---------- 反馈覆盖明细 ----------
detail_rows = []
for fb in feedbacks:
    g = GROUPS[fb['问题描述']]
    matched_ids = '、'.join(g['matched'])
    basis = '；'.join(g['basis'][wid] for wid in g['matched'])
    detail_rows.append([fb['反馈编号'], fb['填写日期'], fb['用户编码'], fb['原分类'], fb['问题描述'],
                        fb['场景'], fb['影响'], fb['反馈状态'], matched_ids, basis, g['degree'], g['gap']])

# ---------- 样式 ----------
thin = Side(style='thin', color='BFBFBF')
border = Border(left=thin, right=thin, top=thin, bottom=thin)
head_fill = PatternFill('solid', fgColor='2F5597')
head_font = Font(name='等线', bold=True, color='FFFFFF', size=10)
body_font = Font(name='等线', size=10)
wrap = Alignment(wrap_text=True, vertical='top')

def style_sheet(ws, widths, header_row=1):
    for i, w in enumerate(widths, 1):
        ws.column_dimensions[openpyxl.utils.get_column_letter(i)].width = w
    for cell in ws[header_row]:
        cell.fill = head_fill; cell.font = head_font; cell.border = border
        cell.alignment = Alignment(wrap_text=True, vertical='center', horizontal='center')
    for row in ws.iter_rows(min_row=header_row+1):
        for cell in row:
            cell.font = body_font; cell.border = border; cell.alignment = wrap

# ---------- 工作簿：研发覆盖分析.xlsx ----------
out_wb = openpyxl.Workbook()

# Sheet1 反馈覆盖明细
ws1 = out_wb.active; ws1.title = '反馈覆盖明细'
h1 = ['反馈编号','填写日期','用户编码','原分类','问题描述','场景','影响','反馈状态','匹配工作项','匹配依据（问题事实+任务范围）','覆盖程度','未覆盖/需澄清内容']
ws1.append(h1)
for r in detail_rows: ws1.append(r)
style_sheet(ws1, [9,11,9,8,26,10,6,9,12,52,16,52])
for row in ws1.iter_rows(min_row=2):
    ws1.row_dimensions[row[0].row].height = 72
ws1.freeze_panes = 'A2'

# Sheet2 工作项视角汇总（按工作项状态）
ws2 = out_wb.create_sheet('按工作项状态汇总')
ws2.append(['工作项编码','模块','标题','工作项状态','预计完成日期','关联反馈编号','关联反馈数','覆盖程度','说明'])
wi_cover = {}
for fb in feedbacks:
    for wid in GROUPS[fb['问题描述']]['matched']:
        wi_cover.setdefault(wid, []).append(fb['反馈编号'])
order = {'开发中':0,'计划中':1}
matched_wis = sorted(wi_cover, key=lambda w: (order.get(workitems[w]['状态'],9), workitems[w]['预计完成日期']))
for wid in matched_wis:
    w = workitems[wid]; ids = wi_cover[wid]
    gkey = next(k for k,v in GROUPS.items() if wid in v['matched'])
    g = GROUPS[gkey]
    ws2.append([wid, w['模块'], w['标题'], w['状态'], w['预计完成日期'], '、'.join(ids), len(ids),
                g['degree'] if len(g['matched'])==1 else f"与{'、'.join(x for x in g['matched'] if x!=wid)}组合",
                g['basis'][wid]])
ws2.append([])
ws2.append(['状态小计','','','','','','','',''])
stat_start = ws2.max_row + 1
from collections import Counter, OrderedDict
status_count = OrderedDict()
for wid in matched_wis:
    st = workitems[wid]['状态']
    status_count.setdefault(st, {'items':0,'fbs':0})
    status_count[st]['items'] += 1
    status_count[st]['fbs'] += len(wi_cover[wid])
for st, v in status_count.items():
    ws2.append([f'{st}', '', '', '', '', f'覆盖反馈 {v["fbs"]} 条', f'工作项 {v["items"]} 个', '',
                '；'.join(f'{w}({len(wi_cover[w])}条)' for w in matched_wis if workitems[w]['状态']==st)])
style_sheet(ws2, [11,8,20,11,13,42,11,18,60])

# Sheet3 未匹配反馈的工作项
ws3 = out_wb.create_sheet('未关联反馈的工作项')
ws3.append(['工作项编码','模块','标题','状态','预计完成日期','不构成覆盖的原因'])
for wid in workitems:
    if wid not in wi_cover:
        w = workitems[wid]
        ws3.append([wid, w['模块'], w['标题'], w['状态'], w['预计完成日期'], DISTRACTOR_NOTE[wid]])
style_sheet(ws3, [11,8,20,10,13,70])

out_wb.save('/workspace/outputs/研发覆盖分析.xlsx')
print('xlsx saved')

# ---------- 文档：研发覆盖分析.docx ----------
doc = Document()
style = doc.styles['Normal']; style.font.name = 'Noto Sans CJK SC'; style.font.size = Pt(10.5)
style.element.rPr.rFonts.set(__import__('docx').oxml.ns.qn('w:eastAsia'), 'Noto Sans CJK SC')

def h(text, level):
    p = doc.add_heading(text, level=level)
    for r in p.runs:
        r.font.name = 'Noto Sans CJK SC'
        r.element.rPr.rFonts.set(__import__('docx').oxml.ns.qn('w:eastAsia'), 'Noto Sans CJK SC')
    return p

title = doc.add_heading('研发覆盖分析报告', 0)
title.alignment = WD_ALIGN_PARAGRAPH.CENTER
meta = doc.add_paragraph('分析对象：用户反馈.xlsx（42条）与研发工作项.xlsx（12项）｜用途：研发周会确认反馈是否进入排期')
meta.alignment = WD_ALIGN_PARAGRAPH.CENTER

h('一、分析方法与口径', 1)
p = doc.add_paragraph('本次匹配以“问题事实 + 任务范围”联合判断：先从42条反馈中归并问题事实（42条反馈实际为6类重复问题），再逐类核对工作项的“具体范围”与“验收条件”是否直接解决问题事实，并用工作项“明确不涉及”一栏反向排除同模块但不构成覆盖的工作项。仅编号相邻或标题关键词相似不作为覆盖依据；凡出现“明确不涉及”排除对应场景的，一律判为不覆盖并在明细中注明。')
doc.add_paragraph('覆盖程度分两档：完全覆盖——工作项验收条件可直接验证反馈问题消除；部分覆盖——需多个工作项组合、或范围尚不能完全覆盖反馈事实，需澄清。所有42条反馈的填写日期在明细表中逐条保留，未做归并丢弃。')

h('二、总体结论', 1)
p = doc.add_paragraph('42条反馈全部能在现有研发工作项中找到对应排期：35条为完全覆盖（5类问题，各7条），7条为部分覆盖（“剩余额度未及时更新，重复购买”需 W004+W010 组合，且组合边界需澄清）。匹配工作项共5个：W001、W002、W003、W005、W006、W004与W010（组合覆盖）。12个工作项中有5个（W007、W008、W009、W011、W012）与反馈问题事实同模块、同主题，但在“明确不涉及”中排除了对应场景，不构成覆盖，周会讨论时不应据此认定反馈已排期。')

h('三、逐类问题事实与匹配结论', 1)
for gname, g in GROUPS.items():
    fbs = [f for f in feedbacks if f['问题描述']==gname]
    ids = '、'.join(f['反馈编号'] for f in fbs)
    dates = '、'.join(sorted(set(f['填写日期'] for f in fbs)))
    h(f'3.{list(GROUPS).index(gname)+1} {gname}', 2)
    info = doc.add_paragraph()
    info.add_run(f'涉及反馈：{len(fbs)}条（{ids}），原分类“{fbs[0]["原分类"]}”，场景“{fbs[0]["场景"]}”，影响“{fbs[0]["影响"]}”。原始填写日期覆盖 {dates}，明细见Excel逐条记录。').bold = False
    t = doc.add_table(rows=1, cols=2); t.style = 'Table Grid'; t.alignment = WD_TABLE_ALIGNMENT.CENTER
    hdr = t.rows[0].cells
    hdr[0].text = '项目'; hdr[1].text = '内容'
    rows_data = [
      ('匹配工作项', '、'.join(g['matched'])),
      ('匹配依据', '；'.join(g['basis'][w] for w in g['matched'])),
      ('覆盖程度', g['degree']),
      ('未覆盖/需澄清', g['gap']),
    ]
    for k, v in rows_data:
        row = t.add_row().cells; row[0].text = k; row[1].text = v
    for r_ in t.rows:
        for c in r_.cells:
            for pp in c.paragraphs:
                for run in pp.runs:
                    run.font.name='Noto Sans CJK SC'; run.font.size=Pt(9.5)
                    run.element.rPr.rFonts.set(__import__('docx').oxml.ns.qn('w:eastAsia'),'Noto Sans CJK SC')
    doc.add_paragraph()

h('四、按工作项状态汇总', 1)
t = doc.add_table(rows=1, cols=5); t.style='Table Grid'; t.alignment = WD_TABLE_ALIGNMENT.CENTER
hdr = t.rows[0].cells
for i, txt in enumerate(['工作项状态','工作项','关联反馈数','覆盖程度','预计完成日期']):
    hdr[i].text = txt
status_rows = [
 ('开发中','W003 PDF导出宽表分页','7条（F003、F009、F015、F021、F027、F033、F039）','完全覆盖','2026-10-04'),
 ('开发中','W006 XLSX金额类型保护','7条（F006、F012、F018、F024、F030、F036、F042）','完全覆盖','2026-10-07'),
 ('计划中','W001 离职成员共享访问回收','7条（F001、F007、F013、F019、F025、F031、F037）','完全覆盖','2026-10-02'),
 ('计划中','W002 长文档检索索引优化','7条（F002、F008、F014、F020、F026、F032、F038）','完全覆盖','2026-10-03'),
 ('计划中','W004 余额事件读回 + W010 套餐购买防重复','7条（F004、F010、F016、F022、F028、F034、F040）','部分覆盖（组合）','2026-10-05 / 2026-10-11'),
 ('计划中','W005 移动端键盘避让','7条（F005、F011、F017、F023、F029、F035、F041）','完全覆盖','2026-10-06'),
]
for row in status_rows:
    cells = t.add_row().cells
    for i, v in enumerate(row): cells[i].text = v
for r_ in t.rows:
    for c in r_.cells:
        for pp in c.paragraphs:
            for run in pp.runs:
                run.font.name='Noto Sans CJK SC'; run.font.size=Pt(9.5)
                run.element.rPr.rFonts.set(__import__('docx').oxml.ns.qn('w:eastAsia'),'Noto Sans CJK SC')
doc.add_paragraph()
p = doc.add_paragraph('汇总：开发中工作项2个，覆盖14条反馈；计划中工作项5个（含W004/W010组合），覆盖28条反馈。全部42条反馈均有对应排期，周会可逐类确认验收口径。')

h('五、未关联反馈的工作项（防误判提示）', 1)
p = doc.add_paragraph('以下5个工作项与反馈主题相近，容易被误认为已覆盖，实际其“明确不涉及”排除了对应场景：')
for wid, note in DISTRACTOR_NOTE.items():
    w = workitems[wid]
    doc.add_paragraph(f'{wid} {w["标题"]}（{w["状态"]}）：{note}', style='List Bullet')

h('六、需周会澄清的事项', 1)
doc.add_paragraph('1. “剩余额度未及时更新，重复购买”类反馈（7条）：W004与W010为组合覆盖，需确认实际重复购买场景是否均为短时重复点击；若存在因余额延迟显示导致的间隔性二次购买，需明确归属与处理方案。', style='List Number')
doc.add_paragraph('2. 各类反馈的“已复核/未处理”状态与研发排期相互独立，复核通过不代表已进入开发，建议周会按本报告逐类确认排期优先级。', style='List Number')

doc.save('/workspace/outputs/研发覆盖分析.docx')
print('docx saved')
