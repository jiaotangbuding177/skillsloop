#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import csv
from datetime import datetime, timedelta
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment

TZ = "Asia/Shanghai"

rows = []
with open("/workspace/inputs/reminders.csv", newline="", encoding="utf-8") as f:
    reader = csv.DictReader(f)
    for r in reader:
        rows.append(r)

# 只保留有效事项；同一事项ID只取最新有效安排
latest = {}
for r in rows:
    if r["状态"].strip() == "有效":
        latest[r["事项ID"]] = r  # CSV顺序即先后，覆盖保留最新

items = [latest[k] for k in sorted(latest.keys())]

def fmt_dt(s):
    dt = datetime.strptime(s.strip(), "%Y-%m-%d %H:%M")
    return dt

def ics_stamp(dt):
    return dt.strftime("%Y%m%dT%H%M%S")

now = datetime(2026, 10, 15, 15, 46, 0)

lines = [
    "BEGIN:VCALENDAR",
    "VERSION:2.0",
    "PRODID:-//team-reminders//CN//",
    "CALSCALE:GREGORIAN",
    "METHOD:PUBLISH",
    "BEGIN:VTIMEZONE",
    "TZID:Asia/Shanghai",
    "BEGIN:STANDARD",
    "DTSTART:19700101T000000",
    "TZOFFSETFROM:+0800",
    "TZOFFSETTO:+0800",
    "TZNAME:CST",
    "END:STANDARD",
    "END:VTIMEZONE",
]
for r in items:
    dt = fmt_dt(r["时间"])
    end = dt + timedelta(minutes=int(r["分钟"]))
    lines += [
        "BEGIN:VEVENT",
        f"UID:{r['事项ID']}@team-reminders",
        f"DTSTAMP:{ics_stamp(now)}Z",
        f"DTSTART;TZID=Asia/Shanghai:{ics_stamp(dt)}",
        f"DTEND;TZID=Asia/Shanghai:{ics_stamp(end)}",
        f"SUMMARY:{r['标题']}",
        "BEGIN:VALARM",
        "ACTION:DISPLAY",
        f"DESCRIPTION:{r['标题']}",
        "TRIGGER:-PT30M",
        "END:VALARM",
        "END:VEVENT",
    ]
lines.append("END:VCALENDAR")

with open("/workspace/outputs/team_reminders.ics", "w", encoding="utf-8", newline="") as f:
    f.write("\r\n".join(lines) + "\r\n")

# xlsx summary
wb = Workbook()
ws = wb.active
ws.title = "日程汇总"
headers = ["事项ID", "标题", "开始时间", "结束时间", "时长(分钟)", "状态", "时区", "提醒"]
ws.append(headers)
for c in range(1, len(headers) + 1):
    ws.cell(row=1, column=c).font = Font(bold=True)
    ws.cell(row=1, column=c).alignment = Alignment(horizontal="center")

# 状态: 全部为有效（已纳入日历），并列出排除项
all_status = {}
for r in rows:
    tid = r["事项ID"]
    all_status[tid] = r

for r in items:
    dt = fmt_dt(r["时间"])
    end = dt + timedelta(minutes=int(r["分钟"]))
    ws.append([
        r["事项ID"], r["标题"],
        dt.strftime("%Y-%m-%d %H:%M"),
        end.strftime("%Y-%m-%d %H:%M"),
        int(r["分钟"]), "有效", TZ, "提前30分钟",
    ])

# 排除说明 sheet
ws2 = wb.create_sheet("排除事项")
ws2.append(["事项ID", "标题", "时间", "时长(分钟)", "原状态", "排除原因"])
for c in range(1, 7):
    ws2.cell(row=1, column=c).font = Font(bold=True)
    ws2.cell(row=1, column=c).alignment = Alignment(horizontal="center")
seen = set()
for r in rows:
    tid = r["事项ID"]
    if r["状态"].strip() != "有效" and tid not in seen:
        seen.add(tid)
        reason = "已撤销，不创建事件" if r["状态"].strip() == "撤销" else "已完成，不创建事件"
        if r["状态"].strip() == "被改":
            reason = "已被同事项更新安排取代，仅保留最新有效安排"
        ws2.append([tid, r["标题"], r["时间"], int(r["分钟"]), r["状态"].strip(), reason])

# 列宽
for wsx in (ws, ws2):
    widths = {}
    for row in wsx.iter_rows():
        for cell in row:
            v = str(cell.value) if cell.value is not None else ""
            w = sum(2 if ord(ch) > 127 else 1 for ch in v) + 2
            widths[cell.column_letter] = max(widths.get(cell.column_letter, 0), w)
    for col, w in widths.items():
        wsx.column_dimensions[col].width = min(w, 40)

wb.save("/workspace/outputs/calendar_summary.xlsx")
print("ICS events:", len(items))
for r in items:
    print(" -", r["事项ID"], r["标题"], r["时间"], r["分钟"], "min")
print("Excluded:", [(r['事项ID'], r['状态']) for r in rows if r['事项ID'] not in latest])
