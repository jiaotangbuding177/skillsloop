# -*- coding: utf-8 -*-
from docx import Document
from docx.shared import Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING
from docx.oxml.ns import qn
import openpyxl
from openpyxl.styles import Font, Alignment, PatternFill

# ---------- corrections ----------
CORR = {"丁城": "丁成", "严朝": "闫朝", "普汇大厦": "浦汇大厦"}
def fix(s):
    for a, b in CORR.items():
        s = s.replace(a, b)
    return s

# ---------- minutes.docx ----------
doc = Document()
style = doc.styles['Normal']
style.font.name = 'KaiTi'
style.font.size = Pt(12)
style.element.rPr.rFonts.set(qn('w:eastAsia'), '楷体')

def para(text, bold=False, center=False, size=12):
    p = doc.add_paragraph()
    p.paragraph_format.line_spacing_rule = WD_LINE_SPACING.ONE_POINT_FIVE
    if center:
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run(text)
    r.bold = bold
    r.font.size = Pt(size)
    r.font.name = 'KaiTi'
    r.element.rPr.rFonts.set(qn('w:eastAsia'), '楷体')
    return p

para("浦汇大厦试点合作会议纪要", bold=True, center=True, size=16)
para("会议时间：2026年10月8日")
para("参会人员：林青、丁成、闫朝")
para("会议背景：三方就浦汇大厦试点合作进行讨论，明确先做样机测试、暂不谈独家，并就样机交付、场地安排与付款口径交换意见。")

para("一、样机测试与交付安排", bold=True)
para("总体口径：会议明确先进行样机测试，暂不讨论独家（排他）合作。")
para("交付数量：丁成表示11月前最多可交付两台样机；具体交付时间需向工程部门确认，尚无明确答复。")

para("二、浦汇大厦试点与场地安排", bold=True)
para("试点意向：与会人员谈到浦汇大厦试点，一致同意推进两项前期工作：丁成于10月12日前提交两台样机报价；闫朝于10月15日前反馈场地审批情况。")
para("未决事项（分歧）：闫朝提出安全测试可由我方提供场地，林青追问场地由谁批准，会上未获答复，场地审批归属仍待明确。")

para("三、商务条款", bold=True)
para("付款口径：林青表示款项待验收后再行商谈，本次会议未确定金额，不构成任何商务承诺。")
para("未决事项：会议结尾各方表示希望未来讨论排他合作，目前仅为意向，尚无任何决定，未签署任何协议。")

para("后续行动项", bold=True)
para("行动项1：丁成于2026年10月12日前提交浦汇大厦试点两台样机的报价。")
para("行动项2：闫朝于2026年10月15日前反馈场地审批情况。")
para("行动项3：向工程部门确认两台样机的具体交付时间（责任人与期限待定）。")
para("行动项4：明确安全测试场地的审批归属（责任人与期限待定）。")

para("备注：本纪要系根据会议逐字记录整理归纳，人名及项目名称已按经三方主持确认的更正清单统一更正（丁城→丁成、严朝→闫朝、普汇大厦→浦汇大厦）；其余名称未作推断。纪要中的时间、数量等以逐字稿口径为准，如与实际不符请以与会各方确认为准。")

doc.save('/workspace/outputs/minutes.docx')

# ---------- actions.xlsx ----------
wb = openpyxl.Workbook()
ws = wb.active
ws.title = "行动项"
headers = ["序号", "行动项", "责任人", "截止日期", "状态", "备注"]
rows = [
    [1, "提交浦汇大厦试点两台样机报价", "丁成", "2026-10-12", "进行中", "试点前期工作，会上已议定"],
    [2, "反馈场地审批情况", "闫朝", "2026-10-15", "进行中", "会上已议定；场地审批归属尚未明确，待跟进"],
    [3, "确认两台样机具体交付时间", "待定（需问工程）", "待定", "未决", "丁成会上表示需向工程部门确认，未给出答复"],
    [4, "明确安全测试场地审批归属", "待定", "待定", "未决（分歧）", "林青追问场地由谁批准，会上无答复"],
    [5, "商谈款项及金额", "待定", "待定", "未决", "林青表示款项待验收后谈，金额未定，不构成承诺"],
    [6, "讨论排他（独家）合作", "待定", "待定", "未决（仅为意向）", "会议结尾表达未来讨论意愿，尚无决定，未签任何协议"],
]
ws.append(headers)
for r in rows:
    ws.append(r)
fill = PatternFill('solid', fgColor='D9E1F2')
for c in ws[1]:
    c.font = Font(name='等线', bold=True, size=11)
    c.fill = fill
    c.alignment = Alignment(horizontal='center', vertical='center')
widths = [6, 34, 16, 12, 16, 46]
for i, w in enumerate(widths, 1):
    ws.column_dimensions[openpyxl.utils.get_column_letter(i)].width = w
for row in ws.iter_rows(min_row=2):
    for c in row:
        c.font = Font(name='等线', size=11)
        c.alignment = Alignment(vertical='center', wrap_text=True)
ws.freeze_panes = 'A2'
wb.save('/workspace/outputs/actions.xlsx')
print('done')
