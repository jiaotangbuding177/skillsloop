# -*- coding: utf-8 -*-
"""生成 dd_responses.docx 与 evidence_gaps.xlsx"""
from docx import Document
from docx.shared import Pt, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
import openpyxl
from openpyxl.styles import Font, Alignment, PatternFill

# ---------------- 回复数据 ----------------
responses = [
    {
        "id": "Q01", "dept": "法务",
        "q": "知识产权属于谁？",
        "a": "公司现有专利3件：其中2件专利权人为本公司名下，1件登记在合作高校名下（证据E01）。高校名下专利已通过授权条款允许公司在当前应用领域使用，但该专利的所有权仍归属高校。",
        "basis": "E01",
        "gap": "需补充高校授权协议原件扫描件及许可期限、地域、费用条款明细，以便确认权属与授权链条完整性。",
        "owner": "法务负责人",
    },
    {
        "id": "Q02", "dept": "财务",
        "q": "2026收入及回款？",
        "a": "2026年1-9月确认收入360万元，同期回款290万元（证据E02）。该数据为截至2026-09-30的实际发生数；2026年全年收入及回款数据尚在统计/形成中，待第四季度结束后提供，目前不在此做预测性承诺。",
        "basis": "E02",
        "gap": "需补充2026年10-12月实际发生数及全年最终数据；如投资机构需要，可另行提供分月收入与回款明细表。",
        "owner": "财务负责人",
    },
    {
        "id": "Q03", "dept": "法务",
        "q": "高校成果是否排他授权？",
        "a": "否。根据高校授权条款，公司获得的仅是当前应用领域内的非排他使用许可，不构成排他授权（证据E01）。公司未取得也不对外声称拥有排他授权。",
        "basis": "E01",
        "gap": "如需进一步核验，待补充授权协议原文中关于许可性质、应用领域界定及是否可扩展的条款文本。",
        "owner": "法务负责人",
    },
    {
        "id": "Q04", "dept": "人事",
        "q": "研发人员人数及稳定性？",
        "a": "截至证据基准日，研发团队共14人。过去12个月内离职2人、新增3人，净增1人，团队规模保持稳定并小幅增长（证据E03）。",
        "basis": "E03",
        "gap": "待补充研发人员名单（可脱敏）、核心成员岗位与任职年限，以及2名离职人员的原因说明与是否涉及竞业限制。",
        "owner": "人事负责人",
    },
    {
        "id": "Q05", "dept": "管理层",
        "q": "未来18个月资金用途？",
        "a": "公司编制了未来资金使用预算1200万元，拟用于：产品研发500万元、客户交付300万元、销售投入250万元、流动资金150万元（证据E04）。需要特别说明：该1200万元为预算计划数，尚未经董事会审批通过，不属于已发生的实际费用，也不构成对资金用途的既定承诺；实际执行以董事会审批结果为准。",
        "basis": "E04",
        "gap": "待补充董事会审批决议文件；审批通过后如预算金额或结构发生调整，将以决议版本为准更新本回复。",
        "owner": "管理层/董事会秘书",
    },
    {
        "id": "Q06", "dept": "财务",
        "q": "最大客户占比？",
        "a": "2026年1-9月最大客户确认收入90万元，占同期确认收入360万元的25%（证据E02）。客户集中度以实际确认收入口径计算，回款口径未单独统计该客户占比。",
        "basis": "E02",
        "gap": "待补充最大客户合作合同期限、续约安排及前五大客户收入分布，以完整反映客户集中度风险。",
        "owner": "财务负责人",
    },
    {
        "id": "Q07", "dept": "交付",
        "q": "是否已有认证？",
        "a": "尚无已获得的认证证书。认证申请已提交，目前处于审核过程中，未获得证书（证据E05）。公司将跟踪审核进度，获证后第一时间更新。",
        "basis": "E05",
        "gap": "待补充认证申请受理凭证、认证类别与审核机构名称、预计获证时间。",
        "owner": "交付负责人",
    },
    {
        "id": "Q08", "dept": "法务",
        "q": "是否有未决诉讼？",
        "a": "截至目前无经确认的未决诉讼结论。公司诉讼登记表尚未经法务负责人签核，暂无法出具正式结论（证据E06）。签核完成后，公司将书面确认是否存在未决诉讼及具体涉案情况。",
        "basis": "E06",
        "gap": "待补充经法务签核的诉讼登记表及对外担保、行政处罚等关联排查结果，作为本回复的正式支撑文件。",
        "owner": "法务负责人",
    },
]

summary_gaps = (
    "本回复全部基于截至2026-09-30的公司证据材料（E01—E06）。材料中已明确的事项均引用证据编号作答；"
    "预算类数字（E04，1200万元）仅为计划数且未经董事会审批，未作为实际费用陈述；高校授权（E01）为非排他性质，本回复未作出任何排他授权承诺。"
    "凡证据未覆盖的事项，均在各条回复及文末《待补资料清单》中标注，并明确责任角色。"
)

# ---------------- dd_responses.docx ----------------
doc = Document()
style = doc.styles["Normal"]
style.font.name = "Noto Sans CJK SC"
style.font.size = Pt(11)
style.element.rPr.rFonts.set(qn("w:eastAsia"), "Noto Sans CJK SC")

for sec in doc.sections:
    sec.top_margin = Cm(2.2)
    sec.bottom_margin = Cm(2.2)

h = doc.add_paragraph()
h.alignment = WD_ALIGN_PARAGRAPH.CENTER
run = h.add_run("投资机构尽调问题回复")
run.font.size = Pt(18)
run.bold = True

sub = doc.add_paragraph()
sub.alignment = WD_ALIGN_PARAGRAPH.CENTER
r = sub.add_run("（数据基准日：2026-09-30；证据编号对应公司证据材料 E01—E06）")
r.font.size = Pt(10)

doc.add_paragraph(summary_gaps)

doc.add_heading("一、逐项回复", level=1)
for item in responses:
    doc.add_heading(f"{item['id']}　{item['q']}　（责任部门：{item['dept']}）", level=2)
    p = doc.add_paragraph()
    r = p.add_run("回复：")
    r.bold = True
    p.add_run(item["a"])
    p2 = doc.add_paragraph()
    r2 = p2.add_run("证据依据：")
    r2.bold = True
    p2.add_run(item["basis"])
    p3 = doc.add_paragraph()
    r3 = p3.add_run("待补资料及责任角色：")
    r3.bold = True
    p3.add_run(item["gap"] + "（责任角色：" + item["owner"] + "）")

doc.add_heading("二、总体口径说明", level=1)
doc.add_paragraph(summary_gaps)

notes = [
    "本回复中所有金额均为人民币。",
    "2026年全年财务数据待第四季度结束后提供，本回复不包含预测性数字。",
    "高校名下专利授权为非排他许可，公司未取得、也未承诺任何排他授权安排。",
    "1200万元资金用途为编制中的预算数，未经董事会审批，不构成实际费用发生数。",
]
doc.add_heading("三、重点提示", level=1)
for n in notes:
    doc.add_paragraph(n, style="List Bullet")

doc.add_heading("四、待补资料清单", level=1)
gap_table = doc.add_table(rows=1, cols=3)
gap_table.style = "Table Grid"
hdr = gap_table.rows[0].cells
for i, t in enumerate(["对应问题", "待补资料", "责任角色"]):
    hdr[i].text = ""
    rr = hdr[i].paragraphs[0].add_run(t)
    rr.bold = True
for item in responses:
    row = gap_table.add_row().cells
    row[0].text = item["id"]
    row[1].text = item["gap"]
    row[2].text = item["owner"]

doc.save("/workspace/outputs/dd_responses.docx")

# ---------------- evidence_gaps.xlsx ----------------
wb = openpyxl.Workbook()
ws = wb.active
ws.title = "证据缺口台账"

headers = ["问题ID", "问题", "责任部门", "已有证据", "缺口/待补资料", "责任角色", "状态"]
ws.append(headers)

# 状态: 已支撑=证据充分可直接对外; 部分支撑=已有部分证据但需补充
rows = [
    ["Q01", "知识产权属于谁？", "法务", "E01", "高校授权协议原件（含许可期限、地域、费用条款），确认权属与授权链条", "法务负责人", "部分支撑"],
    ["Q02", "2026收入及回款？", "财务", "E02", "2026年10-12月实际数及全年最终收入、回款数据；如需可提供分月明细", "财务负责人", "部分支撑"],
    ["Q03", "高校成果是否排他授权？", "法务", "E01", "授权协议原文中许可性质、应用领域界定及可否扩展的条款文本", "法务负责人", "已支撑（结论明确：非排他）"],
    ["Q04", "研发人员人数及稳定性？", "人事", "E03", "研发人员名单（脱敏）、核心成员岗位与任职年限、离职原因及竞业限制情况", "人事负责人", "部分支撑"],
    ["Q05", "未来18个月资金用途？", "管理层", "E04", "董事会审批决议（1200万元预算尚未获批，不得作为实际费用口径）", "管理层/董事会秘书", "部分支撑"],
    ["Q06", "最大客户占比？", "财务", "E02", "最大客户合同期限与续约安排、前五大客户收入分布", "财务负责人", "部分支撑"],
    ["Q07", "是否已有认证？", "交付", "E05", "认证申请受理凭证、认证类别、审核机构、预计获证时间", "交付负责人", "部分支撑"],
    ["Q08", "是否有未决诉讼？", "法务", "E06", "经法务签核的诉讼登记表及担保、行政处罚关联排查结果", "法务负责人", "待补（登记表未签核，无结论）"],
]
for row in rows:
    ws.append(row)

# 样式
bold_font = Font(name="Noto Sans CJK SC", bold=True, size=11)
body_font = Font(name="Noto Sans CJK SC", size=11)
fill = PatternFill("solid", fgColor="DDEBF7")
for cell in ws[1]:
    cell.font = bold_font
    cell.fill = fill
    cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
widths = [9, 24, 10, 12, 52, 20, 26]
for i, w in enumerate(widths, start=1):
    ws.column_dimensions[openpyxl.utils.get_column_letter(i)].width = w
for row in ws.iter_rows(min_row=2):
    for cell in row:
        cell.font = body_font
        cell.alignment = Alignment(vertical="top", wrap_text=True)
ws.freeze_panes = "A2"

# 说明sheet
ws2 = wb.create_sheet("口径说明")
notes2 = [
    "1. 本台账汇总尽调回复（dd_responses.docx）中各项的证据支撑情况与待补资料。",
    "2. “已支撑”表示现有证据（E01—E06）可直接支持对外回复；“部分支撑”表示已有部分依据但需补充材料；“待补”表示暂无法出具正式结论。",
    "3. 1200万元资金用途（E04）为预算计划数，未经董事会审批，不得作为实际费用对外陈述。",
    "4. 高校名下专利（E01）授权性质为当前应用领域内非排他许可，公司未取得亦不承诺排他授权。",
    "5. 数据基准日：2026-09-30。",
]
ws2.column_dimensions["A"].width = 100
for i, t in enumerate(notes2, start=1):
    c = ws2.cell(row=i, column=1, value=t)
    c.font = body_font
    c.alignment = Alignment(vertical="top", wrap_text=True)

wb.save("/workspace/outputs/evidence_gaps.xlsx")
print("saved both files")
