import openpyxl
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
from openpyxl.utils import get_column_letter

# ---- 分类映射（按合并口径.md）----
CLASS = {
    '产品销售回款': ('经营', '流入', '产品销售回款'),
    '研发补贴':     ('经营', '流入', '研发补贴'),
    '银行利息收入': ('经营', '流入', '利息收入'),
    '内部往来收款': ('经营', '流入', '内部往来'),
    '材料采购':     ('经营', '流出', '材料采购'),
    '员工报销':     ('经营', '流出', '员工报销'),
    '备用金转出':   ('经营', '流出', '备用金转出'),
    '服务外包':     ('经营', '流出', '服务外包'),
    '内部往来付款': ('经营', '流出', '内部往来'),
    '设备采购':     ('投资', '流出', '设备采购'),
    '项目投资款':   ('投资', '流出', '项目投资款'),
    '股东增资':     ('筹资', '流入', '股东增资'),
}

def load(path):
    wb = openpyxl.load_workbook(path)
    ws = wb.active
    rows = []
    for r in ws.iter_rows(min_row=2, values_only=True):
        if r[0] is None:
            continue
        rows.append({'id': r[0], 'date': r[1], 'summary': r[2],
                     'in': float(r[3] or 0), 'out': float(r[4] or 0), 'cp': r[5]})
    return rows

parent = load('inputs/母公司流水.xlsx')
child  = load('inputs/子公司流水.xlsx')
for r in parent + child:
    r['cat'] = CLASS[r['summary']]

# ---- 汇总函数 ----
def summarize(rows):
    s = {}
    for r in rows:
        cat, dirn, sub = r['cat']
        amt = r['in'] if dirn == '流入' else r['out']
        s[(cat, dirn, sub)] = s.get((cat, dirn, sub), 0) + amt
    return s

# ---- 内部抵销：按口径编号 IC-20260612-01 匹配（母TA001 收 120000 <-> 子TB001 付 120000）----
MATCH_ID = 'IC-20260612-01'
match_m = [r for r in parent if r['id'] == 'TA001']
match_c = [r for r in child if r['id'] == 'TB001']
unmatched_m = [r for r in parent if r['summary'] == '内部往来收款' and r['id'] != 'TA001']
unmatched_c = [r for r in child if r['summary'] == '内部往来付款' and r['id'] != 'TB001']
elim_in  = sum(r['in'] for r in match_m)
elim_out = sum(r['out'] for r in match_c)
assert elim_in == elim_out == 120000.0

wb = openpyxl.Workbook()
wb.remove(wb.active)

hdr_fill = PatternFill('solid', fgColor='1F4E78')
hdr_font = Font(bold=True, color='FFFFFF')
tot_fill = PatternFill('solid', fgColor='D9E1F2')
thin = Side(style='thin', color='BFBFBF')
border = Border(left=thin, right=thin, top=thin, bottom=thin)
NUM = '#,##0.00'

def style_header(ws, row, ncol):
    for c in range(1, ncol + 1):
        cell = ws.cell(row=row, column=c)
        cell.fill = hdr_fill; cell.font = hdr_font
        cell.alignment = Alignment(horizontal='center', vertical='center')
        cell.border = border

def style_num(ws, r1, r2, cols):
    for r in range(r1, r2 + 1):
        for c in cols:
            cell = ws.cell(row=r, column=c)
            cell.number_format = NUM
            cell.border = border

def detail_sheet(name, rows):
    ws = wb.create_sheet(name)
    cols = ['流水ID', '日期', '摘要', '收入元', '支出元', '对方机构', '一级类别', '收支方向', '明细类别']
    ws.append(cols)
    style_header(ws, 1, len(cols))
    for r in rows:
        cat, dirn, sub = r['cat']
        ws.append([r['id'], r['date'], r['summary'], r['in'], r['out'], r['cp'], cat, dirn, sub])
    style_num(ws, 2, ws.max_row, [4, 5])
    widths = [10, 12, 14, 12, 12, 12, 10, 10, 12]
    for i, w in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = w
    ws.freeze_panes = 'A2'
    return ws

def summary_rows(name, s):
    # 返回：[(子类说明, 金额...)] 及合计行
    def g(cat, dirn): return sum(v for (c, d, _), v in s.items() if c == cat and d == dirn)
    return {
        '经营流入小计': g('经营', '流入'), '经营流出小计': g('经营', '流出'), '经营净额': g('经营', '流入') - g('经营', '流出'),
        '投资流入小计': g('投资', '流入'), '投资流出小计': g('投资', '流出'), '投资净额': g('投资', '流入') - g('投资', '流出'),
        '筹资流入小计': g('筹资', '流入'), '筹资流出小计': g('筹资', '流出'), '筹资净额': g('筹资', '流入') - g('筹资', '流出'),
        '总净额': sum(g(c, '流入') - g(c, '流出') for c in ('经营', '投资', '筹资')),
    }

def summary_sheet(name, title, blocks, extra_note=None):
    # blocks: [(主体名, s)] ；经营流入流出分项先列示，再列三大类小计/净额/总净额
    subs_in  = ['产品销售回款', '研发补贴', '利息收入', '内部往来']
    subs_out = ['材料采购', '员工报销', '备用金转出', '服务外包', '内部往来']
    ws = wb.create_sheet(name)
    head = ['主体', '产品销售回款', '研发补贴', '利息收入', '内部往来流入', '经营流入小计',
            '材料采购', '员工报销', '备用金转出', '服务外包', '内部往来流出', '经营流出小计', '经营净额',
            '投资流入小计', '投资流出小计', '投资净额',
            '筹资流入小计', '筹资流出小计', '筹资净额', '总净额']
    ws.append([title]); ws.append(head)
    style_header(ws, 2, len(head))
    for nm, s in blocks:
        def gv(cat, dirn, sub): return s.get((cat, dirn, sub), 0)
        def g(cat, dirn): return sum(v for (c, d, _), v in s.items() if c == cat and d == dirn)
        row = [nm]
        row += [gv('经营', '流入', x) for x in subs_in]
        row += [g('经营', '流入')]
        row += [gv('经营', '流出', x) for x in subs_out]
        row += [g('经营', '流出'), g('经营', '流入') - g('经营', '流出')]
        row += [g('投资', '流入'), g('投资', '流出'), g('投资', '流入') - g('投资', '流出')]
        row += [g('筹资', '流入'), g('筹资', '流出'), g('筹资', '流入') - g('筹资', '流出')]
        row += [sum(g(c, '流入') - g(c, '流出') for c in ('经营', '投资', '筹资'))]
        ws.append(row)
    style_num(ws, 3, ws.max_row, list(range(2, len(head) + 1)))
    for i, w in enumerate([12] + [14] * (len(head) - 1), 1):
        ws.column_dimensions[get_column_letter(i)].width = w
    if extra_note:
        ws.append([]); ws.append([extra_note])
    return ws

# 1-2 明细
detail_sheet('母公司明细', parent)
detail_sheet('子公司明细', child)

# 3 主体汇总
sp, sc = summarize(parent), summarize(child)
summary_sheet('主体汇总', '主体汇总（2026年5—6月，单位：人民币元）',
              [('母公司', sp), ('子公司', sc)])

# 4 内部抵销
ws = wb.create_sheet('内部抵销')
head = ['匹配编号', '母方流水ID', '母方摘要', '母方收入元', '子方流水ID', '子方摘要', '子方支出元',
        '抵销经营流入元', '抵销经营流出元', '是否抵销']
ws.append(head); style_header(ws, 1, len(head))
m, c = match_m[0], match_c[0]
ws.append([MATCH_ID, m['id'], m['summary'], m['in'], c['id'], c['summary'], c['out'], elim_in, elim_out, '是（仅集团层抵销）'])
style_num(ws, 2, ws.max_row, [4, 8, 9])
unmatched = unmatched_m + unmatched_c
ws.append([])
ws.append(['未匹配往来待核', '母方ID', '摘要', '金额元', '子方ID', '摘要', '金额元', '说明'])
un_start = ws.max_row
for i in range(max(len(unmatched_m), len(unmatched_c), 1)):
    a = unmatched_m[i] if i < len(unmatched_m) else None
    b = unmatched_c[i] if i < len(unmatched_c) else None
    ws.append(['待核', a['id'] if a else '', a['summary'] if a else '', a['in'] if a else '',
               b['id'] if b else '', b['summary'] if b else '', b['out'] if b else '',
               '待核：不按金额自动抵销'])
un_end = ws.max_row
if unmatched:
    style_num(ws, un_start + 1, un_end, [4, 7])
else:
    ws.append(['待核', '—', '—', '', '—', '—', '', '本期无未匹配内部往来记录'])
ws.append([])
ws.append(['口径说明：仅抵销有匹配编号的内部收付款；金额相同但无匹配编号的往来不得自动抵销，列入待核。'])
for i, w in enumerate([16, 12, 14, 14, 12, 14, 14, 16, 16, 20], 1):
    ws.column_dimensions[get_column_letter(i)].width = w

# 5 集团汇总（主体相加后抵销匹配对）
gs = dict(sp)
for k, v in sc.items():
    gs[k] = gs.get(k, 0) + v
gs[('经营', '流入', '内部往来')] = gs.get(('经营', '流入', '内部往来'), 0) - elim_in
gs[('经营', '流出', '内部往来')] = gs.get(('经营', '流出', '内部往来'), 0) - elim_out
summary_sheet('集团汇总', '集团合并汇总（2026年5—6月，单位：人民币元，已抵销匹配编号内部往来）',
              [('集团合计（抵销后）', gs)],
              extra_note='抵销说明：抵销匹配编号 %s 对应内部往来流入 %.2f 元、流出 %.2f 元；未匹配往来见"内部抵销"表待核列。' % (MATCH_ID, elim_in, elim_out))

wb.save('outputs/集团现金流.xlsx')
print('saved')
