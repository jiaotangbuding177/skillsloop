# -*- coding: utf-8 -*-
from docx import Document
from docx.shared import Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

FONT = "Noto Sans CJK SC"

def set_font(run, size=8, bold=False, color=None):
    run.font.name = FONT
    run.font.size = Pt(size)
    run.font.bold = bold
    if color:
        run.font.color.rgb = RGBColor(*color)
    rPr = run._element.get_or_add_rPr()
    rFonts = rPr.find(qn('w:rFonts'))
    if rFonts is None:
        rFonts = OxmlElement('w:rFonts')
        rPr.append(rFonts)
    rFonts.set(qn('w:eastAsia'), FONT)
    rFonts.set(qn('w:ascii'), FONT)
    rFonts.set(qn('w:hAnsi'), FONT)

def cell_shading(cell, hex_color):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement('w:shd')
    shd.set(qn('w:val'), 'clear')
    shd.set(qn('w:fill'), hex_color)
    tcPr.append(shd)

def cell_text(cell, text, size=8, bold=False, color=None):
    cell.text = ""
    p = cell.paragraphs[0]
    p.paragraph_format.space_before = Pt(1)
    p.paragraph_format.space_after = Pt(1)
    r = p.add_run(text)
    set_font(r, size=size, bold=bold, color=color)

def header_row(table, headers, widths):
    for i, h in enumerate(headers):
        c = table.rows[0].cells[i]
        cell_text(c, h, bold=True, color=(0xFF,0xFF,0xFF))
        cell_shading(c, "1F4E79")
    for i, w in enumerate(widths):
        for row in table.rows:
            row.cells[i].width = Cm(w)

def add_table(doc, headers, rows, widths):
    t = doc.add_table(rows=1+len(rows), cols=len(headers))
    t.style = 'Table Grid'
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    t.autofit = False
    header_row(t, headers, widths)
    for ri, row in enumerate(rows, start=1):
        for ci, val in enumerate(row):
            cell_text(t.rows[ri].cells[ci], val)
        if ri % 2 == 0:
            for c in t.rows[ri].cells:
                cell_shading(c, "EDF3FA")
    return t

def section_title(doc, text):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(3)
    p.paragraph_format.space_after = Pt(1)
    r = p.add_run(text)
    set_font(r, size=10, bold=True, color=(0x1F,0x4E,0x79))

doc = Document()
for sec in doc.sections:
    sec.page_width, sec.page_height = Cm(21.0), Cm(29.7)
    sec.top_margin = sec.bottom_margin = Cm(0.9)
    sec.left_margin = sec.right_margin = Cm(1.2)

t = doc.add_paragraph()
t.alignment = WD_ALIGN_PARAGRAPH.CENTER
t.paragraph_format.space_after = Pt(1)
r = t.add_run("衡算工艺 竞争应对卡（对标：工联助手 / 现场智控）")
set_font(r, size=12, bold=True)
p = doc.add_paragraph()
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
p.paragraph_format.space_after = Pt(2)
r = p.add_run("目标客户：化工/制造企业知识检索类采购 | 用途：销售一线应对竞争 | 数据边界见各栏括注")
set_font(r, size=7.5, color=(0x59,0x59,0x59))

section_title(doc, "一、我方差异化优势（全部基于已列证据，边界如实标注）")
add_table(doc,
    ["维度", "衡算工艺（我方）", "工联助手", "现场智控", "差异化结论与边界"],
    [
        ["离线可用", "支持", "不支持", "支持", "网络隔离客户工联直接出局；现场智控虽离线但价值在控制设备，非知识检索。"],
        ["价格", "8万/年（1站点20人软件费，不含硬件与定制对接）", "6万/年", "15万/年", "低于现场智控7万、高于工联2万；报价必须说明不含硬件与定制对接。"],
        ["ERP已测", "3种", "8种", "2种", "兼容面弱于工联，仅可承诺已测3种内直接对接；名单外需定制（费用另计）。"],
        ["控制设备", "不支持", "不支持", "支持指定设备", "我方与工联均不做控制，不做闭环控制承诺。"],
        ["响应", "4工作小时（首次响应，非修复完成）", "8（同口径待证）", "2（同口径待证）", "仅承诺工作时间4小时首响；对手数据为书面答复无实测对比，不当场承诺修复时限。"],
        ["验证", "5厂32人试点；改善30%来自其中1厂8周样本", "公开10案例", "2厂6产线", "试点规模领先；30%仅为单厂8周数据，介绍时注明样本范围，不外推。"],
    ],
    [1.7, 4.0, 2.6, 2.6, 7.5])

section_title(doc, "二、客户常见异议应对话术（异议→核心答复→实证/待补证）")
add_table(doc,
    ["客户异议", "核心答复要点", "实证支撑 / 待补证"],
    [
        ["1. 你们太贵了，工联才6万", "2万差价买三样：离线可用（工联不支持）、4小时首响（工联8小时）、5厂32人真实试点。若客户可联网且预算紧，如实建议评估工联。", "实证：试点5厂32人；待补证：用其ERP与检索量现场测算ROI。"],
        ["2. 离线版维护是不是很难", "离线是产品设计能力，为网络隔离环境而生；隔离环境反而免除外部攻击面。", "待补证：维护流程与升级方式需售前演示确认，留操作手册。"],
        ["3. ERP兼容够不够", "如实说：已测3种，名单内直接对接；名单外需定制、费用另计。工联已测8种兼容面更广，不回避。", "实证：已测名单（售前带清单核对）；待补证：名单外对接工期与报价。"],
        ["4. 会不会自动操作我们的机器", "不会。我方不支持控制设备，仅做知识检索，不存在误操作产线风险，也无需设备侧安全审批。", "实证：产品边界明示不支持控制设备（与工联同口径）。"],
        ["5. 故障多久能响应", "如实说：4工作小时为工作时间首次响应，非修复完成，不冒充修复承诺。现场智控2小时首响更快，但15万/年且价值在控制设备。", "实证：SLA条款写明首响口径；待补证：历史平均修复时长统计。"],
    ],
    [3.6, 10.0, 4.8])

section_title(doc, "三、更适合我方的场景（2个）与不适合的场景（2个）")
add_table(doc,
    ["类型", "客户场景", "业务条件", "胜负逻辑"],
    [
        ["√ 更适合", "甲化工厂类：网络隔离环境的知识检索", "网络隔离；ERP在我方已测3种名单内；仅需知识检索，不碰设备。", "离线能力是硬门槛，工联不可用；现场智控多7万且其强项（控制）客户用不上。"],
        ["√ 更适合", "同构隔离站点：约1站点20人规模的离线检索需求", "预算8万量级、接受软件费口径；规模与试点经验（5厂32人）匹配。", "报价与试点规模匹配，交付风险低，可比照已有试点复制。"],
        ["× 不适合", "乙小仓库：预算5万且可联网", "预算低于8万软件费下限；环境可联网，离线优势无用。", "价格与能力均不匹配；如实转介评估工联助手（6万/年、可联网），不硬推。"],
        ["× 不适合", "丙产线：需闭环控制设备", "核心诉求是对设备的闭环控制。", "我方不支持控制设备（工联亦不支持）；应引导至现场智控（支持指定设备），不虚假承诺。"],
    ],
    [1.9, 4.2, 5.4, 6.9])

p = doc.add_paragraph()
p.paragraph_format.space_before = Pt(3)
r = p.add_run("数据来源与边界：衡算参数来自试点记录与产品边界（5厂32人；30%改善为其中1厂8周样本；8万=1站点20人软件费，不含硬件与定制对接；4小时为工作时间首响非修复）。工联与现场智控参数为供应商书面答复，未经实测对比。另：20种ERP全球部署类集团需求（丁类）超出我方已测3种范围，属不适合场景。")
set_font(r, size=7, color=(0x59,0x59,0x59))

doc.save("/workspace/outputs/battlecard.docx")
print("saved")
