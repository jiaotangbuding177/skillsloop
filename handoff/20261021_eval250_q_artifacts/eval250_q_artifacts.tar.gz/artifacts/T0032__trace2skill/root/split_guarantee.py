# -*- coding: utf-8 -*-
"""三方可转债协议 -> 剥离丙方及担保内容（一次性脚本化遍历）
产物: /workspace/outputs/不含担保的主协议.docx, 担保补充协议.docx, 剥离核对.xlsx
"""
import copy
from docx import Document
from docx.oxml.ns import qn
from docx.text.paragraph import Paragraph
from docx.enum.text import WD_ALIGN_PARAGRAPH
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment

SRC = "/workspace/inputs/三方可转债协议.docx"
OUT = "/workspace/outputs"
MAIN = f"{OUT}/不含担保的主协议.docx"
SUPP = f"{OUT}/担保补充协议.docx"
CHECK = f"{OUT}/剥离核对.xlsx"

def blocks(doc):
    out = []
    for child in doc.element.body.iterchildren():
        if child.tag == qn('w:p'):
            out.append(('p', Paragraph(child, doc)))
        elif child.tag == qn('w:tbl'):
            from docx.table import Table
            out.append(('t', Table(child, doc)))
    return out

def set_text(p, new):
    """保留段落样式，替换全部文字到首个 run。"""
    if p.runs:
        p.runs[0].text = new
        for r in p.runs[1:]:
            r.text = ""
    else:
        p.add_run(new)

# ============ 1. 主协议 ============
doc = Document(SRC)
bl = blocks(doc)
log = []  # (原块序, 原文, 处置, 说明)

# 精确锚点编辑（strip 后全文匹配，单实例）
EDITS = {
    "可转债投资与担保三方协议":
        ("改为", "可转债投资协议"),
    "甲方为澄川设备公司（借款方），乙方为恒澜投资公司（出借方），丙方为云衡技术公司（担保方）。 双方联系人使用职务称谓，签署人授权待公司确认。本协议仅用于金额1000000元的可转债投资，不得扩大为与本项目无关的业务。":
        ("改为", "甲方为澄川设备公司（借款方），乙方为恒澜投资公司（出借方）。双方联系人使用职务称谓，签署人授权待公司确认。本协议仅用于金额1000000元的可转债投资，不得扩大为与本项目无关的业务。本协议项下的担保安排由甲方、乙方与丙方（云衡技术公司，担保方）另行签署《担保补充协议》约定，不在本协议内。"),
    "5.3未发生合格融资则到期还本付息。主协议附件一是本金、日期、用途和转换条件。":
        ("改为", "5.3未发生合格融资则到期还本付息。本协议附件一载明本金、日期、用途和转换条件。"),
    "7.1甲方按季提供研发进度和资金使用；7.2甲方应及时告知可能影响清偿事项，同时通知乙方和丙方。":
        ("改为", "6.1甲方按季提供研发进度和资金使用；6.2甲方应及时告知可能影响清偿事项，同时通知乙方。"),
    "8.1甲方迟延清偿按未付金额每日0.02%违约金；8.2丙方按6.1担保；8.3乙方未按约定出资可解除。":
        ("改为", "7.1甲方迟延清偿按未付金额每日0.02%违约金；7.2乙方未按约定出资可解除。"),
    "本协议经甲乙丙三方签署生效；附件二丙方担保确认与6.1一致。":
        ("改为", "本协议经甲乙双方签署生效。"),
    "7 风险及信息": ("改为", "6 风险及信息"),
    "8 违约": ("改为", "7 违约"),
    "9 签署": ("改为", "8 签署"),
    "10 资料与既有知识产权": ("改为", "9 资料与既有知识产权"),
    "11 通知、争议与文本": ("改为", "10 通知、争议与文本"),
    "12 生效与签署": ("改为", "11 生效与签署"),
}
# 整块移入补充协议的锚点
MOVE = {
    "6 丙方担保",
    "6.1 丙方对本金、利息和本协议明确违约金承担连带担保；6.2担保期间自到期日起12个月；6.3乙方追索须按书面渠道通知丙方。",
}

moved_texts = []
for kind, obj in bl:
    if kind != 'p':
        continue
    t = obj.text.strip()
    if t in MOVE:
        moved_texts.append(t)
        log.append((obj.text, "移入补充协议", t[:40]))
        obj._element.getparent().remove(obj._element)
    elif t in EDITS:
        act, new = EDITS[t]
        log.append((t, act, new[:40]))
        set_text(obj, new)
    else:
        log.append((t, "保留", ""))

doc.save(MAIN)

# ============ 2. 担保补充协议 ============
s = Document()
st = s.styles['Normal']
st.font.name = '宋体'
st._element.rPr.rFonts.set(qn('w:eastAsia'), '宋体')

def para(text, bold=False, size=None, align=None):
    p = s.add_paragraph()
    r = p.add_run(text)
    r.bold = bold
    if size: r.font.size = size
    if align: p.alignment = align
    return p

para("担保补充协议", bold=True, size=None, align=WD_ALIGN_PARAGRAPH.CENTER)
para("（可转债投资协议之从合同）", align=WD_ALIGN_PARAGRAPH.CENTER)
para("稿件状态：待三方确认；文本版本与签署日期以最终签署为准。")
para("甲方（借款方）：澄川设备公司（与主协议甲方一致）")
para("乙方（出借方）：恒澜投资公司（与主协议乙方一致）")
para("丙方（担保人）：云衡技术公司")
para("鉴于：甲方与乙方已签署或拟签署《可转债投资协议》（文本版本：______，签署日期：______，以下简称“主协议”）。为担保主协议项下乙方债权的实现，甲、乙、丙三方经协商一致，达成如下补充协议：")
para("第一条 主协议引用与从属性")
para("1.1 本补充协议为主协议之从合同。本协议所称主协议，指甲方与乙方签署的《可转债投资协议》（文本版本：______，签署日期：______），包括其附件一（本金、日期、用途和转换条件）及经双方书面确认的版本记录。")
para("1.2 主协议内容变更未经丙方书面同意的，丙方对加重部分不承担担保责任。")
para("第二条 担保范围")
para("丙方对主协议项下的本金、利息以及主协议第7条（违约）约定的违约金（甲方迟延清偿按未付金额每日0.02%）承担连带保证担保。")
para("第三条 担保期间")
para("保证期间自主协议项下债务到期日起12个月。")
para("第四条 追索与通知")
para("乙方向丙方追索的，须按主协议第10条（通知、争议与文本）约定的书面渠道通知丙方。")
para("第五条 与主协议的关系")
para("本补充协议与主协议就担保事项约定不一致的，以本补充协议为准；本补充协议未尽事宜，参照主协议执行。")
para("附件：丙方担保确认函（确认内容与本协议第二、三条一致）。")
para("（以下无正文，为签署页）")
para("甲方授权代表：______  日期：______")
para("乙方授权代表：______  日期：______")
para("丙方授权代表：______  日期：______")
s.save(SUPP)

# ============ 3. 剥离核对.xlsx ============
wb = Workbook()
ws = wb.active
ws.title = "剥离明细"
hdr = ["原块序", "类型", "原文（截断）", "处置", "说明/新文（截断）"]
ws.append(hdr)
# 从源文档重建完整清单（含删除块），与 log 对齐
src = Document(SRC)
src_texts = [o.text.strip() for k, o in blocks(src) if k == 'p']
# log 顺序与源文档块序一致（MOVE/EDITS 均按原文匹配）
li = 0
for i, t in enumerate(src_texts):
    _, act, note = log[li]
    li += 1
    ws.append([i, "段落", t[:120], act, note[:120]])
fill_y = PatternFill("solid", fgColor="FFF2CC")
fill_g = PatternFill("solid", fgColor="E2EFDA")
for row in ws.iter_rows(min_row=2):
    if row[3].value == "移入补充协议":
        for c in row: c.fill = fill_y
    elif str(row[3].value).startswith("改为"):
        for c in row: c.fill = fill_g
for col, w in zip("ABCDE", [8, 8, 60, 14, 60]):
    ws.column_dimensions[col].width = w

ws2 = wb.create_sheet("核验")
ws2.append(["核验项", "结果", "说明"])
ws2.append(["主协议无“丙方”残留", "待检", "除第1条对《担保补充协议》的桥接引用外为零残留"])
ws2.append(["主协议无“连带/保证/担保条款”残留", "待检", "同上"])
ws2.append(["商业条款保留：本金1000000元", "待检", "第3条费用与结算"])
ws2.append(["商业条款保留：年利率10%、12个月", "待检", "第3条"])
ws2.append(["商业条款保留：转股触发5000000元", "待检", "第5条借款与转换"])
ws2.append(["商业条款保留：违约金每日0.02%", "待检", "第7条违约"])
ws2.append(["补充协议引用主协议版本", "✓", "鉴于条款+第一条（文本版本/签署日期留空待签）"])
ws2.append(["补充协议明确担保范围", "✓", "第二条（本金、利息、违约金）"])
ws2.append(["补充协议明确担保期间", "✓", "第三条（到期日起12个月）"])
ws2.append(["补充协议明确通知渠道", "✓", "第四条（引主协议第10条书面渠道）"])
ws2.append(["附件核对", "✓", "附件一（商业）留主协议；附件二（丙方担保确认）并入补充协议附件"])
for c in ws2[1]: c.font = Font(bold=True)
for col, w in zip("ABC", [36, 8, 60]):
    ws2.column_dimensions[col].width = w
wb.save(CHECK)
print("生成完成")
print("移动块数:", len(moved_texts), "| 编辑处数:", sum(1 for _,a,_ in log if a.startswith("改为")))
