# search_index 使用说明

## 覆盖范围

本索引覆盖 `/workspace/inputs/docs/` 下全部 **12 份资料**（12/12 收录，每文档恰好 1 条），索引文件为 `search_index.json`。

## 字段说明

| 字段 | 含义 |
| --- | --- |
| title | 文档标题（取自正文一级标题） |
| path | 相对 `/workspace/inputs` 的路径，保留中文文件名 |
| updated | 正文标注的更新日期 |
| version | 正文标注的版本号（当前 12 份均为 1.0） |
| owner | 正文标注的负责人/部门 |
| keywords | 取自正文内容的关键词 |
| snippet | 直接摘自正文的匹配摘录 |

## 按关键词查找

索引支持按关键词匹配 **标题、路径、更新时间、匹配摘录**。示例：

- 查「报价」→ `01_采购报价.md`（path 与 snippet 命中）
- 查「2026-09-07」→ `07_项目预算.md`（updated 命中）
- 查「验收」→ `09_验收清单.md`（title、path、keywords 命中）
- 查「4小时」→ `10_服务承诺.md`（snippet 命中）

也可以用 `grep` 直接检索 JSON 文件，例如：

```bash
grep "权限" /workspace/outputs/search_index.json
```

## 边界说明

- 索引只提供**定位**信息（标题、路径、时间、摘录），不代表阅读者拥有正文权限；正文访问仍按 `04_权限规则.md` 执行。
- 所有 snippet 均逐字摘自各文档正文，未添加材料中不存在的事实，未引用任何外部链接。
- 中文文件名与版本号均按原文保留。
