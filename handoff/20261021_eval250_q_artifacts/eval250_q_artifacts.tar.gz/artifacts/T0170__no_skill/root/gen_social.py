# -*- coding: utf-8 -*-
import csv
from decimal import Decimal, ROUND_HALF_UP
from docx import Document
from docx.shared import Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.section import WD_SECTION, WD_ORIENT
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
import openpyxl
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
from openpyxl.utils import get_column_letter

LOWER, UPPER = Decimal('6200'), Decimal('31000')
PERSONAL_RATES = [('养老', Decimal('0.08')), ('医疗', Decimal('0.02')), ('失业', Decimal('0.005'))]
COMPANY_RATES = [('养老', Decimal('0.16')), ('医疗', Decimal('0.09')), ('失业', Decimal('0.005')), ('工伤', Decimal('0.004'))]

def r2(x):
    return Decimal(x).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)

def calc(base, rates):
    out = []
    for name, rate in rates:
        out.append((name, rate, r2(Decimal(base) * rate)))
    return out

# read csv
people = []
with open('/workspace/inputs/人员基数明细.csv', newline='', encoding='utf-8-sig') as f:
    for row in csv.DictReader(f):
        people.append({
            'id': row['员工编号'], 'name': row['称谓'],
            'avg': Decimal(row['上年度月均工资元']),
            'old_base': Decimal(row['原缴费基数元']),
            'status': row['状态'],
        })

active = [p for p in people if p['status'] == '在岗']
left = [p for p in people if p['status'] != '在岗']

for p in active:
    nb = min(max(p['avg'], LOWER), UPPER)
    p['new_base'] = nb.quantize(Decimal('1'))  # integer yuan
    if p['avg'] < LOWER:
        p['cap'] = '按下限6200元'
    elif p['avg'] > UPPER:
        p['cap'] = '按上限31000元'
    else:
        p['cap'] = '按实际月均'
    # old totals (same rates on old base)
    po = calc(p['old_base'], PERSONAL_RATES); co = calc(p['old_base'], COMPANY_RATES)
    pn = calc(p['new_base'], PERSONAL_RATES); cn = calc(p['new_base'], COMPANY_RATES)
    p['old_p_items'], p['old_c_items'] = po, co
    p['new_p_items'], p['new_c_items'] = pn, cn
    p['old_p'] = r2(sum(v for _,_,v in po))
    p['old_c'] = r2(sum(v for _,_,v in co))
    p['new_p'] = r2(sum(v for _,_,v in pn))
    p['new_c'] = r2(sum(v for _,_,v in cn))
    p['d_p'] = r2(p['new_p'] - p['old_p'])
    p['d_c'] = r2(p['new_c'] - p['old_c'])
    p['d_t'] = r2(p['d_p'] + p['d_c'])

tot_old_p = r2(sum(p['old_p'] for p in active))
tot_old_c = r2(sum(p['old_c'] for p in active))
tot_new_p = r2(sum(p['new_p'] for p in active))
tot_new_c = r2(sum(p['new_c'] for p in active))
tot_dp = r2(sum(p['d_p'] for p in active))
tot_dc = r2(sum(p['d_c'] for p in active))
tot_dt = r2(sum(p['d_t'] for p in active))

fmt = lambda d: f'{d:,.2f}'
fmi = lambda d: f'{int(d):,}'

# ============ XLSX ============
wb = openpyxl.Workbook()
thin = Side(style='thin', color='999999')
border = Border(left=thin, right=thin, top=thin, bottom=thin)
hfill = PatternFill('solid', fgColor='D9E2F3')
tfill = PatternFill('solid', fgColor='1F4E79')
hfont = Font(name='Noto Sans CJK SC', bold=True, size=10)
tfont = Font(name='Noto Sans CJK SC', bold=True, size=14, color='FFFFFF')
font = Font(name='Noto Sans CJK SC', size=10)
bold = Font(name='Noto Sans CJK SC', size=10, bold=True)
red = Font(name='Noto Sans CJK SC', size=10, color='C00000', bold=True)
center = Alignment(horizontal='center', vertical='center', wrap_text=True)
right = Alignment(horizontal='right', vertical='center')
left_a = Alignment(horizontal='left', vertical='center', wrap_text=True)

def style_cell(c, f=font, a=center, b=True):
    c.font = f; c.alignment = a; c.border = border
    if b: c.border = border

# --- Sheet 1: 汇总 ---
ws = wb.active
ws.title = '调整汇总'
ws.sheet_view.showGridLines = False
ws.merge_cells('A1:H1')
c = ws['A1']; c.value = '2026年10月社保基数调整测算汇总表'; c.font = tfont; c.fill = tfill; c.alignment = center
ws.row_dimensions[1].height = 30

rows = [
    ('调整口径', '以本人上年度月平均工资为缴费基数，低于6200元按6200元，高于31000元按31000元，其余按实际月平均工资，统一保留整数元；10月起执行。'),
    ('费率（个人）', '养老8%、医疗2%、失业0.5%；不含住房公积金。'),
    ('费率（单位）', '养老16%、医疗9%、失业0.5%、工伤0.4%；不含住房公积金。'),
    ('计算规则', '每人每险种先按基数×费率计算并四舍五入到分，再汇总个人/单位合计；不计算补缴，不按当月工资变化自动变更基数。'),
    ('适用范围', '员工明细中的在岗人员共29人；离职人员3人（E009、E018、E027）不纳入本次调整。'),
]
r0 = 3
ws.cell(r0-1, 1, '一、调整口径').font = bold
for i, (k, v) in enumerate(rows):
    ws.cell(r0+i, 1, k).font = hfont; ws.cell(r0+i, 1).fill = hfill
    ws.cell(r0+i, 1).alignment = center
    ws.merge_cells(start_row=r0+i, start_column=2, end_row=r0+i, end_column=8)
    cc = ws.cell(r0+i, 2, v); cc.font = font; cc.alignment = left_a
    for col in range(1, 9): ws.cell(r0+i, col).border = border

r1 = r0 + len(rows) + 1
ws.cell(r1, 1, '二、责任流程').font = bold
flow = [('1. HR', '核定上年度工资和员工在岗状态'), ('2. 薪酬专员', '编制调整测算表'),
        ('3. 财务', '复核测算数据与总额'), ('4. 负责人', '审批通过后再行录入'),
        ('说明', '本次仅整理报告与测算，不实际申报。')]
for i, (k, v) in enumerate(flow):
    ws.cell(r1+1+i, 1, k).font = hfont; ws.cell(r1+1+i, 1).fill = hfill; ws.cell(r1+1+i, 1).alignment = center
    ws.merge_cells(start_row=r1+1+i, start_column=2, end_row=r1+1+i, end_column=8)
    cc = ws.cell(r1+1+i, 2, v); cc.font = font; cc.alignment = left_a
    for col in range(1, 9): ws.cell(r1+1+i, col).border = border

r2_ = r1 + len(flow) + 2
ws.cell(r2_, 1, '三、人数与费用变化（在岗29人）').font = bold
headers = ['项目', '调整前（元/月）', '调整后（元/月）', '差额（元/月）', '说明']
for j, h in enumerate(headers):
    c = ws.cell(r2_+1, j+1, h); style_cell(c, hfont, center); c.fill = hfill
sumrows = [
    ('个人缴费合计', tot_old_p, tot_new_p, tot_dp, '个人养老+医疗+失业'),
    ('单位缴费合计', tot_old_c, tot_new_c, tot_dc, '单位养老+医疗+失业+工伤'),
    ('公司总负担', r2(tot_old_p+tot_old_c), r2(tot_new_p+tot_new_c), tot_dt, '个人+单位合计'),
]
for i, (k, a, b_, d, note) in enumerate(sumrows):
    rr = r2_+2+i
    vals = [k, fmt(a), fmt(b_), ('+' if d>0 else '')+fmt(d), note]
    for j, v in enumerate(vals):
        c = ws.cell(rr, j+1, v)
        style_cell(c, red if j==3 and d>0 else font, right if j in (1,2,3) else center)
        if k == '公司总负担': c.font = bold if j != 3 else red
    ws.cell(rr, 3).value = float(b_); ws.cell(rr, 2).value = float(a); ws.cell(rr, 4).value = float(d)
    for col in (2,3,4): ws.cell(rr, col).number_format = '#,##0.00'
ws.cell(r2_+5, 1, '注：以上均为月度金额；财务总额与人员明细逐人合计一致。').font = Font(name='Noto Sans CJK SC', size=9, italic=True)
ws.merge_cells(start_row=r2_+5, start_column=1, end_row=r2_+5, end_column=8)

widths = [16, 14, 14, 14, 14, 12, 12, 24]
for i, w in enumerate(widths): ws.column_dimensions[get_column_letter(i+1)].width = w

# --- Sheet 2: 逐人明细 ---
ws2 = wb.create_sheet('逐人测算明细')
ws2.sheet_view.showGridLines = False
ws2.merge_cells('A1:S1')
c = ws2['A1']; c.value = '在岗人员逐人社保测算明细（2026年10月起执行，单位：元）'; c.font = tfont; c.fill = tfill; c.alignment = center
ws2.row_dimensions[1].height = 28
headers = ['员工编号','称谓','上年度月均工资','原缴费基数','调整后基数','基数判定',
           '原个人合计','原单位合计',
           '个人-养老8%','个人-医疗2%','个人-失业0.5%','个人合计',
           '单位-养老16%','单位-医疗9%','单位-失业0.5%','单位-工伤0.4%','单位合计',
           '个人差额','单位差额']
for j, h in enumerate(headers):
    c = ws2.cell(2, j+1, h); style_cell(c, hfont, center); c.fill = hfill
ws2.row_dimensions[2].height = 30
for i, p in enumerate(active):
    rr = 3+i
    vals = [p['id'], p['name'], float(p['avg']), float(p['old_base']), float(p['new_base']), p['cap'],
            float(p['old_p']), float(p['old_c'])]
    vals += [float(v) for _,_,v in p['new_p_items']] + [float(p['new_p'])]
    vals += [float(v) for _,_,v in p['new_c_items']] + [float(p['new_c'])]
    vals += [float(p['d_p']), float(p['d_c'])]
    for j, v in enumerate(vals):
        c = ws2.cell(rr, j+1, v)
        style_cell(c, font, right if j >= 2 else center)
        if j >= 2 and j != 5: c.number_format = '#,##0.00'
        elif j == 5: pass
    if p['d_p'] > 0 or p['d_c'] > 0:
        ws2.cell(rr, 18).font = red; ws2.cell(rr, 19).font = red
# totals row
rr = 3+len(active)
ws2.cell(rr, 1, '合计'); ws2.cell(rr, 2, f'{len(active)}人')
totals = {3: tot_old_p, 4: tot_old_c, 5: None, 7: None, 8: None}
ws2.cell(rr, 7, float(tot_old_p)); ws2.cell(rr, 8, float(tot_old_c))
for k in range(3): ws2.cell(rr, 9+k, float(r2(sum(p['new_p_items'][k][2] for p in active))))
ws2.cell(rr, 12, float(tot_new_p))
for k in range(4): ws2.cell(rr, 13+k, float(r2(sum(p['new_c_items'][k][2] for p in active))))
ws2.cell(rr, 17, float(tot_new_c))
ws2.cell(rr, 18, float(tot_dp)); ws2.cell(rr, 19, float(tot_dc))
for j in range(1, 20):
    c = ws2.cell(rr, j); style_cell(c, bold, right if j >= 3 else center); c.fill = hfill
    if j >= 3: c.number_format = '#,##0.00'
for i, w in enumerate([10,9,14,12,12,22,12,12,12,12,13,11,13,12,13,13,12,11,11]):
    ws2.column_dimensions[get_column_letter(i+1)].width = w
ws2.freeze_panes = 'C3'

# --- Sheet 3: 离职人员 ---
ws3 = wb.create_sheet('离职人员')
ws3.sheet_view.showGridLines = False
ws3.merge_cells('A1:F1')
c = ws3['A1']; c.value = '离职人员名单（不纳入本次调整）'; c.font = tfont; c.fill = tfill; c.alignment = center
ws3.row_dimensions[1].height = 28
for j, h in enumerate(['员工编号','称谓','上年度月均工资（元）','原缴费基数（元）','状态','处理说明']):
    c = ws3.cell(2, j+1, h); style_cell(c, hfont, center); c.fill = hfill
for i, p in enumerate(left):
    vals = [p['id'], p['name'], float(p['avg']), float(p['old_base']), p['status'], '已离职，不进入本次调整，不参与基数变更与测算']
    for j, v in enumerate(vals):
        c = ws3.cell(3+i, j+1, v)
        style_cell(c, font, right if j in (2,3) else center)
        if j in (2,3): c.number_format = '#,##0'
for i, w in enumerate([10,9,18,16,10,42]):
    ws3.column_dimensions[get_column_letter(i+1)].width = w

wb.save('/workspace/outputs/社保调整测算.xlsx')
print('xlsx ok; totals:', tot_old_p, tot_new_p, tot_dp, tot_old_c, tot_new_c, tot_dc, tot_dt)

# ============ DOCX ============
doc = Document()
st = doc.styles['Normal']
st.font.name = 'Noto Sans CJK SC'; st.font.size = Pt(10.5)
st.element.rPr.rFonts.set(qn('w:eastAsia'), 'Noto Sans CJK SC')

def set_cell(cell, text, bold_=False, size=9.5, align='center', color=None):
    cell.text = ''
    p = cell.paragraphs[0]
    p.alignment = {'center': WD_ALIGN_PARAGRAPH.CENTER, 'left': WD_ALIGN_PARAGRAPH.LEFT, 'right': WD_ALIGN_PARAGRAPH.RIGHT}[align]
    run = p.add_run(text)
    run.font.name = 'Noto Sans CJK SC'; run.font.size = Pt(size); run.bold = bold_
    run._element.rPr.rFonts.set(qn('w:eastAsia'), 'Noto Sans CJK SC')
    if color: run.font.color.rgb = RGBColor(*color)

def add_table(doc, headers, rows_data, widths=None, header_fill='D9E2F3', size=9.5):
    t = doc.add_table(rows=1+len(rows_data), cols=len(headers))
    t.style = 'Table Grid'; t.alignment = WD_TABLE_ALIGNMENT.CENTER
    t.autofit = False
    tblPr = t._tbl.tblPr
    layout = OxmlElement('w:tblLayout'); layout.set(qn('w:type'), 'fixed')
    tblPr.append(layout)
    mar = OxmlElement('w:tblCellMar')
    for side in ('left', 'right'):
        el = OxmlElement(f'w:{side}')
        el.set(qn('w:w'), '45'); el.set(qn('w:type'), 'dxa')
        mar.append(el)
    tblPr.append(mar)
    for j, h in enumerate(headers):
        set_cell(t.rows[0].cells[j], h, bold_=True, size=size)
        # shading
        tcPr = t.rows[0].cells[j]._tc.get_or_add_tcPr()
        shd = OxmlElement('w:shd'); shd.set(qn('w:val'), 'clear'); shd.set(qn('w:fill'), header_fill)
        tcPr.append(shd)
    for i, row in enumerate(rows_data):
        for j, v in enumerate(row):
            if isinstance(v, tuple):  # (text, bold, color[, size])
                set_cell(t.rows[i+1].cells[j], v[0], bold_=v[1], color=v[2], size=(v[3] if len(v) > 3 else size))
            else:
                set_cell(t.rows[i+1].cells[j], v, size=size)
    if widths:
        for j, w in enumerate(widths):
            for row in t.rows:
                row.cells[j].width = Cm(w)
        grid = t._tbl.find(qn('w:tblGrid'))
        if grid is not None:
            for gc, w in zip(grid.findall(qn('w:gridCol')), widths):
                gc.set(qn('w:w'), str(int(round(w * 567))))
        tblW = OxmlElement('w:tblW')
        tblW.set(qn('w:w'), str(int(round(sum(widths) * 567))))
        tblW.set(qn('w:type'), 'dxa')
        tblPr.append(tblW)
    return t

def heading(text, size=14):
    p = doc.add_paragraph()
    r = p.add_run(text); r.bold = True; r.font.size = Pt(size)
    r.font.name = 'Noto Sans CJK SC'; r._element.rPr.rFonts.set(qn('w:eastAsia'), 'Noto Sans CJK SC')
    p.space_before = Pt(6)
    return p

tt = doc.add_paragraph(); tt.alignment = WD_ALIGN_PARAGRAPH.CENTER
r = tt.add_run('2026年10月社保基数调整汇报'); r.bold = True; r.font.size = Pt(18)
r.font.name = 'Noto Sans CJK SC'; r._element.rPr.rFonts.set(qn('w:eastAsia'), 'Noto Sans CJK SC')
sub = doc.add_paragraph(); sub.alignment = WD_ALIGN_PARAGRAPH.CENTER
r = sub.add_run('汇报单位：行政人事部　　汇报日期：2026年10月'); r.font.size = Pt(10); r.font.color.rgb = RGBColor(0x60,0x60,0x60)
r.font.name = 'Noto Sans CJK SC'; r._element.rPr.rFonts.set(qn('w:eastAsia'), 'Noto Sans CJK SC')

heading('一、调整口径')
p = doc.add_paragraph('根据公司批准的实施通知，本次调整口径如下（10月起执行，不涉及地方政策判断）：')
add_table(doc, ['项目', '口径内容'], [
    ('缴费基数', '以本人上年度月平均工资为基础：低于6200元按6200元，高于31000元按31000元，其余按实际月平均工资，统一保留整数元。'),
    ('个人费率', '养老8%、医疗2%、失业0.5%（合计10.5%）。'),
    ('单位费率', '养老16%、医疗9%、失业0.5%、工伤0.4%（合计25.9%）。'),
    ('计算规则', '每人每险种先按基数×费率计算并四舍五入到分，再汇总个人/单位合计。'),
    ('范围约定', '不含住房公积金；不计算补缴；不按工资当月变化自动变更基数。'),
    ('适用范围', '在岗人员29人；离职人员3人不纳入本次调整。'),
], widths=[3.2, 12.8])

heading('二、实施责任与流程')
add_table(doc, ['环节', '责任主体', '工作内容'], [
    ('1', 'HR', '核定上年度工资和员工在岗状态'),
    ('2', '薪酬专员', '编制调整测算表'),
    ('3', '财务', '复核测算数据与总额（与人员明细合计一致）'),
    ('4', '负责人', '审批通过后再行录入'),
    ('备注', '—', '本次仅整理报告与测算，不实际申报。'),
], widths=[1.5, 3.5, 11.0])

heading('三、人数与费用变化（在岗29人，单位：元/月）')
add_table(doc, ['项目', '调整前', '调整后', '差额', '说明'], [
    ('个人缴费合计', fmt(tot_old_p), fmt(tot_new_p), ('+' if tot_dp>0 else '')+fmt(tot_dp), '个人养老+医疗+失业'),
    ('单位缴费合计', fmt(tot_old_c), fmt(tot_new_c), ('+' if tot_dc>0 else '')+fmt(tot_dc), '单位养老+医疗+失业+工伤'),
    (('公司总负担', True, None), fmt(r2(tot_old_p+tot_old_c)), fmt(r2(tot_new_p+tot_new_c)),
     ('+'+fmt(tot_dt), True, (0xC0,0,0)), ('个人+单位合计', True, None)),
], widths=[3.0, 2.8, 2.8, 2.6, 4.8])
p = doc.add_paragraph()
r = p.add_run('注：以上为月度金额；财务总额与逐人测算明细合计一致。涉及基数变化的人数见附件逐人明细（差额为红色标注）。')
r.font.size = Pt(9); r.font.color.rgb = RGBColor(0x60,0x60,0x60)
r.font.name = 'Noto Sans CJK SC'; r._element.rPr.rFonts.set(qn('w:eastAsia'), 'Noto Sans CJK SC')

# count changed-base people
changed = [p for p in active if p['old_base'] != p['new_base']]
heading('四、结论')
p = doc.add_paragraph(
    f'本次调整涉及在岗人员29人，其中缴费基数发生变化{len(changed)}人。'
    f'调整后个人月缴合计{fmt(tot_new_p)}元，单位月缴合计{fmt(tot_new_c)}元，'
    f'公司月度总负担较调整前增加{fmt(tot_dt)}元。'
    '材料按上述流程经财务复核、负责人审批后再行录入，本次不实际申报。')

doc.add_page_break()

# landscape section for the wide attachment table
sec = doc.add_section(WD_SECTION.NEW_PAGE)
sec.orientation = WD_ORIENT.LANDSCAPE
new_w, new_h = sec.page_height, sec.page_width
sec.page_width, sec.page_height = new_w, new_h
sec.left_margin = Cm(1.5); sec.right_margin = Cm(1.5)
sec.top_margin = Cm(1.5); sec.bottom_margin = Cm(1.5)

heading('附件：在岗人员逐人测算明细（单位：元）', 13)
p = doc.add_paragraph()
r = p.add_run('说明：调整后基数按上下限口径确定；各险种金额四舍五入到分；离职人员（E009、E018、E027）单列于附表二，不纳入调整。')
r.font.size = Pt(9); r.font.color.rgb = RGBColor(0x60,0x60,0x60)
r.font.name = 'Noto Sans CJK SC'; r._element.rPr.rFonts.set(qn('w:eastAsia'), 'Noto Sans CJK SC')

hdr = ['编号','月均工资','原基数','调整后基数','基数判定','个养8%','个医2%','个失0.5%','个人合计',
       '单养16%','单医9%','单失0.5%','单工0.4%','单位合计','个差额','单差额']
def raw(d): return str(d)
rows_data = []
for p_ in active:
    rows_data.append([
        p_['id'], raw(p_['avg']), raw(p_['old_base']), raw(p_['new_base']), p_['cap'],
        raw(p_['new_p_items'][0][2]), raw(p_['new_p_items'][1][2]), raw(p_['new_p_items'][2][2]), raw(p_['new_p']),
        raw(p_['new_c_items'][0][2]), raw(p_['new_c_items'][1][2]), raw(p_['new_c_items'][2][2]), raw(p_['new_c_items'][3][2]), raw(p_['new_c']),
        ('+'+raw(p_['d_p']), False, (0xC0,0,0)) if p_['d_p']>0 else raw(p_['d_p']),
        ('+'+raw(p_['d_c']), False, (0xC0,0,0)) if p_['d_c']>0 else raw(p_['d_c']),
    ])
rows_data.append([
    ('合计', True, None, 8), '', '', '', ('29人', True, None, 8),
    (raw(r2(sum(p_['new_p_items'][0][2] for p_ in active))), True, None, 8), (raw(r2(sum(p_['new_p_items'][1][2] for p_ in active))), True, None, 8),
    (raw(r2(sum(p_['new_p_items'][2][2] for p_ in active))), True, None, 8), (raw(tot_new_p), True, None, 8),
    (raw(r2(sum(p_['new_c_items'][0][2] for p_ in active))), True, None, 8), (raw(r2(sum(p_['new_c_items'][1][2] for p_ in active))), True, None, 8),
    (raw(r2(sum(p_['new_c_items'][2][2] for p_ in active))), True, None, 8), (raw(r2(sum(p_['new_c_items'][3][2] for p_ in active))), True, None, 8),
    (raw(tot_new_c), True, None, 8), (raw(tot_dp), True, None, 8), (raw(tot_dc), True, None, 8),
])
add_table(doc, hdr, rows_data, widths=[1.25,1.7,1.5,1.7,1.25,1.6,1.45,1.5,1.85,1.95,1.45,1.5,1.4,2.4,1.8,1.8], size=9)

p = doc.add_paragraph(); p.paragraph_format.space_before = Pt(10)
heading('附表二：离职人员（不纳入本次调整）', 12)
add_table(doc, ['员工编号','称谓','上年度月均工资（元）','原缴费基数（元）','状态','处理说明'],
          [[p_['id'], p_['name'], fmi(p_['avg']), fmi(p_['old_base']), p_['status'], '已离职，不进入本次调整，不参与基数变更与测算'] for p_ in left],
          widths=[2.0, 1.8, 3.0, 2.8, 1.8, 4.6])

doc.save('/workspace/outputs/社保调整汇报.docx')
print('docx ok; changed people:', len(changed))
