# -*- coding: utf-8 -*-
"""生成 investor_shortlist.xlsx 与 outreach_brief.docx"""
import csv
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from docx import Document
from docx.shared import Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT

# ---------- 数据：逐条硬约束核对 ----------
# 硬约束定义（源自 company_constraints.md）
HARD = [
    "A. 阶段匹配：机构投资阶段需覆盖种子期",
    "B. 额度匹配：单笔投资能力需覆盖 2000–3000 万元（不足者需明确联合投资补足）",
    "C. 总部不迁移：机构不得要求本轮迁移总部（研发必须留苏州；可异地设销售分支）",
    "D. 研发不迁移：机构不得要求研发迁出苏州",
    "E. 行业匹配：投资方向优先工业软件、企业 AI",
    "F. 领投能力：需一家可领投；『可能领投』仅视为待确认意愿，不作为承诺",
    "G. 无保本回购：公司不接受保本回购条款，机构不得附带此要求",
]

FUNDS = [
    {
        "name": "栖原资本", "stage": "种子-A", "ticket": "1000-3000",
        "ind": "工业软件", "hq": "待核", "rd": "否", "lead": "是", "buyback": "待核",
        "rank": 1, "status": "优先接洽",
        "hard": {"A": "满足（种子-A 覆盖种子期）", "B": "满足（上限 3000 万覆盖全额需求）",
                 "C": "待确认（总部迁移标注为『待核』，接洽前必须书面确认不迁总部）",
                 "D": "满足（研发迁移为否）", "E": "满足（工业软件，与公司方向一致）",
                 "F": "满足（明确可领投）", "G": "待确认（回购要求『待核』，须确认不设保本回购）"},
        "reason": "阶段、额度、行业、领投意愿四项核心条件与本项目最吻合：种子-A 阶段策略、单笔 1000-3000 万恰好覆盖 2000-3000 万融资需求、专注工业软件、明确可领投；研发迁移为否。唯一不确定项是总部迁移与回购条款均标注『待核』，若任一项为『要求/保本』则不满足硬约束。",
        "todo": ["书面确认其不要求本轮迁移总部", "书面确认不设保本回购条款（回购待核的真实含义）", "确认当前可投余额、单项目上限与投决流程周期", "确认领投额度分配（其自身出资额）与是否需引入跟投方"],
    },
    {
        "name": "启航创投", "stage": "种子-PreA", "ticket": "1000-2500",
        "ind": "工业软件", "hq": "否", "rd": "否", "lead": "可能", "buyback": "无",
        "rank": 2, "status": "优先接洽",
        "hard": {"A": "满足（种子-PreA 覆盖种子期）", "B": "部分满足（上限 2500 万，若按 3000 万融资需联合投资补足 500 万以上）",
                 "C": "满足（总部迁移为否）", "D": "满足（研发迁移为否）", "E": "满足（工业软件）",
                 "F": "待确认（标注『可能领投』，仅为意愿信号，不构成承诺）", "G": "满足（无回购要求）"},
        "reason": "硬约束 C/D/G 三项明确满足且行业方向契合；单笔上限 2500 万覆盖 2000-2500 万融资方案，但按 3000 万融资存在 500 万以上缺口。领投仅为『可能』，在拿到其明确的领投确认函前不应计入领投方案。",
        "todo": ["确认其本轮领投意愿是否明确，以及领投条件", "确认 3000 万融资方案下单笔上限能否突破或如何安排联合投资", "确认 620 万收入体量是否达到其种子-PreA 的项目门槛"],
    },
    {
        "name": "江桥基金", "stage": "种子", "ticket": "800-1800",
        "ind": "企业AI", "hq": "否", "rd": "否", "lead": "是", "buyback": "无",
        "rank": 3, "status": "可接洽（需联合投资方案）",
        "hard": {"A": "满足（种子阶段专注）", "B": "不满足（单笔上限 1800 万，低于 2000 万融资下限，无法独立满足额度需求）",
                 "C": "满足（总部迁移为否）", "D": "满足（研发迁移为否）", "E": "满足（企业 AI）",
                 "F": "满足（明确可领投）", "G": "满足（无回购要求）"},
        "reason": "除额度外各项硬约束全部满足，且明确可领投。但单笔 800-1800 万低于本轮 2000 万下限，即便领投也无法独立完成 2000-3000 万融资，必须与启航创投、栖原资本等组成联合投资。可将其定位为领投或跟投成员之一。",
        "todo": ["确认是否存在超额跟投/追加权限突破 1800 万上限", "确认其是否愿意在联合投资结构中领投并牵头条款", "确认其对工业软件属性企业 AI 项目的行业判断"],
    },
    {
        "name": "沄泽创投", "stage": "PreA", "ticket": "1500-3000",
        "ind": "企业AI", "hq": "否", "rd": "否", "lead": "可能", "buyback": "保本",
        "rank": 4, "status": "条件接洽（先解决回购条款冲突）",
        "hard": {"A": "需确认（其策略为 PreA，公司当前为种子期、收入 620 万，阶段判断需其确认）",
                 "B": "满足（1500-3000 万覆盖需求）", "C": "满足（总部迁移为否）", "D": "满足（研发迁移为否）",
                 "E": "满足（企业 AI）", "F": "待确认（『可能领投』不构成承诺）",
                 "G": "不满足（保本回购要求与公司硬约束直接冲突）"},
        "reason": "额度、行业、迁移政策均匹配，但『保本回购』要求触碰公司不可接受的底线，属当前唯一被硬约束直接否决的条件。仅当其明确同意放弃保本回购时才可继续推进；否则应中止。",
        "todo": ["确认其能否在无保本回购结构下投资（如接受普通股+标准清算优先权）", "确认其 PreA 策略是否接受公司当前种子期定位与 620 万收入体量", "确认『可能领投』的真实意愿与前提条件"],
    },
    {
        "name": "海澄成长", "stage": "B轮", "ticket": "5000-10000",
        "ind": "企业服务", "hq": "否", "rd": "否", "lead": "是", "buyback": "无",
        "rank": 5, "status": "暂缓（留作后续轮次储备）",
        "hard": {"A": "不满足（B 轮策略，公司为种子期，阶段严重错配）",
                 "B": "不满足（单笔 5000-10000 万远超 2000-3000 万融资规模）",
                 "C": "满足（总部迁移为否）", "D": "满足（研发迁移为否）",
                 "E": "部分相关（企业服务与公司方向相邻，但非公司优先方向）",
                 "F": "满足（明确可领投）", "G": "满足（无回购要求）"},
        "reason": "迁移政策与回购条款合规，但 B 轮阶段策略与种子期公司严重错配，单笔规模也远超本轮需求，本轮不具可操作性。建议保留联系，作为公司进入 A/B 轮时的潜在储备投资方。",
        "todo": ["本轮无需推进；可在下一轮融资前重新评估其 A/B 轮兴趣"],
    },
    {
        "name": "同杉天使", "stage": "天使", "ticket": "300-800",
        "ind": "通用科技", "hq": "否", "rd": "否", "lead": "否", "buyback": "无",
        "rank": 6, "status": "仅作小额跟投备选",
        "hard": {"A": "不满足（天使阶段，早于公司当前种子期定位）",
                 "B": "不满足（单笔 300-800 万，远低于需求且明确不可领投）",
                 "C": "满足（总部迁移为否）", "D": "满足（研发迁移为否）",
                 "E": "不满足（通用科技，非工业软件/企业 AI 优先方向）",
                 "F": "不满足（明确不领投）", "G": "满足（无回购要求）"},
        "reason": "不领投且额度太小，无法满足『需一家可领投』的核心要求，阶段与行业方向亦不匹配。仅在公司需要小额跟投补足联合投资结构时作为低优先级备选。",
        "todo": ["仅在联合投资结构存在小额缺口时考虑；本轮不作为主要接洽对象"],
    },
    {
        "name": "城脉产业", "stage": "A轮", "ticket": "3000-5000",
        "ind": "先进制造", "hq": "要求", "rd": "否", "lead": "是", "buyback": "待核",
        "rank": 7, "status": "不推荐接洽（硬约束否决）",
        "hard": {"A": "不满足（A 轮策略，公司为种子期）",
                 "B": "部分相关（3000-5000 万与需求上沿重叠，但阶段错配）",
                 "C": "不满足（明确要求总部迁移，直接违反公司不迁总部的硬约束）",
                 "D": "满足（研发迁移为否）", "E": "不满足（先进制造，非工业软件/企业 AI）",
                 "F": "满足（明确可领投）", "G": "待确认（回购要求『待核』）"},
        "reason": "总部迁移为其明确要求，与公司『不接受本轮总部迁移』的硬约束正面冲突，无谈判空间即被否决；叠加 A 轮阶段错配与行业方向不符，本轮不具备接洽价值。",
        "todo": ["本轮不接洽；如公司未来改变总部策略可再评估"],
    },
]
FUNDS.sort(key=lambda f: f["rank"])

# ================= investor_shortlist.xlsx =================
wb = Workbook()

thin = Border(*[Side(style="thin", color="BFBFBF")] * 4)
hdr_fill = PatternFill("solid", fgColor="1F4E79")
hdr_font = Font(color="FFFFFF", bold=True, size=11)
warn_fill = PatternFill("solid", fgColor="FFF2CC")
fail_fill = PatternFill("solid", fgColor="F8CBAD")
ok_fill = PatternFill("solid", fgColor="E2EFDA")

# --- Sheet1: 短名单总表 ---
ws = wb.active
ws.title = "投资机构短名单"
ws["A1"] = "澄川软件 本轮融资（2000–3000 万元）投资机构筛选短名单"
ws["A1"].font = Font(bold=True, size=14)
ws["A2"] = "硬约束：阶段覆盖种子期 | 单笔覆盖 2000–3000 万（不足需联合投资）| 不迁总部 | 研发留苏州 | 行业偏好工业软件/企业AI | 需一家可领投 | 不接受保本回购；排序依据适配程度（硬约束满足度+匹配质量）"
ws["A2"].font = Font(size=9, color="595959")
ws.merge_cells("A1:L1"); ws.merge_cells("A2:L2")

headers = ["排名", "机构", "接洽状态", "阶段", "单笔(万元)", "行业", "领投意愿(原始记录)",
           "硬约束核对结果(摘要)", "核心理由", "待确认信息", "总部迁移(原始)", "回购(原始)"]
hr = 4
for c, h in enumerate(headers, 1):
    cell = ws.cell(hr, c, h)
    cell.font = hdr_font; cell.fill = hdr_fill
    cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    cell.border = thin

for i, f in enumerate(FUNDS):
    hard_summary = "；".join(v for k, v in f["hard"].items() if not v.startswith("满足（") or k in ("B", "C", "F", "G"))
    hard_summary = "全部满足（除特别注明待确认项）" if all(v.startswith("满足") for v in f["hard"].values()) else \
        "；".join(f"{k}:{v}" for k, v in f["hard"].items() if not v.startswith("满足")) or "全部满足"
    row = hr + 1 + i
    vals = [f["rank"], f["name"], f["status"], f["stage"], f["ticket"], f["ind"], f["lead"],
            hard_summary, f["reason"], "\n".join(f"{j+1}. {t}" for j, t in enumerate(f["todo"])), f["hq"], f["buyback"]]
    for c, v in enumerate(vals, 1):
        cell = ws.cell(row, c, v)
        cell.alignment = Alignment(vertical="top", wrap_text=True)
        cell.border = thin
    st = f["status"]
    fill = ok_fill if st.startswith("优先") else (warn_fill if (st.startswith("可接洽") or st.startswith("条件") or st.startswith("仅作")) else fail_fill)
    ws.cell(row, 3).fill = fill

widths = [6, 11, 22, 10, 12, 10, 16, 40, 46, 40, 12, 10]
for c, w in enumerate(widths, 1):
    ws.column_dimensions[get_column_letter(c)].width = w
ws.row_dimensions[1].height = 22; ws.row_dimensions[2].height = 30
for r in range(hr + 1, hr + 1 + len(FUNDS)):
    ws.row_dimensions[r].height = 130
ws.freeze_panes = "C5"

# --- Sheet2: 逐项硬约束核对 ---
ws2 = wb.create_sheet("逐项硬约束核对")
ws2["A1"] = "逐项硬约束核对矩阵（✔满足 / ✘不满足 / ⚠待确认或部分满足）"
ws2["A1"].font = Font(bold=True, size=12)
h2 = ["机构", "A 阶段", "B 额度", "C 总部", "D 研发", "E 行业", "F 领投", "G 回购", "核对明细"]
for c, h in enumerate(h2, 1):
    cell = ws2.cell(3, c, h)
    cell.font = hdr_font; cell.fill = hdr_fill; cell.border = thin
    cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)

def mark(v):
    if v.startswith("满足") and "待确认" not in v:
        return "✔"
    if v.startswith("不满足"):
        return "✘"
    return "⚠"

for i, f in enumerate(FUNDS):
    r = 4 + i
    ws2.cell(r, 1, f["name"]).font = Font(bold=True)
    keys = ["A", "B", "C", "D", "E", "F", "G"]
    for j, k in enumerate(keys):
        cell = ws2.cell(r, 2 + j, mark(f["hard"][k]))
        cell.alignment = Alignment(horizontal="center", vertical="center")
        cell.font = Font(bold=True, size=12,
                         color="2E7D32" if cell.value == "✔" else ("C00000" if cell.value == "✘" else "B26B00"))
    detail = " | ".join(f"{k}:{f['hard'][k]}" for k in keys)
    ws2.cell(r, 9, detail).alignment = Alignment(vertical="top", wrap_text=True)
    for c in range(1, 10):
        ws2.cell(r, c).border = thin
    ws2.row_dimensions[r].height = 60
for c, w in enumerate([12, 8, 8, 8, 8, 8, 8, 8, 110], 1):
    ws2.column_dimensions[get_column_letter(c)].width = w
ws2.cell(4 + len(FUNDS) + 1, 1, "注：『可能领投』按待确认处理，不视为领投承诺；『待核』项在未核实前按风险项处理。数据来源：inputs/funds.csv 与 inputs/company_constraints.md。")
ws2.cell(4 + len(FUNDS) + 1, 1).font = Font(size=9, color="595959")

# --- Sheet3: 待确认信息汇总 ---
ws3 = wb.create_sheet("待确认信息汇总")
ws3["A1"] = "接洽前必须澄清的信息清单（按机构）"
ws3["A1"].font = Font(bold=True, size=12)
for c, h in enumerate(["机构", "优先级", "待确认信息"], 1):
    cell = ws3.cell(3, c, h); cell.font = hdr_font; cell.fill = hdr_fill; cell.border = thin
r = 4
for f in FUNDS:
    pri = "高" if f["status"].startswith("优先") else ("中" if ("接洽" in f["status"] or "备选" in f["status"]) else "低")
    for t in f["todo"]:
        ws3.cell(r, 1, f["name"]); ws3.cell(r, 2, pri); ws3.cell(r, 3, t)
        for c in range(1, 4):
            ws3.cell(r, c).border = thin
            ws3.cell(r, c).alignment = Alignment(vertical="top", wrap_text=True)
        r += 1
for c, w in enumerate([12, 8, 90], 1):
    ws3.column_dimensions[get_column_letter(c)].width = w

wb.save("/workspace/outputs/investor_shortlist.xlsx")
print("xlsx saved")

# ================= outreach_brief.docx =================
doc = Document()
style = doc.styles["Normal"]
style.font.name = "Noto Sans CJK SC"
style.font.size = Pt(10.5)
from docx.oxml.ns import qn
style.element.rPr.rFonts.set(qn("w:eastAsia"), "Noto Sans CJK SC")

def h(text, level=1):
    p = doc.add_heading(text, level=level)
    for run in p.runs:
        run.font.name = "Noto Sans CJK SC"
        run._element.rPr.rFonts.set(qn("w:eastAsia"), "Noto Sans CJK SC")
    return p

def para(text, bold=False, size=10.5, color=None):
    p = doc.add_paragraph()
    r = p.add_run(text)
    r.bold = bold; r.font.size = Pt(size)
    r.font.name = "Noto Sans CJK SC"
    r._element.rPr.rFonts.set(qn("w:eastAsia"), "Noto Sans CJK SC")
    if color:
        r.font.color.rgb = color
    return p

# 标题
t = doc.add_heading("澄川软件本轮融资投资机构接洽简报", 0)
for run in t.runs:
    run.font.name = "Noto Sans CJK SC"
    run._element.rPr.rFonts.set(qn("w:eastAsia"), "Noto Sans CJK SC")
para("日期：2026-10-15　|　编制依据：inputs/company_constraints.md、inputs/funds.csv　|　用途：管理层内部决策参考，非对外文件", size=9, color=RGBColor(0x59, 0x59, 0x59))

h("一、公司融资条件与硬约束", 1)
para("澄川软件当前处于种子期，已有收入 620 万元；本轮融资目标 2000–3000 万元，需要一家机构领投。公司立场与底线如下，本简报全部机构均按此逐项核对：")
for x in ["阶段匹配：机构投资阶段需覆盖种子期；",
          "额度匹配：单笔投资能力需覆盖 2000–3000 万元（不足者需有明确的联合投资补足方案）；",
          "总部不迁移：本轮不接受总部迁出苏州（可在异地设立销售分支，这不构成障碍）；",
          "研发留苏州：不接受研发团队或研发中心迁出；",
          "行业偏好：优先工业软件、企业 AI 方向的投资机构；",
          "领投要求：需一家可领投的机构；『可能领投』仅为待确认意愿，一律不作为承诺或既成事实；",
          "条款底线：不接受保本回购条款；接受董事席位讨论。"]:
    p = doc.add_paragraph(x, style="List Bullet")
    for run in p.runs:
        run.font.name = "Noto Sans CJK SC"; run._element.rPr.rFonts.set(qn("w:eastAsia"), "Noto Sans CJK SC")

h("二、筛选结论（按适配程度排序）", 1)
tbl = doc.add_table(rows=1, cols=5)
tbl.style = "Table Grid"
tbl.alignment = WD_TABLE_ALIGNMENT.CENTER
hd = tbl.rows[0].cells
for i, txt in enumerate(["排序", "机构", "接洽建议", "一句话判断", "需先确认的关键项"]):
    hd[i].text = txt
    for p in hd[i].paragraphs:
        for r in p.runs:
            r.bold = True; r.font.size = Pt(9.5)
summary = {
    "栖原资本": ("优先接洽", "四项核心条件最吻合，两项待核是唯一风险", "总部迁移、回购条款（均标『待核』）"),
    "启航创投": ("优先接洽", "无任何硬冲突；领投是『可能』、额度上限 2500 万", "领投意愿明确化；3000 万缺口补足方案"),
    "江桥基金": ("可接洽（需联合投资）", "各项合规但单笔上限 1800 万，无法独立满足额度", "超额权限或联合投资结构"),
    "沄泽创投": ("条件接洽", "保本回购与公司底线直接冲突，先谈条款再谈投资", "能否放弃保本回购"),
    "海澄成长": ("暂缓", "B 轮策略与种子期错配，留作下轮储备", "本轮无需确认"),
    "同杉天使": ("仅作小额跟投备选", "不领投、额度小、行业方向不符", "仅在有跟投缺口时再议"),
    "城脉产业": ("不推荐", "要求迁总部，直接违反硬约束，另有阶段与行业错配", "无（本轮不接洽）"),
}
for f in FUNDS:
    s = summary[f["name"]]
    row = tbl.add_row().cells
    for i, v in enumerate([str(f["rank"]), f["name"], s[0], s[1], s[2]]):
        row[i].text = v
        for p in row[i].paragraphs:
            for r in p.runs:
                r.font.size = Pt(9)
para("注：排序依据为硬约束满足度与匹配质量，不代表任何机构已作出投资承诺。", size=9, color=RGBColor(0x59, 0x59, 0x59))

h("三、机构逐项分析", 1)
for f in FUNDS:
    h(f"{f['rank']}. {f['name']}——{f['status']}", 2)
    para(f"原始画像：阶段 {f['stage']}；单笔 {f['ticket']} 万元；行业 {f['ind']}；总部迁移：{f['hq']}；研发迁移：{f['rd']}；领投：{f['lead']}；回购要求：{f['buyback']}。", size=9.5)
    para("硬约束逐项核对：", bold=True)
    for k in ["A", "B", "C", "D", "E", "F", "G"]:
        v = f["hard"][k]
        flag = "✔" if (v.startswith("满足") and "待确认" not in v) else ("✘" if v.startswith("不满足") else "⚠")
        p = doc.add_paragraph(f"{flag} {k}：{v}", style="List Bullet")
        for r in p.runs:
            r.font.name = "Noto Sans CJK SC"; r._element.rPr.rFonts.set(qn("w:eastAsia"), "Noto Sans CJK SC"); r.font.size = Pt(9.5)
    para("理由：" + f["reason"])
    para("仍需确认的信息：", bold=True)
    for i, td in enumerate(f["todo"], 1):
        p = doc.add_paragraph(f"（{i}）{td}", style="List Bullet")
        for r in p.runs:
            r.font.name = "Noto Sans CJK SC"; r._element.rPr.rFonts.set(qn("w:eastAsia"), "Noto Sans CJK SC"); r.font.size = Pt(9.5)

h("四、总体风险提示与行动建议", 1)
for x in ["『可能领投』不等于领投承诺：启航创投、沄泽创投均标注『可能』，在获得书面领投确认前，融资方案不应基于其领投展开；",
          "『待核』项是本轮最大不确定来源：栖原资本的总部迁移与回购要求、城脉产业的回购要求均未核实；对拟优先接洽的栖原资本，建议在首次会议前以邮件书面确认这两点，避免进入尽调后才发现条款冲突；",
          "额度结构建议：若栖原资本确认合规，可由其领投 2000–3000 万；若其单笔实际出资不足，或选择启航创投（上限 2500 万），应同步准备联合投资结构（如江桥基金 800–1800 万跟投）补足缺口；",
          "回购条款红线：沄泽创投的保本回购要求与公司底线冲突，接洽话术应首先确认条款弹性，对方不放弃保本回购即中止，不进入估值讨论；",
          "数据局限：本简报仅基于提供的 funds.csv（7 家机构静态画像），未核实各机构当前基金余额、在投项目冲突、决策周期与最新投资策略，正式接洽前应由公司以机构一手信息补核。"]:
    p = doc.add_paragraph(x, style="List Bullet")
    for r in p.runs:
        r.font.name = "Noto Sans CJK SC"; r._element.rPr.rFonts.set(qn("w:eastAsia"), "Noto Sans CJK SC")

h("五、建议接洽顺序（本周可执行）", 1)
for x in ["第 1 步：邮件联系栖原资本，随附项目摘要，书面确认不迁总部与不设保本回购两点后再约深度会议；",
          "第 2 步：并行接触启航创投，重点确认领投意愿与 2500 万上限的处理方式；",
          "第 3 步：视前两家进展，决定是否引入江桥基金组成联合投资，或与沄泽创投谈判放弃保本回购；",
          "第 4 步：同步预留海澄成长的联系（仅建立关系，不推进本轮），为下一轮储备。"]:
    p = doc.add_paragraph(x, style="List Bullet")
    for r in p.runs:
        r.font.name = "Noto Sans CJK SC"; r._element.rPr.rFonts.set(qn("w:eastAsia"), "Noto Sans CJK SC")

doc.save("/workspace/outputs/outreach_brief.docx")
print("docx saved")
