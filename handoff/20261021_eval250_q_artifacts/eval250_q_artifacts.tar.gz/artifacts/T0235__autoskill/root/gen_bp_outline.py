# -*- coding: utf-8 -*-
"""生成12页路演BP提纲 bp_outline.docx
规则：仅使用 verified_facts.csv 中已核/有限范围事实；无证市场规模不使用；
融资为计划且未获承诺，仅在待证主张中说明；待证主张单列。"""
import os
from docx import Document
from docx.shared import Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn

ACCENT = RGBColor(0x1F, 0x4E, 0x79)
GRAY = RGBColor(0x59, 0x59, 0x59)
RED = RGBColor(0x9C, 0x27, 0x0B)

doc = Document()
style = doc.styles["Normal"]
style.font.name = "Noto Sans CJK SC"
style.font.size = Pt(10.5)
style.element.rPr.rFonts.set(qn("w:eastAsia"), "Noto Sans CJK SC")

for s in doc.sections:
    s.top_margin = Cm(2); s.bottom_margin = Cm(2)
    s.left_margin = Cm(2.2); s.right_margin = Cm(2.2)

def title(text, size=20, color=ACCENT, center=False, space_before=0):
    p = doc.add_paragraph()
    if center: p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(space_before)
    p.paragraph_format.space_after = Pt(6)
    r = p.add_run(text); r.bold = True; r.font.size = Pt(size); r.font.color.rgb = color
    return p

def sub(text, color=GRAY, size=10.5, center=False):
    p = doc.add_paragraph()
    if center: p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(4)
    r = p.add_run(text); r.font.size = Pt(size); r.font.color.rgb = color
    return p

def field(label, text, label_color=ACCENT):
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(3)
    r1 = p.add_run(label + "："); r1.bold = True; r1.font.color.rgb = label_color
    p.add_run(text)
    return p

def bullet(text, color=None, bold=False):
    p = doc.add_paragraph(style="List Bullet")
    p.paragraph_format.space_after = Pt(2)
    r = p.add_run(text); r.bold = bold
    if color: r.font.color.rgb = color
    return p

def page_header(idx, name):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(14)
    p.paragraph_format.space_after = Pt(4)
    r = p.add_run("第%d页  %s" % (idx, name))
    r.bold = True; r.font.size = Pt(14); r.font.color.rgb = ACCENT

def P(idx, name, ev, chart, talk, note=None):
    page_header(idx, name)
    field("标题建议", name)
    field("关键证据", ev)
    field("图表建议", chart)
    field("口头要点", talk)
    if note:
        p = doc.add_paragraph()
        p.paragraph_format.space_after = Pt(3)
        r1 = p.add_run("注意："); r1.bold = True; r1.font.color.rgb = RED
        r2 = p.add_run(note); r2.font.color.rgb = RED

# ============ 文档首页：使用说明 ============
title("泉析 · 路演BP提纲（12页版）", 22, center=True, space_before=60)
sub("编制依据：inputs/bp_draft.md 与 inputs/verified_facts.csv", center=True)
sub("编制日期：2026-10-15", center=True)
p = doc.add_paragraph(); p.paragraph_format.space_before = Pt(30)
r = p.add_run("使用说明"); r.bold = True
bullet("本提纲共12页，每页给出：标题建议、关键证据、图表建议、口头要点。")
bullet("关键证据仅引用已核事实（雇员表、合同汇总、签收记录、台账、人员表、预算）；标注“有限范围”的结论表述需附带适用条件。")
bullet("原始草稿中“千亿市场规模”无证据来源，本提纲不使用，该主张及相关推论全部列入文末“待证主张清单”。")
bullet("2026Q4拟融资1500万元为计划、未获任何投资承诺，仅以“拟/计划”措辞出现，不作为承诺性表述。")
bullet("草稿未覆盖的买方采购流程、竞争边界、阶段里程碑等，在对应页列为待补内容，不虚构填充。")

doc.add_page_break()

# ============ 12页提纲 ============
doc.add_heading("12页提纲", level=1)

P(1, "封面：泉析——水质检验设备",
  "一句话定位；产品形态（实验室原型已转入小批量）。本页不出现任何未经核实的规模数字。",
  "主视觉设备图 + 公司名 + 一句话定位；不放数据图表。",
  "用一句话说清：我们做水质检验设备，产品已从实验室原型进入小批量阶段。")

P(2, "问题：买方为什么需要水质检验设备",
  "草稿未提供买方采购流程证据；本页仅作问题描述，不引用无证市场数据。",
  "示意图：典型采购/使用场景流程占位图，标注“待补充实际采购流程调研”。",
  "先讲客户在哪些环节需要水质检验、现状痛点是什么。",
  note="待补：买方采购流程与决策链（草稿未说明），访谈1-2家已签约客户后回填。")

P(3, "产品与技术：检验误差5%以内（饮用水样）",
  "已核事实（证据：报告）：检验误差5%以内——但适用范围有限，仅为饮用水样。",
  "柱状图：本项目实测误差 vs 5%限值；图注明确“饮用水样、报告来源”。",
  "强调精度指标时必须带上“饮用水样范围内”这一限定，不外推到其他水样。",
  note="“有限范围”事实：不得表述为全品类/全水样精度。")

P(4, "阶段进展：从实验室原型到小批量",
  "已核事实：产品处于小批量阶段；可靠性与交付验证预计需12个月（公司计划）。",
  "时间轴：实验室原型 → 小批量 → 12个月可靠性与交付验证 → 规模化（后两项为计划，标注虚线）。",
  "如实说明当前处于原型转小批量的验证期，12个月验证是计划而非已完成事实。")

P(5, "订单与交付：已签30台、已交付18台、回款96万元",
  "已核事实（证据：合同汇总/签收记录/台账）：已签订单30台；已交付18台；回款96万元。交付率=18/30=60%。",
  "漏斗/进度条图：签约30台 → 交付18台 → 回款96万元；三组数字均注明证据来源。",
  "这是本次路演最硬的一页：有合同、有签收、有回款，逐项对应台账可查。")

P(6, "客户与案例",
  "草稿提及“客户”页但未附已核客户名单；引用客户时以已签合同对象为准。",
  "客户logo墙/案例卡片：仅放可公开引用的已签约客户；其余以“已签约客户（名单待授权）”占位。",
  "挑1-2个已交付客户讲使用情况，避免引用未经客户授权的名称与数据。")

P(7, "竞争边界",
  "草稿未说明竞争边界；本页不引用无证市占率或排名。",
  "二维对比矩阵：我方 vs 主要竞品在精度（饮用水样）、交付、价格等维度占位，标注“竞品信息待核实”。",
  "坦率说明与竞品的差异点目前基于产品规格与客户反馈，正式版需补充竞品核实。",
  note="待补：竞品清单与对比依据（草稿未说明）。")

P(8, "售后与交付保障：2名专职工程师",
  "已核事实（证据：人员表）：售后工程师2名。结合已交付18台，人均支撑9台。",
  "服务模型图：2名工程师 × 18台在役设备的支撑结构；随交付量增长的支撑规划留白待补。",
  "说明当前售后配置真实、可支撑现阶段交付；规模化后的售后扩编方案在里程碑页衔接。")

P(9, "阶段里程碑（未来12个月）",
  "以“12个月验证可靠性和交付”计划为骨架拆分里程碑；具体季度目标为计划，不作为承诺。",
  "甘特图/里程碑图：按季度拆分可靠性与交付验证节点，全部标注“计划”。",
  "讲清未来12个月要验证什么：可靠性指标、交付能力，以及判断标准。",
  note="待补：可量化的里程碑验收标准（草稿未说明）。")

P(10, "团队：12人",
  "已核事实（证据：雇员表）：团队12人。成员姓名职务等明细待确认后补充。",
  "组织结构图：12人团队按研发/交付/售后/市场分组示意（人数分配待确认）。",
  "介绍核心成员背景与分工；未确认的姓名职务一律不写，避免编造。",
  note="待补：核心成员姓名、职务与履历（需用户提供）。")

P(11, "资金计划：拟融资1500万元及用途",
  "资金用途为预算计划（证据：预算）：研发600万、交付450万、市场300万、流动150万，合计1500万元。2026Q4拟融资1500万元——未获投资承诺，仅作计划表述。",
  "环形图/堆叠柱：1500万元按四项用途拆分（600/450/300/150），图注“预算计划”。",
  "明确说：本轮拟融资1500万元，用途按上述比例；目前尚未锁定投资承诺，正在接洽中。",
  note="红线：不得使用“已获承诺”“基本确定”等承诺性措辞；金额均为计划。")

P(12, "结束页 + 待证主张清单",
  "汇总本提纲所有未经核实、需补充证据的主张，路演中不作断言。",
  "版式页：结尾致谢 + 待证主张清单表格（见文末附表）。",
  "结尾复述三个已核数字：30台签约、18台交付、96万元回款；欢迎尽调核验台账。")

doc.add_page_break()
doc.add_heading("附表：待证主张清单（路演中不作断言，待补证据后再使用）", level=1)

tbl = doc.add_table(rows=1, cols=4)
tbl.style = "Table Grid"
hdr = tbl.rows[0].cells
for i, h in enumerate(["主张", "当前状态", "来源情况", "处理方式"]):
    hdr[i].paragraphs[0].add_run(h).bold = True
rows = [
 ("市场规模千亿", "无证", "仅口头描述，无任何报告或数据来源", "本提纲全部删除；补充第三方行业报告或自建测算（口径+假设）后才可使用"),
 ("2026Q4融资1500万元", "计划，未获承诺", "公司融资计划，无投资协议或意向书", "仅以“拟融资/计划”表述；获得书面承诺后才可升级"),
 ("12个月完成可靠性与交付验证", "计划", "公司内部计划，无里程碑验收标准", "第9页拆分为季度计划并制定验收标准"),
 ("买方采购流程与决策链", "缺失", "草稿未说明", "访谈1-2家已签约客户后回填第2页"),
 ("竞争边界与竞品对比", "缺失", "草稿未说明", "核实竞品规格与报价后回填第7页"),
 ("核心成员姓名与履历", "缺失", "雇员表仅确认总人数12人", "用户提供成员明细后回填第10页"),
 ("可引用客户名单与案例数据", "部分受限", "已签合同客户身份需授权后可公开", "取得客户授权后在第6页引用"),
]
for r in rows:
    cells = tbl.add_row().cells
    for i, v in enumerate(r):
        cells[i].paragraphs[0].add_run(v)

doc.add_paragraph()
p = doc.add_paragraph()
r = p.add_run("已核事实一览（本提纲引用并保留）："); r.bold = True
bullet("团队12人（雇员表）")
bullet("已签订单30台（合同汇总）")
bullet("已交付18台（签收记录）")
bullet("回款96万元（台账）")
bullet("检验误差5%以内——限饮用水样（报告，有限范围）")
bullet("售后工程师2名（人员表）")
bullet("资金用途计划：研发600万/交付450万/市场300万/流动150万（预算）")

os.makedirs("/workspace/outputs", exist_ok=True)
out = "/workspace/outputs/bp_outline.docx"
doc.save(out)
print("saved", out)
