# -*- coding: utf-8 -*-
import csv
from docx import Document
from docx.shared import Pt
from docx.oxml.ns import qn

rows = [
    ("D1","合同模板","客户服务条款","商务;现行","标准商务文件，状态为批准，批准映现行"),
    ("D2","报价草稿","50席位采购","商务;草稿","报价属商务主题，状态为草稿"),
    ("D3","权限SOP","资料最小授权","安全;现行","权限与最小授权属安全主题，批准映现行"),
    ("D4","产品FAQ","离线检索边界","产品;现行","产品说明文件，批准映现行"),
    ("D5","培训复盘","20人试训观察","培训;归档","培训主题，状态为归档"),
    ("D6","研发计划","国产数据库联测","研发;草稿","研发主题，状态为草稿"),
    ("D7","验收纪要","一期权限测试","交付;安全;现行","验收属交付主题，摘要明确涉及权限测试故加安全，批准映现行"),
    ("D8","退款记录","已批准客户退款","商务;归档","退款属商务主题，状态为归档，按资料状态记录归档"),
    ("D9","行业消息","公开融资摘要","市场;归档","公开行业融资信息属市场主题，状态为归档"),
    ("D10","客户纪要","工厂试点需求","商务;草稿","客户需求沟通属商务主题，状态为草稿"),
]

with open("/workspace/outputs/taxonomy.csv","w",newline="",encoding="utf-8-sig") as f:
    w = csv.writer(f)
    w.writerow(["id","title","summary","tags","tags_rationale"])
    for r in rows:
        w.writerow(r)

doc = Document()
style = doc.styles["Normal"]
style.font.name = "Noto Sans CJK SC"
style.font.size = Pt(10.5)
style.element.rPr.rFonts.set(qn("w:eastAsia"), "Noto Sans CJK SC")

def h(text, level=1):
    p = doc.add_heading(text, level=level)
    for run in p.runs:
        run.font.name = "Noto Sans CJK SC"
        run._element.rPr.rFonts.set(qn("w:eastAsia"), "Noto Sans CJK SC")
    return p

def para(text):
    p = doc.add_paragraph(text)
    for run in p.runs:
        run.font.name = "Noto Sans CJK SC"
        run._element.rPr.rFonts.set(qn("w:eastAsia"), "Noto Sans CJK SC")
    return p

h("文档分类指南（taxonomy_guide）", 0)
para("本指南说明 document_records.json 中 10 篇文档（D1–D10）的标签分类结果与规则。标签仅来自 inputs/tag_rules.md 的允许标签清单，配套结果见 outputs/taxonomy.csv。")

h("一、标签体系")
para("业务主题（7 个）：商务、交付、安全、产品、培训、研发、市场。")
para("资料状态（3 个）：现行、草稿、归档。状态字段为“批准”的文档映为“现行”。")

h("二、分类规则")
for t in [
    "每篇文档最多 3 个标签，且必须同时包含至少一个业务主题和一个资料状态。",
    "状态映射：记录状态为“批准”映为资料状态“现行”；“草稿”“归档”直接使用对应状态。",
    "只依据文档 title 与 summary 的明确内容判断，不推测具体行业背景。",
    "主题交叉时可加第 2 个业务主题（如 D7 验收纪要明确涉及权限测试，加安全主题）。",
    "文档 ID 保持不变；多标签不等于将正文复制到多个目录，每篇文档仍只登记一条记录。",
]:
    doc.add_paragraph(t, style="List Number")

h("三、逐篇分类结果")
table = doc.add_table(rows=1, cols=4)
table.style = "Table Grid"
hdr = table.rows[0].cells
for i, name in enumerate(["ID","标题","标签","判定依据"]):
    hdr[i].text = name
for doc_id, title, summary, tags, rationale in rows:
    c = table.add_row().cells
    c[0].text = doc_id
    c[1].text = f"{title}（{summary}）"
    c[2].text = tags.replace(";", "、")
    c[3].text = rationale

h("四、结果统计")
para("共 10 篇文档，覆盖率 100%；每篇 2–3 个标签，均含一个业务主题和一个资料状态。分布：现行 5 篇（D1、D3、D4、D7 计及 D1），草稿 3 篇（D2、D6、D10），归档 3 篇（D5、D8、D9）。")
para("说明：D8 虽摘要为“已批准客户退款”，其记录状态为“归档”，按资料状态规则记为归档；状态映射仅对状态字段为“批准”的文档生效。")

doc.save("/workspace/outputs/taxonomy_guide.docx")
print("done")
