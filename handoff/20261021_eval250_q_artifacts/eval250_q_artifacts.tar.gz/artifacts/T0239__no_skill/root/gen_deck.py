# -*- coding: utf-8 -*-
"""生成《合作项目管理方案.pptx》(6页,16:9,白底蓝色商务风) 与讲稿 docx。
仅使用 inputs/合作项目管理方案事实.md 中的事实,不补未知业绩。"""
from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.chart.data import CategoryChartData
from pptx.enum.chart import XL_CHART_TYPE, XL_LEGEND_POSITION

BLUE_D = RGBColor(0x1F, 0x4E, 0x79)   # 深蓝
BLUE_M = RGBColor(0x2E, 0x75, 0xB6)   # 中蓝
BLUE_L = RGBColor(0xDE, 0xEB, 0xF7)   # 浅蓝底
GREY_T = RGBColor(0x40, 0x40, 0x40)   # 正文灰黑
WHITE = RGBColor(0xFF, 0xFF, 0xFF)

SW, SH = Inches(13.333), Inches(7.5)
prs = Presentation()
prs.slide_width, prs.slide_height = SW, SH
BLANK = prs.slide_layouts[6]

# ---------- 基础绘制函数 ----------
def add_rect(slide, x, y, w, h, fill, line=None):
    from pptx.enum.shapes import MSO_SHAPE
    sp = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, x, y, w, h)
    sp.fill.solid(); sp.fill.fore_color.rgb = fill
    if line is None:
        sp.line.fill.background()
    else:
        sp.line.color.rgb = line; sp.line.width = Pt(0.75)
    sp.shadow.inherit = False
    return sp

def set_text(tf, runs, size=16, color=GREY_T, bold=False, align=PP_ALIGN.LEFT,
             anchor=MSO_ANCHOR.TOP, line_spacing=1.12, space_after=4):
    """runs: str 或 [(text,{bold,color,size}),...] 或多段 [[...],[...]]"""
    tf.word_wrap = True
    tf.vertical_anchor = anchor
    if isinstance(runs, str):
        runs = [[(runs, {})]]
    elif runs and isinstance(runs[0], tuple):
        runs = [runs]
    first = True
    for para in runs:
        p = tf.paragraphs[0] if first else tf.add_paragraph()
        first = False
        p.alignment = align; p.line_spacing = line_spacing; p.space_after = Pt(space_after)
        if isinstance(para, str):
            para = [(para, {})]
        for text, style in para:
            r = p.add_run(); r.text = text
            f = r.font
            f.size = Pt(style.get("size", size)); f.bold = style.get("bold", bold)
            f.name = "Noto Sans CJK SC"
            f.color.rgb = style.get("color", color)
    return tf

def add_text(slide, x, y, w, h, runs, **kw):
    tb = slide.shapes.add_textbox(x, y, w, h)
    set_text(tb.text_frame, runs, **kw)
    return tb

def add_header(slide, num, title, subtitle=None):
    """页眉:白底+蓝色标题+左侧色块+底部细线"""
    add_rect(slide, 0, 0, Inches(0.18), Inches(1.0), BLUE_D)
    add_text(slide, Inches(0.45), Inches(0.22), Inches(10.5), Inches(0.6),
             [(title, {"bold": True, "size": 28, "color": BLUE_D})])
    if subtitle:
        add_text(slide, Inches(0.45), Inches(0.82), Inches(11.5), Inches(0.4),
                 [(subtitle, {"size": 13, "color": BLUE_M})])
    add_text(slide, Inches(12.35), Inches(0.28), Inches(0.8), Inches(0.4),
             [(f"{num}/6", {"size": 12, "color": BLUE_M, "bold": True})], align=PP_ALIGN.RIGHT)
    add_rect(slide, Inches(0.45), Inches(1.22), Inches(12.43), Pt(1.6), BLUE_M)

def add_note(slide, text, y=None):
    y = y if y is not None else Inches(6.95)
    add_text(slide, Inches(0.45), y, Inches(12.4), Inches(0.4),
             [(text, {"size": 11, "color": RGBColor(0x59, 0x59, 0x59)})])

def style_table(tbl, header_bg=BLUE_D, header_color=WHITE, font_size=13,
                header_size=13, row_h=None, aligns=None):
    nrows, ncols = len(tbl.rows), len(tbl.columns)
    for r in range(nrows):
        if row_h:
            tbl.rows[r].height = row_h
        for c in range(ncols):
            cell = tbl.cell(r, c)
            cell.margin_left = Inches(0.08); cell.margin_right = Inches(0.08)
            cell.margin_top = Inches(0.03); cell.margin_bottom = Inches(0.03)
            cell.vertical_anchor = MSO_ANCHOR.MIDDLE
            if r == 0:
                cell.fill.solid(); cell.fill.fore_color.rgb = header_bg
            else:
                cell.fill.solid()
                cell.fill.fore_color.rgb = WHITE if r % 2 else BLUE_L
            for p in cell.text_frame.paragraphs:
                if aligns:
                    p.alignment = aligns[c]
                for run in p.runs:
                    run.font.size = Pt(header_size if r == 0 else font_size)
                    run.font.name = "Noto Sans CJK SC"
                    run.font.bold = (r == 0)
                    run.font.color.rgb = header_color if r == 0 else GREY_T

# ============================================================
# 第1页 封面
# ============================================================
s = prs.slides.add_slide(BLANK)
add_rect(s, 0, 0, SW, SH, WHITE)
add_rect(s, 0, Inches(2.35), Inches(0.55), Inches(2.5), BLUE_D)
add_text(s, Inches(1.0), Inches(2.35), Inches(11.3), Inches(1.4),
         [("合作项目管理方案", {"bold": True, "size": 52, "color": BLUE_D})])
add_text(s, Inches(1.0), Inches(3.62), Inches(11.3), Inches(0.6),
         [("企业设备知识库建设项目 · 面向双方工作组", {"size": 22, "color": BLUE_M})])
add_rect(s, Inches(1.0), Inches(4.45), Inches(3.2), Pt(2.2), BLUE_M)
add_text(s, Inches(1.0), Inches(4.75), Inches(11.3), Inches(1.6), [
    [("项目周期：16 周（2026年10月12日 启动）", {"size": 16})],
    [("总费用：80 万元（含税）　　输入资料：120 份确认版", {"size": 16})],
    [("本方案仅依据已确认事实编制；缺项与待确认事项如实标注。", {"size": 13, "color": RGBColor(0x59,0x59,0x59)})],
], space_after=8)
add_rect(s, 0, Inches(7.14), SW, Inches(0.36), BLUE_D)
add_text(s, Inches(0.5), Inches(7.16), Inches(12.3), Inches(0.32),
         [("双方工作组 · 项目沟通材料", {"size": 11, "color": WHITE})])

# ============================================================
# 第2页 现状:目标、范围与关键数值
# ============================================================
s = prs.slides.add_slide(BLANK)
add_header(s, 2, "一、项目现状：目标与范围", "16 周建成企业设备知识库；输入、交付与边界均按已确认口径")

# 左:目标与交付
add_text(s, Inches(0.45), Inches(1.45), Inches(6.3), Inches(0.4),
         [("■ 建设目标", {"bold": True, "size": 17, "color": BLUE_D})])
add_text(s, Inches(0.55), Inches(1.85), Inches(6.15), Inches(1.0), [
    [("用 16 周项目建设企业设备知识库，实现资料的结构化管理与日常检索使用。", {"size": 14})],
], space_after=6)
add_text(s, Inches(0.45), Inches(2.75), Inches(6.3), Inches(0.4),
         [("■ 交付内容（按合同范围）", {"bold": True, "size": 17, "color": BLUE_D})])
deliv = [("目录", "分类目录体系"), ("权限工作区", "按角色控制访问"),
         ("检索 / 导出", "关键词检索与结果导出"),
         ("30 条确认样本测试记录", "阶段3逐条测试并留存"),
         ("2 场培训", "阶段4完成，附操作手册")]
tbl = s.shapes.add_table(len(deliv)+1, 2, Inches(0.55), Inches(3.2), Inches(6.1), Inches(3.0)).table
tbl.columns[0].width = Inches(2.55); tbl.columns[1].width = Inches(3.55)
rows = [("交付项", "说明")] + deliv
for r, (a, b) in enumerate(rows):
    tbl.cell(r, 0).text = a; tbl.cell(r, 1).text = b
style_table(tbl, row_h=Inches(0.46), aligns=[PP_ALIGN.LEFT, PP_ALIGN.LEFT])

# 右:关键数值卡片
add_text(s, Inches(7.15), Inches(1.45), Inches(5.7), Inches(0.4),
         [("■ 关键数值（单位：周 / 份 / 条 / 场 / 万元）", {"bold": True, "size": 17, "color": BLUE_D})])
cards = [("16", "周 · 项目周期"), ("120", "份 · 确认版输入资料"),
         ("30", "条 · 确认样本测试记录"), ("2", "场 · 培训"),
         ("80", "万元 · 总费用（含税）")]
cx, cy, cw, ch = Inches(7.15), Inches(1.95), Inches(2.72), Inches(1.5)
for i, (num, lab) in enumerate(cards):
    x = cx + (i % 2) * (cw + Inches(0.2))
    y = cy + (i // 2) * (ch + Inches(0.22))
    add_rect(s, x, y, cw, ch, BLUE_L)
    add_rect(s, x, y, Inches(0.08), ch, BLUE_M)
    add_text(s, x + Inches(0.2), y + Inches(0.12), cw - Inches(0.3), Inches(0.75),
             [(num, {"bold": True, "size": 34, "color": BLUE_D})])
    add_text(s, x + Inches(0.2), y + Inches(0.88), cw - Inches(0.3), Inches(0.55),
             [(lab, {"size": 12.5, "color": GREY_T})])
# 范围外
add_rect(s, Inches(10.12), Inches(3.67), Inches(2.75), Inches(3.28), WHITE, line=BLUE_M)
add_text(s, Inches(10.28), Inches(3.78), Inches(2.45), Inches(3.1), [
    [("范围外（不含）", {"bold": True, "size": 13.5, "color": BLUE_D})],
    [("· 客户所有历史聊天", {"size": 12.5})],
    [("· 额外 OCR", {"size": 12.5})],
    [("· 底座源代码所有权", {"size": 12.5})],
    [("· 第三方按量费（未纳入合同总价，需另行确认）", {"size": 12.5})],
], space_after=6)
add_note(s, "注：以上均为合同内已确认口径；交付以验收记录为准，不另行承诺额外内容。")

# ============================================================
# 第3页 问题:已知风险与待确认事项
# ============================================================
s = prs.slides.add_slide(BLANK)
add_header(s, 3, "二、问题与风险：当前未完成与待确认事项", "以下为开工阶段已识别的风险与未决事项，需按责任人跟进")

add_text(s, Inches(0.45), Inches(1.42), Inches(12.4), Inches(0.4),
         [("■ 已知风险清单（尚未全部解决）", {"bold": True, "size": 17, "color": BLUE_D})])
risks = [("缺文件版本", "部分资料缺少版号信息", "影响阶段1去重与字典确认"),
         ("权限配置待确认", "权限方案尚待双方确认", "影响阶段2配置启动"),
         ("样本答案缺失", "30条样本的参考答案不齐", "影响阶段3测试与验收"),
         ("现场网络", "实施现场网络条件未落实", "影响配置演示与测试"),
         ("导出版式", "导出格式要求待细化", "影响交付物一致性")]
tbl = s.shapes.add_table(len(risks)+1, 3, Inches(0.45), Inches(1.85), Inches(12.43), Inches(2.9)).table
tbl.columns[0].width = Inches(2.5); tbl.columns[1].width = Inches(5.0); tbl.columns[2].width = Inches(4.93)
rows = [("风险", "现状说明", "对计划的影响")] + risks
for r, row in enumerate(rows):
    for c, v in enumerate(row):
        tbl.cell(r, c).text = v
style_table(tbl, row_h=Inches(0.42), aligns=[PP_ALIGN.LEFT]*3)

add_text(s, Inches(0.45), Inches(5.0), Inches(12.4), Inches(0.4),
         [("■ 管控约束（书面规则）", {"bold": True, "size": 17, "color": BLUE_D})])
cons = [
    [("· 变更管理：", {"bold": True, "color": BLUE_D}),
     ("材料变更通过书面变更单；范围新增须说明工期 / 费用 / 验收影响，", {"size": 13.5}),
     ("未签批不进入范围", {"size": 13.5, "bold": True, "color": BLUE_D}),
     ("。", {"size": 13.5})],
    [("· 验收口径：", {"bold": True, "color": BLUE_D}),
     ("不得仅按日历到点称已达验收；不得以“全部交付”掩盖待客户依赖。", {"size": 13.5})],
    [("· 冲突处理：", {"bold": True, "color": BLUE_D}),
     ("由双方项目经理先协调，重大事项交管理层。", {"size": 13.5})],
]
add_text(s, Inches(0.55), Inches(5.42), Inches(12.2), Inches(1.4), cons, space_after=7)
add_note(s, "注：上述风险状态截至方案编制时，均为“待解决/待确认”，未标注完成；后续以问题表跟踪更新。")

# ============================================================
# 第4页 计划:四阶段计划(表格+周数图表)
# ============================================================
s = prs.slides.add_slide(BLANK)
add_header(s, 4, "三、计划：四阶段 16 周安排", "阶段工期与起止日期为合同确认口径")

plan = [("阶段1 材料整理", "4 周", "2026-10-12 ~ 2026-11-08",
         "客户数据管理员交目录/版号；供应商整理与去重；双方确认字典"),
        ("阶段2 系统配置", "6 周", "2026-11-09 ~ 2026-12-20",
         "配置权限/检索/导出，并完成演示"),
        ("阶段3 测试", "4 周", "2026-12-21 ~ 2027-01-17",
         "用确认样本测试并留存缺陷记录"),
        ("阶段4 培训", "2 周", "2027-01-18 ~ 2027-01-31",
         "交操作手册、培训和验收材料")]
tbl = s.shapes.add_table(5, 4, Inches(0.45), Inches(1.5), Inches(12.43), Inches(2.75)).table
tbl.columns[0].width = Inches(2.35); tbl.columns[1].width = Inches(1.0)
tbl.columns[2].width = Inches(3.28); tbl.columns[3].width = Inches(5.8)
rows = [("阶段", "工期", "起止日期", "主要工作")] + plan
for r, row in enumerate(rows):
    for c, v in enumerate(row):
        tbl.cell(r, c).text = v
style_table(tbl, row_h=Inches(0.44), aligns=[PP_ALIGN.LEFT, PP_ALIGN.CENTER, PP_ALIGN.CENTER, PP_ALIGN.LEFT])

# 左下:阶段周数条形图
cd = CategoryChartData()
cd.categories = ["阶段1 整理", "阶段2 配置", "阶段3 测试", "阶段4 培训"]
cd.add_series("工期（周）", (4, 6, 4, 2))
gf = s.shapes.add_chart(XL_CHART_TYPE.BAR_CLUSTERED, Inches(0.45), Inches(4.5),
                        Inches(6.4), Inches(2.5), cd)
ch = gf.chart
ch.has_legend = False
ch.has_title = True
ch.chart_title.text_frame.text = "各阶段工期（单位：周）"
for p in ch.chart_title.text_frame.paragraphs:
    for r in p.runs:
        r.font.size = Pt(13); r.font.bold = True; r.font.color.rgb = BLUE_D; r.font.name = "Noto Sans CJK SC"
plot = ch.plots[0]
plot.has_data_labels = True
plot.data_labels.font.size = Pt(12); plot.data_labels.font.bold = True
plot.data_labels.font.color.rgb = BLUE_D
plot.gap_width = 80
ch.series[0].format.fill.solid()
ch.series[0].format.fill.fore_color.rgb = BLUE_M
ch.category_axis.tick_labels.font.size = Pt(11)
ch.value_axis.has_major_gridlines = False
ch.value_axis.tick_labels.font.size = Pt(10)

# 右下:付款节点
add_text(s, Inches(7.2), Inches(4.5), Inches(5.6), Inches(0.4),
         [("■ 付款节点（总费用 80 万元，含税）", {"bold": True, "size": 16, "color": BLUE_D})])
pay = [("启动", "30%", "24 万元"), ("配置验收", "40%", "32 万元"), ("最终验收", "30%", "24 万元")]
px, py, pw = Inches(7.2), Inches(5.0), Inches(1.78)
for i, (name, pct, amt) in enumerate(pay):
    x = px + i * (pw + Inches(0.14))
    add_rect(s, x, py, pw, Inches(1.55), BLUE_L)
    add_rect(s, x, py, pw, Inches(0.4), BLUE_M)
    add_text(s, x, py + Inches(0.04), pw, Inches(0.35),
             [(name, {"bold": True, "size": 13, "color": WHITE})], align=PP_ALIGN.CENTER)
    add_text(s, x, py + Inches(0.5), pw, Inches(0.5),
             [(pct, {"bold": True, "size": 20, "color": BLUE_D})], align=PP_ALIGN.CENTER)
    add_text(s, x, py + Inches(1.02), pw, Inches(0.45),
             [(amt, {"size": 13, "color": GREY_T})], align=PP_ALIGN.CENTER)
add_text(s, Inches(7.2), Inches(6.68), Inches(5.6), Inches(0.35),
         [("付款以对应验收通过为前提，不按日历自动触发。", {"size": 11.5, "color": RGBColor(0x59,0x59,0x59)})])

# ============================================================
# 第5页 计划:职责与协作机制
# ============================================================
s = prs.slides.add_slide(BLANK)
add_header(s, 5, "三、计划：职责分工与协作机制", "决策、变更、问题跟踪均有明确责任人和流程")

add_text(s, Inches(0.45), Inches(1.42), Inches(12.4), Inches(0.4),
         [("■ 职责与交接", {"bold": True, "size": 17, "color": BLUE_D})])
roles = [("客户项目经理", "确认范围 / 样本 / 验收"),
         ("客户数据管理员", "确认数据版本与权限"),
         ("供应商交付经理", "项目排期"),
         ("研发", "实现配置"),
         ("测试负责人", "保存测试结果")]
tbl = s.shapes.add_table(len(roles)+1, 2, Inches(0.45), Inches(1.85), Inches(6.3), Inches(3.0)).table
tbl.columns[0].width = Inches(2.5); tbl.columns[1].width = Inches(3.8)
rows = [("角色", "职责")] + roles
for r, (a, b) in enumerate(rows):
    tbl.cell(r, 0).text = a; tbl.cell(r, 1).text = b
style_table(tbl, row_h=Inches(0.44), aligns=[PP_ALIGN.LEFT]*2)

add_text(s, Inches(7.05), Inches(1.42), Inches(5.85), Inches(0.4),
         [("■ 协作机制", {"bold": True, "size": 17, "color": BLUE_D})])
mech = [
    [("每周例会：", {"bold": True, "color": BLUE_D}), ("双方每周召开会议（每周三），同步进展与问题。", {"size": 13.5})],
    [("问题表跟踪：", {"bold": True, "color": BLUE_D}), ("问题表含编号、事实、影响、责任人、", {"size": 13.5}),
     ("截止日", {"bold": True, "color": BLUE_D}), ("与状态。", {"size": 13.5})],
    [("决策与变更：", {"bold": True, "color": BLUE_D}), ("决策变更需双方授权人确认；范围新增按书面变更单执行。", {"size": 13.5})],
    [("升级路径：", {"bold": True, "color": BLUE_D}), ("冲突由双方项目经理先协调，重大事项交管理层。", {"size": 13.5})],
]
add_text(s, Inches(7.05), Inches(1.9), Inches(5.85), Inches(2.9), mech, space_after=10)

# 底部:问题表示意(空状态即当前未完成跟踪)
add_text(s, Inches(0.45), Inches(5.05), Inches(12.4), Inches(0.4),
         [("■ 问题表结构（按周例会滚动更新）", {"bold": True, "size": 17, "color": BLUE_D})])
issue_cols = ["编号", "事实", "影响", "责任", "截止日", "状态"]
sample_row = ["（例）", "如：某资料缺版号", "去重无法确认", "客户数据管理员", "例：10-25", "未解决"]
tbl = s.shapes.add_table(2, 6, Inches(0.45), Inches(5.5), Inches(12.43), Inches(1.1)).table
for c, v in enumerate(issue_cols):
    tbl.cell(0, c).text = v
for c, v in enumerate(sample_row):
    tbl.cell(1, c).text = v
style_table(tbl, row_h=Inches(0.42), aligns=[PP_ALIGN.CENTER]*6)
add_note(s, "注：示例行仅为说明问题表用法，实际条目由周例会登记；当前风险项见第3页。", y=Inches(6.85))

# ============================================================
# 第6页 付款与验收原则、待办
# ============================================================
s = prs.slides.add_slide(BLANK)
add_header(s, 6, "四、付款、证据与待确认事项", "付款与验收挂钩，证据分轨保存；未决事项如实列出")

tbl = s.shapes.add_table(4, 4, Inches(0.45), Inches(1.5), Inches(7.0), Inches(2.4)).table
tbl.columns[0].width = Inches(1.7); tbl.columns[1].width = Inches(1.3)
tbl.columns[2].width = Inches(1.8); tbl.columns[3].width = Inches(2.2)
pay_rows = [("节点", "比例", "金额", "前提"),
            ("启动", "30%", "24 万元", "合同生效"),
            ("配置验收", "40%", "32 万元", "阶段2 验收通过"),
            ("最终验收", "30%", "24 万元", "阶段4 验收通过")]
for r, row in enumerate(pay_rows):
    for c, v in enumerate(row):
        tbl.cell(r, c).text = v
style_table(tbl, row_h=Inches(0.5), aligns=[PP_ALIGN.LEFT, PP_ALIGN.CENTER, PP_ALIGN.CENTER, PP_ALIGN.LEFT])

add_text(s, Inches(7.75), Inches(1.42), Inches(5.15), Inches(0.4),
         [("■ 验收与证据原则", {"bold": True, "size": 17, "color": BLUE_D})])
princ = [
    [("· 不得仅按日历到点称已达验收。", {"size": 13.5, "bold": True, "color": BLUE_D})],
    [("· 付款凭据、验收记录、模型/文件版本分别保存。", {"size": 13.5})],
    [("· 不以“全部交付”掩盖待客户依赖。", {"size": 13.5})],
    [("· 第三方按量费未纳入合同总价，需另行确认。", {"size": 13.5})],
]
add_text(s, Inches(7.75), Inches(1.9), Inches(5.15), Inches(2.2), princ, space_after=8)

add_text(s, Inches(0.45), Inches(4.2), Inches(12.4), Inches(0.4),
         [("■ 启动前待客户确认事项（当前未完成）", {"bold": True, "size": 17, "color": BLUE_D})])
todo = [("1", "补充缺失文件版号，供阶段1去重与字典确认"),
        ("2", "确认权限配置方案"),
        ("3", "补齐 30 条确认样本的参考答案"),
        ("4", "落实现场网络条件与导出版式要求"),
        ("5", "确认第三方按量费的承担方式（未纳入合同总价）")]
tbl = s.shapes.add_table(len(todo)+1, 2, Inches(0.45), Inches(4.65), Inches(12.43), Inches(2.0)).table
tbl.columns[0].width = Inches(0.9); tbl.columns[1].width = Inches(11.53)
rows = [("序号", "待确认事项")] + todo
for r, row in enumerate(rows):
    for c, v in enumerate(row):
        tbl.cell(r, c).text = v
style_table(tbl, row_h=Inches(0.34), aligns=[PP_ALIGN.CENTER, PP_ALIGN.LEFT])
add_note(s, "注：本页未列任何未发生的业绩或承诺；全部内容以事实资料为依据。")

prs.save("/workspace/outputs/合作项目管理方案.pptx")
print("PPTX saved")

# ============================================================
# 讲稿 DOCX（约5分钟）
# ============================================================
from docx import Document
from docx.shared import Pt as DPt, RGBColor as DRGB, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn

doc = Document()
style = doc.styles["Normal"]
style.font.name = "Noto Sans CJK SC"
style.font.size = DPt(12)
style.element.rPr.rFonts.set(qn("w:eastAsia"), "Noto Sans CJK SC")

def h(text, size=16, color="1F4E79", space_before=10, space_after=6):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = DPt(space_before)
    p.paragraph_format.space_after = DPt(space_after)
    r = p.add_run(text); r.bold = True
    r.font.size = DPt(size); r.font.name = "Noto Sans CJK SC"
    r.element.rPr.rFonts.set(qn("w:eastAsia"), "Noto Sans CJK SC")
    r.font.color.rgb = DRGB.from_string(color)
    return p

def para(text, bold_prefix=None):
    p = doc.add_paragraph()
    p.paragraph_format.space_after = DPt(5)
    p.paragraph_format.line_spacing = 1.25
    if bold_prefix:
        r0 = p.add_run(bold_prefix); r0.bold = True
        r0.font.color.rgb = DRGB.from_string("1F4E79")
        r0.font.name = "Noto Sans CJK SC"
        r0.element.rPr.rFonts.set(qn("w:eastAsia"), "Noto Sans CJK SC")
    r = p.add_run(text)
    r.font.name = "Noto Sans CJK SC"
    r.element.rPr.rFonts.set(qn("w:eastAsia"), "Noto Sans CJK SC")
    return p

h("合作项目管理方案 · 讲稿", 18)
para("说明：本讲稿配合 6 页演示使用，时长约 5 分钟（约 1200 字），内容与页面事实一致，未补充资料之外的业绩或承诺。", bold_prefix=None)

h("第1页 · 封面（约30秒）")
para("各位工作组的同事好。今天向大家汇报《合作项目管理方案》。这个项目是在16周内建设企业设备知识库，总费用80万元含税，输入是120份确认版资料。本方案只依据双方已确认的事实编制，缺少的数据和未完成的事项我们如实标注，不做额外承诺。下面按现状、问题、计划三个部分来讲。")

h("第2页 · 现状：目标与范围（约50秒）")
para("先看现状和目标。项目的目标很明确：16周建成企业设备知识库，实现资料结构化管理和日常检索。合同内交付五项内容：分类目录、权限工作区、检索和导出功能、30条确认样本的测试记录，以及2场培训，培训配套操作手册。")
para("请大家注意页面右侧的范围边界：客户所有历史聊天、额外OCR、底座源代码所有权，这三项不在本项目范围内；第三方按量费没有纳入合同总价，需要另行确认。范围清楚，双方的预期才能一致。")

h("第3页 · 问题与风险（约60秒）")
para("第二部分讲问题。开工阶段我们识别出五项已知风险：一是部分文件缺版本号，会影响阶段1的去重和字典确认；二是权限配置方案还没确认，影响阶段2启动；三是30条样本的参考答案还不齐，直接影响阶段3测试和验收；四是现场网络条件未落实；五是导出版式要求待细化。这些目前都是待解决状态，不是已完成项。")
para("同时明确三条管控约束：第一，一切变更走书面变更单，未签批的追加不进入范围；第二，不能只因为日历到了就说验收通过；第三，不能用“全部交付”的说法掩盖还等着客户提供的依赖项。出现冲突先由双方项目经理协调，重大事项交管理层。")

h("第4页 · 四阶段计划与付款节点（约60秒）")
para("第三部分是计划。四个阶段共16周：阶段1四周，10月12日到11月8日，材料整理，客户数据管理员提供目录和版号，供应商负责去重，双方确认字典；阶段2六周，11月9日到12月20日，系统配置并演示；阶段3四周，12月21日到明年1月17日，用确认样本测试并留存缺陷记录；阶段4两周，1月18日到31日，交操作手册、完成培训和验收材料。页面左下的图表就是各阶段周数：4、6、4、2。")
para("付款分三笔，和验收直接挂钩：启动30%即24万，配置验收40%即32万，最终验收30%即24万。这里强调一遍：付款以对应验收通过为前提，不按日历自动触发。")

h("第5页 · 职责与协作机制（约50秒）")
para("为了让计划落地，职责这样分：客户项目经理确认范围、样本和验收；客户数据管理员确认数据版本与权限；供应商交付经理负责排期；研发实现配置；测试负责人保存测试结果。")
para("协作机制有四条：双方每周三开例会；所有问题进问题表，表里必须写清编号、事实、影响、责任人、截止日和状态；决策和变更要双方授权人确认；冲突先由项目经理协调，解决不了交管理层。页面下方的表是问题表的结构示例，实际条目在例会上滚动登记。")

h("第6页 · 付款、证据与待确认事项（约50秒）")
para("最后一页，把证据和待办再强调一下。付款凭据、验收记录、模型和文件版本要分别保存，三类证据分轨管理。启动前有五件事需要客户确认：补齐文件版号、确认权限方案、补齐30条样本答案、落实现场网络和导出版式，以及第三方按量费的承担方式。这五项解决得越早，阶段1和阶段2越顺利。")
para("总结一句话：范围清楚、计划明确、风险如实、付款与验收挂钩。请双方工作组对第6页的五项待确认事项给出时间安排。我的汇报到这里，谢谢大家。")

doc.save("/workspace/outputs/合作项目管理方案讲稿.docx")
print("DOCX saved")
