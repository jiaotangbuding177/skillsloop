import openpyxl
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
from datetime import datetime

wb = openpyxl.load_workbook('inputs/银行流水.xlsx', data_only=True)
ws = wb['银行流水']
rows = [list(r) for r in ws.iter_rows(min_row=2, values_only=True) if r[0]]
assert len(rows) == 60, len(rows)
lo, hi = datetime(2026,5,1), datetime(2026,6,30)
for r in rows:
    d = r[1] if isinstance(r[1], datetime) else datetime.strptime(str(r[1])[:10], '%Y-%m-%d')
    r[1] = d
    assert lo <= d <= hi

out = openpyxl.Workbook()
m = out.active; m.title = '分类汇总'
d = out.create_sheet('流水明细')

hdr = ['流水ID','日期','摘要','收入元','支出元','对方机构','分类（公式）']
d.append(hdr)
for r in rows:
    d.append([r[0], r[1], r[2], r[3], r[4], r[5], None])
for i in range(2, 2+len(rows)):
    d.cell(i,7).value = (
        '=IF(C{i}="产品销售回款","经营流入",IF(C{i}="研发补贴","经营流入",'
        'IF(C{i}="银行利息收入","经营流入—利息收入",IF(C{i}="材料采购","经营流出",'
        'IF(C{i}="员工报销","经营流出",IF(C{i}="备用金转出","经营流出（员工类）",'
        'IF(C{i}="服务外包","经营流出",IF(C{i}="设备采购","投资流出",'
        'IF(C{i}="项目投资款","投资流出",IF(C{i}="股东增资","筹资流入","待核"))))))))))'
    ).format(i=i)
for i in range(2, 2+len(rows)):
    d.cell(i,2).number_format = 'YYYY-MM-DD'
for col,w in zip('ABCDEFG',[10,12,16,12,12,14,20]):
    d.column_dimensions[col].width = w
for c in d[1]: c.font = Font(bold=True)
d.freeze_panes = 'A2'

D = "流水明细"
Dend = 1 + len(rows)  # last data row
# date-range criteria strings
DR = f'{D}!$B$2:$B${Dend},">="&DATE(2026,5,1),{D}!$B$2:$B${Dend},"<="&DATE(2026,6,30)'
def sumif_inc(cat): return f'=SUMIFS({D}!$D$2:$D${Dend},{D}!$C$2:$C${Dend},"{cat}",{DR})'
def sumif_exp(cat): return f'=SUMIFS({D}!$E$2:$E${Dend},{D}!$C$2:$C${Dend},"{cat}",{DR})'

title_font = Font(bold=True, size=14)
sec_fill = PatternFill('solid', fgColor='DDEBF7')
bold = Font(bold=True)
thin = Side(style='thin', color='999999')
border = Border(left=thin, right=thin, top=thin, bottom=thin)

m['A1'] = '2026年5月1日—6月30日现金流汇总（单位：人民币元，日期含首尾日）'
m['A1'].font = title_font
m.append(['类别','项目','流入元','流出元','净额元'])
for c in m[2]: c.font = bold; c.border = border

def item(cat_label, cat, r):
    m.cell(r,1).value = None
    m.cell(r,2).value = cat_label
    m.cell(r,3).value = sumif_inc(cat)
    m.cell(r,4).value = sumif_exp(cat)
    m.cell(r,5).value = f'=C{r}-D{r}'

def subtotal(label, r1, r2):
    m.cell(r,1) if False else None
    return None

r = 3
# 经营流入
sec_rows = []
m.cell(r,1).value = '经营活动'; m.cell(r,2).value = '经营流入—产品销售回款'
m.cell(r,3).value = sumif_inc('产品销售回款'); m.cell(r,4).value = 0; m.cell(r,5).value = f'=C{r}-D{r}'; r+=1
m.cell(r,2).value = '经营流入—研发补贴'; m.cell(r,3).value = sumif_inc('研发补贴'); m.cell(r,4).value = 0; m.cell(r,5).value = f'=C{r}-D{r}'; r+=1
m.cell(r,2).value = '经营流入—利息收入'; m.cell(r,3).value = sumif_inc('银行利息收入'); m.cell(r,4).value = 0; m.cell(r,5).value = f'=C{r}-D{r}'; r+=1
op_inc_sub = r
m.cell(r,2).value = '经营流入小计'; m.cell(r,3).value = f'=SUM(C3:C{r-1})'; m.cell(r,4).value = f'=SUM(D3:D{r-1})'; m.cell(r,5).value = f'=C{r}-D{r}'
for c in m[r]: c.font = bold
r+=1
# 经营流出
op_out_first = r
for lbl, cat in [('经营流出—材料采购','材料采购'),('经营流出—员工报销','员工报销'),('经营流出—备用金转出（员工类）','备用金转出'),('经营流出—服务外包','服务外包')]:
    m.cell(r,2).value = lbl; m.cell(r,3).value = sumif_inc(cat); m.cell(r,4).value = sumif_exp(cat); m.cell(r,5).value = f'=C{r}-D{r}'; r+=1
op_out_sub = r
m.cell(r,2).value = '经营流出小计'; m.cell(r,3).value = f'=SUM(C{op_out_first}:C{r-1})'; m.cell(r,4).value = f'=SUM(D{op_out_first}:D{r-1})'; m.cell(r,5).value = f'=C{r}-D{r}'
for c in m[r]: c.font = bold
r+=1
op_net = r
m.cell(r,2).value = '经营活动净额（流入小计−流出小计）'
m.cell(r,3).value = f'=C{op_inc_sub}'; m.cell(r,4).value = f'=D{op_out_sub}'; m.cell(r,5).value = f'=C{r}-D{r}'
for c in m[r]: c.font = bold; c.fill = sec_fill
r+=2
# 投资
inv_first = r
for lbl, cat in [('投资流出—设备采购','设备采购'),('投资流出—项目投资款','项目投资款')]:
    m.cell(r,2).value = lbl; m.cell(r,3).value = sumif_inc(cat); m.cell(r,4).value = sumif_exp(cat); m.cell(r,5).value = f'=C{r}-D{r}'; r+=1
inv_sub = r
m.cell(r,2).value = '投资流出小计'; m.cell(r,3).value = f'=SUM(C{inv_first}:C{r-1})'; m.cell(r,4).value = f'=SUM(D{inv_first}:D{r-1})'; m.cell(r,5).value = f'=C{r}-D{r}'
for c in m[r]: c.font = bold
r+=1
inv_net = r
m.cell(r,2).value = '投资活动净额（流入−流出）'; m.cell(r,3).value = 0; m.cell(r,4).value = f'=D{inv_sub}'; m.cell(r,5).value = f'=C{r}-D{r}'
for c in m[r]: c.font = bold; c.fill = sec_fill
r+=2
# 筹资
fin_first = r
m.cell(r,2).value = '筹资流入—股东增资'; m.cell(r,3).value = sumif_inc('股东增资'); m.cell(r,4).value = 0; m.cell(r,5).value = f'=C{r}-D{r}'; r+=1
fin_sub = r
m.cell(r,2).value = '筹资流入小计'; m.cell(r,3).value = f'=SUM(C{fin_first}:C{r-1})'; m.cell(r,4).value = f'=SUM(D{fin_first}:D{r-1})'; m.cell(r,5).value = f'=C{r}-D{r}'
for c in m[r]: c.font = bold
r+=1
fin_net = r
m.cell(r,2).value = '筹资活动净额（流入−流出）'; m.cell(r,3).value = f'=C{fin_sub}'; m.cell(r,4).value = 0; m.cell(r,5).value = f'=C{r}-D{r}'
for c in m[r]: c.font = bold; c.fill = sec_fill
r+=2
# 总净额
total = r
m.cell(r,2).value = '总净额（经营+投资+筹资）'; m.cell(r,3).value = f'=E{op_net}+E{inv_net}+E{fin_net}'
m.cell(r,3).font = bold; m.cell(r,2).font = bold
r+=2
# 核对区
m.cell(r,1).value = '核对区'; m.cell(r,1).font = bold; r+=1
chk1 = r
m.cell(r,2).value = '核对1：总净额 − 明细（收入合计−支出合计）'
m.cell(r,3).value = f'=C{total}-(SUM({D}!$D$2:$D${Dend})-SUM({D}!$E$2:$E${Dend}))'; r+=1
chk2 = r
m.cell(r,2).value = '核对2：汇总各项目流入合计 − 明细收入合计'
# sum of item inflow cells (all item rows, excluding subtotal/net rows)
m.cell(r,3).value = (f'=C3+C4+C5+C{op_out_first}+C{op_out_first+1}+C{op_out_first+2}+C{op_out_first+3}'
                     f'+C{inv_first}+C{inv_first+1}+C{fin_first}-SUM({D}!$D$2:$D${Dend})'); r+=1
chk3 = r
m.cell(r,2).value = '核对3：汇总各项目流出合计 − 明细支出合计'
m.cell(r,3).value = (f'=D3+D4+D5+D{op_out_first}+D{op_out_first+1}+D{op_out_first+2}+D{op_out_first+3}'
                     f'+D{inv_first}+D{inv_first+1}-SUM({D}!$E$2:$E${Dend})'); r+=1
chk4 = r
m.cell(r,2).value = '核对4：待核（未匹配分类）流水条数'
m.cell(r,3).value = f'=COUNTIF({D}!$G$2:$G${Dend},"待核")'; r+=1
chk5 = r
m.cell(r,2).value = '核对5：明细流水条数（每条只计一次）'
m.cell(r,3).value = f'=COUNTA({D}!$A$2:$A${Dend})'; r+=1
m.cell(r,2).value = '说明：核对1—3应为0；核对4应为0（无未匹配摘要）；核对5应为60。'

for col,w in zip('ABCDE',[12,40,16,16,16]):
    m.column_dimensions[col].width = w
for row in m.iter_rows(min_row=2):
    for c in row:
        if c.value is not None and c.column >= 2:
            c.border = border
for row in m.iter_rows(min_row=3):
    for c in row:
        if c.column in (3,4,5) and c.value is not None:
            c.number_format = '#,##0.00'

out.save('outputs/两月现金流汇总.xlsx')
print('saved')
