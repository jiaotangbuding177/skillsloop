# -*- coding: utf-8 -*-
"""按 technology_card.json / scenarios.csv / selection_rule.md 生成
commercialization.xlsx 与 pilot_proposal.docx。所有结论仅引用输入文件证据。"""
import csv, json
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
from openpyxl.utils import get_column_letter
from docx import Document
from docx.shared import Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn

# ---------- 读取输入 ----------
with open('/workspace/inputs/technology_card.json', encoding='utf-8') as f:
    tech = json.load(f)
with open('/workspace/inputs/scenarios.csv', encoding='utf-8-sig') as f:
    rows = list(csv.DictReader(f))
with open('/workspace/inputs/selection_rule.md', encoding='utf-8') as f:
    rule_text = f.read()

temp_lo, temp_hi = tech['temperature_range_c']
lifetime_ok = tech['validated_lifetime_months']
cost = tech['prototype_cost_yuan_m2']
VALIDATION_LIMIT = 6  # 规则：优先六个月内可验证

# 每项技术事实的条件检查：返回 (是否满足, 匹配表述, 不匹配表述)
def check(sc):
    name = sc['场景']
    t_req = int(sc['温度上限']); life_req = int(sc['寿命月'])
    cert = sc['认证需要']; budget = int(sc['客户预算元平']); months = int(sc['验证月'])
    m, nm = [], []

    # 1 温度
    if t_req <= temp_hi:
        m.append(f"温度上限{t_req}℃落在已证温区{temp_lo}~{temp_hi}℃内")
    else:
        nm.append(f"温度上限{t_req}℃超出已证温区{temp_lo}~{temp_hi}℃")
    # 2 寿命
    if life_req <= lifetime_ok:
        m.append(f"要求寿命{life_req}个月≤已证寿命{lifetime_ok}个月")
    else:
        nm.append(f"要求寿命{life_req}个月>已证寿命{lifetime_ok}个月")
    # 3 认证（未获或未知不能假定补齐）
    if cert == '无食品接触':
        m.append("无需食品接触认证；selection_rule.md 明确\"仓库保温本期无需产品专项认证\"")
    elif cert == '部件安全':
        nm.append("需部件安全认证；selection_rule.md 明确\"仪器隔热的部件安全认证尚未提供\"，technology_card.json 其他认证为\"材料未提供\"——未获，不能假定补齐")
    elif cert == '食品接触':
        nm.append("需食品接触认证；technology_card.json food_contact_certificate=false——未获")
    elif cert == '防火等级':
        nm.append("需防火等级认证；technology_card.json fire_class=\"仅小样测试\"——未获正式认证")
    elif cert == '建筑验收':
        nm.append("需建筑验收认证；technology_card.json 其他认证为\"材料未提供\"——未获")
    elif cert == '清洗卫生':
        nm.append("需清洗卫生认证；technology_card.json 其他认证为\"材料未提供\"——未获，不能假定补齐")
    # 4 预算（上限，与成本对比仅判断可行性空间）
    if budget >= cost:
        m.append(f"客户预算{budget}元/平高于样品成本{cost}元/平（预算为客户可承受上限，非成交价）")
    else:
        nm.append(f"客户预算{budget}元/平低于样品成本{cost}元/平，无盈利空间")
    # 5 验证周期
    if months <= VALIDATION_LIMIT:
        m.append(f"验证周期{months}个月≤{VALIDATION_LIMIT}个月，可在六个月内验证")
    else:
        nm.append(f"验证周期{months}个月>{VALIDATION_LIMIT}个月，超出本期六个月窗口")
    return name, m, nm

evaluations = [check(sc) for sc in rows]
qualified = [e for e in evaluations if not e[2]]
conditional = [e for e in evaluations if e[0] == '仪器隔热']
rejected = [e for e in evaluations if e[2] and e[0] != '仪器隔热']

# ---------- commercialization.xlsx ----------
wb = Workbook()
thin = Side(style='thin', color='999999')
border = Border(left=thin, right=thin, top=thin, bottom=thin)
hdr_fill = PatternFill('solid', fgColor='305496')
q_fill = PatternFill('solid', fgColor='C6EFCE')   # 合格
c_fill = PatternFill('solid', fgColor='FFEB9C')   # 条件性
r_fill = PatternFill('solid', fgColor='F2F2F2')   # 不合格
hdr_font = Font(bold=True, color='FFFFFF')
wrap = Alignment(wrap_text=True, vertical='top')

def style_sheet(ws, widths, n_rows):
    for i, w in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = w
    for row in ws.iter_rows(min_row=1, max_row=n_rows, max_col=len(widths)):
        for cell in row:
            cell.border = border
            cell.alignment = wrap
            if cell.row == 1:
                cell.fill = hdr_fill; cell.font = hdr_font

# Sheet1 筛选结论
ws1 = wb.active; ws1.title = '筛选结论'
ws1.append(['结论类别', '场景', '判据依据', '说明'])
ws1.append(['合格首选（付费验证）', '仓库保温',
            '温度60≤120、寿命3≤3、无需专项认证（规则确认）、预算220≥成本160、验证3≤6个月',
            '全部条件匹配，六个月内可完成验证；首批付费验证仅此一项，合格不足按规则少列'])
ws1.append(['条件性候选', '仪器隔热',
            '温度110≤120、寿命3≤3、预算320≥160、验证4≤6个月均匹配；部件安全认证尚未提供',
            '技术条件全部匹配，唯一缺口为部件安全认证；状态为\"待验证\"而非已合格，认证补齐前不进入首批付费验证'])
for name, m, nm in rejected:
    concl = '不合格' if not nm else '不合格'
    ws1.append(['不合格', name, '；'.join(nm), '存在硬性不匹配条件，本轮不列'] if nm else ['不合格', name, '', ''])
style_sheet(ws1, [18, 12, 55, 55], ws1.max_row)
for r in range(2, ws1.max_row+1):
    v = ws1.cell(row=r, column=1).value
    ws1.cell(row=r, column=1).fill = q_fill if '首选' in v else (c_fill if '条件' in v else r_fill)
    ws1.cell(row=r, column=2).font = Font(bold=True)

# Sheet2 逐场景条件对照
ws2 = wb.create_sheet('逐场景条件对照')
ws2.append(['场景', '温度上限(℃)', '要求寿命(月)', '认证需要', '客户预算(元/平)', '验证(月)',
            '匹配条件（逐项引用输入文件）', '不匹配条件（逐项引用输入文件）', '结论'])
status = {}
for name, m, nm in evaluations:
    if name == '仓库保温': s = '合格首选'
    elif name == '仪器隔热': s = '条件性候选（部件安全认证待验证）'
    else: s = '不合格'
    status[name] = s
    sc = next(r for r in rows if r['场景'] == name)
    ws2.append([name, int(sc['温度上限']), int(sc['寿命月']), sc['认证需要'],
                int(sc['客户预算元平']), int(sc['验证月']),
                '\n'.join(f"{i+1}. {x}" for i, x in enumerate(m)) or '无',
                '\n'.join(f"{i+1}. {x}" for i, x in enumerate(nm)) or '无', s])
style_sheet(ws2, [12, 12, 12, 12, 13, 9, 60, 60, 22], ws2.max_row)
for r in range(2, ws2.max_row+1):
    s = ws2.cell(row=r, column=9).value
    fill = q_fill if s == '合格首选' else (c_fill if '条件性' in s else r_fill)
    for c in range(1, 10):
        ws2.cell(row=r, column=c).fill = fill

# Sheet3 技术事实与规则依据
ws3 = wb.create_sheet('技术事实与规则依据')
ws3.append(['来源', '条目', '内容'])
ws3.append(['technology_card.json', '技术', tech['technology']])
ws3.append(['technology_card.json', '已证温度范围(℃)', f"{temp_lo} ~ {temp_hi}"])
ws3.append(['technology_card.json', '已证寿命(月)', lifetime_ok])
ws3.append(['technology_card.json', '食品接触认证', '无（false）'])
ws3.append(['technology_card.json', '防火等级', tech['fire_class']])
ws3.append(['technology_card.json', '其他认证', tech['other_certificates']])
ws3.append(['technology_card.json', '样品成本(元/平)', cost])
for i, line in enumerate(l for l in rule_text.splitlines() if l.strip()):
    ws3.append(['selection_rule.md', f'规则第{i+1}条', line.strip()])
style_sheet(ws3, [22, 18, 80], ws3.max_row)

wb.save('/workspace/outputs/commercialization.xlsx')

# ---------- pilot_proposal.docx ----------
doc = Document()
style = doc.styles['Normal']
style.font.name = 'Noto Sans CJK SC'; style.font.size = Pt(11)
style._element.rPr.rFonts.set(qn('w:eastAsia'), 'Noto Sans CJK SC')
for i in (1, 2):
    hs = doc.styles[f'Heading {i}']
    hs.font.name = 'Noto Sans CJK SC'
    hs._element.rPr.rFonts.set(qn('w:eastAsia'), 'Noto Sans CJK SC')
    hs.font.color.rgb = RGBColor(0, 0, 0)

doc.add_heading('材料技术首批付费验证场景筛选与试点验证方案', level=0)
p = doc.add_paragraph('技术对象：低温隔热复合膜（依据 inputs/technology_card.json）')
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
p = doc.add_paragraph('筛选依据：inputs/scenarios.csv、inputs/selection_rule.md')
p.alignment = WD_ALIGN_PARAGRAPH.CENTER

doc.add_heading('一、技术现状（全部引自 technology_card.json）', level=1)
for line in [
    f"已证温度范围：{temp_lo}℃ ~ {temp_hi}℃；",
    f"已证寿命：{lifetime_ok}个月；",
    "食品接触认证：无；",
    f"防火等级：{tech['fire_class']}（未获正式防火认证）；",
    f"其他认证：{tech['other_certificates']}；",
    f"样品成本：{cost}元/平。",
]:
    doc.add_paragraph(line, style='List Bullet')
doc.add_paragraph('上述为当前唯一可引用的技术事实，未获或未知认证不作为已具备能力。')

doc.add_heading('二、筛选规则与判定标准（引自 selection_rule.md）', level=1)
for line in [
    '已证温度和寿命必须满足：场景要求的温度上限与寿命不得超过已证值；',
    '未获或未知认证不能假定补齐；',
    '至多两项合格首选，合格不足可以少列；可另列一项条件性候选，但须写明\"待验证\"而非\"已合格\"；',
    '报价以客户预算为可承受上限，不能当成交价；',
    '优先选择可在六个月内完成验证的场景。',
]:
    doc.add_paragraph(line, style='List Number')

doc.add_heading('三、筛选结果汇总', level=1)
tbl = doc.add_table(rows=1, cols=3)
tbl.style = 'Table Grid'
hdr = tbl.rows[0].cells
for i, t in enumerate(['结论', '场景', '关键依据']):
    hdr[i].text = t
    hdr[i].paragraphs[0].runs[0].font.bold = True
summary = [
    ('合格首选（1项）', '仓库保温', '温度、寿命、认证、预算、验证周期五项全部匹配'),
    ('条件性候选（1项）', '仪器隔热', '技术条件全部匹配，部件安全认证待验证，未获前不进入首批'),
    ('不合格（4项）', '食品包装、电池防火、仪器隔热外场景说明见第五章', '食品包装、电池防火、建筑外墙、冷链周转箱各有硬性不匹配'),
]
for a, b, c in summary:
    r = tbl.add_row().cells
    r[0].text, r[1].text, r[2].text = a, b, c
p = doc.add_paragraph('合格场景仅一项，少于规则允许的两项上限，按规则如实少列；不放宽任何未满足条件，不补造认证。')
p.runs[0].font.bold = True

doc.add_heading('四、首批付费验证场景：仓库保温', level=1)
doc.add_heading('4.1 匹配条件逐项引用', level=2)
for line in [
    '温度：场景温度上限60℃，落在已证温区-20~120℃内；',
    '寿命：场景要求3个月，等于已证寿命3个月，恰好满足；',
    '认证：场景认证需要为\"无食品接触\"，且 selection_rule.md 明确\"仓库保温本期无需产品专项认证\"；',
    '预算：客户预算220元/平高于样品成本160元/平，存在报价空间（220元/平为客户可承受上限，非成交价，实际报价需另行谈判）；',
    '验证周期：3个月，在六个月窗口内。',
]:
    doc.add_paragraph(line, style='List Bullet')
doc.add_heading('4.2 六个月验证方案', level=2)
for line in [
    '第1个月：与仓库客户签订付费试点协议，明确按可交付状态小批量供货（成本160元/平为定价底线参考）；',
    '第2~3个月：在实际仓库环境完成3个月连续使用验证，对照已证指标（温度60℃以内、寿命3个月）；',
    '第4~5个月：复核使用数据，评估续购意愿与批量订单报价区间；',
    '第6个月：输出验证结论，决定是否扩大供货规模。',
]:
    doc.add_paragraph(line, style='List Number')
doc.add_paragraph('风险提示：已证寿命仅3个月，场景要求即3个月，无冗余余量；若仓库实际工况出现温度波动超出60℃或使用超期，需重新评估。')

doc.add_heading('五、不合格场景及具体不匹配条件', level=1)
rej_detail = {
    '食品包装': ['要求寿命12个月，超过已证寿命3个月；', '需食品接触认证，technology_card.json 为 food_contact_certificate=false；', '客户预算120元/平低于样品成本160元/平，无盈利空间。'],
    '电池防火': ['温度上限300℃，远超已证温区上限120℃；', '要求寿命36个月，超过已证寿命3个月；', '需防火等级认证，当前仅为\"仅小样测试\"，未获正式认证；', '验证周期9个月，超出六个月窗口。'],
    '建筑外墙': ['要求寿命60个月，超过已证寿命3个月；', '需建筑验收认证，其他认证\"材料未提供\"；', '客户预算90元/平低于样品成本160元/平；', '验证周期12个月，超出六个月窗口。'],
    '冷链周转箱': ['要求寿命6个月，超过已证寿命3个月；', '需清洗卫生认证，其他认证\"材料未提供\"，未获不能假定补齐。'],
}
for name in ['食品包装', '电池防火', '建筑外墙', '冷链周转箱']:
    doc.add_heading(name, level=2)
    for line in rej_detail[name]:
        doc.add_paragraph(line, style='List Bullet')

doc.add_heading('六、条件性候选：仪器隔热（待验证，非已合格）', level=1)
doc.add_paragraph('以下条件匹配：', style=None)
for line in [
    '温度：场景温度上限110℃，落在已证温区-20~120℃内；',
    '寿命：场景要求3个月，等于已证寿命3个月；',
    '预算：客户预算320元/平高于样品成本160元/平；',
    '验证周期：4个月，在六个月窗口内。',
]:
    doc.add_paragraph(line, style='List Bullet')
doc.add_paragraph('待验证项（唯一缺口）：')
doc.add_paragraph('部件安全认证：selection_rule.md 明确\"仪器隔热的部件安全认证尚未提供\"，technology_card.json 其他认证为\"材料未提供\"。按规则\"未获或未知认证不能假定补齐\"，该项状态为待验证而非已合格。')
doc.add_paragraph('后续路径：若客户在试点期内接受以第三方部件安全检测替代（检测周期与费用需另行确认，本方案不预设其结果），认证补齐后仪器隔热可升级为付费验证场景；补齐前不列入首批。')

doc.add_heading('七、声明', level=1)
for line in [
    '本方案所有结论仅引用 technology_card.json、scenarios.csv、selection_rule.md 三份输入文件，未引入外部假设；',
    '认证状态以输入文件记载为准，未补造任何认证；',
    '客户预算为可承受上限，均不作为成交价；',
    '合格首选仅1项（仓库保温），少于规则允许的2项上限，属合格不足情形，已按规则如实少列并说明。',
]:
    doc.add_paragraph(line, style='List Number')

doc.save('/workspace/outputs/pilot_proposal.docx')
print('OK: both files written')
print('qualified:', [e[0] for e in qualified])
print('conditional:', [e[0] for e in conditional])
print('rejected:', [e[0] for e in rejected])
