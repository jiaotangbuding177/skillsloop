# 索引使用说明（index_readme.md）

本说明配套 `search_index.json`，用于在 `/workspace/inputs/docs/` 的12份资料上按关键词定位文档。索引为静态文件，不需要检索服务，也不访问外网。

## 覆盖范围

- 源目录：`inputs/docs/`，共12份 Markdown 文档，索引每份恰好1条。
- 文件名保留中文原名与序号（如 `01_采购报价.md`），路径字段可直接复制使用。
- 全部文档版本均为 1.0（每条记录的 `version` 字段来自文档正文自述）。

## JSON 结构

顶层字段：

| 字段 | 含义 |
| --- | --- |
| `index_name` / `description` | 索引名称与范围说明 |
| `schema` | 各字段定义 |
| `usage` | 检索方式与示例 |
| `generated_at` | 索引生成日期 |
| `entries` | 12条文档记录 |

每条 `entry`：

| 字段 | 含义 |
| --- | --- |
| `title` | 文档标题，取自正文一级标题 |
| `path` | 相对路径，保留中文文件名 |
| `updated` | 文档自述更新日期（正文“更新YYYY-MM-DD”） |
| `version` | 文档自述版本号 |
| `owner` | 文档自述责任人（正文“owner=XX”） |
| `keywords` | 检索关键词，全部取自该文档标题、正文或元信息 |
| `snippet` | 正文原文摘录，逐字引用，未改写 |

## 检索方法

索引支持按关键词命中**标题、路径、更新时间与匹配摘录**。最简单的本地检索方式：

```bash
# 用 grep 直接在索引中找关键词（命中行所在 JSON 块即对应文档）
grep -n "预算" /workspace/outputs/search_index.json
```

```python
# 用 Python 一次匹配多个字段并打印结果
import json
idx = json.load(open("/workspace/outputs/search_index.json", encoding="utf-8"))
kw = "预算"
for e in idx["entries"]:
    hay = [e["title"], e["path"], e["updated"], e["snippet"], " ".join(e["keywords"])]
    if any(kw in h for h in hay):
        print(e["path"], "|", e["updated"], "|", e["snippet"])
```

示例：

- 关键词 `预算` → `inputs/docs/07_项目预算.md`（更新 2026-09-07）
- 关键词 `2026-09-12` → `inputs/docs/12_隐私边界.md`（按更新时间检索）
- 关键词 `90天` → `inputs/docs/11_保留周期.md`（按摘录检索）

## 边界声明

1. 索引只提供**定位信息**（标题、路径、时间、摘录），不代表访问者拥有对应正文权限；正文访问仍按 `04_权限规则.md` 的权限体系执行。
2. 所有 `snippet` 与 `keywords` 均逐字取自文档本身，未加入材料中不存在的事实，未编造任何外部链接。
3. 文档内容后续如有变更，请以 `inputs/docs/` 原文为准，并重新生成本索引。
