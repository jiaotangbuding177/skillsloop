# -*- coding: utf-8 -*-
"""整理 baseline.json + status_updates.csv -> status_report.docx / status_changes.xlsx
口径(status_rules.md): 报告日期10月7日; 签收文件不等于业务验收; C无新记录不自动启动;
保留所有负证据与待验证自述。
"""
import json, csv
from docx import Document
from docx.shared import Pt
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment

baseline = {r["project"]: r for r in json.load(open("/workspace/inputs/baseline.json", encoding="utf-8-sig"))}
updates = list(csv.DictReader(open("/workspace/inputs/status_updates.csv", encoding="utf-8-sig")))

# 每项目最新记录(按日期)
latest = {}
for u in updates:
    p = u["项目"].strip()
    if p not in latest or u["日期"] > latest[p]["日期"]:
        latest[p] = u

# 核对表: 项目 | 基线 | 基线日期 | 最新进展 | 进展日期 | 证据 | 结论/缺失
rows = []
for p in sorted(baseline):
    b = baseline[p]
    if p in latest:
        u = latest[p]
        msg, ev, date = u["消息"].strip(), u["证据"].strip(), u["日期"]
        if p == "A":
            conclusion = "有书面证据(联调日志E5)的进展记录，采信为最新状态；仍处联调阶段，非已验收"
            missing = "验收证据缺失(未到验收环节)"
        elif p == "B":
            conclusion = "最新记录为权限问题(测试E6，负证据，保留)；10-04\u201c有人说都成功了\u201d为口头自述、无书面证据，不升级为已验收/成功"
            missing = "10-04\u201c都成功\u201d无证据(口头)；需补充修复权限问题的书面测试记录"
        elif p == "D":
            conclusion = "客户已签收(签收E7)，但签收文件不等于业务验收，状态保持\u201c已交付待验\u201d，不升级为已验收"
            missing = "业务验收记录缺失(仅有签收E7)"
        else:
            conclusion, missing = "按记录整理", "按记录核对"
        rows.append([p, b["state"], b["as_of"], msg, date, ev, conclusion, missing])
    else:
        rows.append([p, b["state"], b["as_of"], "无新记录", "-", "-",
                     "C无新记录，不能自动启动，保留基线状态\u201c待启动\u201d与基线日期2026-09-30",
                     "10月进展证据缺失：无任何新记录(仅基线E3)"])

# ============ status_changes.xlsx ============
wb = Workbook()
ws = wb.active
ws.title = "状态核对"
headers = ["项目", "基线状态", "基线日期", "最新进展", "进展日期", "证据", "结论", "缺失证据"]
ws.append(headers)
for r in rows:
    ws.append(r)
head_fill = PatternFill("solid", fgColor="D9E2F3")
for c in ws[1]:
    c.font = Font(bold=True); c.fill = head_fill
    c.alignment = Alignment(horizontal="center", vertical="center")
widths = [8, 12, 12, 22, 12, 12, 52, 44]
for i, w in enumerate(widths, 1):
    ws.column_dimensions[chr(64 + i)].width = w
for row in ws.iter_rows(min_row=2):
    for c in row:
        c.alignment = Alignment(vertical="top", wrap_text=True)

# 明细sheet: 全部更新记录(保留负证据与自述)
ws2 = wb.create_sheet("更新记录明细")
ws2.append(["日期", "项目", "消息", "证据", "性质判定"])
nature = {
    ("2026-10-03", "A"): "书面证据(联调日志E5)，采信",
    ("2026-10-04", "B"): "口头自述，待验证，不升级状态",
    ("2026-10-05", "B"): "负证据(测试E6)，保留",
    ("2026-10-06", "D"): "签收E7；签收不等于业务验收，不升级为已验收",
}
for u in updates:
    ws2.append([u["日期"], u["项目"], u["消息"], u["证据"],
                nature.get((u["日期"], u["项目"]), "按记录整理")])
for c in ws2[1]:
    c.font = Font(bold=True); c.fill = head_fill
for i, w in enumerate([12, 8, 22, 12, 46], 1):
    ws2.column_dimensions[chr(64 + i)].width = w
for row in ws2.iter_rows(min_row=2):
    for c in row:
        c.alignment = Alignment(vertical="top", wrap_text=True)
wb.save("/workspace/outputs/status_changes.xlsx")

# ============ status_report.docx ============
doc = Document()
style = doc.styles["Normal"]
style.font.name = "Noto Sans CJK SC"; style.font.size = Pt(10.5)

t = doc.add_heading("四项目状态报告（截至2026年10月7日）", level=1)
p = doc.add_paragraph("数据来源：inputs/baseline.json（基线，截至2026-09-30）、inputs/status_updates.csv（10月更新）；口径依据 inputs/status_rules.md。")
p = doc.add_paragraph("核对口径：① 签收文件不等于业务验收；② C无新记录，不能自动启动，保留基线；③ 保留所有负证据与待验证自述；④ 无新记录项目保留基线日期。")

# 逐项
doc.add_heading("一、各项目最新进展与缺失证据", level=2)
proj_note = {
    "A": ["最新进展：2026-10-03 接口通过（证据：联调日志E5）。",
          "判定：有书面证据，采信为最新状态；仍处联调阶段，未到验收。",
          "缺失证据：验收记录（当前无需，进入验收环节时需补）。"],
    "B": ["最新进展：2026-10-05 发现权限问题（证据：测试E6，负证据，予以保留）。",
          "2026-10-04 \u201c有人说都成功了\u201d为口头自述、无书面证据，属待验证自述，不升级为已验收/成功。",
          "缺失证据：\u201c都成功\u201d无证据；需补充权限问题修复后的书面测试记录。"],
    "C": ["最新进展：无新记录（10月无任何更新）。",
          "判定：按口径不能自动启动，保留基线状态\u201c待启动\u201d及基线日期2026-09-30（基线证据E3）。",
          "缺失证据：10月进展证据缺失。"],
    "D": ["最新进展：2026-10-06 客户签收但没验收（证据：签收E7）。",
          "判定：签收文件不等于业务验收，状态保持\u201c已交付待验\u201d，不升级为已验收。",
          "缺失证据：业务验收记录（仅有签收E7）。"],
}
for r in rows:
    p = r[0]
    doc.add_heading(f"项目 {p}", level=3)
    tbl = doc.add_table(rows=1, cols=2)
    tbl.style = "Table Grid"
    info = [("基线状态", f"{baseline[p]['state']}（{baseline[p]['as_of']}，证据 {baseline[p]['evidence']}）"),
            ("最新进展", r[3] if r[3] != "无新记录" else "无新记录"),
            ("进展日期", r[4]),
            ("证据", r[5]),
            ("当前状态判定", r[6]),
            ("缺失证据", r[7])]
    for k, v in info:
        cells = tbl.add_row().cells
        cells[0].text = k; cells[1].text = v
    tbl._tbl.remove(tbl.rows[0]._tr)  # 去掉空表头行
    for note in proj_note[p]:
        doc.add_paragraph(note, style="List Bullet")

doc.add_heading("二、缺失证据汇总", level=2)
mt = doc.add_table(rows=1, cols=2)
mt.style = "Table Grid"
h = mt.rows[0].cells
h[0].text = "项目"; h[1].text = "缺失证据"
for c in h: c.paragraphs[0].runs and None
mt.rows[0].cells[0].paragraphs[0].add_run("")
for r in rows:
    cells = mt.add_row().cells
    cells[0].text = r[0]; cells[1].text = r[7]
# 加粗表头
from docx.oxml.ns import qn
for c in mt.rows[0].cells:
    for para in c.paragraphs:
        for run in para.runs:
            run.font.bold = True

doc.add_heading("三、说明", level=2)
for s in ["本报告仅依据所给三个输入文件整理，未采集其他渠道信息。",
          "所有负证据（B项目权限问题）与待验证自述（B项目口头\u201c都成功\u201d）均如实保留，未作升级或删除。",
          "C项目无新记录，按口径未自动启动；如后续收到C的正式启动证据，可更新报告。"]:
    doc.add_paragraph(s, style="List Bullet")

doc.save("/workspace/outputs/status_report.docx")
print("generated")
