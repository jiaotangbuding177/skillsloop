# -*- coding: utf-8 -*-
import docx, copy
from docx.shared import RGBColor

RED = RGBColor(0xC0, 0x00, 0x00)

def rebuild(par, parts):
    """parts: list of (text, is_changed)"""
    # keep first run as formatting template
    tmpl = par.runs[0]
    for r in list(par.runs):
        r._element.getparent().remove(r._element)
    for text, changed in parts:
        r = par.add_run(text)
        if tmpl is not None:
            r.font.name = tmpl.font.name
            r.font.size = tmpl.font.size
        if changed:
            r.font.bold = True
            r.font.color.rgb = RED

d = docx.Document('inputs/采购框架草稿.docx')
P = d.paragraphs

# 条6 验收：新增指标走书面变更
rebuild(P[13], [
    ("客户到货后10工作日按型号、数量和确认性能表验收。", False),
    ("验收以双方已确认的性能附件为限；客户在验收中提出的新增指标或其他新要求，须经双方书面变更单确认后方可实施，费用与工期按变更单约定执行。", True),
])

# 条7 保修：保修归因
rebuild(P[15], [
    ("正常使用保修12个月，供应商自身质量缺陷的保修责任不减；", False),
    ("因客户误用、擅自拆修、第三方软件不兼容，或客户未按第9条提供现场条件导致的故障，不自动由供应商承担保修责任，故障原因由双方共同确认后归因。", True),
])

# 条8 责任：付款迟延救济（保留供应商迟延0.02%与间接损失表述不动）
rebuild(P[17], [
    ("供应商迟延每日0.02%；", False),
    ("采购方付款迟延超过15日的，供应商可书面催告并暂停交付未交部分，同时保留相关记录，交付期相应顺延。", True),
    ("对任何间接损失供应商不设上限。", False),
])

# 条9 未决事项：现场前提
rebuild(P[19], [
    ("现场网络和电源条件清单还需客户提供；签订附件前不以本稿推断现场满足。", False),
    ("客户应按双方确认的清单在设备到货前提供现场网络、电源等条件；现场条件未具备影响安装调试、验收或保修响应的，相关工期顺延，相应后果不由供应商承担。", True),
])

d.save('outputs/采购框架局部修订.docx')
print('saved')
