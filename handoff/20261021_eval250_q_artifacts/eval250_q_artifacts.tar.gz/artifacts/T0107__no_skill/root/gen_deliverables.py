# -*- coding: utf-8 -*-
from docx import Document
from docx.shared import Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
import openpyxl
from openpyxl.styles import Font, Alignment, PatternFill
import os

os.makedirs('/workspace/outputs', exist_ok=True)

# ============ incident_brief.docx ============
doc = Document()
doc.add_heading('桥溪园区仓库火情事故简报', level=1)
p = doc.add_paragraph('信息截止：2026-10-08 13:00（北京时间） | 事故与机构均为模拟数据 | 编制：运营团队内部参考')
p.runs[0].font.size = Pt(9)
p.runs[0].font.color.rgb = RGBColor(0x66, 0x66, 0x66)

doc.add_heading('一、时间与地点', level=2)
doc.add_paragraph('2026-10-08 07:40，桥溪园区一处仓库发生火情（园区应急办公室 08:15 首次通报）。')

doc.add_heading('二、官方确认事实（来源：桥溪园区应急办公室，按时间顺序）', level=2)
for t, txt in [
    ('08:15 首次通报', '7:40 一处仓库发生火情，已疏散现场人员；伤亡信息当时核实中。'),
    ('10:00 阶段通报', '火已扑灭；两人送医观察，未确认死亡；承包商人数仍在核对。'),
    ('12:00 更新（截至 13:00 的最新口径）', '现场人员全部核对完成；两人轻伤，无死亡；起火原因仍在调查。'),
]:
    bp = doc.add_paragraph(style='List Bullet')
    r1 = bp.add_run(f'【{t}】')
    r1.bold = True
    bp.add_run(txt)

doc.add_paragraph('伤亡结论以办公室 12:00 最新通报为准：两人轻伤，无死亡。早期“核实中”为过程信息，予以保留，不作为最终结论。')

doc.add_heading('三、企业自述（仓库经营公司，未经官方独立核实）', level=2)
for t, txt in [
    ('08:30 企业说明', '公司称员工名单完整，正在核对承包商名单。'),
    ('12:15 物流声明', '涉事仓库暂停作业，其他仓库继续；恢复日期未定。'),
]:
    bp = doc.add_paragraph(style='List Bullet')
    r1 = bp.add_run(f'【{t}】')
    r1.bold = True
    bp.add_run(txt)

doc.add_heading('四、传闻与未证实信息（不采信，仅记录以供比对）', level=2)
for t, txt in [
    ('08:45 社交转述（传闻）', '有人称“十余人失联”，无姓名名单或出处；与官方 12:00“现场人员全部核对完成、无死亡”不符，不予采信。'),
    ('12:30 社交转述（推测）', '猜测电池故障引发，无任何调查依据；原因以官方调查结论为准。'),
    ('10:30 媒体乙（转述）', '报道“两人送医，原因待调查”，与官方口径一致，属二手转述，不作为独立证据。'),
]:
    bp = doc.add_paragraph(style='List Bullet')
    r1 = bp.add_run(f'【{t}】')
    r1.bold = True
    bp.add_run(txt)

doc.add_heading('五、起火原因状态', level=2)
doc.add_paragraph('未明。截至 2026-10-08 13:00，官方口径为“起火原因仍在调查”（12:00 更新），尚无确认的起火原因。')

doc.add_heading('六、业务影响（以企业声明为准，官方未另行通报）', level=2)
doc.add_paragraph('涉事仓库自 10-08 起暂停作业；园区其他仓库继续作业；恢复日期未定。')

doc.add_heading('七、待跟进事项', level=2)
for item in [
    '官方起火原因调查结论（截至 13:00 仍在调查）。',
    '官方对承包商人数核对结果的正式确认（10:00 通报仍在核对；12:00 通报为“现场人员全部核对完成”，建议以官方后续书面结论为准）。',
    '涉事仓库恢复作业时间（企业称未定）。',
]:
    doc.add_paragraph(item, style='List Number')

doc.add_heading('八、说明与边界', level=2)
doc.add_paragraph('本简报仅汇总官方通报、企业自述与传闻三类信息并标注核实状态；截至 2026-10-08 13:00，不作任何赔偿、责任认定或医学建议，不依据报道热度补充结论。所有事故与机构均为模拟数据。')

doc.save('/workspace/outputs/incident_brief.docx')
print('docx saved')

# ============ claim_evidence.xlsx ============
wb = openpyxl.Workbook()
ws = wb.active
ws.title = '主张与证据'
headers = ['消息ID', '通报时间', '来源机构', '信息类型', '主张内容', '核实状态', '与其他信息比对/备注']
ws.append(headers)
rows = [
    ['M01', '2026-10-08 08:15', '桥溪园区应急办公室', '官方确认（首次通报）', '7:40 一处仓库发生火情，已疏散现场人员；伤亡信息核实中。', '官方发布；伤亡当时核实中，后续已更新', '事故起点：10-08 07:40，桥溪园区一处仓库'],
    ['M02', '2026-10-08 08:30', '仓库经营公司', '企业自述', '员工名单完整，正在核对承包商名单。', '企业单方表述，未经官方独立核实', '与 M01 核实中状态衔接；承包商人数官方 10:00 仍在核对'],
    ['M03', '2026-10-08 08:45', '社交转述', '传闻（未证实）', '有人称十余人失联，无姓名名单或出处。', '不采信：无出处，且与官方 12:00“全部核对完成、无死亡”不符', '不作为任何结论依据，仅记录'],
    ['M04', '2026-10-08 10:00', '桥溪园区应急办公室', '官方确认（阶段通报）', '火已扑灭；两人送医观察，未确认死亡；承包商人数仍在核对。', '官方发布；后续被 12:00 更新细化', '伤亡口径演进：送医观察 → 轻伤'],
    ['M05', '2026-10-08 10:30', '媒体乙', '媒体转述', '两人送医，原因待调查。', '与官方口径一致的二手转述，不作为独立证据', '佐证 M04，无新增信息'],
    ['M06', '2026-10-08 12:00', '桥溪园区应急办公室', '官方确认（截至 13:00 最新）', '现场人员全部核对完成；两人轻伤，无死亡；起火原因仍在调查。', '官方发布，为当前伤亡与人员核对结论依据', '覆盖 M04“未确认死亡”与承包商核对事项'],
    ['M07', '2026-10-08 12:15', '仓库经营公司', '企业自述', '涉事仓库暂停作业，其他仓库继续；恢复日期未定。', '企业单方表述，未经官方独立核实', '业务影响唯一来源，需后续确认恢复时间'],
    ['M08', '2026-10-08 12:30', '社交转述', '推测（未证实）', '猜测电池故障引发火情，无调查依据。', '不采信：无任何调查依据', '起火原因以官方调查结论为准，截至 13:00 仍在调查'],
]
for r in rows:
    ws.append(r)
ws.append([])
ws.append(['说明', '截止 2026-10-08 13:00；伤亡以官方 12:00 通报为准（两人轻伤、无死亡）；起火原因未明仍在调查；不作赔偿、责任或医学建议；事故与机构均为模拟。'])

thin = Font(bold=True)
fill = PatternFill('solid', fgColor='DDE6F0')
for c in ws[1]:
    c.font = thin
    c.fill = fill
    c.alignment = Alignment(vertical='center', wrap_text=True)
widths = [8, 18, 20, 22, 52, 34, 40]
for i, w in enumerate(widths, 1):
    ws.column_dimensions[openpyxl.utils.get_column_letter(i)].width = w
for row in ws.iter_rows(min_row=2, max_row=ws.max_row):
    for c in row:
        c.alignment = Alignment(vertical='top', wrap_text=True)
ws.freeze_panes = 'A2'

ws2 = wb.create_sheet('分类汇总')
ws2.append(['信息类型', '条目', '消息ID'])
ws2.append(['官方确认', '桥溪园区应急办公室通报 3 条（08:15 / 10:00 / 12:00）', 'M01、M04、M06'])
ws2.append(['企业自述', '仓库经营公司声明 2 条（08:30 / 12:15）', 'M02、M07'])
ws2.append(['媒体转述', '媒体乙转述 1 条（10:30），与官方一致', 'M05'])
ws2.append(['传闻/未证实', '社交转述 2 条（08:45 失联传闻 / 12:30 电池故障推测），均不采信', 'M03、M08'])
ws2.append([])
ws2.append(['核实结论', '截至 2026-10-08 13:00：两人轻伤、无死亡；现场人员全部核对完成；起火原因仍在调查（未明）；涉事仓库暂停作业，恢复日期未定。', ''])
for c in ws2[1]:
    c.font = thin
    c.fill = fill
    c.alignment = Alignment(vertical='center', wrap_text=True)
for i, w in enumerate([14, 70, 20], 1):
    ws2.column_dimensions[openpyxl.utils.get_column_letter(i)].width = w
for row in ws2.iter_rows(min_row=2, max_row=ws2.max_row):
    for c in row:
        c.alignment = Alignment(vertical='top', wrap_text=True)

wb.save('/workspace/outputs/claim_evidence.xlsx')
print('xlsx saved')
