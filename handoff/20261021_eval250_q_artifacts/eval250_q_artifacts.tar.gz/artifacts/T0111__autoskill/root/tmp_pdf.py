# -*- coding: utf-8 -*-
import re, asyncio
from playwright.async_api import async_playwright

html = open('/workspace/tmp/brief.html', encoding='utf-8').read()
# rebuild main table with all 32 rows (previous script truncated it)
import openpyxl
wb = openpyxl.load_workbook('/workspace/inputs/两周累计用量.xlsx', data_only=True)
rows = list(wb.active.iter_rows(min_row=2, values_only=True))
normal = sorted([(c, d, cu - pv) for c, d, pv, cu in rows if cu - pv >= 0], key=lambda x: -x[2])
def fmt(v): return f'{v:,}'
trs = '\n'.join(
    ('<tr class="top">' if i < 3 else '<tr>') +
    f'<td>{i+1}</td><td>{c}</td><td>{d}</td><td class="num">{fmt(v)}</td></tr>'
    for i, (c, d, v) in enumerate(normal))
html = re.sub(r'(<tr><th style="width:14%">排名</th>.*?</tr>\n)(?:.*\n)*?(</table>)',
              lambda m: m.group(1) + trs + '\n' + m.group(2), html, flags=re.S)
open('/workspace/tmp/brief.html', 'w', encoding='utf-8').write(html)

async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(executable_path='/usr/bin/chromium', args=['--no-sandbox'])
        pg = await b.new_page()
        await pg.goto('file:///workspace/tmp/brief.html')
        await pg.pdf(path='/workspace/outputs/一页用量简报.pdf', format='A4', print_background=True)
        await b.close()
asyncio.run(main())
