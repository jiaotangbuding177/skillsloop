# -*- coding: utf-8 -*-
import openpyxl, asyncio
from playwright.async_api import async_playwright

wb = openpyxl.load_workbook('/workspace/inputs/两周累计用量.xlsx', data_only=True)
rows = list(wb.active.iter_rows(min_row=2, values_only=True))
normal, anomaly = [], []
for code, dept, prev, curr in rows:
    d = curr - prev
    (anomaly if d < 0 else normal).append((code, dept, prev, curr, d))
normal.sort(key=lambda x: -x[2])
def fmt(v): return f'{v:,}'

def row(i, c, d, v, top=False):
    cls = ' class="top"' if top else ''
    return f'<tr{cls}><td>{i}</td><td>{c}</td><td>{d}</td><td class="num">{fmt(v)}</td></tr>'
trs = '\n'.join([row(i+1, c, d, v, i < 3) for i, (c, d, v) in enumerate(
    [(c, d, dd) for c, d, p, u, dd in normal])])
arows = '\n'.join(
    f'<tr class="anom"><td>{c}</td><td>{d}</td><td class="num">{fmt(p)}</td><td class="num">{fmt(u)}</td><td class="num">{fmt(dd)}</td></tr>'
    for c, d, p, u, dd in anomaly)
total = sum(v for _, _, v in [(c, d, dd) for c, d, p, u, dd in normal])

html = f'''<!DOCTYPE html><html><head><meta charset="utf-8"><style>
* {{ margin:0; padding:0; box-sizing:border-box; font-family:"Noto Sans CJK SC", sans-serif; }}
body {{ width:210mm; height:297mm; padding:9mm 12mm; color:#1a2a3a; }}
h1 {{ font-size:19pt; color:#1F4E79; text-align:center; margin-bottom:1.5mm; }}
.sub {{ text-align:center; font-size:9pt; color:#555; margin-bottom:3mm; }}
.meta {{ display:flex; justify-content:space-between; background:#EAF1F8; border-radius:4px; padding:2mm 5mm; font-size:9.5pt; margin-bottom:3mm; }}
.meta b {{ color:#1F4E79; }}
h2 {{ font-size:11.5pt; color:#1F4E79; border-left:4px solid #1F4E79; padding-left:2.5mm; margin:0 0 2mm; }}
.anom-sec h2 {{ color:#8a2b2b; border-color:#8a2b2b; }}
table {{ width:100%; border-collapse:collapse; font-size:8.5pt; }}
th {{ background:#1F4E79; color:#fff; padding:1.4mm 1.5mm; font-weight:600; }}
td {{ border-bottom:1px solid #d5dee8; padding:0.9mm 1.5mm; text-align:center; }}
td.num {{ text-align:right; font-variant-numeric:tabular-nums; }}
tr:nth-child(even) td {{ background:#F4F8FC; }}
.top td {{ font-weight:600; }}
.anom-sec {{ margin-top:3.5mm; }}
.anom-sec th {{ background:#8a2b2b; }}
.anom td {{ background:#FDF2F2; color:#8a2b2b; }}
.note {{ margin-top:2.5mm; font-size:8.5pt; color:#777; }}
@page {{ size:A4; margin:0; }}
</style></head><body>
<h1>9月第二周用量榜 · 一页简报</h1>
<div class="sub">口径：本周末累计 − 上周末累计 = 本周增量；累计下降者列为重置/异常，不参与排名</div>
<div class="meta">
  <span>参与排名：<b>{len(normal)} 人</b></span>
  <span>本周增量合计：<b>{fmt(total)}</b></span>
  <span>重置/异常：<b>{len(anomaly)} 人</b></span>
</div>
<h2>本周用量榜（按增量降序）</h2>
<table>
<tr><th style="width:14%">排名</th><th style="width:22%">员工编码</th><th style="width:22%">部门</th><th style="width:42%">本周增量</th></tr>
{trs}
</table>
<div class="anom-sec">
<h2>重置/异常记录（保留原值，不计排名）</h2>
<table>
<tr><th>员工编码</th><th>部门</th><th>上周末累计token</th><th>本周末累计token</th><th>累计变动</th></tr>
{arows}
</table>
</div>
<div class="note">说明：正文仅含员工编码、部门、本周增量与排名；重置/异常记录按原始累计值单列，不做负消耗排名。本表不含配额及使用率信息。</div>
</body></html>'''
open('/workspace/tmp/brief.html', 'w', encoding='utf-8').write(html)

async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(executable_path='/usr/bin/chromium', args=['--no-sandbox'])
        pg = await b.new_page()
        await pg.goto('file:///workspace/tmp/brief.html')
        await pg.pdf(path='/workspace/outputs/一页用量简报.pdf', format='A4', print_background=True)
        await b.close()
asyncio.run(main())
