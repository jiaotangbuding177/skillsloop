# -*- coding: utf-8 -*-
import openpyxl, json
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side

wb = openpyxl.load_workbook('/workspace/inputs/两周累计用量.xlsx', data_only=True)
ws = wb.active
rows = list(ws.iter_rows(min_row=2, values_only=True))

normal, anomaly = [], []
for code, dept, prev, curr in rows:
    delta = curr - prev
    if delta < 0:
        anomaly.append((code, dept, prev, curr, delta))
    else:
        normal.append((code, dept, delta))
normal.sort(key=lambda x: -x[2])
ranked = [(i+1, c, d, v) for i, (c, d, v) in enumerate(normal)]

# ---------- xlsx ----------
out = openpyxl.Workbook()
s1 = out.active
s1.title = '周用量榜'
header = ['排名', '员工编码', '部门', '本周增量']
s1.append(header)
for r in ranked:
    s1.append(list(r))

thin = Side(style='thin', color='999999')
border = Border(left=thin, right=thin, top=thin, bottom=thin)
hf = Font(bold=True)
hfill = PatternFill('solid', fgColor='1F4E79')
for c in s1[1]:
    c.font = Font(bold=True, color='FFFFFF')
    c.fill = hfill
    c.alignment = Alignment(horizontal='center')
    c.border = border
for i, row in enumerate(s1.iter_rows(min_row=2, max_col=4), start=1):
    for c in row:
        c.border = border
        if i % 2 == 0:
            c.fill = PatternFill('solid', fgColor='EAF1F8')
    row[0].alignment = Alignment(horizontal='center')
for col, w in zip('ABCD', [8, 12, 10, 14]):
    s1.column_dimensions[col].width = w
s1.freeze_panes = 'A2'

s2 = out.create_sheet('重置异常记录')
s2.append(['员工编码', '部门', '上周末累计token', '本周末累计token', '累计变动（重置/异常，不参与排名）'])
for a in anomaly:
    s2.append(list(a))
for c in s2[1]:
    c.font = Font(bold=True, color='FFFFFF')
    c.fill = hfill
    c.alignment = Alignment(horizontal='center')
    c.border = border
for row in s2.iter_rows(min_row=2, max_col=5):
    for c in row:
        c.border = border
for col, w in zip('ABCDE', [12, 10, 16, 16, 30]):
    s2.column_dimensions[col].width = w
out.save('/workspace/outputs/周用量榜.xlsx')

# ---------- HTML brief ----------
def fmt(v):
    return f'{v:,}'

trs = ''
for rank, code, dept, val in ranked:
    trs += f'<tr><td>{rank}</td><td>{code}</td><td>{dept}</td><td class="num">{fmt(val)}</td></tr>\n'
aranom = ''
for code, dept, prev, curr, delta in anomaly:
    aranom += f'<tr class="anom"><td>{code}</td><td>{dept}</td><td class="num">{fmt(prev)}</td><td class="num">{fmt(curr)}</td><td class="num">{fmt(delta)}</td></tr>\n'

total = sum(v for _, _, _, v in ranked)
html = f'''<!DOCTYPE html><html><head><meta charset="utf-8"><style>
* {{ margin:0; padding:0; box-sizing:border-box; font-family:"Noto Sans CJK SC", sans-serif; }}
body {{ width:210mm; height:297mm; padding:14mm 16mm; color:#1a2a3a; }}
h1 {{ font-size:22pt; color:#1F4E79; text-align:center; margin-bottom:2mm; }}
.sub {{ text-align:center; font-size:10pt; color:#555; margin-bottom:5mm; }}
.meta {{ display:flex; justify-content:space-between; background:#EAF1F8; border-radius:4px; padding:3mm 6mm; font-size:10.5pt; margin-bottom:5mm; }}
.meta b {{ color:#1F4E79; }}
h2 {{ font-size:13pt; color:#1F4E79; border-left:4px solid #1F4E79; padding-left:3mm; margin-bottom:3mm; }}
table {{ width:100%; border-collapse:collapse; font-size:9.5pt; }}
th {{ background:#1F4E79; color:#fff; padding:2mm 1.5mm; font-weight:600; }}
td {{ border-bottom:1px solid #d5dee8; padding:1.4mm 1.5mm; text-align:center; }}
td.num {{ text-align:right; font-variant-numeric:tabular-nums; }}
tr:nth-child(even) td {{ background:#F4F8FC; }}
.top td {{ font-weight:600; }}
.anom-sec {{ margin-top:5mm; }}
.anom td {{ background:#FDF2F2; color:#8a2b2b; }}
.note {{ margin-top:4mm; font-size:8.5pt; color:#777; }}
@page {{ size:A4; margin:0; }}
</style></head><body>
<h1>9月第二周用量榜 · 一页简报</h1>
<div class="sub">口径：本周末累计 − 上周末累计 = 本周增量；累计下降者列为重置/异常，不参与排名</div>
<div class="meta">
  <span>参与排名：<b>{len(ranked)} 人</b></span>
  <span>本周增量合计：<b>{fmt(total)}</b></span>
  <span>重置/异常：<b>{len(anomaly)} 人</b></span>
</div>
<h2>本周用量榜（按增量降序）</h2>
<table>
<tr><th style="width:14%">排名</th><th style="width:22%">员工编码</th><th style="width:22%">部门</th><th style="width:42%">本周增量</th></tr>
{''.join(f'<tr class="top">{r}</tr>' for r in trs.splitlines()[:3])}
{trs.splitlines()[3]}
</table>
<div class="anom-sec">
<h2 style="color:#8a2b2b; border-color:#8a2b2b;">重置/异常记录（保留原值，不计排名）</h2>
<table>
<tr><th>员工编码</th><th>部门</th><th>上周末累计token</th><th>本周末累计token</th><th>累计变动</th></tr>
{aranom}
</table>
</div>
<div class="note">说明：正文仅含员工编码、部门、本周增量与排名；重置/异常记录按原始累计值单列，不做负消耗排名。本表不含配额及使用率信息。</div>
</body></html>'''

with open('/workspace/tmp/brief.html', 'w', encoding='utf-8') as f:
    f.write(html)
print('RANKED', len(ranked), 'ANOM', anomaly[:1])
print('top3:', ranked[:3])
