# -*- coding: utf-8 -*-
import csv
from datetime import date
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from docx import Document
from docx.shared import Pt
from docx.oxml.ns import qn

CUR = date(2026, 10, 9)  # 基准日期，依据 action_rules.md

rows = []
with open('/workspace/inputs/meeting_actions.csv', encoding='utf-8-sig') as f:
    for r in csv.DictReader(f):
        r['日期'] = r['日期'].strip()
        r['截止'] = r['截止'].strip()
        rows.append(r)

# 按事项ID聚合完整历史（按会议日期排序）
hist_by_id = {}
for r in sorted(rows, key=lambda x: (x['日期'], x['会议'])):
    hist_by_id.setdefault(r['ID'], []).append(r)

items = []
for aid, recs in hist_by_id.items():
    latest = recs[-1]
    first = recs[0]
    changed = any(x['截止'] != latest['截止'] for x in recs[:-1])
    items.append({
        'ID': aid, '动作': latest['动作'], '负责人': latest['负责人'],
        '原截止': first['截止'],
        '当前截止': latest['截止'],
        '是否变更': '是' if changed else '否',
        '变更日期': latest['日期'] if changed else '',
        '变更依据会议': latest['会议'] if changed else '',
        '最新记录会议': latest['会议'],
        '状态原始': latest['状态'],
        '历史记录': recs,
    })

def status_class(s):
    if '受阻' in s:
        return '受阻'
    if s in ('完成', '已完成'):
        return '完成'
    return '待办'  # 待办/处理中等未完结状态

STATUS_FILL = {
    '待办': PatternFill('solid', fgColor='FFF3CD'),
    '受阻': PatternFill('solid', fgColor='F8D7DA'),
    '完成': PatternFill('solid', fgColor='D4EDDA'),
}
HEADER_FILL = PatternFill('solid', fgColor='305496')
HEADER_FONT = Font(color='FFFFFF', bold=True, name='Noto Sans CJK SC')
BODY_FONT = Font(name='Noto Sans CJK SC')
THIN = Side(style='thin', color='999999')
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)

wb = Workbook()

# ---------- Sheet1 行动追踪总表 ----------
ws = wb.active
ws.title = '行动追踪总表'
headers = ['事项ID', '事项', '负责人', '原截止', '当前截止', '截止是否变更', '截止变更日期',
           '变更依据会议', '最新记录会议', '当前状态', '状态类别', '截至2026-10-09是否逾期', '跟进说明']
ws.append(headers)
for c, h in enumerate(headers, 1):
    cell = ws.cell(row=1, column=c)
    cell.font = HEADER_FONT
    cell.fill = HEADER_FILL
    cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
    cell.border = BORDER

items_sorted = sorted(items, key=lambda x: x['ID'])
for it in items_sorted:
    cat = status_class(it['状态原始'])
    cur_d = date.fromisoformat(it['当前截止'])
    if cat != '完成' and cur_d < CUR:
        overdue = '是（逾期，保留跟进）'
    else:
        overdue = '否'
    if cat == '受阻':
        follow = '受阻（' + it['状态原始'] + '），仍需跟进，未删除'
    elif cat == '待办' and cur_d < CUR:
        follow = '已逾期，按规则保留，不删除'
    elif cat == '完成':
        follow = '按最新会议记录为完成'
    else:
        follow = '未逾期'
    row = [it['ID'], it['动作'], it['负责人'], it['原截止'], it['当前截止'], it['是否变更'],
           it['变更日期'], it['变更依据会议'], it['最新记录会议'], it['状态原始'], cat, overdue, follow]
    ws.append(row)
    ri = ws.max_row
    for c in range(1, len(headers) + 1):
        cell = ws.cell(row=ri, column=c)
        cell.font = BODY_FONT
        cell.border = BORDER
        cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
    ws.cell(row=ri, column=10).fill = STATUS_FILL[cat]
    ws.cell(row=ri, column=11).fill = STATUS_FILL[cat]

widths = [8, 14, 10, 11, 11, 12, 13, 12, 12, 12, 10, 22, 30]
for i, w in enumerate(widths, 1):
    ws.column_dimensions[get_column_letter(i)].width = w
ws.freeze_panes = 'A2'

legend_row = ws.max_row + 2
ws.cell(row=legend_row, column=1, value='状态类别图例：').font = Font(bold=True, name='Noto Sans CJK SC')
for i, (k, v) in enumerate([('待办', '待办/处理中，未完结'), ('受阻', '受阻（如受阻客户）'), ('完成', '按记录完成')]):
    c1 = ws.cell(row=legend_row + 1 + i, column=1, value=k)
    c1.fill = STATUS_FILL[k]
    c1.font = BODY_FONT
    c1.border = BORDER
    c2 = ws.cell(row=legend_row + 1 + i, column=2, value=v)
    c2.font = BODY_FONT
note = ws.cell(row=legend_row + 5, column=1,
               value='依据 inputs/action_rules.md（当前 2026-10-09）：最新明确记录决定当前状态；受阻与逾期任务均保留跟进，不删除；完成仅记录所述，不额外推断验收全部完成。')
note.font = Font(italic=True, name='Noto Sans CJK SC')

# ---------- Sheet2 截止日变更历史 ----------
ws2 = wb.create_sheet('截止日变更历史')
h2 = ['事项ID', '事项', '负责人', '会议', '记录日期', '当时截止', '状态', '备注']
ws2.append(h2)
for c, h in enumerate(h2, 1):
    cell = ws2.cell(row=1, column=c)
    cell.font = HEADER_FONT
    cell.fill = HEADER_FILL
    cell.alignment = Alignment(horizontal='center', vertical='center')
    cell.border = BORDER
for it in items_sorted:
    for k, rec in enumerate(it['历史记录']):
        if k == 0:
            remark = '首次记录'
        elif rec['截止'] != it['历史记录'][k - 1]['截止']:
            remark = '截止日变更：' + it['历史记录'][k - 1]['截止'] + ' → ' + rec['截止']
        else:
            remark = ''
        ws2.append([rec['ID'], rec['动作'], rec['负责人'], rec['会议'], rec['日期'], rec['截止'], rec['状态'], remark])
        ri = ws2.max_row
        for c in range(1, len(h2) + 1):
            cell = ws2.cell(row=ri, column=c)
            cell.font = BODY_FONT
            cell.border = BORDER
            cell.alignment = Alignment(horizontal='center', vertical='center')
for i, w in enumerate([8, 14, 10, 8, 12, 12, 12, 32], 1):
    ws2.column_dimensions[get_column_letter(i)].width = w

# ---------- Sheet3 原始记录 ----------
ws3 = wb.create_sheet('原始记录')
h3 = ['会议', '日期', 'ID', '动作', '负责人', '截止', '状态']
ws3.append(h3)
for c, h in enumerate(h3, 1):
    cell = ws3.cell(row=1, column=c)
    cell.font = HEADER_FONT
    cell.fill = HEADER_FILL
    cell.border = BORDER
for r in rows:
    ws3.append([r['会议'], r['日期'], r['ID'], r['动作'], r['负责人'], r['截止'], r['状态']])
    ri = ws3.max_row
    for c in range(1, len(h3) + 1):
        cell = ws3.cell(row=ri, column=c)
        cell.font = BODY_FONT
        cell.border = BORDER
for i, w in enumerate([8, 12, 8, 16, 10, 12, 12], 1):
    ws3.column_dimensions[get_column_letter(i)].width = w

wb.save('/workspace/outputs/action_tracker.xlsx')
print('xlsx saved')

# ---------- DOCX 摘要 ----------
doc = Document()
style = doc.styles['Normal']
style.font.name = 'Noto Sans CJK SC'
style.font.size = Pt(11)
style.element.rPr.rFonts.set(qn('w:eastAsia'), 'Noto Sans CJK SC')

doc.add_heading('行动项摘要（Action Digest）', level=0)
doc.add_paragraph('数据来源：inputs/meeting_actions.csv（会议 M1–M3）；合并规则：inputs/action_rules.md。基准日期：2026-10-09。')

todo = [it for it in items if status_class(it['状态原始']) == '待办']
blocked = [it for it in items if status_class(it['状态原始']) == '受阻']
done = [it for it in items if status_class(it['状态原始']) == '完成']
changed = [it for it in items if it['是否变更'] == '是']

doc.add_heading('一、概览', level=1)
doc.add_paragraph('共 %d 项行动：待办 %d 项、受阻 %d 项、完成 %d 项；其中 %d 项发生过截止日变更（历史保留）。' % (
    len(items), len(todo), len(blocked), len(done), len(changed)))

def add_table(title, list_items, status_label):
    doc.add_heading(title, level=1)
    if not list_items:
        doc.add_paragraph('（无）')
        return
    tb = doc.add_table(rows=1, cols=6)
    tb.style = 'Table Grid'
    hdr = tb.rows[0].cells
    for i, h in enumerate(['事项ID', '事项', '负责人', '截止', '状态', '说明']):
        hdr[i].text = h
        for pp in hdr[i].paragraphs:
            for rr in pp.runs:
                rr.font.bold = True
    for it in list_items:
        cur_d = date.fromisoformat(it['当前截止'])
        if status_label == '受阻':
            desc = it['状态原始'] + '；截至2026-10-09逾期，仍保留跟进'
        elif status_label == '待办' and cur_d < CUR:
            desc = '已逾期，按规则保留，不删除'
        elif status_label == '待办':
            desc = '未逾期'
        else:
            desc = '按最新会议记录为完成'
        cells = tb.add_row().cells
        for i, v in enumerate([it['ID'], it['动作'], it['负责人'], it['当前截止'], it['状态原始'], desc]):
            cells[i].text = v

add_table('二、待办（含处理中）', todo, '待办')
add_table('三、受阻', blocked, '受阻')
add_table('四、完成', done, '完成')

doc.add_heading('五、截止日变更历史（保留）', level=1)
tb = doc.add_table(rows=1, cols=6)
tb.style = 'Table Grid'
hdr = tb.rows[0].cells
for i, h in enumerate(['事项ID', '原截止', '现截止', '变更日期', '依据会议', '负责人']):
    hdr[i].text = h
    for pp in hdr[i].paragraphs:
        for rr in pp.runs:
            rr.font.bold = True
for it in changed:
    cells = tb.add_row().cells
    for i, v in enumerate([it['ID'], it['原截止'], it['当前截止'], it['变更日期'], it['变更依据会议'], it['负责人']]):
        cells[i].text = v

doc.add_heading('六、处理说明', level=1)
for s in [
    '按事项ID合并各会议记录，以最新明确记录决定当前状态：A1、A2 取 M3（2026-10-08）记录，A3、A4 取其各自最新会议记录。',
    'A1（权限测试，王工）最新记录为“受阻客户”，截至 2026-10-09 已逾期（现截止 2026-10-07），仍列入跟进，未删除。',
    'A3（补字段字典，李宁）截止日由 2026-10-06 变更为 2026-10-10（M3，2026-10-08），状态“处理中”，列入待办；原截止 2026-10-06 已逾期，历史保留。',
    'A2（准备培训，赵琪）按 M3 记录为“完成”；完成仅依据记录所述，未额外推断验收全部完成。',
    'A4（回传验收记录，赵琪）仅在 M3 出现一次，状态“待办”，截止 2026-10-12，未逾期。',
    '逾期任务（A1、A3 的原截止）均保留在追踪表中，未做删除。',
]:
    doc.add_paragraph(s, style='List Bullet')

doc.save('/workspace/outputs/action_digest.docx')
print('docx saved')
