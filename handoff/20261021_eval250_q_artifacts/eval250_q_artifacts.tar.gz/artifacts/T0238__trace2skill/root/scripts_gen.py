# -*- coding: utf-8 -*-
"""生成 技术转移项目路演概要.pptx 与 讲稿.docx（仅使用输入事实，不补未知业绩）"""
from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.chart.data import CategoryChartData
from pptx.enum.chart import XL_CHART_TYPE, XL_LEGEND_POSITION, XL_LABEL_POSITION
import copy

BLUE_D = RGBColor(0x1F, 0x4E, 0x79)   # 深蓝
BLUE_M = RGBColor(0x2E, 0x75, 0xB6)   # 中蓝
BLUE_L = RGBColor(0xDE, 0xEB, 0xF7)   # 浅蓝底
GRAY   = RGBColor(0x55, 0x55, 0x55)
DARK   = RGBColor(0x22, 0x2A, 0x35)
WHITE  = RGBColor(0xFF, 0xFF, 0xFF)
FONT   = 'Noto Sans CJK SC'


def set_run_font(run, size=14, bold=False, color=DARK, name=FONT):
    f = run.font
    f.name = name
    f.size = Pt(size)
    f.bold = bold
    f.color.rgb = color
    # 同时设置东亚字体
    rPr = run._r.get_or_add_rPr()
    ea = rPr.find('{http://schemas.openxmlformats.org/drawingml/2006/main}ea')
    if ea is None:
        ea = rPr.makeelement('{http://schemas.openxmlformats.org/drawingml/2006/main}ea', {})
        rPr.append(ea)
    ea.set('typeface', name)


def add_text(tf, lines, align=PP_ALIGN.LEFT, wrap=True):
    """lines: list of (text, size, bold, color, bullet_space_before)"""
    tf.word_wrap = wrap
    first = True
    for ln in lines:
        text, size, bold, color = ln[:4]
        space_before = ln[4] if len(ln) > 4 else 4
        p = tf.paragraphs[0] if first else tf.add_paragraph()
        first = False
        p.alignment = align
        p.space_before = Pt(space_before)
        p.space_after = Pt(2)
        r = p.add_run()
        r.text = text
        set_run_font(r, size, bold, color)


def rect(slide, x, y, w, h, fill, line=None):
    from pptx.enum.shapes import MSO_SHAPE
    sh = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, x, y, w, h)
    sh.fill.solid()
    sh.fill.fore_color.rgb = fill
    if line is None:
        sh.line.fill.background()
    else:
        sh.line.color.rgb = line
        sh.line.width = Pt(0.75)
    sh.shadow.inherit = False
    return sh


def header(slide, page_no, title, sub=None):
    """统一页眉：左侧蓝色竖条 + 标题"""
    rect(slide, Inches(0.55), Inches(0.42), Inches(0.09), Inches(0.52), BLUE_M)
    tb = slide.shapes.add_textbox(Inches(0.78), Inches(0.30), Inches(10.8), Inches(0.75))
    tf = tb.text_frame
    add_text(tf, [(title, 26, True, BLUE_D, 0)])
    if sub:
        tb2 = slide.shapes.add_textbox(Inches(0.80), Inches(0.95), Inches(11.5), Inches(0.4))
        add_text(tb2.text_frame, [(sub, 12.5, False, GRAY, 0)])
    # 页码
    tb3 = slide.shapes.add_textbox(Inches(12.35), Inches(7.02), Inches(0.7), Inches(0.35))
    add_text(tb3.text_frame, [(str(page_no), 11, False, GRAY, 0)], align=PP_ALIGN.RIGHT)


def card(slide, x, y, w, h, title, body_lines, fill=WHITE, title_color=BLUE_D, bar=BLUE_M):
    """带左侧色条的卡片"""
    box = rect(slide, x, y, w, h, fill, line=RGBColor(0xC9, 0xD9, 0xEC))
    box.text_frame.word_wrap = True
    rect(slide, x, y, Inches(0.06), h, bar)
    tb = slide.shapes.add_textbox(x + Inches(0.18), y + Inches(0.10), w - Inches(0.30), h - Inches(0.2))
    lines = [(title, 14.5, True, title_color, 0)]
    for b in body_lines:
        lines.append((b, 12, False, DARK, 5))
    add_text(tb.text_frame, lines)
    return box


def style_table(tbl, header_size=12.5, body_size=12):
    for ri, row in enumerate(tbl.rows):
        for cell in row.cells:
            cell.margin_left = Inches(0.08)
            cell.margin_right = Inches(0.08)
            cell.margin_top = Inches(0.03)
            cell.margin_bottom = Inches(0.03)
            cell.vertical_anchor = MSO_ANCHOR.MIDDLE
            for p in cell.text_frame.paragraphs:
                p.alignment = PP_ALIGN.CENTER if ri == 0 else PP_ALIGN.LEFT
                for r in p.runs:
                    set_run_font(r, header_size if ri == 0 else body_size,
                                 bold=(ri == 0), color=WHITE if ri == 0 else DARK)


def fill_table(tbl, data, col_widths=None):
    for ri, row in enumerate(data):
        for ci, val in enumerate(row):
            cell = tbl.cell(ri, ci)
            cell.text = val
    # 表头底色
    for ci in range(len(data[0])):
        c = tbl.cell(0, ci)
        c.fill.solid()
        c.fill.fore_color.rgb = BLUE_D
    for ri in range(1, len(data)):
        for ci in range(len(data[0])):
            c = tbl.cell(ri, ci)
            c.fill.solid()
            c.fill.fore_color.rgb = WHITE if ri % 2 == 1 else BLUE_L
    if col_widths:
        for ci, w in enumerate(col_widths):
            for ri in range(len(data)):
                tbl.cell(ri, ci).width = w


prs = Presentation()
prs.slide_width = Inches(13.333)
prs.slide_height = Inches(7.5)
blank = prs.slide_layouts[6]

# ============ 第1页 封面与现状 ============
s = prs.slides.add_slide(blank)
rect(s, 0, 0, prs.slide_width, Inches(2.35), WHITE)
rect(s, 0, Inches(2.30), prs.slide_width, Inches(0.045), BLUE_M)
tb = s.shapes.add_textbox(Inches(0.85), Inches(0.62), Inches(11.6), Inches(1.5))
add_text(tb.text_frame, [
    ('技术转移项目路演概要', 40, True, BLUE_D, 0),
    ('低温酶催化精制工艺 · 面向企业合作方', 17, False, BLUE_M, 10),
])
rect(s, Inches(0.85), Inches(2.55), Inches(11.63), Inches(0.4), BLUE_L)
tb = s.shapes.add_textbox(Inches(1.0), Inches(2.58), Inches(11.4), Inches(0.36))
add_text(tb.text_frame, [('当前状态一句话：实验室 100 批验证完成，50 升小试进行中，尚未进入吨级工业量产与中试。', 13, True, BLUE_D, 0)])

# 现状关键数值表
data = [
    ['现状项目', '当前事实', '边界说明'],
    ['技术路线', '低温酶催化精制工艺', '—'],
    ['验证规模', '实验室 100 批验证', '实验室规模，非产线'],
    ['纯度结果', '98.6%±0.4%（最大批间范围）', '±0.4% 不是标准差'],
    ['放大进度', '50 升小试进行中', '不是吨级工业量产'],
    ['团队配置', '工程师 4 人 + 工艺负责人 1 人', '共 5 人'],
]
from pptx.util import Cm
gt = s.shapes.add_table(6, 3, Inches(0.85), Inches(3.15), Inches(11.63), Inches(3.4)).table
fill_table(gt, data)
style_table(gt)
gt.columns[0].width = Inches(2.2)
gt.columns[1].width = Inches(4.9)
gt.columns[2].width = Inches(4.53)
# 修正单元格内对齐：第一列左对齐
for ri in range(1, 6):
    for ci in range(3):
        for p in gt.cell(ri, ci).text_frame.paragraphs:
            p.alignment = PP_ALIGN.LEFT if ci != 1 else PP_ALIGN.LEFT

# ============ 第2页 业务问题与技术流程证据 ============
s = prs.slides.add_slide(blank)
header(s, 2, '业务问题与技术流程', '按“现状 → 问题 → 计划”组织：本页为问题与技术证据')

card(s, Inches(0.55), Inches(1.42), Inches(5.9), Inches(2.05), '业务问题（合作对象与目标）', [
    '对象：需要低温精制的材料企业；',
    '目标：减少高温处理对敏感组分的影响；',
    '未给对照能耗或成本数据，不宣称具体降本节能比例；',
    '现阶段目的：验证可迁移工艺，不是销售成熟吨级产线。',
])
card(s, Inches(6.75), Inches(1.42), Inches(6.05), Inches(2.05), '技术流程（四步）', [
    '① 样品预处理  ② 低温酶催化',
    '③ 分离纯化    ④ 检测与批记录',
    '测试方法和样品条件由技术材料确认；',
    '不能跨其他原料保证同样结果。',
], fill=BLUE_L, bar=BLUE_D)

# 纯度分布柱状图（含单位）
tb = s.shapes.add_textbox(Inches(0.55), Inches(3.62), Inches(7.2), Inches(0.4))
add_text(tb.text_frame, [('实验室 100 批纯度分布（纵轴：批数，批；横轴：纯度档，%）', 13.5, True, BLUE_D, 0)])
chart_data = CategoryChartData()
chart_data.categories = ['98.2', '98.4', '98.6', '98.8', '99.0']
chart_data.add_series('批数（批）', (10, 20, 40, 20, 10))
gf = s.shapes.add_chart(XL_CHART_TYPE.COLUMN_CLUSTERED, Inches(0.55), Inches(4.0),
                        Inches(7.1), Inches(2.95), chart_data)
chart = gf.chart
chart.has_legend = False
plot = chart.plots[0]
plot.has_data_labels = True
dl = plot.data_labels
dl.font.size = Pt(11)
dl.font.color.rgb = BLUE_D
dl.position = XL_LABEL_POSITION.OUTSIDE_END
ser = plot.series[0]
ser.format.fill.solid()
ser.format.fill.fore_color.rgb = BLUE_M
ca = chart.category_axis
ca.has_title = True
ca.axis_title.text_frame.text = '纯度档（%）'
for p in ca.axis_title.text_frame.paragraphs:
    for r in p.runs:
        set_run_font(r, 11, False, GRAY)
ca.tick_labels.font.size = Pt(11)
va = chart.value_axis
va.has_title = True
va.axis_title.text_frame.text = '批数（批）'
for p in va.axis_title.text_frame.paragraphs:
    for r in p.runs:
        set_run_font(r, 11, False, GRAY)
va.tick_labels.font.size = Pt(11)

# 限制说明（图形不能替代关键限制文字）
card(s, Inches(7.95), Inches(3.62), Inches(4.85), Inches(3.35), '关键数值与限制说明', [
    '100 批平均纯度 98.6%；',
    '±0.4% 为最大批间范围，不是标准差；',
    '分布：98.2% 共 10 批、98.4% 共 20 批、98.6% 共 40 批、98.8% 共 20 批、99.0% 共 10 批；',
    '测试方法和样品条件由技术材料确认，不能跨其他原料保证同结果。',
], fill=WHITE)

# ============ 第3页 放大状态与计划 ============
s = prs.slides.add_slide(blank)
header(s, 3, '放大状态与验证计划', '已完成为 50 升小试；200 升连续试验尚未开展')

card(s, Inches(0.55), Inches(1.45), Inches(6.0), Inches(2.5), '已完成（现状）', [
    '50 升小试完成 2 批；',
    '设备运行情况与参数窗口有记录；',
    '实验室 100 批验证数据完整（见第 2 页分布）。',
], fill=BLUE_L, bar=BLUE_D)
card(s, Inches(0.55), Inches(4.15), Inches(6.0), Inches(2.5), '尚未完成（如实说明）', [
    '连续 200 升试验尚未开展；',
    '流量、产率及长期活性目前无完整数据，列为需补证项；',
    '当前为 50 升小试，不是吨级工业量产。',
])

# 计划步骤
tb = s.shapes.add_textbox(Inches(6.9), Inches(1.45), Inches(6.0), Inches(0.4))
add_text(tb.text_frame, [('中试计划（尚未完成，按顺序推进）', 14.5, True, BLUE_D, 0)])
steps = [
    ('第 1 步', '开展 10 批 200 升放大验证', '计划批次明确，尚未启动'),
    ('第 2 步', '评估设备接口与运行稳定性', '以第 1 步数据为依据'),
    ('需补证', '流量、产率、长期活性', '目前无完整数据，不预填结论'),
]
yy = 2.0
for tag, t1, t2 in steps:
    rect(s, Inches(6.9), Inches(yy), Inches(5.9), Inches(1.32), WHITE, line=RGBColor(0xC9, 0xD9, 0xEC))
    rect(s, Inches(6.9), Inches(yy), Inches(1.05), Inches(1.32), BLUE_D)
    tbx = s.shapes.add_textbox(Inches(6.9), Inches(yy + 0.42), Inches(1.05), Inches(0.5))
    add_text(tbx.text_frame, [(tag, 12.5, True, WHITE, 0)], align=PP_ALIGN.CENTER)
    tbx = s.shapes.add_textbox(Inches(8.1), Inches(yy + 0.14), Inches(4.55), Inches(1.1))
    add_text(tbx.text_frame, [(t1, 13, True, DARK, 0), (t2, 11.5, False, GRAY, 4)])
    yy += 1.52

# ============ 第4页 团队资产与合作安排 ============
s = prs.slides.add_slide(blank)
header(s, 4, '团队、资产边界与合作安排', '本次路演请求：有条件的中试合作；不把意向写成交易')

card(s, Inches(0.55), Inches(1.45), Inches(6.0), Inches(2.35), '团队与分工', [
    '工程师 4 人：分别负责试验、分析、放大、记录；',
    '工艺负责人 1 人：负责工艺决策。',
], fill=BLUE_L, bar=BLUE_D)
card(s, Inches(0.55), Inches(3.95), Inches(6.0), Inches(2.7), '资产与知识产权边界', [
    '现有方法资料和样品按协议用于验证；',
    '背景知识产权不因合作付款而全部转让；',
    '专利或独家许可未提供，不编造证书或授权。',
])

# 合作安排表
tb = s.shapes.add_textbox(Inches(6.9), Inches(1.45), Inches(6.0), Inches(0.4))
add_text(tb.text_frame, [('企业合作安排（截至路演日）', 14.5, True, BLUE_D, 0)])
data = [
    ['合作事项', '当前状态'],
    ['初步交流', '2 家企业已初步沟通原料与现有设备'],
    ['待共同确认', '样品、技术边界、试验批数、数据共享'],
    ['销售订单', '尚无'],
    ['定价方案', '尚无'],
    ['正式中试合同', '尚无'],
]
gt = s.shapes.add_table(6, 2, Inches(6.9), Inches(1.95), Inches(5.9), Inches(3.1)).table
fill_table(gt, data)
style_table(gt)
gt.columns[0].width = Inches(1.9)
gt.columns[1].width = Inches(4.0)

card(s, Inches(6.9), Inches(5.35), Inches(5.9), Inches(1.3), '本次请求', [
    '有条件的中试合作（先完成 10 批 200 升验证），意向不写成交。',
], fill=WHITE, bar=BLUE_D)

prs.save('/workspace/outputs/技术转移项目路演概要.pptx')
print('pptx saved')

# ================= DOCX 讲稿 =================
import docx
from docx.shared import Pt as DPt, RGBColor as DRGB, Cm as DCm
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn

doc = docx.Document()
style = doc.styles['Normal']
style.font.name = 'Noto Sans CJK SC'
style.font.size = DPt(12)
style.element.rPr.rFonts.set(qn('w:eastAsia'), 'Noto Sans CJK SC')


def para(text, size=12, bold=False, color=None, align=None, space_after=6, indent=False):
    p = doc.add_paragraph()
    if align:
        p.alignment = align
    p.paragraph_format.space_after = DPt(space_after)
    if indent:
        p.paragraph_format.first_line_indent = DCm(0.74)
    r = p.add_run(text)
    r.font.name = 'Noto Sans CJK SC'
    r.font.size = DPt(size)
    r.font.bold = bold
    r._element.rPr.rFonts.set(qn('w:eastAsia'), 'Noto Sans CJK SC')
    if color:
        r.font.color.rgb = color
    return p


BLUE = DRGB(0x1F, 0x4E, 0x79)
para('《技术转移项目路演概要》讲解稿', 18, True, BLUE, WD_ALIGN_PARAGRAPH.CENTER, 4)
para('（面向企业合作方，约 5 分钟；内容与演示页面事实一致，只使用已给事实，缺数据直接说明）', 10.5, False, DRGB(0x55, 0x55, 0x55), WD_ALIGN_PARAGRAPH.CENTER, 14)

para('开场与整体现状（约 1 分钟）', 14, True, BLUE, None, 6)
para('各位好，感谢安排这次交流。今天用大约五分钟，介绍我们的低温酶催化精制工艺，以及希望与企业合作方开展的中试合作。先把现状讲清楚：这项工艺已经在实验室完成了 100 批验证，平均纯度 98.6%，最大批间范围正负 0.4%。需要强调的是，这个正负 0.4% 是最大批间范围，不是标准差。目前放大进度是 50 升小试，还没有进入吨级工业量产。团队一共 5 人，包括 4 名工程师和 1 名工艺负责人。今天要请求的，是一个有条件的中试合作。', indent=True)

para('第一页补充：业务问题与技术证据（约 1.5 分钟）', 14, True, BLUE, None, 10)
para('我们面向的合作对象，是需要低温精制的材料企业，目标是减少高温处理对敏感组分的影响。这里要如实说明：目前没有对照能耗和成本数据，所以我们不宣称具体的降本节能比例。现阶段合作的目的，是验证这套工艺能否迁移到贵方的体系，而不是销售成熟的吨级产线。', indent=True)
para('技术流程分四步：样品预处理、低温酶催化、分离纯化、检测与批记录。100 批验证的纯度分布是：98.2% 有 10 批，98.4% 有 20 批，98.6% 有 40 批，98.8% 有 20 批，99.0% 有 10 批，平均 98.6%。需要提醒的是，测试方法和样品条件由技术材料确认，我们不能保证对其他原料也得到同样结果。', indent=True)

para('第二部分：放大状态与验证计划（约 1.5 分钟）', 14, True, BLUE, None, 10)
para('放大方面如实汇报：50 升小试已经完成 2 批，设备运行情况和参数窗口都有记录；但连续 200 升试验尚未开展，流量、产率和长期活性目前没有完整数据，这些我们都列为需要补充验证的项目。', indent=True)
para('我们的计划很明确：先做 10 批 200 升的放大验证，再依据这批数据评估设备接口和运行稳定性。在数据补齐之前，我们不做超出事实的承诺。', indent=True)

para('第三部分：团队、资产边界与合作安排（约 1 分钟）', 14, True, BLUE, None, 10)
para('团队方面，4 名工程师分别负责试验、分析、放大和记录，1 名工艺负责人负责工艺决策。知识产权边界需要提前讲清楚：现有方法资料和样品按协议用于验证，背景知识产权不会因为合作付款而全部转让；目前也没有提供专利或独家许可，我们不会编造任何证书或授权。', indent=True)
para('合作进展方面：目前有 2 家企业做了初步交流，沟通了原料和现有设备情况；接下来需要共同确认样品、技术边界、试验批数和数据共享方式。要如实说明的是，目前尚无销售订单、尚无定价方案，也没有签订正式中试合同。', indent=True)

para('结尾（约 30 秒）', 14, True, BLUE, None, 10)
para('总结一下：实验室 100 批验证完成，纯度 98.6%±0.4%；50 升小试进行中；下一步是 10 批 200 升验证。我们今天请求的，是一个有条件的中试合作——条件就是把样品、技术边界、试验批数和数据共享先谈清楚。我们不会把意向说成交易，也希望用数据和验证结果说话。谢谢大家，欢迎提问。', indent=True)

doc.save('/workspace/outputs/技术转移项目路演概要讲稿.docx')
print('docx saved')
