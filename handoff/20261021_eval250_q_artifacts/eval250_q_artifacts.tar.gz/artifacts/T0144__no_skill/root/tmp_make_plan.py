# -*- coding: utf-8 -*-
import csv, os

# 段落: (日期, 开始, 结束, 类型, 主题, 内容说明)
rows = [
    ("2026-11-10","09:00","09:45","工作段","版本与命名","阅读25分钟：版本与命名；案例讨论与练习20分钟：项目A报价v2/v3命名与批准证据练习"),
    ("2026-11-10","09:45","10:00","休息","","茶歇，不安排学习内容"),
    ("2026-11-10","10:00","10:45","工作段","权限与共享","阅读30分钟：权限与共享；案例讨论与练习15分钟：目录索引与正文权限、公开介绍外发核对练习"),
    ("2026-11-10","10:45","11:00","休息","","茶歇，不安排学习内容"),
    ("2026-11-10","11:00","11:45","工作段","评审与纠正","阅读35分钟：评审与纠正；案例讨论10分钟：37人完成率数据口径批注，未决讨论延续至11月11日复盘"),
    ("2026-11-10","11:45","12:00","休息","","午前结束休息，不安排学习内容"),
    ("2026-11-11","09:00","09:45","工作段","交付检查","阅读40分钟：交付检查；案例讨论5分钟：税率10%/13%对账、附件与单位核对要点"),
    ("2026-11-11","09:45","10:00","休息","","茶歇，不安排学习内容"),
    ("2026-11-11","10:00","10:45","工作段","失败恢复","阅读30分钟：失败恢复；案例讨论与练习15分钟：T17/T18幂等检查练习"),
    ("2026-11-11","10:45","11:00","休息","","茶歇，不安排学习内容"),
    ("2026-11-11","11:00","11:45","工作段","归档检索+综合复盘","阅读25分钟：归档检索；综合复盘20分钟：六主题核对动作汇总，含11月10日评审与纠正延续讨论"),
    ("2026-11-11","11:45","12:00","休息","","午前结束休息，不安排学习内容"),
]

os.makedirs("/workspace/outputs", exist_ok=True)
with open("/workspace/outputs/学习计划.csv","w",newline="",encoding="utf-8-sig") as f:
    w = csv.writer(f)
    w.writerow(["日期","开始时间","结束时间","类型","主题","内容安排","时长(分钟)"])
    for d,s,e,t,tp,c in rows:
        sh,sm = map(int,s.split(":")); eh,em = map(int,e.split(":"))
        dur = (eh*60+em)-(sh*60+sm)
        w.writerow([d,s,e,t,tp,c,dur])

# ICS with VTIMEZONE Asia/Shanghai
tz = """BEGIN:VTIMEZONE
TZID:Asia/Shanghai
BEGIN:STANDARD
DTSTART:19700101T000000
TZOFFSETFROM:+0800
TZOFFSETTO:+0800
TZNAME:CST
END:STANDARD
END:VTIMEZONE
"""

def dt(d,t):
    return d.replace("-","")+"T"+t.replace(":","")+"00"

ev = []
for i,(d,s,e,t,tp,c) in enumerate(rows,1):
    label = tp if not t else f"{t}"
    if tp=="休息":
        summ = "休息（15分钟）"
    elif t=="归档检索+综合复盘":
        summ = "学习工作段：归档检索与综合复盘"
    else:
        summ = f"学习工作段：{t}"
    ev.append(f"""BEGIN:VEVENT
UID:qinglu-study-{i}@training.example.com
DTSTAMP:20261015T000000Z
DTSTART;TZID=Asia/Shanghai:{dt(d,s)}
DTEND;TZID=Asia/Shanghai:{dt(d,e)}
SUMMARY:{summ}
DESCRIPTION:{tp}：{c}
LOCATION:青芦项目组学习（线上）
ATTENDEE;CN=培训学员:mailto:training@example.com
END:VEVENT
""")

ics = """BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//qinglu//study-plan//CN
CALSCALE:GREGORIAN
METHOD:PUBLISH
""" + tz + """".join(ev) + "END:VCALENDAR\r\n"

with open("/workspace/outputs/学习安排.ics","w",encoding="utf-8") as f:
    f.write(ics)
print("done")
