# -*- coding: utf-8 -*-
from docx import Document
from docx.shared import Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn

# ============ change_email.docx ============
doc = Document()
style = doc.styles['Normal']
style.font.name = 'Noto Sans CJK SC'
style.font.size = Pt(11)
style.element.rPr.rFonts.set(qn('w:eastAsia'), 'Noto Sans CJK SC')

def set_font(run, bold=False, size=11):
    run.font.name = 'Noto Sans CJK SC'
    run._element.rPr.rFonts.set(qn('w:eastAsia'), 'Noto Sans CJK SC')
    run.font.size = Pt(size)
    run.bold = bold

def para(text, bold=False, size=11, align=None):
    p = doc.add_paragraph()
    r = p.add_run(text)
    set_font(r, bold, size)
    if align: p.alignment = align
    return p

para('项目变更沟通函', bold=True, size=14, align=WD_ALIGN_PARAGRAPH.CENTER)
para('主题：关于项目范围内缺陷修复与新增需求变更确认的沟通（截至10月5日，事项C1–C6）', bold=True)
para('致：甲方项目组')
para('发件方：乙方项目组')
para('日期：2026年10月5日')
para('')
para('贵方好：')
para('感谢贵方于10月2日至10月4日期间通过测试反馈和变更申请提出的各项事项。根据双方2026年8月20日确认的项目范围（内网知识检索、50用户、PDF/DOCX导入、访问权限、日志导出，搜索响应小于5秒，10月30日验收）及合同关于“已确认范围内缺陷修复不另收费、新增范围须书面变更、工期费用影响需售前与交付联合估算再确认”的约定，现将6项事项（C1–C6）逐项分类说明，并就工期与费用影响提出待确认安排，请贵方审阅后书面回复。')

para('一、属于已确认范围内的缺陷（按合同不另收费）', bold=True)
para('经与基线范围逐项核对，以下2项属于约定范围内的功能缺陷，我方将按合同约定不另收费安排修复：')
tbl = doc.add_table(rows=1, cols=3)
tbl.style = 'Table Grid'
hdr = tbl.rows[0].cells
for i, t in enumerate(['编号', '事项', '缺陷说明与处理安排']):
    r = hdr[i].paragraphs[0].add_run(t); set_font(r, True)
rows = [
    ('C1', '搜索结果少了一份可搜索PDF（提出日期10月2日）', '该PDF为可搜索文本型PDF，PDF/DOCX导入与检索属于基线范围；当前现象为导入索引失败，属范围内缺陷。我方将排查导入解析与索引流程，不另收费修复。'),
    ('C4', '日志导出字段漏访问时间（提出日期10月3日）', '日志导出属于基线范围，漏字段属实现缺陷。我方将补齐访问时间字段，不另收费修复。'),
]
for a, b, c in rows:
    cells = tbl.add_row().cells
    for i, t in enumerate([a, b, c]):
        r = cells[i].paragraphs[0].add_run(t); set_font(r)
para('注：测试中发现的扫描PDF无法检索问题，与C1中“可搜索PDF”不同——扫描PDF不在双方约定的OCR范围内（见下文C5），不计为缺陷。')

para('二、属于新增需求的事项（需按合同以书面变更确认）', bold=True)
para('以下4项超出2026-08-20双方确认的基线范围（双方未约定手机端、微信集成、OCR及超出50用户的并发规模），按合同“新增范围须书面变更”执行。在双方签署变更单前，我方无法承诺将其纳入本期交付或10月30日验收范围：')
tbl2 = doc.add_table(rows=1, cols=3)
tbl2.style = 'Table Grid'
hdr = tbl2.rows[0].cells
for i, t in enumerate(['编号', '新增需求', '范围差异说明']):
    r = hdr[i].paragraphs[0].add_run(t); set_font(r, True)
rows2 = [
    ('C2', '微信内发起审批（10月2日）', '基线无微信集成及审批流程，属全新功能模块。'),
    ('C3', '200用户并发（10月3日）', '基线为50用户，并发规模扩大4倍，涉及扩容与性能验证。'),
    ('C5', '扫描PDF识别OCR（10月4日）', '双方明确未约定扫描PDF的OCR，属新增能力。'),
    ('C6', '手机响应布局（10月4日）', '双方未约定手机端，属新增前端适配工作。'),
]
for a, b, c in rows2:
    cells = tbl2.add_row().cells
    for i, t in enumerate([a, b, c]):
        r = cells[i].paragraphs[0].add_run(t); set_font(r)

para('三、工期与费用影响的初步评估（待联合估算确认）', bold=True)
para('按合同约定，变更的工期费用影响需售前与交付联合估算后再确认。以下为售前侧初步量级，供贵方决策参考，最终以联合估算结果和双方签署的书面变更单为准：')
tbl3 = doc.add_table(rows=1, cols=4)
tbl3.style = 'Table Grid'
hdr = tbl3.rows[0].cells
for i, t in enumerate(['编号', '初步工作量（人日）', '工期影响（约）', '费用口径']):
    r = hdr[i].paragraphs[0].add_run(t); set_font(r, True)
rows3 = [
    ('C2 微信审批', '10–15人日', '约+2周', '另行报价'),
    ('C3 200用户并发', '5–8人日', '约+1周（视扩容方案）', '另行报价（含可能的资源费用）'),
    ('C5 扫描PDF OCR', '15–20人日', '约+3周', '另行报价（含OCR引擎/许可）'),
    ('C6 手机响应布局', '10–15人日', '约+2周', '另行报价'),
]
for a, b, c, d in rows3:
    cells = tbl3.add_row().cells
    for i, t in enumerate([a, b, c, d]):
        r = cells[i].paragraphs[0].add_run(t); set_font(r)
para('以上4项若全部纳入本期，累计工期影响约需顺延4–6周；我方将在贵方明确立项意向后5个工作日内提交售前与交付联合估算的正式变更报价单。')

para('四、对10月30日验收的安排建议', bold=True)
para('1. 范围内缺陷（C1、C4）的修复不影响验收基线，我方按正常排期在验收前完成。')
para('2. 新增需求（C2、C3、C5、C6）在变更签署前不纳入本期范围。请贵方在以下两种安排中择一：')
para('（a）本期按原基线范围于10月30日验收，新增需求列入二期并同步启动变更估算；')
para('（b）将全部或部分新增需求纳入本期，验收日期相应顺延，以书面变更单为准。')
para('3. 为不影响项目整体进度，请贵方于10月10日前书面回复上述确认事项。')

para('五、请贵方确认的事项', bold=True)
para('1. 确认C1、C4两项缺陷清单无遗漏，以便我方排期修复；')
para('2. 对C2、C3、C5、C6四项新增需求，逐项确认是否立项变更（纳入本期/列入二期/暂缓）；')
para('3. 确认验收安排采用上述（a）或（b）方案；')
para('4. 补充各变更事项的提出人信息，以便按合同要求完善变更记录台账。')
para('')
para('以上事项请贵方审阅确认。如需就估算口径或排期进一步沟通，我方随时配合。')
para('')
para('顺祝商祺！')
para('乙方项目组')
para('2026年10月5日')

doc.save('/workspace/outputs/change_email.docx')
print('docx saved')

# ============ change_log.xlsx ============
import openpyxl
from openpyxl.styles import Font, Alignment, PatternFill
from openpyxl.utils import get_column_letter

wb = openpyxl.Workbook()
ws = wb.active
ws.title = '变更台账'

headers = ['编号', '要求', '提出日期', '提出人', '分类（范围内缺陷/新增需求）', '范围差异说明', '影响评估（初步）', '处理决定', '状态']
ws.append(headers)

widths = [8, 30, 12, 16, 24, 40, 34, 36, 12]
for i, w in enumerate(widths, 1):
    ws.column_dimensions[get_column_letter(i)].width = w

data = [
    ['C1', '搜索结果少了一份可搜索PDF', '2026-10-02', '甲方（人员待补充）', '范围内缺陷',
     '可搜索文本型PDF；PDF/DOCX导入与检索属2026-08-20基线范围，当前导入索引失败。',
     '修复工作量小；不另收费；不影响验收基线。',
     '按合同“范围内缺陷修复不另收费”，纳入缺陷修复排期，验收前完成。', '修复中'],
    ['C2', '微信内发起审批', '2026-10-02', '甲方（人员待补充）', '新增需求',
     '双方未约定微信集成与审批流程，属全新功能模块。',
     '初步估10–15人日，工期约+2周；费用待售前与交付联合估算后报价。',
     '按合同须书面变更；已致函甲方确认是否立项，签署变更单前不纳入本期。', '待甲方确认'],
    ['C3', '200用户并发', '2026-10-03', '甲方（人员待补充）', '新增需求',
     '基线为50用户，并发扩大4倍，涉及扩容与性能验证。',
     '初步估5–8人日，工期约+1周；可能产生资源费用。',
     '按合同须书面变更；已致函甲方确认是否立项，签署变更单前不纳入本期。', '待甲方确认'],
    ['C4', '日志导出字段漏访问时间', '2026-10-03', '甲方（人员待补充）', '范围内缺陷',
     '日志导出属基线范围，漏字段属实现缺陷。',
     '修复工作量小；不另收费。',
     '按合同“范围内缺陷修复不另收费”，补齐字段，验收前完成。', '修复中'],
    ['C5', '扫描PDF识别（OCR）', '2026-10-04', '甲方（人员待补充）', '新增需求',
     '双方明确未约定扫描PDF的OCR（测试中已确认扫描PDF不在约定OCR范围）。',
     '初步估15–20人日，工期约+3周；含OCR引擎/许可费用。',
     '按合同须书面变更；已致函甲方确认是否立项，签署变更单前不纳入本期。', '待甲方确认'],
    ['C6', '手机响应布局', '2026-10-04', '甲方（人员待补充）', '新增需求',
     '双方未约定手机端，属新增前端适配工作。',
     '初步估10–15人日，工期约+2周。',
     '按合同须书面变更；已致函甲方确认是否立项，签署变更单前不纳入本期。', '待甲方确认'],
]
for row in data:
    ws.append(row)

header_fill = PatternFill('solid', fgColor='D9E2F3')
for cell in ws[1]:
    cell.font = Font(bold=True)
    cell.fill = header_fill
    cell.alignment = Alignment(horizontal='center', vertical='center')
for row in ws.iter_rows(min_row=2):
    for cell in row:
        cell.alignment = Alignment(vertical='top', wrap_text=True)

ws.append([])
ws.append(['说明：分类依据为双方2026-08-20确认的基线范围与合同变更条款；新增需求的最终工期费用以售前与交付联合估算及双方书面变更单为准。记录日期：2026-10-05。'])
ws.cell(row=ws.max_row, column=1).alignment = Alignment(wrap_text=True)

wb.save('/workspace/outputs/change_log.xlsx')
print('xlsx saved')
