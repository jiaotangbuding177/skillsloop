# -*- coding: utf-8 -*-
from docx import Document
from docx.shared import Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
import openpyxl
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side

# ---------- quarterly_news_update.docx ----------
doc = Document()

title = doc.add_heading('季度新闻更新：产品版本、发布时间与最新状态', level=0)
p = doc.add_paragraph('编制日期：2026-10-15　|　信息截止：2026-10-13（依据快照 company_updates.json）')
p.runs[0].italic = True

# 一、版本与最新状态总览
doc.add_heading('一、版本与最新状态总览', level=1)
t = doc.add_table(rows=1, cols=4)
t.style = 'Light Grid Accent 1'
hdr = t.rows[0].cells
for i, h in enumerate(['产品/事项', '最新状态（截至2026-10-13）', '最新信息时间', '发布时间说明']):
    hdr[i].text = h
rows = [
    ('离线2.0（U1）', '仅进入封闭测试；正式发布日期待定；首版不含 OCR。', '2026-10-05（更正 M04）', '无正式日期，不得自行给出任何日期'),
    ('在线1.8（U2）', '已稳定发布；含来源定位功能；不含离线与 OCR 功能。', '2026-09-20（稳定发布 M03）', '2026-09-20 已正式发布'),
    ('已售在线版本维护（U3）', '继续维护一年，合同条款不变。', '2026-10-08（支持公告 M05）', '2026-10-08 公告生效'),
]
for r in rows:
    c = t.add_row().cells
    for i, v in enumerate(r):
        c[i].text = v

doc.add_heading('版本时间线（离线2.0，事件 U1）', level=2)
for line in [
    '2026-08-01（M01）：计划 9月15发布，含 PDF 检索与 OCR。——已被后续消息取代',
    '2026-09-10（M02）：延期至 10月20，OCR 可能单独发布。——该日期已被 2026-10-05 更正撤回，不得继续使用',
    '2026-10-05（M04）：更正——离线2.0 只进入封闭测试，正式日期待定，首版不含 OCR。——当前有效口径',
    '2026-10-10（M06）：渠道转发 9月10 旧消息（“10月20全功能离线发布”）。——旧消息重复转发，与 M04 冲突，不得采用',
]:
    doc.add_paragraph(line, style='List Bullet')

# 二、不得继续使用的发布时间
doc.add_heading('二、不得继续使用的发布时间（重点）', level=1)
for line in [
    '“9月15发布”：源自 M01 计划，已被 M02 延期、又被 M04 更正撤回。',
    '“10月20全功能发布”：源自 M02 延期，已被 M04 更正撤回；M06 仅为渠道转发旧消息，不构成新依据。',
    '“OCR 随离线2.0 发布”：M04 明确首版不含 OCR，OCR 是否单独发布及时间均未定。',
]:
    doc.add_paragraph(line, style='List Number')
doc.add_paragraph('以上时间/说法一律从销售资料中移除；离线2.0 当前唯一可用口径：封闭测试中，正式日期待定。')

# 三、销售资料需要修改之处
doc.add_heading('三、销售资料需要修改之处', level=1)
t2 = doc.add_table(rows=1, cols=4)
t2.style = 'Light Grid Accent 1'
hdr2 = t2.rows[0].cells
for i, h in enumerate(['客户', '现销售说法', '与最新状态的冲突', '需修改为']):
    hdr2[i].text = h
rows2 = [
    ('甲厂（未签）', '9月15离线OCR', '9月15日期已撤回；首版不含 OCR；OCR 发布安排未定。', '改为：离线2.0 处于封闭测试，正式日期待定，首版不含 OCR；不给日期、不承诺 OCR 时间。'),
    ('乙仓（已签）', '在线1.8已发布', '与最新状态一致，无需修改。', '保留；可补充说明：含来源定位，不含离线与 OCR；已售版本继续维护一年，合同不变。'),
    ('丙园（未签）', '10月20离线', '10月20日期已撤回（M04 更正），且 M06 属旧消息转发。', '改为：离线2.0 封闭测试中，正式日期待定；客户 12月部署需求暂无法承诺对应发布，不给自行日期。'),
]
for r in rows2:
    c = t2.add_row().cells
    for i, v in enumerate(r):
        c[i].text = v

# 四、口径与合规边界
doc.add_heading('四、口径与合规边界（依据 change_policy.md）', level=1)
for line in [
    '本报告仅依据 2026-10-13 截止的消息快照，不引入快照外信息。',
    '销售承诺不是产品状态：以产品组发布为准，不反向“兑现”销售口径。',
    '建议通知客户最新状态，但不代客户发布、不承诺赔偿。',
    '已签维护（在线已售版本维护一年）与未来产品（离线2.0）分别说明，不混用。',
    '没有正式日期就不能自行给日期：对甲厂、丙园一律只讲“待定”。',
]:
    doc.add_paragraph(line, style='List Bullet')

doc.save('/workspace/outputs/quarterly_news_update.docx')
print('docx saved')

# ---------- customer_impacts.xlsx ----------
wb = openpyxl.Workbook()
ws = wb.active
ws.title = '客户影响'
thin = Side(style='thin', color='999999')
border = Border(left=thin, right=thin, top=thin, bottom=thin)
hfill = PatternFill('solid', fgColor='1F4E79')
hfont = Font(name='Noto Sans CJK SC', bold=True, color='FFFFFF', size=11)
bodyfont = Font(name='Noto Sans CJK SC', size=11)
wrap = Alignment(wrap_text=True, vertical='top')

headers = ['客户', '合同状态', '现销售说法', '现需求', '与最新产品状态是否一致', '冲突点/问题', '需修改为的口径', '建议动作（不代发、不承诺赔偿）']
ws.append(headers)
for i in range(1, len(headers) + 1):
    c = ws.cell(row=1, column=i)
    c.fill = hfill; c.font = hfont; c.border = border
    c.alignment = Alignment(wrap_text=True, vertical='center', horizontal='center')

data = [
    ['甲厂', '未签', '9月15离线OCR', '不能联网（需离线能力）', '否', '“9月15”发布时间已被延期（09-10）并被更正（10-05）撤回；首版不含 OCR；OCR 发布安排未定', '离线2.0 处于封闭测试，正式日期待定，首版不含 OCR；不给出任何日期', '通知客户最新状态与口径；不代发、不承诺赔偿、不给自行日期'],
    ['乙仓', '已签', '在线1.8已发布', '在线来源定位', '是', '无冲突；注意补充边界：在线1.8 含来源定位，不含离线与 OCR 功能', '保留原说法；可补充功能边界与维护安排', '按合同继续履约；说明已售在线版本继续维护一年、合同不变'],
    ['丙园', '未签', '10月20离线', '12月部署', '否', '“10月20”日期已被 10-05 更正撤回；10-10 渠道转发（M06）属旧消息，不得采用；离线2.0 尚无正式日期', '离线2.0 封闭测试中，正式日期待定；无法确认 12月部署对应的发布时间', '通知客户最新状态；不代发、不承诺赔偿、不给自行日期'],
]
for row in data:
    ws.append(row)
for r in range(2, ws.max_row + 1):
    for c in range(1, len(headers) + 1):
        cell = ws.cell(row=r, column=c)
        cell.font = bodyfont; cell.border = border; cell.alignment = wrap
    # 一致性高亮
    flag = ws.cell(row=r, column=5)
    flag.fill = PatternFill('solid', fgColor='C6EFCE' if flag.value == '是' else 'FFC7CE')

widths = [8, 8, 16, 16, 12, 42, 40, 40]
for i, w in enumerate(widths, start=1):
    ws.column_dimensions[openpyxl.utils.get_column_letter(i)].width = w
ws.row_dimensions[1].height = 30
for r in range(2, ws.max_row + 1):
    ws.row_dimensions[r].height = 60
ws.freeze_panes = 'A2'

# 说明sheet
ws2 = wb.create_sheet('口径说明')
notes = [
    '1. 信息截止 2026-10-13，仅依据 company_updates.json 快照与 change_policy.md。',
    '2. 被撤回、不得继续使用的发布时间：“9月15”（M01→M02→M04 撤回）、“10月20”（M02→M04 撤回；M06 为旧消息转发）。',
    '3. 销售承诺不是产品状态；建议通知客户但不代发、不承诺赔偿。',
    '4. 已签维护与未来产品分别适用：已售在线版本维护一年、合同不变；离线2.0 为未来产品，日期待定。',
    '5. 没有正式日期不能自行给日期。',
]
ws2['A1'] = '口径说明'
ws2['A1'].font = Font(name='Noto Sans CJK SC', bold=True, size=13)
for i, n in enumerate(notes, start=3):
    ws2.cell(row=i, column=1, value=n).font = bodyfont
ws2.column_dimensions['A'].width = 100

wb.save('/workspace/outputs/customer_impacts.xlsx')
print('xlsx saved')
