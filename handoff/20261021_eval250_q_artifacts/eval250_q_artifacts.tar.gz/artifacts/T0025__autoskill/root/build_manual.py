# -*- coding: utf-8 -*-
"""以 inputs/企业用户手册材料.docx 为唯一功能依据，生成《企业管理员操作手册.docx》。"""
import re
from docx import Document
from docx.shared import Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

FONT = 'Noto Sans CJK SC'
BLUE = (0x1F, 0x4E, 0x79)
GRAY = (0x59, 0x59, 0x59)

DOC = Document()


def style_font(style, size, bold=False, color=None):
    style.font.name = FONT
    style.font.size = Pt(size)
    style.font.bold = bold
    if color:
        style.font.color.rgb = RGBColor(*color)
    rpr = style.element.get_or_add_rPr()
    rfonts = rpr.find(qn('w:rFonts'))
    if rfonts is None:
        rfonts = OxmlElement('w:rFonts')
        rpr.append(rfonts)
    rfonts.set(qn('w:eastAsia'), FONT)


style_font(DOC.styles['Normal'], 11)
DOC.styles['Normal'].paragraph_format.line_spacing = 1.35
DOC.styles['Normal'].paragraph_format.space_after = Pt(6)
for name, size in [('Heading 1', 16), ('Heading 2', 13), ('Heading 3', 12)]:
    st = DOC.styles[name]
    style_font(st, size, bold=True, color=BLUE)
    st.paragraph_format.space_before = Pt(14)
    st.paragraph_format.space_after = Pt(6)

# 页面设置
sec = DOC.sections[0]
sec.page_width, sec.page_height = Cm(21), Cm(29.7)
sec.top_margin = sec.bottom_margin = Cm(2.5)
sec.left_margin = sec.right_margin = Cm(2.6)
sec.different_first_page_header_footer = True

# 页眉
hp = sec.header.paragraphs[0]
hp.alignment = WD_ALIGN_PARAGRAPH.CENTER
r = hp.add_run('企业管理员操作手册 · 北辰企业协同平台云服务版')
r.font.size = Pt(9)
r.font.color.rgb = RGBColor(*GRAY)
r.font.name = FONT
r._element.rPr.rFonts.set(qn('w:eastAsia'), FONT)

# 页脚页码
fp = sec.footer.paragraphs[0]
fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
run = fp.add_run()
f1 = OxmlElement('w:fldChar'); f1.set(qn('w:fldCharType'), 'begin')
it = OxmlElement('w:instrText'); it.set(qn('xml:space'), 'preserve'); it.text = ' PAGE '
f2 = OxmlElement('w:fldChar'); f2.set(qn('w:fldCharType'), 'end')
run._r.append(f1); run._r.append(it); run._r.append(f2)
run.font.size = Pt(9)
run.font.color.rgb = RGBColor(*GRAY)
run.font.name = FONT
run._element.rPr.rFonts.set(qn('w:eastAsia'), FONT)


def rich(par, text, size=11, color=None, bold=False):
    for i, seg in enumerate(re.split(r'\*\*(.+?)\*\*', text)):
        if not seg:
            continue
        r = par.add_run(seg)
        r.font.bold = bold or (i % 2 == 1)
        r.font.size = Pt(size)
        r.font.name = FONT
        r._element.rPr.rFonts.set(qn('w:eastAsia'), FONT)
        if color:
            r.font.color.rgb = RGBColor(*color)


def P(text, align=None, size=11, color=None, bold=False, style=None):
    p = DOC.add_paragraph(style=style)
    if align is not None:
        p.alignment = align
    rich(p, text, size=size, color=color, bold=bold)
    return p


def H(level, text):
    return DOC.add_heading(text, level=level)


def B(text):
    return P(text, style='List Bullet')


def B2(text):
    return P(text, style='List Bullet 2')


def label(kind, text):
    p = DOC.add_paragraph()
    r = p.add_run('【' + kind + '】')
    r.font.bold = True
    r.font.size = Pt(11)
    r.font.color.rgb = RGBColor(*BLUE)
    r.font.name = FONT
    r._element.rPr.rFonts.set(qn('w:eastAsia'), FONT)
    rich(p, text)
    return p


def warn(text):
    p = DOC.add_paragraph()
    rich(p, text, size=10.5)
    pPr = p._p.get_or_add_pPr()
    shd = OxmlElement('w:shd'); shd.set(qn('w:val'), 'clear'); shd.set(qn('w:fill'), 'FDF2E9')
    pPr.append(shd)
    pbdr = OxmlElement('w:pBdr')
    left = OxmlElement('w:left')
    left.set(qn('w:val'), 'single'); left.set(qn('w:sz'), '18'); left.set(qn('w:color'), 'C55A11')
    pbdr.append(left)
    pPr.append(pbdr)
    p.paragraph_format.space_before = Pt(4)
    p.paragraph_format.space_after = Pt(8)
    return p


def shade(cell, fill):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement('w:shd'); shd.set(qn('w:val'), 'clear'); shd.set(qn('w:fill'), fill)
    tcPr.append(shd)


def table(headers, rows):
    t = DOC.add_table(rows=1, cols=len(headers))
    t.style = 'Table Grid'
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    trPr = t.rows[0]._tr.get_or_add_trPr()
    th = OxmlElement('w:tblHeader'); th.set(qn('w:val'), 'true')
    trPr.append(th)
    for i, h in enumerate(headers):
        c = t.rows[0].cells[i]
        shade(c, '1F4E79')
        p = c.paragraphs[0]
        r = p.add_run(h)
        r.font.bold = True
        r.font.size = Pt(10.5)
        r.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
        r.font.name = FONT
        r._element.rPr.rFonts.set(qn('w:eastAsia'), FONT)
    for row in rows:
        cells = t.add_row().cells
        for i, v in enumerate(row):
            p = cells[i].paragraphs[0]
            rich(p, str(v), size=10.5)
    DOC.add_paragraph().paragraph_format.space_after = Pt(2)
    return t


# ================= 封面 =================
for _ in range(5):
    DOC.add_paragraph()
P('北辰企业协同平台 云服务版', align=WD_ALIGN_PARAGRAPH.CENTER, size=16, color=GRAY)
DOC.add_paragraph()
P('企业管理员操作手册', align=WD_ALIGN_PARAGRAPH.CENTER, size=30, bold=True, color=BLUE)
DOC.add_paragraph()
P('面向初次使用的企业管理员', align=WD_ALIGN_PARAGRAPH.CENTER, size=13, color=GRAY)
for _ in range(8):
    DOC.add_paragraph()
P('版本 2026.05.20', align=WD_ALIGN_PARAGRAPH.CENTER, size=12)
DOC.add_page_break()

# ================= 目录 =================
H(1, '目录')
toc = [
    ('使用须知与法律声明', ''),
    ('第1章 开通与账号', '首次开通与审批 / 管理员登录 / 加入企业、组织 / 切换企业、组织'),
    ('第2章 认识操作页面', '左侧文件管理区 / 中间对话核心区 / 右侧AI工作台'),
    ('第3章 工作区与文件管理', '文件树 / 常用文件操作 / 数据备份与删除提醒'),
    ('第4章 文件分享', '创建分享 / 访问分享 / 管理分享'),
    ('第5章 会话功能', '发送消息与附件 / 中断生成 / 新建会话与历史会话'),
    ('第6章 智能体管理', '内置智能体 / 自定义智能体 / 智能体详情 / 示例：HR智能体'),
    ('第7章 技能管理', '技能库 / 我的技能 / 推荐技能'),
    ('第8章 定时任务', '创建定时任务 / 任务管理与通知'),
    ('第9章 模型配置', ''),
    ('第10章 快捷指令', ''),
    ('第11章 常见问题', ''),
    ('第12章 问题反馈渠道', ''),
    ('附录', 'A 快捷键 / B 术语表 / C 文件预览格式'),
]
for main, sub in toc:
    p = DOC.add_paragraph()
    rich(p, main, size=12, bold=True)
    p.paragraph_format.space_after = Pt(2)
    if sub:
        p2 = DOC.add_paragraph()
        rich(p2, sub, size=10.5, color=GRAY)
        p2.paragraph_format.left_indent = Cm(0.8)
        p2.paragraph_format.space_after = Pt(4)
DOC.add_page_break()

# ================= 使用须知 =================
H(1, '使用须知与法律声明')
H(2, '适用对象')
P('本手册适用于**负责本产品服务企业的相关人员（企业管理员）**，供初次使用时按日常办理顺序完成开通、配置与日常管理。')
H(2, '知识产权与保密声明')
B('**内容保护**：本说明书及相关技术资料（含文档、图纸、音视频等）的版权均归北辰科技公司所有。未经授权，严禁复制、传播或用于第三方商业用途。')
B('**软件授权**：您获得的是软件的有限非独家使用权。除下载数据备份外，禁止对软件进行反向工程、复制或修改。我方无义务提供源代码或非约定版本的升级服务。')
B('**数据责任**：**请所有者定期备份工作区中的关键数据，以防丢失。**')
H(2, '产品使用规范')
B('**禁止篡改**：未经北辰科技公司书面许可，严禁对产品（尤其是安全模块）进行任何修改。')
H(2, '安全与责任界定')
B('**风险提示**：请严格按照说明操作。对于因违反本指南导致的直接或间接损失（包括人身伤害或生产损失），北辰科技公司不承担法律责任。')
B('**版本更新**：我们保留随时更新技术规范与说明的权利，恕不另行预告。')
H(2, '免责声明')
P('北辰企业协同平台生成的所有内容均由 AI 自动产生，**可能存在错误或不准确之处，请务必核查重要信息**。')

# ================= 第1章 =================
H(1, '第1章 开通与账号')

H(2, '1.1 首次开通与审批')
label('操作前提', '企业尚未开通平台服务；企业管理员可接收审批信息。')
label('操作步骤', '')
B('访问产品首页：https://evomind.zzz4ai.com，系统自动跳转至登录页。')
B('提交首次使用开通申请。')
B('等待管理员审批；**审批通过后刷新页面即可使用**。')
label('核对点', '刷新页面后能正常访问平台首页，说明开通完成。')

H(2, '1.2 管理员登录')
label('操作前提', '企业已开通服务；使用 Chrome 或 Edge 浏览器；手机可接收短信验证码。')
label('操作步骤', '')
B('打开浏览器，输入产品首页：https://evomind.zzz4ai.com。')
B('点击「登录」进入登录页：https://evomind.zzz4ai.com/login。')
B('点击「获取验证码」，系统发送 **6 位数字短信验证码**。')
B('输入收到的验证码。')
B('点击「登录」按钮。')
P('登录页面元素说明：', size=10.5, color=GRAY)
table(['元素', '说明'], [
    ['验证码输入框', '6 位数字验证码'],
    ['获取验证码按钮', '点击后 60 秒倒计时，期间不可重复发送'],
    ['登录按钮', '验证通过后自动跳转至首页'],
])
label('核对点', '验证通过后自动跳转至首页，说明登录成功。')
warn('注意：**验证码 60 秒内只能发送一次**，请在有效期内完成输入。')

H(2, '1.3 加入企业/组织')
label('操作前提', '已登录平台账号。')
label('操作步骤', '')
B('进入申请加入企业/组织入口。')
B('填写要加入的企业名称，提交申请即可。')
label('核对点', '申请已提交成功，等待审批结果。')

H(2, '1.4 切换企业/组织')
label('操作前提', '账号已加入多个企业/组织（平台适配多企业/组织架构场景）。')
label('操作步骤', '')
B('在侧边栏底部找到组织切换器。')
B('选择要切换的组织或「默认空间」。')
label('核对点', '切换后**文件树、对话历史、知识库等资源自动切换**到所选组织。')

# ================= 第2章 =================
H(1, '第2章 认识操作页面')
P('平台界面由左侧、中间、右侧三个核心区域组成，办理日常事务前建议先熟悉各区域定位。')
H(2, '2.1 左侧「文件管理区」')
P('定位：**企业级文件与组织管理中枢**。')
table(['功能模块', '说明'], [
    ['个人工作区 / 共享工作区', '支持团队/个人文件的分类存储；**共享工作区整个企业/组织可见**'],
    ['我的分享 / AI会话记录', '快速访问分享的文件、过往AI历史会话存档'],
    ['企业/组织切换', '适配多企业/组织架构场景，一键切换所属主体'],
    ['个人信息区', '展示和修改账号头像等信息，查看云盘空间大小'],
])
H(2, '2.2 中间「对话核心区」')
P('由「会话区」+「对话框区」组成，是人机交互的核心场景。')
P('**会话区**：AI 与用户的对话内容展示窗口，呈现自然语言对话，支持多轮连续交互；AI 回复包含结构化信息。', size=10.5)
P('**对话框区**：用户输入指令、调用工具的操作入口：', size=10.5)
B('基础操作：输入消息后按 Enter 发送，Shift + Enter 换行；支持拖拽本地/左侧文件到输入框，实现「对话+文件处理」联动。')
B('快捷功能：「新对话」（开启全新会话）、「快捷指令」（预设常用指令模板）、「技能库」（调用AI扩展能力）、「人格」（自定义AI交互风格）。')
B('模型配置：「默认大模型」支持切换底层AI模型，可配置自定义模型。')
B('辅助工具：「输入优化」（润色/补全用户输入）、「上传文件」（向对话注入文档等素材）、「发送」（提交当前输入）。')
H(2, '2.3 右侧「AI工作台」')
P('聚焦任务自动化、智能体协同、技能扩展三大方向，是企业效率提升的「工具箱」。')
table(['区域', '定位', '功能'], [
    ['定时任务区', '自动化任务调度中心', '创建周期性/一次性任务，设置触发时间，减少重复人工操作'],
    ['智能体区', '垂直场景AI助手集合', '提供「销售助手」「招聘助手」等行业专属智能体，覆盖业务全流程提效'],
    ['推荐技能区', '通用型AI能力插件库', '推荐「合同风险审查」「法律风险评估」等专业技能，按需调用解决特定问题'],
])
label('核对点', '能准确找到三大区域，并知道各日常办理事项对应的功能入口。')

# ================= 第3章 =================
H(1, '第3章 工作区与文件管理')
P('工作区是平台的文件管理中心，管理员可在此管理 AI 生成和上传的文件。')
H(2, '3.1 文件树')
P('左侧面板展示文件树结构：')
B('**文件**：普通文件，点击可预览。')
B('**目录**：文件夹，点击展开子目录。')
B('**AI工作区**：AI 工作流程中创建的目录。')
H(2, '3.2 常用文件操作')
label('操作前提', '已登录并进入目标工作区（个人工作区或共享工作区）。')
label('操作步骤', '在文件树中定位目标位置后，使用以下操作：')
table(['操作', '说明'], [
    ['新建文件', '创建空白文件'],
    ['新建文件夹', '创建目录'],
    ['上传文件', '从本地上传文件到工作区'],
    ['下载文件', '下载文件到本地'],
    ['重命名', '修改文件或文件夹名称'],
    ['删除', '**永久删除文件或文件夹（不可恢复）**'],
    ['分享', '创建分享链接（见第4章）'],
])
label('核对点', '新建/上传的文件出现在对应目录中，且可正常预览。')
H(2, '3.3 数据备份与删除提醒')
warn('**数据备份：请所有者定期备份工作区中的关键数据，以防丢失。**')
warn('**删除不可恢复：文件、文件夹的「删除」为永久删除，不可恢复；执行删除前请先确认已完成备份或确认数据不再需要。**')

# ================= 第4章 =================
H(1, '第4章 文件分享')
H(2, '4.1 创建分享')
label('操作前提', '已在文件树中选择要分享的文件或文件夹。')
label('操作步骤', '')
B('点击「分享」按钮。')
B('配置分享选项：')
B2('密码保护（可选）：设置访问密码')
B2('有效期（可选）：设置过期时间')
B2('下载权限：是否允许下载')
B2('复制权限：是否允许复制内容')
B('确认创建，生成分享链接。')
H(2, '4.2 访问分享')
B('通过分享链接打开公开页面。')
B('如有密码保护，需输入密码访问。')
B('根据权限设置，可在线预览、下载或复制。')
H(2, '4.3 管理分享')
B('在「我的分享」面板查看所有分享。')
B('支持取消分享、修改权限。')
label('核对点', '分享链接生成后，用新页面按权限可正常访问；过期分享需**重新创建分享**。')

# ================= 第5章 =================
H(1, '第5章 会话功能')
H(2, '5.1 发送消息与附件')
label('操作前提', '已登录并进入对话核心区。')
label('操作步骤', '')
B('在底部输入框输入消息文本。')
B('（可选）添加文件附件。')
B('点击发送按钮。')
label('核对点', '消息发送成功且 AI 开始回复；附件上传失败时依次检查格式、大小、数量和网络（见第11章 Q6）。')
warn('附件限制：**总计 100MB，最多 5 个，支持格式为 PDF / DOCX / TXT / MD / XLS / XLSX**。')
H(2, '5.2 中断生成')
B('AI 回复过程中，可点击「中断」按钮停止生成。')
H(2, '5.3 新建会话与历史会话')
B('点击「新对话」按钮创建新的对话会话。')
B('侧边栏/历史面板展示历史会话列表，支持**搜索、重命名、删除会话**。')
B('点击会话可**恢复上下文继续对话**。')

# ================= 第6章 =================
H(1, '第6章 智能体管理')
P('智能体是预配置的 AI Agent 角色，支持用户自定义创建和编辑。')
H(2, '6.1 内置智能体')
B('系统预置了 **17 个内置智能体**，后续将持续新增迭代。')
B('智能体按**工作岗位性质**分类管理：**运营、人力资源、财务、法务、销售、市场、通用**。')
table(['智能体', '领域'], [
    ['企业知识助手', '企业知识库问答'],
    ['办公助手', '日常办公支持'],
    ['日常助理', '个人日程管理'],
    ['差旅助手', '差旅规划和预订'],
    ['商业参谋', '商业策略分析'],
    ['销售助手', '销售支持'],
    ['市场分析专家', '市场趋势分析'],
    ['招聘助手', '招聘流程支持'],
    ['文案创作助手', '文案撰写'],
    ['公关 PR 助手', '公关策略'],
    ['数据分析专家', '数据处理和分析'],
    ['管理分析', '管理决策支持'],
    ['财务助手', '财务数据分析'],
    ['安全合规助手', '合规检查'],
    ['法律助手', '法律咨询'],
    ['客服助手', '客户服务'],
    ['会议助手', '会议纪要和总结'],
])
H(2, '6.2 自定义智能体')
label('创建智能体', '')
B('在智能体面板点击「创建智能体」。')
B('配置以下参数：')
table(['参数', '说明'], [
    ['模板', '从预设模板选择（日常助手、学习助手、职场助手、文案创作、电商专家、短视频运营、编程助手等）'],
    ['名称', '自定义智能体名称'],
    ['头像', '从预设头像中选择'],
    ['描述', '智能体职责说明'],
    ['风格', '选择智能体沟通风格'],
    ['绑定技能', '可选绑定已安装的技能'],
])
label('编辑智能体', '')
B('在「我的智能体」中找到要编辑的智能体。')
B('点击编辑按钮，修改参数后保存。')
label('删除智能体', '')
B('在智能体详情面板点击删除按钮。')
B('确认后永久删除。')
warn('**删除智能体确认后将永久删除，不可恢复**；如需保留配置，请先记录其参数再删除。')
B('「我的智能体」展示所有自定义的智能体。')
H(2, '6.3 智能体详情')
P('点击智能体卡片打开详情面板，展示内容如下：')
table(['区域', '说明'], [
    ['定位描述', '智能体的核心定位'],
    ['适合场景', '典型使用场景'],
    ['核心能力', '智能体的关键能力'],
    ['示例用法', '如何使用该智能体的示例'],
    ['绑定技能', '已关联的技能列表'],
])
H(2, '6.4 示例：HR智能体')
label('能力定位', 'HR 工作智能体用于辅助处理企业人力资源场景中的制度化、流程化任务，覆盖**招聘录用、培训管理、员工离职、政策合规和绩效评估**五类核心工作。智能体回答和生成建议时**优先引用已编译的证据原子，避免编造未被制度或流程文件支持的业务事实**。适合用于内部 HR 助手、制度问答、流程核查、表单草拟、审批前材料整理和证据追溯等场景。')
label('包含技能', '')
B('human-resources-recruitment：处理招聘录用流程、候选人材料核验、面试安排、录用审批和入职材料检查。')
B('human-resources-training：处理培训项目设计、培训计划、目标人群、培训方式、日程安排和评估标准。')
B('human-resources-departures：处理员工离职、辞职、终止试用、解除劳动合同、离职材料和补偿相关流程。')
B('human-resources-compliance：处理 HR 制度合规、政策适用性、违规风险、制度审查和证据化合规报告。')
B('human-resources-performance：处理绩效评估周期、评价标准、反馈整理、评级尺度、改进计划和培训建议。')
label('使用示例', '')
B('招聘录用：例如「帮我设计财务岗位招聘流程」「检查候选人入职材料是否齐全」。')
B('培训管理：例如「制定新员工培训计划」「根据培训目标生成评估标准」。')
B('员工离职：例如「处理员工主动离职流程」「离职需要哪些材料」。')
B('政策合规：例如「检查这个考勤制度是否合规」「找出制度依据和风险点」。')
B('绩效评估：例如「设计季度绩效评估流程」「根据反馈生成改进计划」。')
B('如请求同时涉及多个 HR 主题，将先识别主任务，再调用最相关的技能；必要时按流程顺序组合多个技能。例如「招聘后安排入职培训」可先使用 human-resources-recruitment，再使用 human-resources-training。')
warn('**涉及员工个人信息、离职原因、纪律处分、薪酬补偿、内部制度细节或对外输出时，应触发人工确认。**')

# ================= 第7章 =================
H(1, '第7章 技能管理')
H(2, '7.1 技能库')
P('技能市场展示所有可用的 AI 技能/Agent，用户可以**浏览、搜索和安装**。页面布局如下：')
table(['区域', '说明'], [
    ['标题栏', '「Skills 市场」+ 可用/受限技能数量'],
    ['搜索框', '按名称或描述过滤技能'],
    ['技能卡片列表', '分为「当前可用」和「当前受限」两区'],
    ['右侧详情面板', '选中技能后展示名称、描述、状态、文件树'],
])
H(2, '7.2 我的技能')
P('「我的技能」页面展示用户从第三方自行安装的技能：')
B('显示已启用技能。')
B('每张技能卡片包含：图标、名称、状态、描述（自安装技能名称、描述等信息由技能自己确定）。')
H(2, '7.3 推荐技能')
P('可快捷查看适合自己岗位的常用技能，并使用技能完成任务。')

# ================= 第8章 =================
H(1, '第8章 定时任务')
H(2, '8.1 创建定时任务')
label('入口', '工作台右侧面板的定时任务模块。')
label('操作步骤', '创建任务时选择以下三种调度类型之一：')
table(['类型', '说明'], [
    ['手动', '点击「执行」按钮立即运行一次'],
    ['定时', '指定具体时间执行'],
    ['周期', '设置重复周期'],
])
P('周期选项：', size=10.5, color=GRAY)
table(['选项', '说明'], [
    ['每小时', '每隔 1 小时执行'],
    ['每天', '每天固定时间执行'],
    ['每周', '每周指定日期执行'],
    ['每月', '每月指定日期执行'],
])
P('定时任务支持**日历视图**，查看所有定时任务详情。', size=10.5)
H(2, '8.2 任务管理与通知')
B('查看运行记录：点击任务查看历史执行记录。')
B('运行消息：实时查看任务执行过程中的消息。')
B('未读通知：侧边栏显示未读任务计数。')
B('全部已读：一键将所有通知标记为已读；也可逐条标记单条已读。')
B('手动执行：点击「运行」按钮立即执行定时任务。')
label('核对点', '任务按所选调度类型在指定时间触发，运行记录中可查到执行结果。')

# ================= 第9章 =================
H(1, '第9章 模型配置')
label('操作前提', '已获取模型服务商的认证密钥（API Key）。')
label('操作步骤', '')
B('点击模型配置入口打开配置对话框。')
B('配置以下参数：')
B2('Provider：LLM 提供商（如千问、火山、百度等）')
B2('Base URL：可以选择其他，填写自定义的 API 服务地址')
B2('Model ID：可选择系统内置的模型ID，也可以选择其他，填写自定义的模型ID')
B2('API Key：认证密钥')
B('**保存配置后生效**。')
label('核对点', '保存后在「默认大模型」处可切换至新配置的底层AI模型。')

# ================= 第10章 =================
H(1, '第10章 快捷指令')
P('快捷指令（Shortcut Command Menu）是工作台中的快捷操作入口，通过预设指令快速向 Agent 发送常用命令。')
H(2, '10.1 打开方式')
B('点击输入框旁的快捷指令按钮。')
H(2, '10.2 指令类别与内置指令')
P('快捷指令按功能分为**系统、笔记、知识库**三个类别：')
table(['分类', '指令名', '说明'], [
    ['系统', '查看上下文', '查看当前对话内容'],
    ['系统', '总结对话', '总结关键信息'],
    ['系统', '查看计划', '查看任务计划和进度'],
    ['系统', '查看记忆', '查看可访问记忆'],
    ['笔记', '导入 ima 笔记', '将全部 ima 笔记导入工作区'],
    ['笔记', '导入 get 笔记', '将全部 get 笔记导入工作区'],
    ['知识库', '整理知识库', '整理知识库与目录结构'],
])
H(2, '10.3 使用方式')
B('打开快捷指令菜单。')
B('顶部搜索栏可搜索指令。')
B('点击分类标签切换视图（全部 / 系统 / 笔记 / 知识库）。')
B('点击指令卡片**一键发送给AI**。')

# ================= 第11章 =================
H(1, '第11章 常见问题')
H(3, 'Q1：验证码收不到？')
B('检查短信是否被拦截或归入垃圾短信。')
B('等待 60 秒后重新发送。')
B('如持续收不到，联系管理员。')
H(3, 'Q2：平台无法访问？')
B('首次使用需要申请开通，等待管理员审批。')
B('审批通过后刷新页面即可使用。')
H(3, 'Q3：如何切换组织空间？')
B('在侧边栏底部找到组织切换器，选择要切换的组织或「默认空间」；切换后文件树、对话历史、知识库等资源自动切换（见 1.4）。')
H(3, 'Q4：文件分享链接过期了？')
B('分享创建者可在「我的分享」面板查看和管理分享。')
B('如已过期，需重新创建分享。')
H(3, 'Q5：如何配置自定义 AI 模型？')
B('打开模型配置对话框，输入 Provider、Base URL 和 API Key（见第9章）。')
H(3, 'Q6：附件上传失败？')
B('检查文件格式是否支持（PDF / DOCX / TXT / MD / XLS / XLSX）。')
B('检查单个文件大小（不超过 100MB）。')
B('检查文件数量（最多 5 个）。')
B('检查网络连接。')

# ================= 第12章 =================
H(1, '第12章 问题反馈渠道')
P('使用过程中遇到的问题通过**飞书问卷**收集，根据需要反馈给提问者：')
P('https://zzz4ai-sh.feishu.cn/share/base/form/shrcnFxfTDbk49YJ20rrElN9E8f', size=10.5, color=BLUE)

# ================= 附录 =================
H(1, '附录A 快捷键')
table(['快捷键', '功能'], [
    ['Enter', '发送消息/确认操作'],
    ['Shift + Enter', '输入框换行'],
])
H(1, '附录B 术语表')
table(['术语', '说明'], [
    ['组织空间', '企业共享的工作区和协作空间'],
    ['技能', '可安装的 AI 能力扩展'],
    ['长期记忆', 'AI Agent 的持久化知识存储'],
    ['快捷指令', '预设的快捷操作命令，一键发送给 Agent'],
    ['智能体', '可自定义配置的 AI Agent 角色，支持模板、风格、技能绑定'],
    ['跨空间复制', '将文件从个人空间复制到企业空间的功能'],
])
H(1, '附录C 文件预览格式')
table(['格式', '扩展名', '预览方式'], [
    ['PDF', '.pdf', '内置查看器'],
    ['Word', '.docx', '内置查看器'],
    ['PPT', '.pptx', '内置查看器'],
    ['图片', '.png, .jpg, .gif, .bmp, .webp', '图片组件'],
    ['Markdown', '.md', 'Markdown 渲染'],
    ['文本/代码', '.txt, .json, .js, .ts, .py 等', '代码块高亮'],
])

OUT = '/workspace/outputs/企业管理员操作手册.docx'
DOC.save(OUT)
print('saved:', OUT)
