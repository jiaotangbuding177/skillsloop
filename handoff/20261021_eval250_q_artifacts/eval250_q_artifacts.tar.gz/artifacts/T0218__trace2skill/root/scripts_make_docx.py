# -*- coding: utf-8 -*-
"""项目建设资金说明讲稿.docx — 约5分钟讲解稿，与页面事实一致。"""
from docx import Document
from docx.shared import Pt, RGBColor, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn

DARK = RGBColor(0x1F, 0x4E, 0x79)
GREY = RGBColor(0x40, 0x40, 0x40)

doc = Document()
# 页面边距
for sec in doc.sections:
    sec.top_margin = Cm(2.5); sec.bottom_margin = Cm(2.5)
    sec.left_margin = Cm(2.8); sec.right_margin = Cm(2.8)

def style_run(r, size=12, bold=False, color=GREY):
    r.font.name = 'Noto Sans CJK SC'
    r._element.rPr.rFonts.set(qn('w:eastAsia'), 'Noto Sans CJK SC')
    r.font.size = Pt(size)
    r.font.bold = bold
    r.font.color.rgb = color

def para(text, size=12, bold=False, color=GREY, align=None, space_after=6, first_indent=None):
    p = doc.add_paragraph()
    if align: p.alignment = align
    p.paragraph_format.space_after = Pt(space_after)
    if first_indent:
        p.paragraph_format.first_line_indent = Pt(first_indent)
    r = p.add_run(text)
    style_run(r, size, bold, color)
    return p

def heading(text):
    para(text, size=14, bold=True, color=DARK, space_after=8)

# 标题
para("项目建设资金说明 · 讲稿", size=18, bold=True, color=DARK,
     align=WD_ALIGN_PARAGRAPH.CENTER, space_after=4)
para("（面向专项资金管理会，约5分钟；内容与演示页面一致，仅使用已给事实）",
     size=10.5, color=GREY, align=WD_ALIGN_PARAGRAPH.CENTER, space_after=18)

heading("开场（约半分钟）")
para("各位领导、各位委员，下面由我向专项资金管理会汇报项目建设资金安排。本次汇报共七页，按照现状、计划、问题与风险的顺序展开。需要提前说明口径：本汇报只使用已经确认的事实，缺数据的地方直接说明，不补充未知业绩，也不把计划目标当作已完成结果。", first_indent=24)

heading("第一部分：现状——项目与预算总览（约1分钟）")
para("先看总览。本项目周期为六个月：月1进行采购，月2到5开展研发测试，月6完成报告。专项预算为300万元；公司另有300万元自筹资金，单独列支管理，不并入专项分母。因此本汇报的专项分母是300万元，而不是600万元。同时提醒一点：同一笔费用如果纳入专项列支，就不得再写自筹报销，避免重复列支。", first_indent=24)
para("右侧图表是预算科目构成：人员90万元、材料55万元、外协60万元、设备55万元、差旅与知识产权15万元、管理10万元、预备15万元，合计300万元，单位均为万元。", first_indent=24)

heading("第二部分：现状——预算测算构成（约1分钟）")
para("这一页是各科目的测算口径。人员费90万元，按5名研发与技术岗位、平均每人每月3万元、共6个月计算，属于本阶段预算口径。材料费55万元，其中培养与试剂30万元、检测耗材18万元、样品物流7万元。外协费60万元，对应6批检测与动物试验，每批10万元。设备费55万元，包括发酵装置35万元、低温设备8万元、分析仪租赁12万元。差旅与知识产权15万元，含差旅5万元、合作会议3万元、专利交底7万元。管理费10万元，预备费15万元，预备费的使用须经审批。", first_indent=24)

heading("第三部分：计划——支付预测与时间安排（约1分钟）")
para("资金支付方面，月1至月6的计划支付分别为45万元、80万元、60万元、50万元、40万元和25万元，合计300万元。这里必须强调：这是资金计划，而不是已支付。设备前期付款需要采购审批和到货、验收凭据；外协按里程碑记录，不因为预算存在就自动授权支付。由于尚未提供费用实际凭证，本次汇报不展示资金执行率。", first_indent=24)
para("阶段产物共四项：细胞功能验证、两批工艺小试、动物模型试验和技术报告。每项交付都要有批记录、方法和数据引用作为支撑。六个月阶段只覆盖这四项内容，商业生产或临床审批不在本阶段范围之内。", first_indent=24)

heading("第四部分：问题与风险——管理机制（约1分钟）")
para("管理机制上，项目负责人负责技术进度，采购负责设备与耗材，财务负责核对金额单位和凭据。节点安排为：第3月进行中期复核，第6月进行阶段验收。风险方面，如果出现试验不达标、外协迟交或设备延期，都会如实记录；预备费的使用须逐笔审批。最后一条合规声明：不得为了让预算看起来均匀而篡改已确定的报价，也不得隐瞒研发风险。", first_indent=24)

heading("结尾：边界重申与请审议（约半分钟）")
para("最后重申四点边界：第一，专项分母为300万元而非600万元，自筹另列；第二，支付预测是资金计划而非已支付，未提供凭证，不展示执行率；第三，本阶段不含商业生产与临床审批；第四，各项目标均处于计划状态，验收以批记录、方法和数据引用为准。", first_indent=24)
para("以上就是项目建设资金说明的全部内容，请专项资金管理会审议，谢谢大家。", first_indent=24)

doc.save("/workspace/outputs/项目建设资金说明讲稿.docx")
print("saved docx")
