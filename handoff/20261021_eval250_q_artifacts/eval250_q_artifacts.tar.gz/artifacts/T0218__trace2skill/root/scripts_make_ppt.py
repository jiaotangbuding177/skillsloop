# -*- coding: utf-8 -*-
"""项目建设资金说明.pptx — 7页 16:9 白底蓝色商务风，仅使用输入事实。"""
from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.chart.data import CategoryChartData
from pptx.enum.chart import XL_CHART_TYPE, XL_LABEL_POSITION, XL_TICK_LABEL_POSITION

DARK = RGBColor(0x1F, 0x4E, 0x79)
BLUE = RGBColor(0x2E, 0x75, 0xB6)
LIGHT = RGBColor(0xDE, 0xEB, 0xF7)
GREY = RGBColor(0x59, 0x59, 0x59)
WHITE = RGBColor(0xFF, 0xFF, 0xFF)
RED = RGBColor(0xC0, 0x50, 0x4D)
FONT = "Noto Sans CJK SC"

prs = Presentation()
prs.slide_width = Inches(13.333)
prs.slide_height = Inches(7.5)
BLANK = prs.slide_layouts[6]

def set_font(run, size=None, bold=None, color=None):
    f = run.font
    f.name = FONT
    rPr = run._r.get_or_add_rPr()
    ea = rPr.find('{http://schemas.openxmlformats.org/drawingml/2006/main}ea')
    if ea is None:
        ea = rPr.makeelement('{http://schemas.openxmlformats.org/drawingml/2006/main}ea', {})
        rPr.append(ea)
    ea.set('typeface', FONT)
    if size: f.size = Pt(size)
    if bold is not None: f.bold = bold
    if color is not None: f.color.rgb = color

def box(slide, x, y, w, h, fill=None, line=None, line_w=None):
    from pptx.enum.shapes import MSO_SHAPE
    sp = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, x, y, w, h)
    if fill is None:
        sp.fill.background()
    else:
        sp.fill.solid(); sp.fill.fore_color.rgb = fill
    if line is None:
        sp.line.fill.background()
    else:
        sp.line.color.rgb = line
        sp.line.width = line_w or Pt(1)
    sp.shadow.inherit = False
    return sp

def text(slide, x, y, w, h, lines, align=PP_ALIGN.LEFT, anchor=MSO_ANCHOR.TOP, wrap=True):
    tb = slide.shapes.add_textbox(x, y, w, h)
    tf = tb.text_frame
    tf.word_wrap = wrap
    tf.vertical_anchor = anchor
    first = True
    for item in lines:
        # item: (text, size, bold, color[, align]) or a plain list of segment tuples
        if isinstance(item, list):
            t, s, b, c = item, None, None, None
            al = align
        else:
            t, s, b, c = item[0], item[1], item[2], item[3]
            al = item[4] if len(item) > 4 else align
        p = tf.paragraphs[0] if first else tf.add_paragraph()
        first = False
        p.alignment = al
        for seg in (t if isinstance(t, list) else [t]):
            if isinstance(seg, tuple):
                r = p.add_run(); r.text = seg[0]
                set_font(r, seg[1] if seg[1] else s, seg[2] if seg[2] is not None else b, seg[3] if seg[3] else c)
            else:
                r = p.add_run(); r.text = seg
                set_font(r, s, b, c)
        if len(item) > 5 and item[5]:
            p.space_before = Pt(item[5])
    return tb

# (text, size, bold, color[, align]) shorthand helpers
def H(t): return (t, 30, True, DARK)
def body(t, size=14): return (t, size, False, GREY)

def header(slide, section, title, page_no):
    box(slide, 0, 0, Inches(13.333), Inches(0.16), fill=BLUE)
    box(slide, Inches(0.55), Inches(0.5), Inches(0.14), Inches(0.72), fill=BLUE)
    text(slide, Inches(0.85), Inches(0.38), Inches(9.5), Inches(1.0), [
        (section, 12, True, BLUE),
        (title, 26, True, DARK),
    ])
    text(slide, Inches(11.6), Inches(0.55), Inches(1.3), Inches(0.5),
         [("%02d" % page_no, 20, True, LIGHT)], align=PP_ALIGN.RIGHT)
    text(slide, Inches(0.55), Inches(7.08), Inches(12.2), Inches(0.32),
         [("口径说明：仅使用已给事实编制；缺数据处直接说明，未补充未知业绩。", 9, False, GREY)])

# ============ P1 封面 ============
s = prs.slides.add_slide(BLANK)
box(s, 0, 0, prs.slide_width, prs.slide_height, fill=WHITE)
box(s, 0, Inches(2.55), prs.slide_width, Inches(0.06), fill=BLUE)
box(s, Inches(5.79), Inches(3.35), Inches(1.75), Inches(0.9), fill=None, line=BLUE, line_w=Pt(2.25))
text(s, Inches(1.5), Inches(1.45), Inches(10.3), Inches(1.1),
     [("项目建设资金说明", 48, True, DARK, PP_ALIGN.CENTER)])
text(s, Inches(1.5), Inches(2.75), Inches(10.3), Inches(0.5),
     [("—— 专项资金管理会汇报", 18, False, BLUE, PP_ALIGN.CENTER)])
text(s, Inches(5.79), Inches(3.45), Inches(1.75), Inches(0.7),
     [("300", 30, True, DARK, PP_ALIGN.CENTER), ("专项预算·万元", 10, False, BLUE, PP_ALIGN.CENTER)])
text(s, Inches(1.5), Inches(4.75), Inches(10.3), Inches(0.9), [
    ("周期：6个月　|　专项预算：300万元（自筹300万元另列，不并入专项分母）", 14, False, GREY, PP_ALIGN.CENTER),
    ("2026年10月", 12, False, GREY, PP_ALIGN.CENTER, 6),
])

# ============ P2 现状·总览 ============
s = prs.slides.add_slide(BLANK)
header(s, "现状 Overview", "项目与预算总览", 2)
# 左：三个指标卡
meta = [
    ("300万元", "六个月专项预算（本汇报专项分母为300，而非600）"),
    ("300万元", "公司自筹资金，另列管理；同一费用纳入专项后不得再写自筹报销"),
    ("6个月", "月1采购、月2—5研发测试、月6报告"),
]
y = 1.55
for v, d in meta:
    box(s, Inches(0.55), Inches(y), Inches(5.9), Inches(1.28), fill=LIGHT)
    box(s, Inches(0.55), Inches(y), Inches(0.1), Inches(1.28), fill=BLUE)
    text(s, Inches(0.85), Inches(y+0.08), Inches(5.5), Inches(1.1), [
        ([(v, 20, True, DARK), ("　" + d, 11.5, False, GREY)], None, None, None),
    ], anchor=MSO_ANCHOR.MIDDLE)
    y += 1.5
# 右：科目构成条形图
text(s, Inches(6.85), Inches(1.5), Inches(6.0), Inches(0.4), [("预算科目构成（单位：万元）", 13, True, DARK)])
cd = CategoryChartData()
cd.categories = ["预备", "管理", "差旅与知识产权", "设备", "外协", "材料", "人员"]
cd.add_series("金额", (15, 10, 15, 55, 60, 55, 90))
gf = s.shapes.add_chart(XL_CHART_TYPE.BAR_CLUSTERED, Inches(6.75), Inches(1.95), Inches(6.1), Inches(4.9), cd)
ch = gf.chart
ch.has_legend = False
pl = ch.plots[0]
pl.gap_width = 60
pl.has_data_labels = True
dl = pl.data_labels
dl.number_format = '0'; dl.number_format_is_linked = False
dl.position = XL_LABEL_POSITION.OUTSIDE_END
ser = pl.series[0]
ser.format.fill.solid(); ser.format.fill.fore_color.rgb = BLUE
va = ch.value_axis
va.has_major_gridlines = False
va.maximum_scale = 100
va.tick_labels.font.size = Pt(9)
va.tick_labels.font.name = FONT
ca = ch.category_axis
ca.tick_labels.font.size = Pt(10)
ca.tick_labels.font.name = FONT
ca.format.line.color.rgb = GREY

# ============ P3 现状·预算测算构成 ============
s = prs.slides.add_slide(BLANK)
header(s, "现状 Overview", "预算测算构成（单位：万元）", 3)
rows = [
    ("科目", "金额", "测算口径"),
    ("人员", "90", "5名研发/技术岗位 × 3万元/月 × 6月（本阶段预算口径）"),
    ("材料", "55", "培养与试剂30；检测耗材18；样品物流7"),
    ("外协", "60", "6批检测/动物试验，每批10万元"),
    ("设备", "55", "发酵装置35；低温设备8；分析仪租赁12"),
    ("差旅与知识产权", "15", "差旅5；合作会议3；专利交底7"),
    ("管理", "10", "项目管理费"),
    ("预备", "15", "预备费，使用须审批"),
    ("合计", "300", "——"),
]
tbl_shape = s.shapes.add_table(len(rows), 3, Inches(0.55), Inches(1.6), Inches(12.2), Inches(5.2))
tbl = tbl_shape.table
tbl.columns[0].width = Inches(2.5)
tbl.columns[1].width = Inches(1.6)
tbl.columns[2].width = Inches(8.1)
for ri, row in enumerate(rows):
    for ci, val in enumerate(row):
        cell = tbl.cell(ri, ci)
        cell.margin_left = Inches(0.08); cell.margin_right = Inches(0.08)
        cell.margin_top = Inches(0.02); cell.margin_bottom = Inches(0.02)
        cell.vertical_anchor = MSO_ANCHOR.MIDDLE
        tf = cell.text_frame; tf.word_wrap = True
        p = tf.paragraphs[0]
        p.alignment = PP_ALIGN.CENTER if ci != 2 else PP_ALIGN.LEFT
        r = p.add_run(); r.text = val
        last = ri == len(rows) - 1
        set_font(r, 13 if not last else 14, ri == 0 or last or ci == 1, DARK if (ri == 0 or last) else GREY)
        if ri == 0:
            cell.fill.solid(); cell.fill.fore_color.rgb = DARK
            r.font.color.rgb = WHITE
        elif last:
            cell.fill.solid(); cell.fill.fore_color.rgb = LIGHT
        else:
            cell.fill.solid(); cell.fill.fore_color.rgb = WHITE if ri % 2 else LIGHT
text(s, Inches(0.55), Inches(6.85), Inches(12.2), Inches(0.35),
     [([("注：", 10, True, RED), ("以上为预算测算口径，尚无实际支付；同一费用纳入专项后不得再列自筹报销。", 10, False, GREY)])])

# ============ P4 计划·月度支付预测 ============
s = prs.slides.add_slide(BLANK)
header(s, "计划 Plan", "月度支付预测（单位：万元）", 4)
text(s, Inches(0.55), Inches(1.5), Inches(12.2), Inches(0.4),
     [([("月1至6计划支付：45、80、60、50、40、25，合计300万元。", 13, True, DARK),
        ("　这是资金计划而非已支付。", 13, True, RED)])])
cd = CategoryChartData()
cd.categories = ["月1", "月2", "月3", "月4", "月5", "月6"]
cd.add_series("计划支付", (45, 80, 60, 50, 40, 25))
gf = s.shapes.add_chart(XL_CHART_TYPE.COLUMN_CLUSTERED, Inches(0.55), Inches(2.0), Inches(7.6), Inches(4.6), cd)
ch = gf.chart
ch.has_legend = False
pl = ch.plots[0]
pl.gap_width = 80
pl.has_data_labels = True
dl = pl.data_labels
dl.number_format = '0'; dl.number_format_is_linked = False
dl.position = XL_LABEL_POSITION.OUTSIDE_END
dl.font.size = Pt(11); dl.font.name = FONT; dl.font.bold = True
ser = pl.series[0]
ser.format.fill.solid(); ser.format.fill.fore_color.rgb = BLUE
va = ch.value_axis
va.has_major_gridlines = True
va.maximum_scale = 90
va.tick_labels.font.size = Pt(9); va.tick_labels.font.name = FONT
ca = ch.category_axis
ca.tick_labels.font.size = Pt(11); ca.tick_labels.font.name = FONT
# 右侧支付规则
box(s, Inches(8.5), Inches(2.0), Inches(4.3), Inches(4.6), fill=LIGHT)
text(s, Inches(8.8), Inches(2.2), Inches(3.75), Inches(4.2), [
    ("支付与证据要求", 15, True, DARK),
    ("· 设备前期付款：需采购审批和到货/验收凭据。", 12, False, GREY, PP_ALIGN.LEFT, 10),
    ("· 外协：按里程碑记录，不因预算存在就自动授权支付。", 12, False, GREY, PP_ALIGN.LEFT, 8),
    ("· 未提供费用实际凭证，本次不展示资金执行率。", 12, True, RED, PP_ALIGN.LEFT, 8),
])

# ============ P5 计划·阶段时间安排与交付 ============
s = prs.slides.add_slide(BLANK)
header(s, "计划 Plan", "阶段时间安排与交付物", 5)
# 时间线
phases = [("月1", "采购"), ("月2—5", "研发测试"), ("月6", "报告")]
x0, wseg = 0.9, 3.6
for i, (m, name) in enumerate(phases):
    x = Inches(x0 + i * (wseg + 0.35))
    box(s, x, Inches(1.9), Inches(wseg), Inches(1.0), fill=BLUE if i != 1 else DARK)
    text(s, x, Inches(2.0), Inches(wseg), Inches(0.85), [
        (m, 16, True, WHITE, PP_ALIGN.CENTER), (name, 13, False, WHITE, PP_ALIGN.CENTER),
    ], anchor=MSO_ANCHOR.MIDDLE)
# 交付物
text(s, Inches(0.55), Inches(3.3), Inches(12.2), Inches(0.4), [("阶段产物（四项，均为计划目标，不作为已完成结果）", 15, True, DARK)])
dels = ["细胞功能验证", "两批工艺小试", "动物模型试验", "技术报告（阶段）"]
for i, d in enumerate(dels):
    x = Inches(0.55 + i * 3.12)
    box(s, x, Inches(3.85), Inches(2.9), Inches(1.0), fill=None, line=BLUE, line_w=Pt(1.5))
    text(s, x, Inches(3.95), Inches(2.9), Inches(0.8), [(d, 14, True, BLUE, PP_ALIGN.CENTER)], anchor=MSO_ANCHOR.MIDDLE)
# 交付要求
box(s, Inches(0.55), Inches(5.3), Inches(12.2), Inches(1.45), fill=LIGHT)
text(s, Inches(0.85), Inches(5.45), Inches(11.6), Inches(1.2), [
    ("交付验收要求", 14, True, DARK),
    ("每项交付都要有批记录、方法和数据引用；六个月阶段只覆盖上述四项，商业生产或临床审批不在此范围。", 12.5, False, GREY),
])

# ============ P6 问题与风险·管理机制 ============
s = prs.slides.add_slide(BLANK)
header(s, "问题与风险 Risks", "管理机制与风险控制", 6)
# 三栏
box(s, Inches(0.55), Inches(1.6), Inches(3.9), Inches(3.3), fill=LIGHT)
text(s, Inches(0.85), Inches(1.78), Inches(3.35), Inches(3.0), [
    ("职责分工", 15, True, DARK),
    ("· 项目负责人：技术进度", 12.5, False, GREY, PP_ALIGN.LEFT, 8),
    ("· 采购：设备/耗材", 12.5, False, GREY, PP_ALIGN.LEFT, 6),
    ("· 财务：核金额单位和凭据", 12.5, False, GREY, PP_ALIGN.LEFT, 6),
])
box(s, Inches(4.7), Inches(1.6), Inches(3.9), Inches(3.3), fill=LIGHT)
text(s, Inches(5.0), Inches(1.78), Inches(3.35), Inches(3.0), [
    ("管理节点", 15, True, DARK),
    ("· 第3月：中期复核", 12.5, False, GREY, PP_ALIGN.LEFT, 8),
    ("· 第6月：阶段验收", 12.5, False, GREY, PP_ALIGN.LEFT, 6),
    ("· 试验不达标、外协迟交或设备延期，均如实记录", 12.5, False, GREY, PP_ALIGN.LEFT, 6),
])
box(s, Inches(8.85), Inches(1.6), Inches(3.9), Inches(3.3), fill=LIGHT)
text(s, Inches(9.15), Inches(1.78), Inches(3.35), Inches(3.0), [
    ("风险与预备费", 15, True, DARK),
    ("· 试验不达标：记录并复核", 12.5, False, GREY, PP_ALIGN.LEFT, 8),
    ("· 外协迟交：按里程碑记录", 12.5, False, GREY, PP_ALIGN.LEFT, 6),
    ("· 预备费使用须审批", 12.5, True, RED, PP_ALIGN.LEFT, 6),
])
# 底部声明
box(s, Inches(0.55), Inches(5.25), Inches(12.2), Inches(1.3), fill=None, line=RED, line_w=Pt(1.5))
text(s, Inches(0.85), Inches(5.4), Inches(11.6), Inches(1.0), [
    ("合规声明", 14, True, RED),
    ("不得为了让预算均匀而篡改已确定报价，或隐瞒研发风险。", 13, False, DARK),
])

# ============ P7 限制与边界·要点回顾 ============
s = prs.slides.add_slide(BLANK)
header(s, "限制与边界 Scope", "汇报边界与请审议事项", 7)
items = [
    ("分母口径", "本汇报专项分母为300万元而非600万元；自筹300万元另列管理，同一费用纳入专项后不得再写自筹报销。"),
    ("支付口径", "月度支付预测为资金计划而非已支付；未提供费用实际凭证，不展示资金执行率。"),
    ("阶段边界", "六个月阶段只覆盖细胞功能验证、两批工艺小试、动物模型试验与技术报告；商业生产或临床审批不在此范围。"),
    ("结果状态", "各项目标均为计划状态，尚未完成；每项交付须凭批记录、方法和数据引用验收，不把目标当已完成结果。"),
]
y = 1.6
for t, d in items:
    box(s, Inches(0.55), Inches(y), Inches(12.2), Inches(1.05), fill=LIGHT)
    box(s, Inches(0.55), Inches(y), Inches(1.9), Inches(1.05), fill=BLUE)
    text(s, Inches(0.55), Inches(y), Inches(1.9), Inches(1.05),
         [(t, 14, True, WHITE, PP_ALIGN.CENTER)], anchor=MSO_ANCHOR.MIDDLE)
    text(s, Inches(2.65), Inches(y), Inches(9.9), Inches(1.05),
         [(d, 12.5, False, DARK)], anchor=MSO_ANCHOR.MIDDLE)
    y += 1.25
text(s, Inches(0.55), Inches(6.65), Inches(12.2), Inches(0.45),
     [("以上说明请专项资金管理会审议。", 15, True, DARK, PP_ALIGN.CENTER)])

prs.save("/workspace/outputs/项目建设资金说明.pptx")
print("saved pptx")
