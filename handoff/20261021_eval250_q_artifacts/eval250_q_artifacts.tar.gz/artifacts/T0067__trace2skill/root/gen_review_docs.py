# -*- coding: utf-8 -*-
"""生成 芯片试制项目评分表.xlsx 与 芯片试制项目意见表.docx
分数全部锚定 /workspace/inputs/项目事实.md 的给定事实或明确缺失。"""
import os
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, Border, Side, PatternFill
from docx import Document
from docx.shared import Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn

OUT = "/workspace/outputs"
os.makedirs(OUT, exist_ok=True)

# ---------------- 评分数据（逐项证据锚定，未给证明不当作实证） ----------------
PROJECT = "园区设备PLC-IoT芯片试制项目"
items = [
    ("问题/目标清晰度", 16,
     "拟开发对象明确（园区设备PLC-IoT芯片），计划9个月完成MPW样片，路径清晰；功耗0.3瓦仅为设计目标、非实测，量化验收指标（如性能、接口、良率）未给出，酌情扣分。"),
    ("技术/交付证据", 10,
     "已有证据：FPGA验证通过3场景（可追溯的实测类证据）。缺口：芯片未流片，无样片；0.3瓦功耗无实测数据；无第三方测试或鉴定报告；3个FPGA场景的覆盖度与芯片级验证差距未说明。"),
    ("计划可执行性", 10,
     "有9个月完成MPW样片的总体计划节点。缺口：缺少里程碑分解（设计/仿真/流片/封装/测试排期）、责任分工与资源到位计划；流片档期与代工厂安排未见材料。"),
    ("预算可追溯性", 14,
     "预算150万元且分项自洽：流片80+EDA15+测试20+人员35=150，各分项用途清楚。缺口：缺供应商报价单/EDA授权依据/人力测算等支撑材料，分项仅有总额无数测算。"),
    ("风险与边界披露", 15,
     "材料如实披露关键边界：芯片未流片、功耗为设计目标非实测、客户仅为意向未签销售合同，且声明资料以本次评审可用事实为准，披露态度良好。缺口：未列技术风险（流片失败、良率）、供应链与资金风险清单，缺应对预案。"),
]
total = sum(s for _, s, _ in items)
assert total == sum(s for _, s, _ in items)

supplements = [
    "芯片级验证计划与FPGA 3场景的覆盖度说明（对应技术/交付证据）",
    "功耗与关键性能指标的实测/仿真数据及第三方测试安排（对应技术/交付证据）",
    "9个月里程碑分解表：设计、仿真、流片、封装、测试排期与责任分工（对应计划可执行性）",
    "流片代工厂报价单/档期确认、EDA授权清单及人力成本测算（对应预算可追溯性）",
    "风险清单与应对预案：技术、供应链、资金、市场（对应风险与边界披露）",
    "客户意向书的书面文件及后续销售合同签署计划（当前仅2家意向、未签合同，不得计为在手订单）",
]

# ---------------- 生成评分表 xlsx ----------------
wb = Workbook()
ws = wb.active
ws.title = "评分表"

thin = Side(style="thin", color="999999")
border = Border(left=thin, right=thin, top=thin, bottom=thin)
head_fill = PatternFill("solid", fgColor="1F4E79")
head_font = Font(name="Noto Sans CJK SC", bold=True, color="FFFFFF", size=11)
body_font = Font(name="Noto Sans CJK SC", size=11)
center = Alignment(horizontal="center", vertical="center", wrap_text=True)
left = Alignment(horizontal="left", vertical="center", wrap_text=True)

ws.merge_cells("A1:C1")
c = ws["A1"]; c.value = "芯片试制项目材料成熟度评分表（内部评审）"
c.font = Font(name="Noto Sans CJK SC", bold=True, size=14)
c.alignment = center
ws.row_dimensions[1].height = 28

r = 2
ws.cell(r, 1, "项目名称").font = head_font
ws.merge_cells(start_row=r, start_column=2, end_row=r, end_column=3)
ws.cell(r, 2, PROJECT).font = body_font
for col in range(1, 4):
    ws.cell(r, col).border = border
    ws.cell(r, col).fill = head_fill if col == 1 else PatternFill("solid", fgColor="FFFFFF")
    ws.cell(r, col).alignment = left
ws.cell(r, 2).alignment = left
r += 1

ws.cell(r, 1, "评分项").font = head_font
ws.cell(r, 2, "分数（0—20）").font = head_font
ws.cell(r, 3, "评分依据（事实锚定）").font = head_font
for col in range(1, 4):
    ws.cell(r, col).fill = head_fill
    ws.cell(r, col).border = border
    ws.cell(r, col).alignment = center
r += 1

for name, score, basis in items:
    ws.cell(r, 1, name).font = body_font
    ws.cell(r, 2, score).font = body_font
    ws.cell(r, 3, basis).font = body_font
    for col in range(1, 4):
        ws.cell(r, col).border = border
        ws.cell(r, col).alignment = center if col == 2 else left
    ws.row_dimensions[r].height = 64
    r += 1

ws.cell(r, 1, "总分").font = Font(name="Noto Sans CJK SC", bold=True, size=11)
ws.cell(r, 2, total).font = Font(name="Noto Sans CJK SC", bold=True, size=11)
ws.cell(r, 3, f"五项合计校验：{' + '.join(str(s) for _, s, _ in items)} = {total} / 100").font = body_font
for col in range(1, 4):
    ws.cell(r, col).border = border
    ws.cell(r, col).fill = PatternFill("solid", fgColor="DDEBF7")
    ws.cell(r, col).alignment = center if col == 2 else left
r += 1

ws.cell(r, 1, "需要补充材料").font = head_font
ws.merge_cells(start_row=r, start_column=2, end_row=r, end_column=3)
ws.cell(r, 2, "\n".join(f"{i+1}. {s}" for i, s in enumerate(supplements))).font = body_font
ws.cell(r, 2).alignment = Alignment(horizontal="left", vertical="top", wrap_text=True)
ws.cell(r, 1).fill = head_fill
ws.cell(r, 1).alignment = center
for col in range(1, 4):
    ws.cell(r, col).border = border
ws.row_dimensions[r].height = 150
r += 1

ws.cell(r, 1, "说明").font = head_font
ws.merge_cells(start_row=r, start_column=2, end_row=r, end_column=3)
ws.cell(r, 2, "本评分仅反映内部材料成熟度，不代表技术成功概率或立项批准结果。分数全部锚定《项目事实》给定内容：未给证明的声称（如功耗0.3瓦、客户意向）均未按已实现/已签约计。缺失证据在“评分依据”中逐项说明，未人为凑分。").font = body_font
ws.cell(r, 2).alignment = Alignment(horizontal="left", vertical="top", wrap_text=True)
ws.cell(r, 1).fill = head_fill
ws.cell(r, 1).alignment = center
for col in range(1, 4):
    ws.cell(r, col).border = border
ws.row_dimensions[r].height = 60

ws.column_dimensions["A"].width = 18
ws.column_dimensions["B"].width = 14
ws.column_dimensions["C"].width = 80
ws.freeze_panes = "A3"

xlsx_path = os.path.join(OUT, "芯片试制项目评分表.xlsx")
wb.save(xlsx_path)
print("saved", xlsx_path)

# ---------------- 生成意见表 docx ----------------
doc = Document()
style = doc.styles["Normal"]
style.font.name = "Noto Sans CJK SC"
style.font.size = Pt(11)
style.element.rPr.rFonts.set(qn("w:eastAsia"), "Noto Sans CJK SC")
for section in doc.sections:
    section.top_margin = Cm(2.2)
    section.bottom_margin = Cm(2.2)
    section.left_margin = Cm(2.4)
    section.right_margin = Cm(2.4)

t = doc.add_paragraph()
t.alignment = WD_ALIGN_PARAGRAPH.CENTER
t.run = None
run = t.add_run("芯片试制项目评审意见表")
run.bold = True
run.font.size = Pt(16)

sub = doc.add_paragraph()
sub.alignment = WD_ALIGN_PARAGRAPH.CENTER
r2 = sub.add_run("（内部材料成熟度评审，不构成立项批准结论）")
r2.font.size = Pt(10)
r2.font.color.rgb = RGBColor(0x59, 0x59, 0x59)

table = doc.add_table(rows=0, cols=2)
table.style = "Table Grid"
table.alignment = WD_TABLE_ALIGNMENT.CENTER

def add_row(label, content, bold_label=True):
    row = table.add_row()
    c0, c1 = row.cells
    c0.width = Cm(3.2)
    c1.width = Cm(12.8)
    p0 = c0.paragraphs[0]
    rr = p0.add_run(label)
    rr.bold = bold_label
    p0.alignment = WD_ALIGN_PARAGRAPH.CENTER
    # 内容支持多段
    for i, seg in enumerate(content if isinstance(content, list) else [content]):
        p = c1.paragraphs[0] if i == 0 else c1.add_paragraph()
        p.add_run(seg).font.size = Pt(10.5)
    return row

add_row("审查日期", "2026-10-1")
add_row("项目概况", [
    "拟开发园区设备PLC-IoT芯片，当前处于FPGA原型验证阶段：已通过3个场景验证，芯片尚未流片。",
    "计划9个月完成MPW样片；功耗0.3瓦为设计目标，非实测数据。",
    "项目预算150万元人民币：流片80万、EDA 15万、测试20万、人员35万（分项合计与总额一致）。",
    "已有2家合作客户表示采购意向，尚未签署销售合同。",
])
add_row("主要优点", [
    "目标对象与产品方向明确：面向园区设备的PLC-IoT芯片。",
    "已有可追溯的技术证据：FPGA验证通过3个场景。",
    "计划有明确节点：9个月完成MPW样片。",
    "预算分项清晰且自洽（80+15+20+35=150万元），可追溯性较好。",
    "边界披露诚实：如实说明未流片、功耗为设计目标非实测、客户未签约。",
])
add_row("关键缺口", [
    "芯片级证据不足：未流片、无样片，无功耗/性能实测数据，无第三方测试报告。",
    "计划缺里程碑分解：设计、仿真、流片、封装、测试的排期与责任分工未见材料。",
    "预算缺支撑依据：无代工厂报价、EDA授权清单、人力测算等佐证。",
    "风险披露不完整：缺技术（流片失败、良率）、供应链、资金风险清单与预案。",
    "市场证据薄弱：客户仅为意向，无书面意向文件或合同，不得计为在手订单。",
])
add_row("建议行动", [
    "补充FPGA 3场景的覆盖度说明与芯片级验证计划（对应流片前仿真、DFT安排）。",
    "补充9个月里程碑分解表：明确各阶段交付物、责任人及流片档期。",
    "收集流片代工厂报价与档期确认、EDA授权清单、人员成本测算，作为预算附件。",
    "建立风险清单与应对预案（技术、供应链、资金、市场），纳入下次评审材料。",
    "取得客户书面意向文件并明确合同签署计划；在合同签署前，相关收入不得作为确定性依据。",
    "功耗0.3瓦在设计定稿后安排实测并留档；无实测数据前，对外表述须保持“设计目标”口径。",
])

note = doc.add_paragraph()
note.paragraph_format.space_before = Pt(8)
rn = note.add_run("说明：本意见表依据《项目事实》与《评审规则》出具，评分仅反映内部材料成熟度，不代表技术成功概率或政府/立项批准结果；未检索企业外部私人资料，缺失内容已留作需补材料。")
rn.font.size = Pt(9)
rn.font.color.rgb = RGBColor(0x59, 0x59, 0x59)

docx_path = os.path.join(OUT, "芯片试制项目意见表.docx")
doc.save(docx_path)
print("saved", docx_path)
