# -*- coding: utf-8 -*-
"""按 inputs/ranking_rules.md 生成 project_ranking.xlsx 与 review_questions.docx"""
import csv
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
from docx import Document
from docx.shared import Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH

# ---------- 读取数据 ----------
projects = []
with open('/workspace/inputs/project_evidence.csv', encoding='utf-8-sig') as f:
    for row in csv.DictReader(f):
        projects.append({
            'id': row['ID'],
            'name': row['项目'],
            'tech': int(row['技术证据计数']),
            'cust': int(row['客户证据计数']),
            'cost': int(row['成本明确度']),
            'team': int(row['团队投入']),
            'owner': int(row['权属清晰度']),
            'pack': row['证据包'],
        })

dims = [('tech', '技术证据计数'), ('cust', '客户证据计数'), ('cost', '成本明确度'),
        ('team', '团队投入'), ('owner', '权属清晰度')]

# ---------- 各维排名：降序，平局按ID字典序，1-9各一次 ----------
for key, _ in dims:
    ordered = sorted(projects, key=lambda p: (-p[key], p['id']))
    for i, p in enumerate(ordered, 1):
        p['rank_' + key] = i

for p in projects:
    p['avg'] = sum(p['rank_' + k] for k, _ in dims) / len(dims)

# 综合名次：平均名次升序，平局按ID字典序
comp = sorted(projects, key=lambda p: (p['avg'], p['id']))
for i, p in enumerate(comp, 1):
    p['rank_comp'] = i

# ---------- 校验：每维1-9各用一次 ----------
for key, label in dims:
    ranks = sorted(p['rank_' + key] for p in projects)
    assert ranks == list(range(1, 10)), f'{label} 排名不满足1-9各一次'
avg_set = set(p['avg'] for p in projects)
assert len([p['rank_comp'] for p in projects]) == 9

# ---------- 生成 project_ranking.xlsx ----------
wb = Workbook()
ws = wb.active
ws.title = '维度排名与综合名次'

thin = Side(style='thin', color='999999')
border = Border(left=thin, right=thin, top=thin, bottom=thin)
header_fill = PatternFill('solid', fgColor='DDEBF7')

title_font = Font(bold=True, size=13)
ws['A1'] = '九个项目五维证据排名与综合平均名次（1=最优；名次为序数，不是1-9质量分）'
ws['A1'].font = title_font
ws.merge_cells('A1:I1')

headers = ['ID', '项目', '证据包'] + [label for _, label in dims] + ['综合平均名次', '综合名次']
ws.append([])
ws.append(headers)
hrow = ws.max_row
for c in range(1, len(headers) + 1):
    cell = ws.cell(row=hrow, column=c)
    cell.font = Font(bold=True)
    cell.fill = header_fill
    cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
    cell.border = border

by_id = sorted(projects, key=lambda p: p['id'])
for p in by_id:
    ws.append([p['id'], p['name'], p['pack'],
               p['rank_tech'], p['rank_cust'], p['rank_cost'],
               p['rank_team'], p['rank_owner'],
               p['avg'], p['rank_comp']])
    r = ws.max_row
    for c in range(1, len(headers) + 1):
        cell = ws.cell(row=r, column=c)
        cell.border = border
        if c >= 4:
            cell.alignment = Alignment(horizontal='center')
            if c == 9:
                cell.number_format = '0.0'

# 综合名次排序表
start = ws.max_row + 2
ws.cell(row=start, column=1, value='综合名次排序（平均名次升序；平局按ID字典序）').font = Font(bold=True, size=12)
ws.cell(row=start + 1, column=1, value='综合名次').font = Font(bold=True)
ws.cell(row=start + 1, column=2, value='ID').font = Font(bold=True)
ws.cell(row=start + 1, column=3, value='项目').font = Font(bold=True)
ws.cell(row=start + 1, column=4, value='综合平均名次').font = Font(bold=True)
for i, p in enumerate(comp):
    r = start + 2 + i
    ws.cell(row=r, column=1, value=p['rank_comp']).alignment = Alignment(horizontal='center')
    ws.cell(row=r, column=2, value=p['id']).alignment = Alignment(horizontal='center')
    ws.cell(row=r, column=3, value=p['name'])
    c4 = ws.cell(row=r, column=4, value=p['avg'])
    c4.number_format = '0.0'
    c4.alignment = Alignment(horizontal='center')

# 原始数值表
start2 = ws.max_row + 2
ws.cell(row=start2, column=1, value='原始数值（数值越高证据越充分，仅用于本题评审）').font = Font(bold=True, size=12)
ws.cell(row=start2 + 1, column=1, value='ID').font = Font(bold=True)
for j, (_, label) in enumerate(dims):
    ws.cell(row=start2 + 1, column=2 + j, value=label).font = Font(bold=True)
for p in by_id:
    r = start2 + 2 + by_id.index(p)
    ws.cell(row=r, column=1, value=p['id']).alignment = Alignment(horizontal='center')
    for j, (k, _) in enumerate(dims):
        ws.cell(row=r, column=2 + j, value=p[k]).alignment = Alignment(horizontal='center')

# 说明sheet
ws2 = wb.create_sheet('排序规则说明')
notes = [
    '排序规则说明（依据 inputs/ranking_rules.md）：',
    '1. 五维数值越高代表证据越充分，仅用于本题评审，不构成投资结论。',
    '2. 各维度分别按数值降序排名，平局按ID字典序；每个维度名次1-9各用一次，不并列。',
    '3. 综合名次按五维平均名次升序排列，平均名次越低越优；平局按ID字典序（P2与P5平均名次均为4.2，P2在前）。',
    '4. 名次为序数排名，不是1-9质量分；相邻名次差距不表示质量差距大小。',
    '5. 项目E1-E9材料均为申报人自报，未经独立验证，不能称为已审计；评审需以独立验证为前提。',
    '6. 数据来源：inputs/project_evidence.csv（数值）、inputs/project_details.md（自报概要）。',
]
for i, t in enumerate(notes, 1):
    cell = ws2.cell(row=i, column=1, value=t)
    if i == 1:
        cell.font = Font(bold=True)
ws2.column_dimensions['A'].width = 110

for col, w in zip('ABCDEFGHIJK', [6, 14, 8, 13, 13, 12, 11, 12, 13, 10]):
    ws.column_dimensions[col].width = w

wb.save('/workspace/outputs/project_ranking.xlsx')

# ---------- 生成 review_questions.docx ----------
details = {
    'P1': ('水质微测：8分钟检测，误差样本仅饮用水，未测高浊度；原型成本3.6万元，需工厂授权样本。',
           ['误差样本仅覆盖饮用水，高浊度水体未测，适用范围证据不足',
            '8分钟检测时长缺乏与标准方法比对的一致性数据',
            '原型成本3.6万元无量产成本或书面报价支撑',
            '检测流程依赖需工厂授权的样本，独立复测渠道受限',
            '缺乏第三方实验室比对结果']),
    'P2': ('管廊巡检：2台轮式样机，地下无线网络不稳定，拟验证断网缓存；无防爆认证。',
           ['断网缓存方案仅为“拟验证”，尚无实测数据',
            '地下无线网络不稳定的实际工况性能未量化',
            '无防爆认证，可进入的管廊类型范围不明',
            '2台样机是否在真实管廊完成连续运行无记录',
            '巡检缺陷检出率/漏检率无第三方或客户确认数据']),
    'P3': ('视觉缺陷：电子工件32批图像，标签由1工程师给出，标注一致性未知；需要独立盲样。',
           ['缺陷标签仅由1名工程师给出，标注一致性未知',
            '未做独立盲样测试，模型检出能力不可外部核验',
            '32批图像的批次覆盖度与产线实际缺陷分布匹配性未说明',
            '误报/漏报率的口径与阈值设定未披露',
            '不同产线、光照与工件型号的泛化性未验证']),
    'P4': ('荧光识别：实验室小样识别94%，不同光源未测试，设备维护方案缺失。',
           ['94%识别率来自实验室小样，现场工况证据不足',
            '不同光源条件未测试，环境适应性不明',
            '设备维护方案缺失，长期可用性无支撑',
            '94%的统计口径（样本量、置信区间）未披露',
            '荧光试剂/耗材的稳定性与更换周期未说明']),
    'P5': ('低温膜：隔热膜通过3月小样验证，批间一致性待测，技术授权高校非排他。',
           ['验证仅为3个月小样，长期老化与耐候数据不足',
            '批间一致性待测，量产质量稳定性未知',
            '技术授权高校为非排他，权属与独家性存在风险',
            '小样与实际应用面积/工况的放大效应未验证',
            '隔热性能测试方法与标准符合性未说明']),
    'P6': ('电池诊断：10块旧电池，模型依赖同批数据；拟找第二厂验证，不自动控制充放电。',
           ['样本仅10块旧电池且模型依赖同批数据，泛化性证据不足',
            '第二厂家验证仍停留在“拟找”阶段，未完成',
            '不自动控制充放电，功能边界与诊断闭环价值需厘清',
            '诊断准确率缺乏跨批次、跨厂家对照数据',
            '电池老化机理假设与失效样本覆盖度未披露']),
    'P7': ('声学定位：两间空室验证，工业噪声与多人移动没测；采样设备成本尚无书面报价。',
           ['验证仅在两间空室进行，工业噪声与多人移动场景未测',
            '采样设备成本无书面报价，成本明确度证据不足',
            '定位精度指标在不同声学环境下的表现未量化',
            '空室与实际工业现场（设备、遮挡、混响）的差异未评估',
            '多人移动同时定位的并发能力与误定位率未验证']),
    'P8': ('机械柔抓：可抓三种零件，碰撞安全须验证；维护需要熟练工程师，客户只有意向。',
           ['碰撞安全仅“须验证”，尚无安全测试报告',
            '客户仅有意向，无订单或现场试用记录',
            '维护依赖熟练工程师，运维成本与可及性证据不足',
            '可抓三种零件之外的工件扩展性未验证',
            '抓取成功率与节拍在实际产线工况下无实测数据']),
    'P9': ('工艺知识：已有5厂试用，答案引用可追溯，错误操作建议需人工核查；权属为公司软件。',
           ['错误操作建议需人工核查，可靠性保障机制证据不足',
            '5厂试用的试用深度、时长与效果评价缺乏独立记录',
            '答案引用可追溯的抽查核验结果未公开',
            '权属为公司软件，与高校/合作方知识产权边界未说明',
            '知识库更新机制与工艺知识时效性维护方案未说明']),
}

doc = Document()
style = doc.styles['Normal']
style.font.name = 'Noto Sans CJK SC'
style.font.size = Pt(10.5)
from docx.oxml.ns import qn
style.element.rPr.rFonts.set(qn('w:eastAsia'), 'Noto Sans CJK SC')

# 首页说明
t = doc.add_paragraph()
t.alignment = WD_ALIGN_PARAGRAPH.CENTER
r = t.add_run('九个项目评审提问清单')
r.font.size = Pt(16)
r.font.bold = True
note = doc.add_paragraph(
    '说明：E1-E9各项目材料均为申报人自报，未经独立验证，不能称为已审计。'
    '本清单逐项目列出证据不足事项与5个针对性提问，供评审访谈使用。'
    '排名（见project_ranking.xlsx）为序数名次，不是1-9质量分，也不构成投资结论。'
    '提问均针对各项目自报概要中的具体场景与缺口。')
note.runs[0].font.size = Pt(9)
doc.add_page_break()

for pid in sorted(details):
    p = next(x for x in projects if x['id'] == pid)
    h = doc.add_paragraph()
    rr = h.add_run(f"{pid} {p['name']}（证据包 {p['pack']}）")
    rr.font.size = Pt(14)
    rr.font.bold = True
    summary = doc.add_paragraph()
    rs = summary.add_run('自报概要：' + details[pid][0])
    rs.font.size = Pt(9)
    rs.font.color.rgb = RGBColor(0x55, 0x55, 0x55)

    doc.add_paragraph().add_run('证据不足事项').bold = True
    for item in details[pid][1]:
        doc.add_paragraph('• ' + item, style='List Bullet')

    doc.add_paragraph().add_run('评审提问（5项）').bold = True
    for i, q in enumerate(details[pid][1], 1):
        doc.add_paragraph(f'问题{i}：{q}')

    if pid != 'P9':
        doc.add_page_break()

doc.save('/workspace/outputs/review_questions.docx')

# ---------- 校验输出 ----------
print('综合名次：')
for p in comp:
    print(f"  {p['rank_comp']}. {p['id']} {p['name']} avg={p['avg']:.1f}")
print('xlsx/docx 已生成')
