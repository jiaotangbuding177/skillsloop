# -*- coding: utf-8 -*-
import csv, json
from docx import Document
from docx.shared import Pt
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, PatternFill

# ---- load inputs ----
limits = json.load(open('/workspace/inputs/site_limits.json', encoding='utf-8'))
rows = list(csv.DictReader(open('/workspace/inputs/participants.csv', encoding='utf-8-sig')))
ids = [(r['ID'], r['部门'], r['轮椅通行需要']) for r in rows]
assert len(ids) == limits['participants'] == 80

# ---- 4 groups of 20, round-robin by ID, then swap so the two wheelchair users are in different groups ----
groups = {'A': [], 'B': [], 'C': [], 'D': []}
order = ['A', 'B', 'C', 'D']
for i, rec in enumerate(ids):
    groups[order[(i + i // 4) % 4]].append(rec)

def find(pid):
    for g, mem in groups.items():
        for i, m in enumerate(mem):
            if m[0] == pid:
                return g, i
    return None, None

# V17 is in A, V33 also lands in A (17%4=1, 33%4=1): move V33 to group C by swapping with V35 (C)
ga, ia = find('V33')
gc, ic = find('V35')
if ga == gc:
    gc, ic = find('V37')
groups[ga][ia], groups[gc][ic] = groups[gc][ic], groups[ga][ia]

wheelchair = [r for r in ids if r[2] == '是']
wg = {find(r[0])[0] for r in wheelchair}
assert len(wg) == len(wheelchair), 'wheelchair users should be in different groups'

staff = {'A': '工作人员1（组长）', 'B': '工作人员2', 'C': '工作人员3', 'D': '工作人员4'}

# ---- schedule ----
# 13:00-13:15 safety briefing (all 80); then 4 rotation slots of 35min + 10min transfer
date = limits['date']
slots = [
    ('第1轮', '13:25', '14:00'),
    ('第2轮', '14:10', '14:45'),
    ('第3轮', '14:55', '15:30'),
    ('第4轮', '15:40', '16:15'),
]
# each slot: one group in factory, other three in classroom (case study + break rotation)
factory_order = ['A', 'B', 'C', 'D']

def classroom_plan(slot_i, g):
    """for a group in classroom at slot_i: 25min case session + 10min break; lead group rotates"""
    leads = ['B', 'C', 'D', 'A']
    lead = leads[slot_i]
    role = '案例主持（带案例分享）' if g == lead else '课堂案例学习 + 讨论'
    return role

timetable = []
timetable.append((date, '13:00', '13:15', '全体', '安全须知宣讲（15分钟，全员必到）', '集合区（可容纳80人）',
                  '宣读禁止摄影规定：全程不安排任何摄影、拍照，手机拍摄请关闭'))
for i, (name, t1, t2) in enumerate(slots):
    fg = factory_order[i]
    timetable.append((date, t1, t2, f'{fg}组（20人）', '产线参观（35分钟，工厂限20人，分批进入）', '工厂产线',
                      '随组工作人员1名全程陪同；A组V17/C组V33走无障碍通道'))
    others = [g for g in factory_order if g != fg]
    lead = ['B', 'C', 'D', 'A'][i]
    timetable.append((date, t1, t2, '、'.join(others) + '组（共60人）',
                      f'课堂案例（25分钟，主持：{lead}组）+ 课间休息（10分钟）；教室容量60人',
                      '教室', '案例材料现场纸质发放，不拍摄投影'))
    if i < len(slots) - 1:
        timetable.append((date, t2, slots[i+1][1], '全体', '转场（10分钟）', '工厂/教室之间', '工作人员在各通道口引导'))
timetable.append((date, '16:15', '16:30', '全体', '总结与集合解散（15分钟）', '集合区',
                  '确认无遗漏人员，再次提醒无摄影安排'))

# ---- site_visit.docx ----
doc = Document()
doc.add_heading('研学参观安排（site_visit）', level=0)
p = doc.add_paragraph()
p.add_run(f"日期：{date}　时间窗口：13:00–16:30　总人数：80人（分4组，每组20人）").bold = True
doc.add_paragraph('依据：site_limits.json（工厂单次上限20人、教室容量60人、安全宣讲15分钟、全程不安排摄影）与 participants.csv（含轮椅通行需要名单）。')

doc.add_heading('一、总体安排', level=1)
doc.add_paragraph('• 80人分为 A/B/C/D 四组，每组20人，各组混合四个部门，配1名工作人员（共4名）。')
doc.add_paragraph('• 每轮仅1组（20人）进入工厂，满足工厂20人上限；其余3组（60人）在教室，满足教室60人容量。')
doc.add_paragraph('• 每组产线参观1次（35分钟）；教室环节为课堂案例25分钟+课间休息10分钟，主持组轮换。')
doc.add_paragraph('• 轮次间10分钟转场，由工作人员在通道口引导。')
doc.add_paragraph('• 摄影规定：全程不安排任何摄影（photo_allowed=false），安全宣讲时向全员宣布，案例材料使用纸质发放，不拍摄投影。')
doc.add_paragraph('• 无障碍：V17（A组）与V33（C组）需轮椅通行，已分入不同组，工厂参观走无障碍通道，工作人员优先协助。')

doc.add_heading('二、时间表', level=1)
tbl = doc.add_table(rows=1, cols=7)
tbl.style = 'Light Grid Accent 1'
hdr = tbl.rows[0].cells
for j, h in enumerate(['日期', '开始', '结束', '对象', '活动', '地点', '说明']):
    hdr[j].text = h
for t in timetable:
    cells = tbl.add_row().cells
    for j, v in enumerate(t):
        cells[j].text = str(v)
for row in tbl.rows:
    for c in row.cells:
        for para in c.paragraphs:
            for run in para.runs:
                run.font.size = Pt(9)

doc.add_heading('三、分组与轮换一览', level=1)
t2 = doc.add_table(rows=1, cols=6)
t2.style = 'Light Grid Accent 1'
for j, h in enumerate(['轮次', '时间', '进厂组（20人）', '教室案例组（60人）', '课堂主持组', '休息安排']):
    t2.rows[0].cells[j].text = h
for i, (name, t1, t2_) in enumerate(slots):
    fg = factory_order[i]
    others = [g for g in factory_order if g != fg]
    lead = ['B', 'C', 'D', 'A'][i]
    cells = t2.add_row().cells
    vals = [name, f'{t1}–{t2_}', fg, '、'.join(others), lead, '教室环节内含10分钟课间休息']
    for j, v in enumerate(vals):
        cells[j].text = str(v)

doc.add_heading('四、注意事项', level=1)
doc.add_paragraph('1. 安全宣讲（13:00–13:15）为强制环节，未参加者不得进入工厂。')
doc.add_paragraph('2. 工厂参观严格按20人一批，不得超员；参观时长35分钟，不得滞留。')
doc.add_paragraph('3. 全程禁止摄影、录像；工作人员负责提醒与巡查。')
doc.add_paragraph('4. 轮椅通行人员所在组（A组：V17；C组：V33）参观路线使用无障碍通道，工作人员随行。')
doc.add_paragraph('5. 如有人员临时缺席，保持每组不超过20人，剩余名额不补人进入工厂。')

doc.save('/workspace/outputs/site_visit.docx')

# ---- visit_groups.xlsx ----
wb = Workbook()
ws = wb.active
ws.title = '分组表'
headers = ['组别', '序号', 'ID', '部门', '轮椅通行需要', '随组工作人员', '进厂轮次', '进厂时间', '备注']
ws.append(headers)
for g in factory_order:
    slot_i = factory_order.index(g)
    name, t1, t2_ = slots[slot_i]
    for i, (pid, dept, wc) in enumerate(sorted(groups[g], key=lambda m: m[0]), 1):
        note = '轮椅通行：工厂参观走无障碍通道，工作人员随行' if wc == '是' else ''
        ws.append([g, i, pid, dept, wc, staff[g], name, f'{t1}–{t2_}', note])

thin = Font(bold=True, color='FFFFFF')
fill = PatternFill('solid', fgColor='4472C4')
for cell in ws[1]:
    cell.font = thin
    cell.fill = fill
    cell.alignment = Alignment(horizontal='center')
widths = [8, 6, 8, 10, 12, 14, 10, 14, 40]
for i, w in enumerate(widths, 1):
    ws.column_dimensions[chr(64 + i)].width = w
for g in factory_order:
    start = 2 + factory_order.index(g) * 20
    ws.merge_cells(start_row=start, start_column=1, end_row=start + 19, end_column=1)
ws.freeze_panes = 'A2'

# summary sheet
ws2 = wb.create_sheet('轮换总表')
ws2.append(['轮次', '时间', '进厂组（20人）', '教室案例组（60人）', '课堂主持组', '说明'])
for i, (name, t1, t2_) in enumerate(slots):
    fg = factory_order[i]
    others = [g for g in factory_order if g != fg]
    lead = ['B', 'C', 'D', 'A'][i]
    ws2.append([name, f'{t1}–{t2_}', fg, '、'.join(others), lead,
                '工厂20人上限；教室60人容量；含25分钟案例+10分钟休息'])
ws2.append(['安全宣讲', '13:00–13:15', '全体80人', '—', '—', '强制环节；宣布全程禁止摄影'])
ws2.append(['总结解散', '16:15–16:30', '全体80人', '—', '—', '清点人数'])
for cell in ws2[1]:
    cell.font = thin
    cell.fill = fill
for i, w in enumerate([12, 14, 16, 20, 12, 44], 1):
    ws2.column_dimensions[chr(64 + i)].width = w

wb.save('/workspace/outputs/visit_groups.xlsx')

# ---- verification ----
print('wheelchair users:', [(r[0], find(r[0])[0]) for r in wheelchair])
for g in factory_order:
    mem = groups[g]
    depts = {}
    for _, d, _ in mem:
        depts[d] = depts.get(d, 0) + 1
    assert len(mem) == 20
    print(g, 'n=20', depts, 'staff:', staff[g], 'factory:', slots[factory_order.index(g)][1])
print('docx + xlsx saved')
