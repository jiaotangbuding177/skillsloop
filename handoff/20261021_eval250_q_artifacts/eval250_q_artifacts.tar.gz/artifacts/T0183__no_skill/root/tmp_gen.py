# -*- coding: utf-8 -*-
from docx import Document
from docx.shared import Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH

doc = Document()

style = doc.styles['Normal']
style.font.name = 'Noto Sans CJK SC'
style.font.size = Pt(10.5)
from docx.oxml.ns import qn
style.element.rPr.rFonts.set(qn('w:eastAsia'), 'Noto Sans CJK SC')

def h(text, level=1):
    p = doc.add_heading(text, level=level)
    for r in p.runs:
        r.font.name = 'Noto Sans CJK SC'
        r.element.rPr.rFonts.set(qn('w:eastAsia'), 'Noto Sans CJK SC')
    return p

def para(text, bold=False):
    p = doc.add_paragraph()
    r = p.add_run(text)
    r.bold = bold
    r.font.name = 'Noto Sans CJK SC'
    r.element.rPr.rFonts.set(qn('w:eastAsia'), 'Noto Sans CJK SC')
    return p

def bullet(text):
    p = doc.add_paragraph(style='List Bullet')
    r = p.add_run(text)
    r.font.name = 'Noto Sans CJK SC'
    r.element.rPr.rFonts.set(qn('w:eastAsia'), 'Noto Sans CJK SC')
    return p

def num(text):
    p = doc.add_paragraph(style='List Number')
    r = p.add_run(text)
    r.font.name = 'Noto Sans CJK SC'
    r.element.rPr.rFonts.set(qn('w:eastAsia'), 'Noto Sans CJK SC')
    return p

def table(headers, rows):
    t = doc.add_table(rows=1, cols=len(headers))
    t.style = 'Table Grid'
    for i, htxt in enumerate(headers):
        cell = t.rows[0].cells[i]
        cell.text = htxt
        for r in cell.paragraphs[0].runs:
            r.bold = True
    for row in rows:
        cells = t.add_row().cells
        for i, v in enumerate(row):
            cells[i].text = str(v)
    return t

# Title
title = doc.add_heading('传感器采购谈判方案（内部）', level=0)
for r in title.runs:
    r.font.name = 'Noto Sans CJK SC'
    r.element.rPr.rFonts.set(qn('w:eastAsia'), 'Noto Sans CJK SC')
para('密级：内部——本文件含内部底线与预算，不向任何供应商出示或转述。', bold=True)
para('日期：2026-10-15　依据：inputs/quotes.csv、inputs/buyer_limits.md')

# 1. 需求
h('一、采购需求与内部约束（仅内部）')
table(['项目','要求'],[
 ['总量','600 个传感器（可分两批）'],
 ['首批','300 个，30 天内到货'],
 ['总采购预算','不超过 130,000 元（内部最高上限，对外绝不透露）'],
 ['物流测试费','另留 8,000 元，专款专用，不得并入采购预算'],
 ['付款上限','预付比例不超过 50%'],
 ['质保底线','不低于 12 个月'],
 ['技术','必须通过已测精度，精度不得降低'],
])
para('单位预算上限：130,000 ÷ 600 ≈ 216.7 元/个（仅内部掌握）。', bold=True)

# 2. 供应商评估
h('二、报价评估')
table(['供应方','单价','MOQ','首批300交期','质保','付款','技术','符合性判断'],[
 ['A','180 元','1000','35 天','12 月','70% 预付','通过','不符合：MOQ 1000 超需求；首批 35 天超期；预付 70% 超上限'],
 ['B','196 元','500','20 天','18 月','30% 预付','通过','符合：MOQ 500 ≤600；20 天 ≤30 天；质保 18≥12 月；预付 30%≤50%'],
 ['C','168 元','1000','45 天','6 月','全预付','未测','不符合：技术未测；45 天超期；质保 6<12 月；100% 预付'],
 ['D','205 元','300','18 天','24 月','验收付款','通过','符合：MOQ 300 可两批；18 天 ≤30 天；质保 24≥12 月；验收付款无预付风险'],
])
para('总价测算（内部）：B = 196×600 = 117,600 元；D = 205×600 = 123,000 元，均在 130,000 元预算内，物流测试费 8,000 元另计不动用。', bold=True)

# 3. 选择
h('三、备选选择')
para('首选方案：供应商 B。技术与交期全部满足（20 天交付首批），总价 117,600 元，付款与质保均达标，剩余预算空间约 12,400 元用于议价。', bold=True)
para('备选方案：供应商 D。全部条件达标且交期更快（18 天）、质保更长（24 月）、验收付款现金流最优；单价 205 元略高，作为谈判 BATNA 与第二订单候选。')
para('淘汰说明：A 因 MOQ、交期、预付三项硬伤不满足；C 技术未测、交期与质保不达标，不进入谈判（仅可作远期备选，若需送测另议）。')

# 4. 可谈项
h('四、可谈项与目标')
table(['可谈项','对 B 的开局目标','可接受区间','说明'],[
 ['单价','190 元/个（总价 114,000）','190–196 元','以 D 报价 205 元及 C 低价 168 元作市场参照，不透露我方上限'],
 ['预付比例','降至 20%','20%–30%','B 现报 30% 已合规，争取进一步降低资金占用'],
 ['质保','延长至 24 个月（对齐 D）','18–24 个月','18 个月已达标，延长为增值筹码'],
 ['交期','首批 300 提前至 15–18 天','≤30 天（硬性）','争取提前，但不为提前牺牲价格底线'],
 ['分批/尾款','第二批 300 可放宽至 45 天内交货','批次节奏灵活','用交期弹性换取单价让步'],
 ['验收标准','写入抽检精度条款','不降低已测精度（硬性）','精度为红线，只可加严不可放宽'],
 ['物流','B 承担首批运费或分担测试费','部分承担','与 8,000 元物流测试专款相衔接，不占用采购预算'],
])

# 5. 底线
h('五、底线（仅内部）')
bullet('价格底线：B 最终单价不超过 196 元/个（即现报价），总价不超过 117,600 元；若 B 不让价且综合条件不优于现报价，转入与 D 签约评估。')
bullet('预算底线：含让价后总价 + 物流测试 8,000 元，总支出不超过 138,000 元整体盘子；采购合同额绝不超过 130,000 元。')
bullet('交期底线：首批 300 个必须 30 天内到货，超期即触发备选 D。')
bullet('技术底线：已测精度不得降低；C 类未测品不得直接供货。')
bullet('付款底线：预付不超过 50%；不接受全预付；优先验收后付款。')
bullet('质保底线：不低于 12 个月。')

# 6. 让步顺序
h('六、让步顺序（由易到难、可交换）')
num('第一批让步：接受 B 的 30% 预付（合规且对 B 现金流友好），换取单价下探至 192 元附近。')
num('第二批让步：第二批 300 个交期放宽至 45 天、批次数量可在 ±10% 内调整，换取单价再降至 190 元或质保延至 24 个月。')
num('订单承诺：若首轮降价达标，承诺 600 个全量下单、不分拆给 D；未达标则保留“分单给 D”的可信威胁。')
num('付款微调：可接受 35%–40% 预付 + 到货验收后付清，换取价格或质保（仍守住 50% 上限）。')
num('最后让步：单价回到 196 元但要求 24 个月质保 + 首批运费由 B 承担；此时总价 117,600 元仍在预算内。')
para('让步原则：每次让步必须换取对等回报；价格让步逐轮递减（如 4→2→1 元），绝不一次性亮出 190 元目标价；任何情况下不透露 130,000 元内部预算或 216.7 元单位上限。', bold=True)

# 7. 对外口径
h('七、对外话术口径（不含内部信息）')
bullet('可对供应商说：“同技术档位已有更低价报价，贵司需在价格或质保上更具竞争力。”（不报数字）')
bullet('可说：“我方有备选供应方案，交期与付款条件均可满足，选择贵司取决于综合条件。”')
bullet('可说：“预算为项目核定，价格空间有限，请给出最优一次报价。”')
bullet('禁止：说出任何预算数字、单位可接受价、让步顺序、D 的报价细节或我方底线。')

# 8. 书面确认清单
h('八、书面确认清单（签约/下单前逐项核对）')
table(['#','确认项','合格标准','确认方式'],[
 ['1','合同总价与单价','单价 ≤196 元，总价 ≤117,600 元，含税口径写明','合同价格条款原件'],
 ['2','数量与分批','600 个，首批 300，两批节奏与日期写明','合同交付条款 + 排产确认函'],
 ['3','首批交期','首批 300 个 ≤30 天到货（目标 15–18 天），逾期违约责任写明','合同交期条款'],
 ['4','技术精度','精度以已测报告为准，不得降低；到货抽检标准与判定方法写入合同','技术协议 + 第三方/自检报告'],
 ['5','质保','≥12 个月（争取 24 个月），质保范围与响应时限写明','质保承诺函'],
 ['6','付款方式','预付 ≤50%，余款验收后支付；发票、账户信息一致','合同付款条款 + 形式发票'],
 ['7','物流与测试','运费承担方、8,000 元物流测试费的承担/分担方式写明','合同或补充协议'],
 ['8','验收与退换','抽检不合格的退换货、补货时限及费用承担','验收条款'],
 ['9','违约与取消','逾期、精度不达标、批次缺货的违约金或备选转换权','合同违约条款'],
 ['10','签署效力','双方法定授权签署、盖章、日期齐全，与报价单版本一致','盖章版合同 PDF 归档'],
])
para('执行提示：谈判完成后，将最终条件与本清单逐项核对，全部书面落实后再支付预付款；备选 D 的报价与联系方式保留至首批验收合格为止。', bold=True)

doc.save('/workspace/outputs/supplier_negotiation.docx')
print('saved')
