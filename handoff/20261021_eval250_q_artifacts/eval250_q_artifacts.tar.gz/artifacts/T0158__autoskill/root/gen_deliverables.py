# -*- coding: utf-8 -*-
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
from openpyxl.utils import get_column_letter
from docx import Document
from docx.shared import Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
import os

os.makedirs('/workspace/outputs', exist_ok=True)

# ---------------- 数据 ----------------
shortlist = [
    {
        "rank": 1, "tier": "强烈推荐", "name": "启航创投", "score": 9.4,
        "stage": "种子-PreA", "ticket": "1000-2500", "sector": "工业软件",
        "hq_move": "否（满足）", "rd_move": "否（满足）", "lead": "可能（待确认）", "buyback": "无（满足）",
        "hard": "全部满足；唯领投意愿为“可能”",
        "why": "阶段（种子-PreA）与赛道（工业软件）完全对口；明确不要求总部与研发迁移；无回购条款；单笔1000-2500万可覆盖2000-2500万融资区间主体，具备领投基础。唯一缺口是领投意愿尚为“可能”，且如融资做到3000万上限需引入跟投方补足。",
        "todo": "1) 直接确认本轮是否愿意独家/牵头领投；2) 确认对种子期已产生620万收入企业的估值区间与单笔上限能否上浮至3000万；3) 确认董事席位安排与投后节奏。",
    },
    {
        "rank": 2, "tier": "重点接触", "name": "栖原资本", "score": 8.3,
        "stage": "种子-A", "ticket": "1000-3000", "sector": "工业软件",
        "hq_move": "待核（风险点）", "rd_move": "否（满足）", "lead": "是（满足）", "buyback": "待核（风险点）",
        "hard": "两项关键待核：总部迁移、回购条款",
        "why": "阶段（种子-A）、赛道（工业软件）、单笔金额（1000-3000万，可独立领投本轮全部区间）三项硬指标全数匹配，且明确可领投、不要求研发迁移。但“总部迁移：待核”与“回购要求：待核”两项未核实——前者直接触碰本轮不可迁总部的红线，后者触碰不接受保本回购的红线，核实前不能进入深度排他谈判。",
        "todo": "1) 首轮沟通即书面确认：本轮是否要求总部迁出苏州（一票否决项）；2) 确认条款清单中是否含保本回购/对赌回购（一票否决项）；3) 两项确认通过后，可作为与启航创投并行推进的领投备选。",
    },
    {
        "rank": 3, "tier": "重点接触（跟投/联合角色）", "name": "江桥基金", "score": 8.4,
        "stage": "种子", "ticket": "800-1800", "sector": "企业AI",
        "hq_move": "否（满足）", "rd_move": "否（满足）", "lead": "是（满足）", "buyback": "无（满足）",
        "hard": "满足约束，但单笔上限低于本轮下限",
        "why": "阶段（种子）与赛道（企业AI）匹配；不要求总部/研发迁移；无回购条款；可领投。核心短板是单笔800-1800万，低于2000万融资下限，无法独立吃下本轮，只能作为联合领投或跟投方，与其他机构拼盘完成2000-3000万融资。其企业AI赛道认知对澄川“工业软件+企业AI”策略是加分项。",
        "todo": "1) 确认本轮投资金额上限能否突破1800万（或以两期投放）；2) 确认是否接受与启航创投/栖原资本联合领投的拼盘结构；3) 确认对苏州本地项目是否有返投口径要求。",
    },
]

excluded = [
    {
        "name": "城脉产业", "stage": "A轮", "ticket": "3000-5000", "sector": "先进制造",
        "reason": "硬约束直接不满足：明确要求总部迁移，触碰“本轮不迁总部”红线；且阶段偏好A轮与澄川种子期错配，赛道（先进制造）与工业软件/企业AI仅部分相邻。无论整体名气如何，均排除在本轮接洽名单之外。",
    },
    {
        "name": "沄泽创投", "stage": "PreA", "ticket": "1500-3000", "sector": "企业AI",
        "reason": "硬约束直接不满足：回购要求为“保本”，触碰“不接受保本回购”红线；且领投意愿仅为“可能”。其余指标虽匹配，条款底线不符即排除；如未来其放弃保本条款可重新评估。",
    },
    {
        "name": "海澄成长", "stage": "B轮", "ticket": "5000-10000", "sector": "企业服务",
        "reason": "阶段严重错配：偏好B轮、单笔5000-10000万，远超本轮2000-3000万的体量区间，机构内部难以通过种子期项目立项；不作为本轮领投候选。可在A/B轮时再行接触。",
    },
    {
        "name": "同杉天使", "stage": "天使", "ticket": "300-800", "sector": "通用科技",
        "reason": "单笔300-800万且明确不领投，既无法满足“需要一家可领投”的要求，也无法在本轮融资中承担实质份额；赛道（通用科技）针对性弱。不列入接洽名单。",
    },
]

headers = ["排名", "梯队", "机构", "综合分", "阶段", "单笔区间(万元)", "行业", "总部迁移", "研发迁移", "可领投", "回购要求",
           "硬约束结论", "核心理由", "仍需确认的信息"]

# ---------------- XLSX ----------------
wb = Workbook()
ws = wb.active
ws.title = "短名单排序"

thin = Side(style="thin", color="BFBFBF")
border = Border(left=thin, right=thin, top=thin, bottom=thin)
head_fill = PatternFill("solid", fgColor="1F4E79")
head_font = Font(name="Noto Sans CJK SC", bold=True, color="FFFFFF", size=11)
body_font = Font(name="Noto Sans CJK SC", size=10)
tier_fills = {"强烈推荐": PatternFill("solid", fgColor="C6EFCE"),
              "重点接触": PatternFill("solid", fgColor="FFEB9C"),
              "重点接触（跟投/联合角色）": PatternFill("solid", fgColor="FFEB9C")}

ws.append(headers)
for c in ws[1]:
    c.font = head_font; c.fill = head_fill; c.border = border
    c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)

for row in shortlist:
    ws.append([row["rank"], row["tier"], row["name"], row["score"], row["stage"], row["ticket"], row["sector"],
               row["hq_move"], row["rd_move"], row["lead"], row["buyback"], row["hard"], row["why"], row["todo"]])

widths = [6, 20, 12, 8, 12, 14, 12, 14, 14, 14, 14, 24, 60, 50]
for i, w in enumerate(widths, 1):
    ws.column_dimensions[get_column_letter(i)].width = w
for r in ws.iter_rows(min_row=2):
    for c in r:
        c.font = body_font; c.border = border
        c.alignment = Alignment(vertical="top", wrap_text=True)
    r[1].fill = tier_fills.get(r[1].value, PatternFill())
ws.freeze_panes = "A2"

ws2 = wb.create_sheet("排除清单")
ws2.append(["机构", "阶段", "单笔区间(万元)", "行业", "排除原因"])
for c in ws2[1]:
    c.font = head_font; c.fill = head_fill; c.border = border
    c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
for e in excluded:
    ws2.append([e["name"], e["stage"], e["ticket"], e["sector"], e["reason"]])
for i, w in enumerate([12, 10, 16, 14, 80], 1):
    ws2.column_dimensions[get_column_letter(i)].width = w
for r in ws2.iter_rows(min_row=2):
    for c in r:
        c.font = body_font; c.border = border
        c.alignment = Alignment(vertical="top", wrap_text=True)
ws2.freeze_panes = "A2"

wb.save('/workspace/outputs/investor_shortlist.xlsx')

# ---------------- DOCX ----------------
doc = Document()
style = doc.styles['Normal']
style.font.name = 'Noto Sans CJK SC'
style.font.size = Pt(11)
from docx.oxml.ns import qn
style.element.rPr.rFonts.set(qn('w:eastAsia'), 'Noto Sans CJK SC')

def h(text, level=1):
    doc.add_heading(text, level=level)

def p(text, bold=False):
    para = doc.add_paragraph()
    run = para.add_run(text)
    run.bold = bold
    return para

title = doc.add_heading('澄川软件本轮融资：投资机构接洽短名单与外联简报', 0)
for run in title.runs:
    run.font.name = 'Noto Sans CJK SC'
    run.element.rPr.rFonts.set(qn('w:eastAsia'), 'Noto Sans CJK SC')
p('依据：inputs/company_constraints.md（公司硬约束）、inputs/funds.csv（候选机构清单）。编制日期：2026-10-15。', bold=False)

h('一、公司背景与硬约束', 1)
p('澄川软件：种子期，已有收入620万元；本轮拟融资2000万–3000万元，需要一家机构领投。硬约束：① 研发必须留在苏州；② 本轮不接受总部迁移（销售分支可异地设立）；③ 不接受保本回购条款；④ 可讨论董事席位；⑤ 投资策略聚焦工业软件、企业AI。')
p('评估口径：逐条核对每家机构的阶段偏好、单笔金额区间、行业方向、总部/研发迁移要求、领投能力与回购条款。任何一条硬约束被明确违反即列入排除清单；“可能领投”“待核”均不作承诺处理，仅列为待确认事项。')

h('二、排序短名单（按适配程度从高到低）', 1)

tbl = doc.add_table(rows=1, cols=6)
tbl.style = 'Light Grid Accent 1'
hdr = tbl.rows[0].cells
for i, t in enumerate(['排名', '机构', '综合分', '梯队', '关键匹配', '关键缺口/风险']):
    hdr[i].text = t
rows_data = [
    ('1', '启航创投', '9.4', '强烈推荐', '种子-PreA阶段；工业软件赛道；无迁移要求；无回购条款；单笔1000-2500万', '领投意愿为“可能”，需确认；3000万上限需拼盘'),
    ('2', '栖原资本', '8.3', '重点接触', '种子-A阶段；工业软件赛道；单笔1000-3000万可独立领投；不要求研发迁移', '总部迁移“待核”、回购“待核”，两项均为一票否决项'),
    ('3', '江桥基金', '8.4', '重点接触（跟投/联合）', '种子阶段；企业AI赛道；可领投；无迁移要求；无回购', '单笔800-1800万低于本轮下限，仅可联合领投/跟投'),
]
for rd in rows_data:
    cells = tbl.add_row().cells
    for i, v in enumerate(rd):
        cells[i].text = v

h('2.1 启航创投（强烈推荐，9.4分）', 2)
p('硬约束核对：全部满足。阶段（种子-PreA）与公司种子期匹配；行业为工业软件，与公司投资策略直接对口；总部迁移=否、研发迁移=否；回购要求=无。领投能力：单笔1000-2500万，可覆盖2000–2500万区间主体，具备领投基础，但清单标注领投为“可能”。', bold=False)
p('理由：除领投意愿待落实外，其余各项均为清单内最干净的一份画像——无任何条款或落地障碍，赛道认知与公司业务完全重合，是最应优先排期路演的对象。')
p('仍需确认：① 本轮是否愿意独家或牵头领投（“可能”不等于承诺）；② 若融资按3000万上限推进，单笔能否上浮或接受其牵头加跟投拼盘；③ 董事席位要求与估值区间。')

h('2.2 栖原资本（重点接触，8.3分）', 2)
p('硬约束核对：部分满足，两项关键待核。阶段（种子-A）匹配；行业为工业软件；单笔1000-3000万可独立吃下本轮全部区间；研发迁移=否；可领投=是。但总部迁移=待核（红线项）、回购要求=待核（红线项）。')

p('理由：纸面参数是三家中唯一能单笔覆盖2000–3000万全区间且明确可领投的机构，参数匹配度最高；但两项“待核”恰好都是公司的一票否决项，在书面确认之前不能投入排他谈判，因此排序第二。')
p('仍需确认：① 首轮沟通即要求书面确认不要求总部迁出苏州；② 条款清单中不含保本回购/对赌回购；③ 确认通过后可作为与启航创投并行的领投备选。')

h('2.3 江桥基金（重点接触·联合领投/跟投角色，8.4分）', 2)
p('硬约束核对：约束全部满足，但金额能力不足。阶段（种子）匹配；行业为企业AI，与公司“工业软件+企业AI”策略吻合；总部迁移=否、研发迁移=否；可领投=是；回购=无。单笔800-1800万低于本轮2000万下限，无法独立领投整轮。')
p('理由：条款干净、赛道认知强，是理想的拼盘伙伴；按综合分甚至略高于栖原资本，但受制于单笔规模只能承担联合角色，对“需要一家可领投”这一核心诉求贡献有限，故列第三。')
p('仍需确认：① 单笔上限能否突破1800万或接受分期投放；② 是否接受与启航创投/栖原资本联合领投；③ 对苏州本地项目有无返投口径。')

h('三、排除清单及原因', 1)
for e in excluded:
    p(f"{e['name']}（{e['stage']}，单笔{e['ticket']}万，{e['sector']}）：{e['reason']}")
p('提示：城脉产业、沄泽创投属硬约束直接不满足，即使整体知名度更高也不纳入本轮；海澄成长、同杉智天使属体量/阶段错配，建议留在未来轮次联系人名单中。'.replace('同杉智天使', '同杉天使'))

h('四、外联策略建议', 1)
p('主攻：启航创投——唯一条款完全干净且赛道完全对口的机构，建议第一时间安排路演并直接确认领投意愿。', bold=True)
p('并行：与启航创投路演同步接触栖原资本（先书面确认两大红线项），避免单一领投方谈判失败导致轮次搁浅。')
p('拼盘结构：若以3000万上限推进，可采用“启航创投牵头2200–2500万 + 江桥基金跟投500–800万”，或“栖原资本牵头2000–3000万（条件通过后）+ 江桥基金补足”。')
p('谈判口径：接受董事席位讨论，但坚持研发留苏州、总部不迁、无保本回购三条底线；对“可能领投”一律以书面条款清单落地为准，不作为承诺。')

h('五、说明与局限', 1)
p('1. 本简报仅基于 inputs/funds.csv 所载机构画像与 inputs/company_constraints.md 所载公司约束编制，未对机构进行外部尽调；实际接洽前应以机构最新基_MARK删除金条款为准。'.replace('_MARK删除', ''))
p('2. 领投意愿、单笔上限、总部迁移与回购条款均为清单标注或“待核”状态，本简报不将任何“可能领投”视为承诺；最终以正式条款清单（Term Sheet）为准。')
p('3. 排序综合分为内部评估口径（阶段、金额、赛道、迁移约束、条款五维加权），用于沟通优先级排序，不构成任何机构承诺或投资建议。')

doc.save('/workspace/outputs/outreach_brief.docx')
print('done')
