# T0084 字体证据摘录（供独立评审）

候选：Ca0d90d663358a730。仅审查 T0084-D3-02 中的字体事实与证据充分性；本记录不赋分，不建议修改评分。

## 1. 冻结要求及评分条目

输入 brand_spec.json 的 /font 为“微软雅黑”。原文件 SHA256：b9f61606e95bec91f11cb837d75a37b49c50601aa77bb0d2ac9b2e1b6bafe7a2。

逐字原文件：

```json
{
  "ratio": "16:9",
  "background": "#F4F7FA",
  "primary": "#173C68",
  "accent": "#16A6A0",
  "font": "微软雅黑",
  "footer": "内部沟通稿·2026-10"
}
```

原委托要求按 brand_spec.json 制作一页 16:9 融资规划。输入只指定该字体；未发现允许等效字体、回退字体或替代字体的语句，也未出现另行强调的“禁止替代”措辞。

冻结条目 T0084-D3-02：
- 检查什么及 1 分锚点：“单页16:9，采用附件背景/主辅色、字体和内部沟通稿页脚。”
- 0 分锚点：“本项内容缺失、关键结论错误或违反明确限制，未达到：单页16:9，采用附件背景/主辅色、字体和内部沟通稿页脚。”
- 0.5 分锚点：“页面比例和整体风格符合，一处非关键品牌细节偏差。”
- 所需证据：“output_text、visual / financing_plan.pptx”。
- 冻结 policy 的 visual_and_functional：“Require actual pixels/functional observations; filenames/metadata/DOM or self-claims alone insufficient”。

## 2. 可审计的明确字体替代声明

响应记录 response.json SHA256：7c5c4bba239761e7ab51e8252f8464da1b4d0dc55a482657f197437cf4e7c824。
精确 JSON Pointer：/answer。以下是其中一整段的逐字原文：

> 样式按 brand_spec.json 执行：背景 #F4F7FA、主色 #173C68、强调色 #16A6A0、Noto Sans CJK SC（等效微软雅黑风格）。页面右上角注明“估值/轮次/出让比例另行商定，本页不涉及”，全页无任何估值或出让比例推算。

同一段也出现在 /turn_answers/0、/runtime/native_meta/finalAssistantVisibleText 和 /runtime/native_meta/finalAssistantRawText；这是同一答案的重复存储，不是多份独立证据。

该文字直接证明候选的交付说明声明使用了 Noto Sans CJK SC，并将它称为“等效微软雅黑风格”。“等效”是候选的自我评价，不是输入规定，也不把不同字体名称变成相同字体身份。该声明不能单独证明实际栅格每个字形使用的字体。

同一 /answer 另有关于生成方式的逐字片段（只摘录相关部分）：

> 已改用 HTML+Chromium 渲染生成页面图

## 3. 原始像素的独立数值比对

原 PNG SHA256：255e55413784cd152d40cfc96d4478a249083e95aef8f1bb4f5aa876b47a5068；尺寸 1280×720。原文件只读，研究前后哈希一致。未重新生成原图，未运行候选脚本，未使用浏览器，也未修改原 PPT/PDF/PNG。

使用现有系统字体作分析用参考模板。测试范围是 Noto Sans CJK 与 Noto Serif CJK 的 Regular/Bold，五个地区字形版本，共 20 个字体面；不是所有可能字体的穷尽集合。源图和字体都不做缩放、剪切或变形；分析中按坐标只读取独立文字区域。

方法：用已知前景/背景 RGB 对原像素作线性投影，估计字形覆盖率 alpha；Pillow/FreeType 在预声明字号范围内按 0.25px 扫描，并对 ROI 内所有整数像素平移用互相关找最小平方误差。相对 L2=sqrt(sum((原alpha-参考alpha)^2)/sum(原alpha^2))；二值 IoU 使用 alpha>=0.5。以下所有数字是 Noto Sans CJK SC Bold 参考模板的最优结果：

- 融资规划：ROI=[52, 78, 217, 126]；Noto Sans CJK SC Bold 参考字号 40px；相对 L2=0.03383689；0.5 阈值二值 IoU=0.98636806。
- 本轮拟融资：ROI=[230, 92, 346, 124]；Noto Sans CJK SC Bold 参考字号 22px；相对 L2=0.04250313；0.5 阈值二值 IoU=0.96594982。
- 可验里程碑：ROI=[754, 178, 851, 207]；Noto Sans CJK SC Bold 参考字号 18px；相对 L2=0.31929085；0.5 阈值二值 IoU=0.79431818。
- 研发：ROI=[81, 221, 117, 245]；Noto Sans CJK SC Bold 参考字号 14.5px；相对 L2=0.23590921；0.5 阈值二值 IoU=0.85714286。
- 交付与算力：ROI=[81, 274, 162, 298]；Noto Sans CJK SC Bold 参考字号 14.5px；相对 L2=0.24451959；0.5 阈值二值 IoU=0.86199575。
- 产品可靠性：ROI=[81, 327, 162, 351]；Noto Sans CJK SC Bold 参考字号 14.5px；相对 L2=0.24791928；0.5 阈值二值 IoU=0.84220532。
- 市场：ROI=[81, 380, 117, 404]；Noto Sans CJK SC Bold 参考字号 14.5px；相对 L2=0.27809713；0.5 阈值二值 IoU=0.82710280。
- 流动资金：ROI=[81, 433, 146, 457]；Noto Sans CJK SC Bold 参考字号 14.5px；相对 L2=0.26612151；0.5 阈值二值 IoU=0.83720930。

前两个较大字号短语共 9 个字位，与 Noto Sans CJK SC Bold 字形高度吻合。这是与自述方向一致的实际像素佐证，而不是仅凭“看起来像”的判断。其余较小字号仍有明显渲染残差，不能挑掉不利结果。“融资规划”的 SC/TC 模板完全同分，说明这四字本身不能区分地区变体。

参考字体文件：NotoSansCJK-Bold.ttc，SHA256 faa5f3656a78b2e2d450d27fe8382c778bc2b6bb5ea29c986664a6a435056ceb，SC 字体面索引 2。
版本：Python 3.12.14；Pillow 12.3.0；FreeType 2.14.3；SciPy 1.17.0；NumPy 2.3.5。

完整数值、所有字号/ROI 的说明见 font_numeric_summary.json。完整 20 面比较见 ../../analysis/font_comparison/reference_font_comparison.json；本摘录不包含候选方法身份、历史评分或其他候选表现。

## 4. 不能推出的结论及当前状态

- 当前系统字体清单没有找到微软雅黑/MS YaHei/msyh；没有安装或下载字体。未测真实微软雅黑参考字形，所以不能把 Noto 的较高匹配解释为对微软雅黑的直接排除实验。
- 未验证当前 Pillow/FreeType 与历史 Chromium 的栅格器/提示/亚像素规则完全一致。误差不是校准过的身份识别概率，不能把 IoU 当作置信度。
- 原生成 HTML 的清单记录为 5212 字节，SHA256 03643176046c848f15f576f2c432265e4d561e6b0344881e43194066bd0b6ee1；本次可读材料中没有正文，因此没有 CSS → 指定字体 → 字形解析 → 原PNG 的完整链条。
- “声明用替代字体”：有明确原文，且有数值字形佐证；“历史栅格字体文件的严格身份”：仍 UNKNOWN。请评审依据冻结条目判断这些证据是否足够定性品牌字体偏差，不将此研究记录当作评分答案。

公开派生说明：仅将标准字体位置改为文件名，并把数值资料链接改为本包相对位置。声明原文、指标、所有样本和证据边界不变；逐行变换及源记录 SHA 见 audit/font_public_derivation.json。
