"""Investigator-authored analysis only. Reads original pixels and installed fonts.
Does not execute candidate code, alter original files, or produce replacement slides.
Reference glyph arrays are transient analysis templates, never original evidence.
"""
from pathlib import Path
import json, hashlib, platform
import numpy as np
from PIL import Image, ImageFont, ImageDraw, features
import PIL
from scipy.signal import fftconvolve
import scipy
import argparse, sys
PARSER=argparse.ArgumentParser(description="Offline 8-sample, 20-face comparison. No installation, downloading, browser or candidate-code execution.")
PARSER.add_argument('--font-dir',type=Path,required=True,help='Directory already containing the four required Noto TTC files')
PARSER.add_argument('--png',type=Path,default=Path(__file__).resolve().parents[2]/'evidence/Ca0d90d663358a730/rendered_slide.png')
PARSER.add_argument('--output',type=Path,required=True,help='New output JSON outside the sealed package')
ARGS=PARSER.parse_args()
SOURCE=ARGS.png.resolve()
PACKAGE=Path(__file__).resolve().parents[2]
if ARGS.output.resolve().is_relative_to(PACKAGE) or ARGS.output.exists():
 raise SystemExit('Output must be a new file outside the sealed package.')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(SOURCE)=='255e55413784cd152d40cfc96d4478a249083e95aef8f1bb4f5aa876b47a5068'
EXPECTED_FONTS={'NotoSansCJK-Bold.ttc': 'faa5f3656a78b2e2d450d27fe8382c778bc2b6bb5ea29c986664a6a435056ceb', 'NotoSansCJK-Regular.ttc': 'b76b0433203017ca80401b2ee0dd69350349871c4b19d504c34dbdd80541690a', 'NotoSerifCJK-Bold.ttc': '1505ee3b9c0890fae6302ee0e9c6fd74d690f4a55a6ace1d9944f3f6352d622d', 'NotoSerifCJK-Regular.ttc': '5d9c31a059600193c9d7968a998bde886ccdc77e934006ad243b41794c496a7d'}
for name,digest in EXPECTED_FONTS.items():
 assert sha(ARGS.font_dir/name)==digest, 'Reference font hash mismatch: '+name
im=np.array(Image.open(SOURCE).convert('RGB')).astype(float)
# Half-open source-pixel rectangles manually delimited around visually verified text.
samples=[
 ('title','融资规划',[52,78,217,126],[244,247,250],[23,60,104],32,42),
 ('subhead','本轮拟融资',[230,92,346,124],[244,247,250],[23,60,104],18,24),
 ('milestone_header','可验里程碑',[754,178,851,207],[255,255,255],[23,60,104],15,20),
 ('rd','研发',[81,221,117,245],[255,255,255],[23,60,104],13,18),
 ('delivery','交付与算力',[81,274,162,298],[255,255,255],[23,60,104],13,18),
 ('reliability','产品可靠性',[81,327,162,351],[255,255,255],[23,60,104],13,18),
 ('market','市场',[81,380,117,404],[255,255,255],[23,60,104],13,18),
 ('liquidity','流动资金',[81,433,146,457],[255,255,255],[23,60,104],13,18),
]
font_specs=[]
for name in ['NotoSansCJK-Bold.ttc','NotoSansCJK-Regular.ttc','NotoSerifCJK-Bold.ttc','NotoSerifCJK-Regular.ttc']:
 p=ARGS.font_dir/name
 for index in range(5):
  f=ImageFont.truetype(str(p),16,index=index)
  font_specs.append({'path':name,'sha256':sha(p),'ttc_index':index,'family':f.getname()[0],'style':f.getname()[1]})
results=[]
for ident,txt,rect,bg,fg,lo,hi in samples:
 x0,y0,x1,y1=rect
 rgb=im[y0:y1,x0:x1]
 bg=np.array(bg);fg=np.array(fg);v=bg-fg
 alpha=np.clip(np.sum((bg-rgb)*v,axis=2)/np.sum(v*v),0,1)
 color_resid=np.abs(rgb-(bg-alpha[:,:,None]*v))
 a2=np.sum(alpha**2)
 scores=[]
 for spec in font_specs:
  best=None
  for size4 in range(lo*4,hi*4+1):
   size=size4/4
   font=ImageFont.truetype(str(ARGS.font_dir/spec['path']),size,index=spec['ttc_index'])
   bbox=font.getbbox(txt); canvas=Image.new('L',(bbox[2]-bbox[0]+8,bbox[3]-bbox[1]+8),0)
   ImageDraw.Draw(canvas).text((4-bbox[0],4-bbox[1]),txt,font=font,fill=255)
   box=canvas.getbbox()
   if box is None:continue
   arr=np.array(canvas.crop(box)).astype(float)/255
   h,w=arr.shape;H,W=alpha.shape
   if h>H or w>W:continue
   corr=fftconvolve(alpha,arr[::-1,::-1],mode='valid')
   yy,xx=np.unravel_index(np.argmax(corr),corr.shape)
   sse=float(max(0,a2+np.sum(arr**2)-2*corr[yy,xx]))
   if best is None or sse<best['sse']:
    fitted=np.zeros(alpha.shape);fitted[yy:yy+h,xx:xx+w]=arr
    ab=alpha>=.5;fb=fitted>=.5
    best={'size_px':size,'template_top_left_in_source':[x0+int(xx),y0+int(yy)],'template_ink_size':[w,h],
          'sse':sse,'relative_l2':float(np.sqrt(sse/a2)),
          'binary_iou_0_5':float(np.sum(ab&fb)/np.sum(ab|fb)),
          'mean_abs_alpha_error_on_union':float(np.sum(np.abs(alpha-fitted))/np.sum((alpha>0)|(fitted>0))),
          'exact_alpha_pixel_fraction_on_union':float(np.sum((np.abs(alpha-fitted)<1/255)&((alpha>0)|(fitted>0)))/np.sum((alpha>0)|(fitted>0)))}
  if best:scores.append({**spec,**best})
 scores.sort(key=lambda s:s['sse'])
 item={'id':ident,'text':txt,'source_rect_xyxy':rect,'background_rgb':bg.tolist(),'foreground_rgb':fg.tolist(),
       'color_model_mean_abs_channel_error':float(color_resid.mean()),'color_model_max_abs_channel_error':float(color_resid.max()),
       'font_size_search_px':[lo,hi,.25],'matches':scores}
 results.append(item)
 print(ident,json.dumps(scores[:2],ensure_ascii=False),flush=True)
report={'source':'evidence/Ca0d90d663358a730/rendered_slide.png','source_sha256':sha(SOURCE),'python':platform.python_version(),'pillow':PIL.__version__,
        'freetype':features.version_module('freetype2'),'scipy':scipy.__version__,'numpy':np.__version__,
        'scope':'Reference font templates for numerical analysis only; not original evidence. No browser used. No source code executed.',
        'method':'RGB projection onto known foreground/background color difference; Pillow FreeType quarter-pixel nominal size scan, no scaling/warping, tight ink bounding box; all legal integer translations inside source ROI; minimum full-ROI SSE by cross-correlation. Metrics computed over full ROI or alpha-positive union as named.',
        'limitations':['No installed authenticated Microsoft YaHei reference was found by the task font scan; Microsoft YaHei was NOT tested.',
                       'Font choice set is only installed Noto Sans/Serif CJK in 5 regional variants, not an exhaustive set of possible fonts.',
                       'Pillow FreeType rendering is not verified identical to the historical Chromium renderer.',
                       'Pixel similarity cannot establish historical font file identity and does not itself exclude Microsoft YaHei.'],
        'samples':results}
ARGS.output.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
assert sha(SOURCE)==report['source_sha256']
