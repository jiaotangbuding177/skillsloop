字体像素比较复验（不是原生运行截图或字体身份鉴定）

reference_font_comparison.json保留8个样本、每个20个字体面的全部最佳拟合数值。font_numeric_summary.json位于evidence/Ca0d90d663358a730/，保留全部8样本的SC Bold摘要及对照数值。

原实验环境：Python 3.12.14；Pillow 12.3.0；FreeType 2.14.3；SciPy 1.17.0；NumPy 2.3.5。
需已存在的NotoSansCJK-Bold.ttc、NotoSansCJK-Regular.ttc、NotoSerifCJK-Bold.ttc、NotoSerifCJK-Regular.ttc。每个TTC索引0至4，共20面。文件SHA写于完整JSON及脚本；字体二进制不包含在包中。本包不自动安装依赖或下载字体，缺失时停止。

在包根目录运行（将YOUR_EXISTING_FONT_DIRECTORY及NEW_OUTPUT_JSON换成你自己的路径）：
python3 analysis/font_comparison/compare_reference_fonts.py --font-dir YOUR_EXISTING_FONT_DIRECTORY --output NEW_OUTPUT_JSON
输出必须是封包目录外的新文件；脚本拒绝覆盖已有文件。默认读取本包原PNG，也可用--png显式提供同SHA原图。
算法：RGB投影估计alpha，枚举各样本事先指定的0.25px字号范围，遍历ROI内所有整数平移，以互相关求最小SSE。参考字形不缩放或扭曲。relative_l2=sqrt(SSE/sum(alpha^2))，IoU阈值0.5。所有ROI、前背景色、字号搜索范围与20面结果均在JSON。

可比对新输出与本包完整JSON的samples字段；本次封包已全量复算并检查所有样本/字体的数值。不同软件环境可能引入浮点/栅格差异，不应强行认定为字体身份变化。

解释边界：没有测试真实微软雅黑，集合非穷尽。SC/TC可能同分；6处小字号有明显残差。当前Pillow/FreeType与历史Chromium的栅格规则一致性未经验证；IoU不是概率。本实验不修改原图，不代替严格历史字体链条。原响应/历史HTML全文和字体二进制未随包提供。
