#!/usr/bin/env python3
"""Offline, read-only verification of this three-item supplement. Python 3 stdlib only."""
import hashlib
import json
from pathlib import Path
import sys
import math
import re
import struct
import zipfile
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent
RUBRICS_SHA = 'b31eefb1434f3e7341de8fb7be31244b507ada59c5dee9e638c8b1f1de9b3d90'
POLICY_SHA = '1623b3be006c03a8d884cd882d270ebc3f667de73790557bf91a1237ad845ac2'
TARGETS = {'Cdfc0bda9402e55d7': ('T0112', 'T0112-D5-01'),
           'Ce5353b9efbae40ec': ('T0171', 'T0171-D5-02'),
           'Ca0d90d663358a730': ('T0084', 'T0084-D3-02')}
CORE_KEYS = ('candidate_id', 'task_id', 'item_id', 'phase', 'review_scope',
             'status', 'review_status', 'score', 'reason', 'model')

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def pairs(items):
    result = {}
    for key, value in items:
        if key in result:
            raise ValueError('Duplicate JSON key: ' + key)
        result[key] = value
    return result

def reject_constant(value):
    raise ValueError('Non-finite JSON constant: ' + value)

def read(path):
    return json.loads(path.read_text(encoding='utf-8'), object_pairs_hook=pairs, parse_constant=reject_constant)

def require(condition, message):
    if not condition:
        raise ValueError(message)

def inside(relative, base=ROOT):
    require(not Path(relative).is_absolute(), 'Absolute package reference')
    p = (base / relative).resolve()
    require(p.is_relative_to(ROOT), 'Path escapes package: ' + relative)
    require(p.is_file() and not p.is_symlink(), 'Missing/non-regular file: ' + relative)
    return p

def verify():
    for p in ROOT.rglob('*'):
        require(not p.is_symlink(), 'Symlink is not allowed in package')
    entries = {}
    for line in (ROOT / 'SHA256SUMS').read_text(encoding='utf-8').splitlines():
        digest, relative = line.split('  ', 1)
        require(re.fullmatch(r'[0-9a-f]{64}', digest) is not None, 'Invalid SHA256')
        require(relative not in entries, 'Duplicate manifest entry: ' + relative)
        entries[relative] = digest
        require(sha(inside(relative)) == digest, 'SHA mismatch: ' + relative)
    actual = {str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file()}
    require(actual == set(entries) | {'SHA256SUMS'}, 'Unlisted or missing package files')
    require(sha(ROOT / 'frozen_policy.json') == POLICY_SHA, 'Frozen policy SHA mismatch')
    provenance = read(ROOT / 'audit/source_validation.json')
    require(provenance['frozen_rubrics_sha256'] == RUBRICS_SHA and provenance['frozen_policy_sha256'] == POLICY_SHA, 'Source frozen hashes mismatch')
    require(provenance['complete_release_hash_verified_before_packaging'] is True and provenance['complete_release_included'] is False, 'Unexpected full-release provenance claim')
    require(provenance['pre_existing_source_score_records_checked_unchanged'] == 750, 'Source integrity baseline mismatch')
    require(len(provenance['packets']) == 3 and all(x['original_manifest_all_hashes_and_sizes_match'] and x['frozen_target_item_exact_match'] for x in provenance['packets']), 'Source audit failure')
    audit = read(ROOT / 'audit/public_derivation.json')
    sources = {(x['candidate_id'], x['phase']): x for x in audit['records']}
    require(len(sources) == 6 and len(audit['records']) == 6, 'Exactly six unique stage records are required')
    rows = []
    evidence_count = 0
    for cid, (tid, iid) in TARGETS.items():
        folder = ROOT / 'records' / cid
        rubric = read(folder / 'target_rubric.json')
        require(rubric['candidate_id'] == cid and rubric['task_id'] == tid, 'Rubric identity mismatch')
        require(rubric['target_item']['item_id'] == iid, 'Rubric item mismatch')
        require(rubric['target_item']['score'] is None, 'Rubric must not be scored or edited')
        require(rubric['frozen_rubrics_sha256'] == RUBRICS_SHA, 'Frozen rubric provenance mismatch')
        require(rubric['frozen_policy_sha256'] == POLICY_SHA, 'Frozen policy provenance mismatch')
        require(sha(folder / 'scoring_policy.json') == POLICY_SHA, 'Per-item policy mismatch')
        for phase in ('DRAFT', 'CHECK'):
            p = folder / (phase + '.json')
            j = read(p)
            require((j['candidate_id'], j['task_id'], j['item_id'], j['phase']) == (cid, tid, iid, phase), 'Stage identity mismatch')
            require(j['review_scope'] == 'TARGETED_ITEM_ONLY', 'Unexpected review scope')
            require(j['model'] == 'gpt-6-astra', 'Unexpected judge model')
            require(j['score'] is None or (type(j['score']) in (int, float) and j['score'] in (0, .5, 1)), 'Invalid item score')
            require((j['status'] == 'SCORED' and j['score'] is not None) or
                    (j['status'] in ('UNSCORED', 'PENDING', 'UNKNOWN') and j['score'] is None), 'Score/status conflict')
            require(j['rubric_sha256'] == sha(folder / 'target_rubric.json'), 'Target rubric SHA mismatch')
            require(j['policy_sha256'] == POLICY_SHA, 'Stage policy SHA mismatch')
            require(j['frozen_rubrics_sha256'] == RUBRICS_SHA, 'Stage frozen rubric mismatch')
            require(j['frozen_policy_sha256'] == POLICY_SHA, 'Stage frozen policy mismatch')
            source = sources[(cid, phase)]
            require(source['public_record_sha256'] == sha(p), 'Derivative record SHA mismatch')
            core = {k: j[k] for k in CORE_KEYS if k in j}
            require(core == source['source_score_fields'], 'Score-bearing fields changed')
            require(j['public_derivative']['source_record_sha256'] == source['source_record_sha256'], 'Original record provenance mismatch')
            base = (folder / j['evidence_base']).resolve()
            require(base.is_relative_to(ROOT), 'Invalid evidence base')
            for e in j['evidence']:
                ep = inside(e['path'], base)
                require(sha(ep) == e['sha256'], 'Evidence SHA mismatch: ' + e['path'])
                evidence_count += 1
            if phase == 'CHECK':
                comparison = j.get('draft_comparison', {})
                if 'draft_sha256' in comparison:
                    require(comparison['draft_sha256'] == sources[(cid, 'DRAFT')]['source_record_sha256'], 'CHECK source DRAFT hash mismatch')
                rows.append(j)
    summary = read(ROOT / 'results.json')
    require(summary['package_kind'] == 'THREE_ITEM_ARTIFACT_SUPPLEMENT', 'Unexpected package kind')
    require(summary['final_stage'] == 'CHECK', 'Final scores must come from CHECK')
    require(len(summary['items']) == 3 and len({(x['candidate_id'], x['task_id'], x['item_id']) for x in summary['items']}) == 3, 'Exactly three unique result items required')
    require(summary['total_q'] is None and summary['new_coverage'] is None, 'Aggregate scores/coverage must stay null')
    require(summary['merged_into_original_750'] is False, 'This is not a 750-record merge')
    require(summary['other_items_regraded'] is False and summary['pending'] == [], 'Unexpected out-of-scope or pending work')
    for item, stage in zip(summary['items'], rows):
        for k in ('candidate_id', 'task_id', 'item_id', 'status', 'score', 'reason'):
            require(item[k] == stage[k], 'Final result differs from CHECK: ' + k)
        require(item['previous_score'] is None and item['score_delta'] is None, 'Unknown historical scores must stay null')
        require(sha(inside(item['check_record'])) == item['check_sha256'], 'Final CHECK reference SHA mismatch')
    for item in read(ROOT / 'audit/file_mapping.json')['files']:
        require(sha(inside(item['public_path'])) == item['source_sha256'] == item['public_sha256'], 'Source byte preservation failed')
    screenshots = read(ROOT / 'audit/screenshot_review.json')['screenshots']
    require(len(screenshots) == 19, 'Screenshot audit must contain 19 entries')
    for item in screenshots:
        require(item['viewed_at_original_resolution'] is True and item['disclosure_check'] == 'PASS', 'Unreviewed screenshot')
        require(sha(inside(item['path'])) == item['sha256'], 'Screenshot audit SHA mismatch')
    verify_v2()
    print(json.dumps({'result': 'PASS', 'files_hashed': len(entries), 'stage_records': 6,
                      'final_item_records': 3, 'evidence_references_checked': evidence_count,
                      'screenshots': len(screenshots), 'source_artifacts': 3,
                      'total_q': None, 'new_coverage': None}, ensure_ascii=False, indent=2))
    print('This checks package integrity and recorded consistency, not the correctness of visual judgments.')
    print('The complete original rubric release and original 750-score package are not included; their recovery or independent revalidation is outside this supplement.')


def verify_v2():
    cid = 'Ca0d90d663358a730'
    ev = ROOT / 'evidence' / cid
    old = read(ROOT / 'audit/previous_package_preservation.json')
    require(old['previous_zip_sha256'] == '2ab04035d688151806430e2c4444d1bc8ceaa176a01cdcdfe7cfd65865b63e28', 'Prior package anchor mismatch')
    require(len(old['files']) == 38, 'Unexpected prior preserved-file count')
    for e in old['files']:
        require(sha(inside(e['path'])) == e['sha256'], 'Prior public bytes changed')
    pinned = {
        'records/Cdfc0bda9402e55d7/DRAFT.json': 'f9a612e5d9fdcfef3f2f3620c079b517cad2454fe1672cd73080d40bf198cd44',
        'records/Cdfc0bda9402e55d7/CHECK.json': '2e7a1f700ae670d633cd7be4aac0c65130458c0e0c673bf9bc46d6785e56c21e',
        'records/Ce5353b9efbae40ec/DRAFT.json': 'f62585812099e637c76d5e2bab7f1dd33da92fba649a70315d15e1c1fb50cc1e',
        'records/Ce5353b9efbae40ec/CHECK.json': 'c78f09da79b64c4520e53408d54e255ef3156b57d53a6e3f463ed4bed6f3adb6'}
    for path, digest in pinned.items():
        require(sha(inside(path)) == digest, 'Prior stage record changed')
    for e in read(ev / 'manifest.json')['files']:
        p = inside(e['path'], ev)
        require(sha(p) == e['sha256'] and p.stat().st_size == e['bytes'], 'New evidence manifest mismatch')
    require(len(read(ev / 'manifest.json')['files']) == 6, 'New manifest scope changed')
    for e in read(ROOT / 'audit/font_public_derivation.json')['records']:
        require(sha(inside(e['public_path'])) == e['public_sha256'], 'Font derivative hash mismatch')
    ppt = ev / 'source_artifact.pptx'
    png = ev / 'rendered_slide.png'
    require(sha(ppt) == '4beefcdc6e046351049e4e8df40e8f103ea582bc3690c540267fc14a3f7b44d7', 'Original PPTX changed')
    require(sha(png) == '255e55413784cd152d40cfc96d4478a249083e95aef8f1bb4f5aa876b47a5068', 'Original PNG changed')
    binding = read(ev / 'source_binding.json')
    require(binding['source_pptx_sha256'] == sha(ppt) and binding['source_png_sha256'] == sha(png), 'Source binding mismatch')
    ns = {'p':'http://schemas.openxmlformats.org/presentationml/2006/main',
          'a':'http://schemas.openxmlformats.org/drawingml/2006/main',
          'r':'http://schemas.openxmlformats.org/officeDocument/2006/relationships'}
    with zipfile.ZipFile(ppt) as z:
        require(z.testzip() is None and len(z.namelist()) == len(set(z.namelist())), 'PPTX CRC or duplicate member error')
        require(z.read('ppt/media/image1.png') == png.read_bytes(), 'PPTX embedded PNG is not byte-identical')
        pres = ET.fromstring(z.read('ppt/presentation.xml'))
        require(len(pres.findall('p:sldIdLst/p:sldId', ns)) == 1, 'Not one slide')
        size = pres.find('p:sldSz',ns).attrib
        require(size == binding['slide_size_emu'], 'Slide size binding mismatch')
        require((int(size['cx']),int(size['cy'])) == (12191695,6858000), 'Unexpected slide geometry')
        slide = ET.fromstring(z.read('ppt/slides/slide1.xml'))
        pics = slide.findall('.//p:pic',ns)
        require(len(pics) == 1 and not slide.findall('.//p:sp',ns) and not slide.findall('.//p:graphicFrame',ns), 'Unexpected content objects')
        require(not slide.findall('.//a:srcRect',ns), 'Image is cropped')
        xfrm = pics[0].find('p:spPr/a:xfrm',ns)
        require(xfrm.find('a:off',ns).attrib == {'x':'0','y':'0'}, 'Picture not at origin')
        require(xfrm.find('a:ext',ns).attrib == {'cx':size['cx'],'cy':size['cy']}, 'Picture not full-page')
        require(pics[0].find('p:blipFill/a:stretch/a:fillRect',ns) is not None, 'Missing full stretch')
        relid = pics[0].find('p:blipFill/a:blip',ns).get('{'+ns['r']+'}embed')
        rels=ET.fromstring(z.read('ppt/slides/_rels/slide1.xml.rels'))
        require(any(x.get('Id')==relid and x.get('Target')=='../media/image1.png' for x in rels), 'Media relationship mismatch')
    require(png.read_bytes()[:8] == b'\x89PNG\r\n\x1a\n' and struct.unpack('>II',png.read_bytes()[16:24]) == (1280,720), 'PNG geometry mismatch')
    full=read(ROOT/'analysis/font_comparison/reference_font_comparison.json')
    brief=read(ev/'font_numeric_summary.json')
    require(full['source_sha256']==brief['source_png_sha256']==sha(png), 'Font source mismatch')
    expected=['title','subhead','milestone_header','rd','delivery','reliability','market','liquidity']
    require([x['id'] for x in full['samples']]==expected and [x['sample_id'] for x in brief['samples']]==expected, 'Incomplete or reordered samples')
    require(len(full['samples'])==len(brief['samples'])==8, 'Eight samples required')
    fonts=set()
    for f,b in zip(full['samples'],brief['samples']):
        require(f['text']==b['text'] and f['source_rect_xyxy']==b['source_rect_xyxy'], 'Sample binding mismatch')
        require(len(f['matches'])==20 and len({(x['path'],x['ttc_index']) for x in f['matches']})==20, 'All 20 font faces required')
        for m in f['matches']:
            fonts.add((m['path'],m['sha256']))
            require(m['ttc_index'] in range(5), 'Invalid TTC index')
            require(m['path'] in {'NotoSansCJK-Bold.ttc','NotoSansCJK-Regular.ttc','NotoSerifCJK-Bold.ttc','NotoSerifCJK-Regular.ttc'}, 'Unexpected font family scope')
            for k in ['sse','relative_l2','binary_iou_0_5','mean_abs_alpha_error_on_union','exact_alpha_pixel_fraction_on_union']:
                require(type(m[k]) in (int,float) and math.isfinite(m[k]) and m[k]>=0, 'Invalid numeric metric')
            require(m['binary_iou_0_5']<=1 and m['exact_alpha_pixel_fraction_on_union']<=1, 'Invalid fraction')
        sc=[m for m in f['matches'] if m['family']=='Noto Sans CJK SC' and m['style']=='Bold']
        require(len(sc)==1 and sc[0]==b['noto_sans_sc_bold'], 'SC Bold summary differs from full comparison')
    require(len(fonts)==4, 'Four consistent reference font files required')
    require(brief['reference_only'] is True and len(full['limitations'])>=4, 'Reference-only limitations missing')
    require(read(ROOT/'records'/cid/'CHECK.json')['evidence_sufficiency']['historical_font_file_identity']=='UNKNOWN', 'Historical identity must remain UNKNOWN')

if __name__ == '__main__':
    try:
        verify()
    except Exception as exc:
        print('FAIL: ' + str(exc), file=sys.stderr)
        sys.exit(1)
