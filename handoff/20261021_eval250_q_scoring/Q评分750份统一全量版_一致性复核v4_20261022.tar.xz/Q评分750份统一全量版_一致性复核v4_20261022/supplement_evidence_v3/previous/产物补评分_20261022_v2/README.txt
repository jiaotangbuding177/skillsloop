产物补评分 v2（2026-10-22）

这是3个指定单项的补评分包，不是完整750份质量评分，也未合并旧750。
- Cdfc0bda9402e55d7 / T0112-D5-01：CHECK 0.5，旧公开记录及证据字节不变。
- Ce5353b9efbae40ec / T0171-D5-02：CHECK 0.5，旧公开记录及证据字节不变。
- Ca0d90d663358a730 / T0084-D3-02：CHECK 0.5，字体替代被判为一处非关键品牌细节偏差。

先读观察说明，再读各CHECK和证据。最终分只取CHECK，共3个唯一项、6份DRAFT/CHECK。模型gpt-6-astra；探索性、未校准。各条DRAFT与CHECK由不同评审者完成，但CHECK读过DRAFT，不是两个独立首评。

重要边界
- 总Q、新coverage、历史单项分数及变化均为null。不猜组均值，不外推到其他条目。
- 旧750质量评分ZIP仍待恢复/提供；现有750份元数据哈希检查不等于已取得或合并旧750质量评分。
- T0084所看PNG是原PPTX唯一满页、无裁切图片的同字节媒体，不是新运行PowerPoint的截图。字体数值不是原生运行截图。
- 明确替代声明与有限像素比对共同支持本条判断，但未严格鉴定历史字体。没有真实微软雅黑参考，20面Noto集合不是穷尽集合，8个样本全部保留，6处小字残差不隐藏。IoU不是字体身份概率；历史字体文件身份仍UNKNOWN。
- 原PPTX、PNG、XLSX、DOCX和原始JPEG不改字节；不提供字体二进制，不安装依赖、不联网、不运行候选代码。
- 阶段记录是公开派生记录，保持判分字段/理由/边界，只调整引用并补充兼容字段。源SHA、逐字段/逐行处理见audit/public_derivation.json与audit/font_public_derivation.json。旧四阶段记录未变。
- 完整冻结rubrics在封包前重算SHA并逐字段核对3个目标，但未随包提供；包内不能重算完整集合哈希。冻结policy原字节附上，保留草稿/待人审状态，冻结不代表校准。

文件导读
results.json：3个CHECK结果与null字段。
records/：3组target_rubric/scoring_policy及6个公开阶段记录。
evidence/：原产物、19份原生JPEG、原PPTX同字节PNG、品牌要求和必要回执/字体摘录。
analysis/font_comparison/：8样本×20面的完整比较、可复验算法和复算说明。
audit/：来源验证、原包字节保持、引用变换、截图披露核验。
SHA256SUMS：除本清单自身外全部文件的SHA256。
verify.py：Python 3.10+标准库离线只读复验，不启动Office、不执行产物。运行 python3 verify.py。

PASS只证明包内完整性与一致性，不证明视觉判分正确，也不是独立认证来源。校验器检查3项6阶段、分数/状态、所有引用SHA、冻结policy、PPTX/PNG同字节绑定、原包保持、完整8×20数值边界和仅CHECK结果。源记录未全部公开，仅有哈希与变换说明。
可选像素全量复算需本地现有指定版本依赖与同SHA的4个Noto TTC文件，详见analysis/font_comparison/README.txt。脚本拒绝不同字体哈希，不下载/安装，不覆盖封包。环境不同可能出现数值差异。
ZIP整体SHA在相邻.zip.sha256；请保留可信外部哈希。包内清单不是数字签名，若清单和校验程序也同时被恶意替换，本包不能自证真实性。

冻结完整rubrics SHA256：b31eefb1434f3e7341de8fb7be31244b507ada59c5dee9e638c8b1f1de9b3d90
冻结policy SHA256：1623b3be006c03a8d884cd882d270ebc3f667de73790557bf91a1237ad845ac2
原两条公开ZIP SHA256：2ab04035d688151806430e2c4444d1bc8ceaa176a01cdcdfe7cfd65865b63e28
