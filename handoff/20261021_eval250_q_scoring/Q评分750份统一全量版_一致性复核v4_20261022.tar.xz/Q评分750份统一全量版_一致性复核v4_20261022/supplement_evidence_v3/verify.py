#!/usr/bin/env python3
"""Offline read-only package verification, stdlib only. Never executes candidate artifacts."""
import csv,hashlib,json,sys,re,subprocess,collections
from pathlib import Path
from datetime import datetime,timezone
from zoneinfo import ZoneInfo
ROOT=Path(__file__).resolve().parent
V2SHA='4cd4186926b09c603aa1c36d90714d821c25691fa1f2460ea0cef30454b4e2c7'
POLICY='1623b3be006c03a8d884cd882d270ebc3f667de73790557bf91a1237ad845ac2'
RUBRICS='b31eefb1434f3e7341de8fb7be31244b507ada59c5dee9e638c8b1f1de9b3d90'
CIDS=['C75A8C33706C3','C9D47EF28BB04','C9EE60570C63F']
OLD=['Cdfc0bda9402e55d7','Ce5353b9efbae40ec','Ca0d90d663358a730']
LEGACY='previous/产物补评分_20261022_v2'

def require(c,m):
 if not c:raise ValueError(m)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def pairs(items):
 d={}
 for k,v in items:
  require(k not in d,'Duplicate JSON key: '+k);d[k]=v
 return d
def read(p):return json.loads(p.read_text(encoding='utf-8'),object_pairs_hook=pairs,parse_constant=lambda x: (_ for _ in ()).throw(ValueError('Nonfinite JSON: '+x)))
def inside(rel,base=ROOT):
 require(isinstance(rel,str) and not Path(rel).is_absolute(),'Absolute/invalid reference')
 p=(base/rel).resolve();require(p.is_relative_to(ROOT),'Escaping reference: '+rel)
 require(p.is_file() and not p.is_symlink(),'Missing/nonregular reference: '+rel);return p
def score(v):require(type(v) in (int,float) and v in (0,.5,1),'Score must be numeric 0, 0.5, or 1, not a boolean')
def pointer(obj,path):
 if path=='':return obj
 for k in path.lstrip('/').split('/'):
  k=k.replace('~1','/').replace('~0','~');obj=obj[int(k)] if isinstance(obj,list) else obj[k]
 return obj
def walk(x,p=''):
 yield p,x
 if isinstance(x,dict):
  for k,v in x.items():yield from walk(v,p+'/'+str(k).replace('~','~0').replace('/','~1'))
 elif isinstance(x,list):
  for i,v in enumerate(x):yield from walk(v,p+'/'+str(i))
def decode_ical(x):
 return re.sub(r'\\([nN,;\\])',lambda m:'\n' if m[1] in 'nN' else m[1],x)
def parse_ical(p):
 # A small strict parser for only the supplied VEVENT form, not a general RFC validator.
 text=p.read_bytes().decode('utf-8-sig');lines=re.sub(r'\r?\n[ \t]','',text).splitlines();events=[];e=None
 for line in lines:
  if line=='BEGIN:VEVENT':require(e is None,'Nested event');e={}
  elif line=='END:VEVENT':require(e is not None,'Unexpected event close');events.append(e);e=None
  elif e is not None:
   key,val=line.split(':',1);parts=key.split(';');base=parts[0]
   require(base not in e,'Duplicate VEVENT field: '+base)
   e[base]=(dict(part.split('=',1) for part in parts[1:]),val)
 require(e is None and events,'Incomplete/no events');return events

def compare_case(c):
 ev=ROOT/'evidence'/c
 manifest=read(ev/'MANIFEST_SHA256.json')
 actual={str(p.relative_to(ev)) for p in ev.rglob('*') if p.is_file()}
 require(actual==set(manifest)|{'MANIFEST_SHA256.json'},'Frozen case inventory mismatch')
 for path,digest in manifest.items():require(sha(inside(path,ev))==digest,'Frozen file mismatch: '+path)
 ics=parse_ical(ev/'source_ics.ics');db=read(ev/'actual_db_events.json')
 with (ev/'source_csv.csv').open(encoding='utf-8-sig',newline='') as f:
  rows=[r for r in csv.DictReader(f) if re.fullmatch(r'\d{4}-\d{2}-\d{2}',r.get('日期','') or '')]
 n={'C75A8C33706C3':12,'C9D47EF28BB04':12,'C9EE60570C63F':10}[c]
 require(len(ics)==len(db)==len(rows)==n,'Event counts mismatch')
 uids=[e['UID'][1] for e in ics];dbids=[e['id'] for e in db]
 require(len(set(uids))==len(set(dbids))==n and set(uids)==set(dbids),'UID binding mismatch')
 native={r['id']:r for r in db};tz=ZoneInfo('Asia/Shanghai');seen=set();dates=collections.Counter();generic=0
 for i,e in enumerate(ics):
  r=native[e['UID'][1]];times=[]
  for prop,col in [('DTSTART','event_start'),('DTEND','event_end')]:
   params,val=e[prop]
   require(params=={'TZID':'Asia/Shanghai'},'Unexpected source timezone schema')
   dt=datetime.strptime(val,'%Y%m%dT%H%M%S').replace(tzinfo=tz)
   expected=int(dt.astimezone(timezone.utc).timestamp()*1000000)
   require(type(r[col]) is int and r[col]==expected,'Native/source timestamp mismatch')
   require(r[col+'_tz']=='Asia/Shanghai','Native timezone mismatch');times.append(dt)
  title=decode_ical(e['SUMMARY'][1]);require(r['title']==title,'Native/source title mismatch')
  if title=='学习工作段：工作段':generic+=1
  start,end=times
  matches=[j for j,row in enumerate(rows) if row['日期']==start.strftime('%Y-%m-%d') and row.get('开始',row.get('开始时间'))==start.strftime('%H:%M') and row.get('结束',row.get('结束时间'))==end.strftime('%H:%M')]
  require(len(matches)==1 and matches[0] not in seen,'CSV one-to-one time binding failed');seen.add(matches[0]);dates[start.strftime('%Y-%m-%d')]+=1
 require(len(seen)==n and dates=={'2026-11-10':n//2,'2026-11-11':n//2},'Two-date count binding failed')
 if c=='C9D47EF28BB04':require(generic==6,'Preserved generic-summary fact mismatch')
 related=ev/'actual_db_related_records.json'
 if related.exists():
  d=read(related);require(d['cal_events']==db,'Primary/related exported records differ')
  desc={x['item_id']:x['value'] for x in d['cal_properties'] if x['key']=='DESCRIPTION'}
  for e in ics:require(desc[e['UID'][1]]==decode_ical(e['DESCRIPTION'][1]),'Imported description mismatch')
 obs=read(ev/'observation.json')
 require(obs['neutral_review_id']==c and obs['observed_event_count_total']==n,'Observation identity/count mismatch')
 require(obs['observed_event_counts_by_date']==dict(dates),'Observation daily counts mismatch')
 require(obs['boundaries']['network_level_isolation_claimed'] is False,'Network-level isolation must not be claimed')
 require(obs['application']['name']=='Mozilla Thunderbird' and obs['application']['version']=='158.0.1','App version mismatch')
 for s in obs['screenshots']:require(sha(inside(s['path'],ev))==s['sha256'],'Observation screenshot mismatch')
 for o in obs['observed_events']:
  require(o['uid'] in native and o['actual_title']==native[o['uid']]['title'],'Observed/native identity mismatch')
  for ref in o['evidence_paths']:
   # Frozen observation schema uses basenames here, unlike /screenshots path records.
   require(Path(ref).name==ref,'Unexpected event evidence basename')
   ep=inside('screenshots/'+ref,ev);require(sha(ep)==manifest['screenshots/'+ref],'Event screenshot reference mismatch')
  for key,col in [('actual_start','event_start'),('actual_end','event_end')]:
   require(int(datetime.fromisoformat(o[key]).timestamp()*1000000)==native[o['uid']][col],'Observed/native timestamp mismatch')
 return n

def verify():
 for p in ROOT.rglob('*'):require(not p.is_symlink(),'Symlink not permitted')
 sums={}
 for line in (ROOT/'SHA256SUMS').read_text().splitlines():
  digest,path=line.split('  ',1);require(re.fullmatch('[0-9a-f]{64}',digest) is not None,'Invalid SHA256')
  require(path not in sums,'Duplicate manifest path');sums[path]=digest
  require(sha(inside(path))==digest,'File SHA mismatch: '+path)
 actual={str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file()}
 require(actual==set(sums)|{'SHA256SUMS'},'Unlisted or missing file')
 # Parse all public JSON strictly, and reject internal absolute text paths.
 for path in actual:
  p=ROOT/path
  require('PRIVATE' not in path and not path.endswith(('.sqlite','.log')),'Private material not permitted')
  if p.suffix=='.json':read(p)
  if p.suffix.lower() in ('.json','.txt','.md','.py') or p.name=='SHA256SUMS':
   t=p.read_text(encoding='utf-8');require(not re.search(r'/(?:workspace|tmp|home|mnt|Users)/',t),'Internal absolute path in public text: '+path)
 old=read(ROOT/'audit/previous_v2_preservation.json');require(old['previous_zip_sha256']==V2SHA,'v2 archive trust anchor changed')
 for e in old['files']:require(sha(inside(e['path']))==e['sha256'] and inside(e['path']).stat().st_size==e['bytes'],'v2 bytes changed')
 require({str(p.relative_to(ROOT)) for p in (ROOT/LEGACY).rglob('*') if p.is_file()}=={e['path'] for e in old['files']},'v2 inventory changed')
 # The prior verifier is a preserved verification utility, never an evaluated candidate script.
 legacy=subprocess.run([sys.executable,str(ROOT/LEGACY/'verify.py')],capture_output=True,text=True)
 require(legacy.returncode==0,'Preserved v2 validation failed: '+legacy.stderr)
 for e in read(ROOT/'audit/byte_preservation.json')['files']:
  p=inside(e['path']);require(sha(p)==e['source_sha256']==e['public_sha256'] and p.stat().st_size==e['bytes'],'Source bytes changed')
 common=ROOT/'common';require(sha(common/'scoring_policy.json')==POLICY,'Policy changed')
 policy=read(common/'scoring_policy.json');require(policy['status']=='DRAFT_PENDING_HUMAN_REVIEW','Frozen draft policy relabeled')
 criterion=read(common/'criterion_T0144-D2-04.json')
 require(criterion['score'] is None and criterion['item_id']=='T0144-D2-04','Rubric score/ID altered')
 provenance=read(common/'method_provenance.json')
 require(provenance['method_file_sha256']=={'rubrics.jsonl':RUBRICS,'scoring_policy.json':POLICY},'Frozen source anchors changed')
 require(provenance['criterion_file_sha256']==sha(common/'criterion_T0144-D2-04.json'),'Criterion hash mismatch')
 prompt=(common/'prompt.txt').read_bytes();require(sha(common/'prompt.txt')==provenance['prompt_file_sha256'],'Prompt file hash mismatch')
 require(hashlib.sha256(prompt.removesuffix(b'\r\n')).hexdigest()==provenance['prompt_text_sha256_without_trailing_CRLF']==criterion['sources'][0]['sha256'],'Prompt-text/rubric source mismatch')
 for path,e in read(common/'source_sha256.json').items():
  p=inside(path,common);require(sha(p)==e['sha256'] and p.stat().st_size==e['bytes'],'Task input source mismatch')
 bindings=read(ROOT/'audit/source_binding.json');require(bindings['v2_zip_sha256']==V2SHA and bindings['frozen_rubrics_sha256']==RUBRICS and bindings['frozen_policy_sha256']==POLICY,'Source binding anchors changed')
 require(bindings['researcher_review_evidence_available'] is False and bindings['model_calibration_evidence_available'] is False,'Invalid method activation claim')
 for case in bindings['cases']:
  for field in ['source_ics','source_csv','frozen_manifest']:require(sha(inside(case[field]))==case[field+'_sha256'],'Case source binding failed')
  require(case['original_candidate_id'] is None,'Calendar original ID invented')
 require([x['neutral_review_id'] for x in bindings['cases']]==CIDS,'Source cases reordered/duplicated')
 n_events=sum(compare_case(c) for c in CIDS)
 audit=read(ROOT/'audit/calendar_public_derivation.json')['records']
 require(len(audit)==6 and {(x['neutral_review_id'],x['phase']) for x in audit}=={(c,p) for c in CIDS for p in ['DRAFT','CHECK']},'Calendar stage audit incomplete/duplicate')
 bykey={(x['neutral_review_id'],x['phase']):x for x in audit};refs=0
 for c in CIDS:
  for phase in ['DRAFT','CHECK']:
   a=bykey[c,phase];j=read(inside(a['public_record']))
   require(sha(inside(a['public_record']))==a['public_record_sha256'],'Stage derivative hash mismatch')
   score(j['score']);require(j.get('neutral_review_id',j.get('candidate_id'))==c and j['item_id']=='T0144-D2-04','Stage target mismatch')
   require(j['status'] in {'DRAFT_PENDING_HUMAN_REVIEW','CHECK_COMPLETE_PENDING_HUMAN_REVIEW','CHECK_DISAGREES_DRAFT_PENDING_HUMAN_REVIEW','MODEL_CHECK_COMPLETE_NOT_HUMAN_REVIEW'},'Unexpected stage status')
   meta=j['public_derivative'];require(meta['source_record_sha256']==a['source_record_sha256'] and meta['human_review_completed'] is False and meta['review_actor']=='MODEL','Model/source status invalid')
   require(meta['score_scope']=='TARGETED_ITEM_ONLY' and meta['candidate_id_namespace']=='NEUTRAL_REVIEW_ID_NOT_ORIGINAL_CANDIDATE' and meta['original_candidate_id'] is None,'Neutral ID namespace missing')
   require(meta['frozen_policy_status']=='DRAFT_PENDING_HUMAN_REVIEW' and meta['calibration_status']=='EXPLORATORY_UNVALIDATED','Unvalidated status missing')
   model=j.get('configured_model',j.get('judge_configuration',{}).get('configured_model'))
   require(model=='gpt-6-astra','Unexpected model')
   for key,value in a['source_score_fields'].items():require(j[key]==value,'Protected source judgment changed: '+key)
   for op in a['field_transformations']:
    if op['operation']=='REMOVE':
     try:pointer(j,op['pointer'])
     except (KeyError,IndexError,TypeError):pass
     else:raise ValueError('Removed field still present')
    else:require(pointer(j,op['pointer'])==op['public_value'],'Transformation audit mismatch')
   for ptr,obj in walk(j):
    if isinstance(obj,dict) and 'path' in obj:
     path=obj['path'];p=inside(path)
     if 'sha256' in obj:require(sha(p)==obj['sha256'],'Evidence reference hash mismatch: '+path);refs+=1
     elif 'expected_sha256' in obj and 'actual_sha256' in obj:
      require(sha(p)==obj['expected_sha256']==obj['actual_sha256'],'Reference verification mismatch');refs+=1
    if isinstance(obj,str) and ptr.endswith(('/manifest_path','/draft_path','/public_draft_record')):inside(obj)
   if phase=='CHECK':
    dr=j.get('draft_review',j.get('review_design'))
    require(dr is not None,'Missing draft exposure record')
    require(dr['draft_hash_scope']=='RAW_SOURCE_RECORD','Draft source hash scope ambiguous')
    require(sha(inside(dr['public_draft_record']))==dr['public_draft_sha256'],'Public DRAFT hash mismatch')
    for key in ['expected_sha256','actual_sha256','observed_sha256','draft_expected_sha256','draft_computed_sha256']:
     if key in dr:require(dr[key]==bykey[c,'DRAFT']['source_record_sha256'],'CHECK raw DRAFT hash mismatch')
 result=read(ROOT/'results.json')
 require(result['package_kind']=='SIX_ITEM_ARTIFACT_SUPPLEMENT' and result['final_stage']=='CHECK','Wrong package scope/final stage')
 require(result['distribution_status']=='INTERNAL_PREPARATION_NOT_PUBLISHED','Unexpected publication claim')
 require(result['status']=='MODEL_CHECK_COMPLETE_PENDING_HUMAN_REVIEW' and result['human_researcher_review_completed'] is False,'Invalid human-review claim')
 require(result['frozen_policy_status']=='DRAFT_PENDING_HUMAN_REVIEW' and result['calibration_status']=='EXPLORATORY_UNVALIDATED','Invalid validation claim')
 for key in ['dimension_scores','total_q','coverage','new_coverage','coverage_delta','group_means','paired_deltas','confidence_intervals']:require(result[key] is None,'Aggregate must be null: '+key)
 for key in ['merged_into_original_750','old750_restored','other_items_regraded','historical_execution_proven_by_current_import']:require(result[key] is False,'Out-of-scope claim: '+key)
 require(result['pending']==[] and len(result['items'])==6,'Six completed targeted items required')
 ids=[x.get('neutral_review_id',x.get('candidate_id')) for x in result['items']];require(ids==OLD+CIDS and len(set(ids))==6,'Item identity mismatch')
 olditems=read(ROOT/LEGACY/'results.json')['items']
 for current,original in zip(result['items'][:3],olditems):
  expected=dict(original);expected['check_record']=LEGACY+'/'+expected['check_record'];require(current==expected,'Prior result fields changed')
 for i,item in enumerate(result['items']):
  score(item['score']);require(item['previous_score'] is None and item['score_delta'] is None,'Historical score/delta must remain null')
  stage=read(inside(item['check_record']));require(sha(inside(item['check_record']))==item['check_sha256'],'Final CHECK hash mismatch')
  require(item['score']==stage['score'],'Final score not from CHECK')
  reason=stage.get('reason',stage.get('reason_zh',stage.get('justification_zh')));require(item['reason']==reason,'Final reason not from CHECK')
  if i>=3:
   require(item['candidate_id'] is None and item['original_candidate_id'] is None,'Neutral ID presented as original candidate ID')
   require(item['dimension_score'] is None and item['total_q'] is None,'Calendar total must remain null')
   draft=read(inside(item['draft_record']));require(sha(inside(item['draft_record']))==item['draft_sha256'] and draft['score']==item['draft_score'],'Draft summary mismatch')
   require(type(item['draft_check_agreement']) is bool and item['draft_check_agreement']==(draft['score']==stage['score']),'Disagreement suppressed')
 require(result['items'][4]['draft_score']==1 and result['items'][4]['score']==.5 and result['items'][4]['draft_check_agreement'] is False,'Known disagreement must be preserved')
 print(json.dumps({'result':'PASS','files_hashed':len(sums),'preserved_v2_files':len(old['files']),'stage_records':12,'targeted_items':6,'calendar_events_bound':n_events,'calendar_original_screenshots':30,'calendar_evidence_references_checked':refs,'total_q':None,'coverage':None,'human_review_completed':False},ensure_ascii=False,indent=2))
 print('Integrity and recorded-consistency check only. Not a new GUI import, historical execution proof, human review, or correctness certification.')
if __name__=='__main__':
 try:verify()
 except Exception as e:print('FAIL: '+str(e),file=sys.stderr);sys.exit(1)
