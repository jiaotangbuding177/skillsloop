import copy
import io
import itertools
import tempfile
import unittest
import zipfile
from pathlib import Path
import recovery_core as r


def fixture():
    rubric = {"task_id": "TTEST", "items": [{"item_id": "TTEST-" + d, "dimension": d, "weight": 1} for d in r.WEIGHTS]}
    base = {"candidate_id": "CTEST", "task_id": "TTEST", "phase": "DRAFT", "judge_id": "old-reviewer",
            "items": [{"item_id": "TTEST-" + d, "score": 1, "status": "SCORED", "reason": "Original judgment", "evidence": [{"quote": "original quotation"}]} for d in r.WEIGHTS]}
    base["items"][-1].update(score=None, status="UNKNOWN")
    patch = {"candidate_id": "CTEST", "task_id": "TTEST", "item_id": "TTEST-D5", "phase": "DRAFT",
             "score": .5, "status": "SCORED", "review_scope": "TARGETED_ITEM_ONLY", "model": "gpt-6-astra",
             "reason": "Synthetic new observation", "evidence": [{"quote": "synthetic"}]}
    auth = {("CTEST", "TTEST", "TTEST-D5")}
    return rubric, base, patch, auth


class RecoveryTests(unittest.TestCase):
    def test_duplicate_json_rejected(self):
        with self.assertRaises(r.Invalid): r.loads('{"a":1,"a":2}')

    def test_nonfinite_json_rejected(self):
        for v in ['NaN', 'Infinity', '-Infinity', '1e999', '-1e999']:
            with self.assertRaises(r.Invalid): r.loads(v)

    def test_unknown_preserves_null(self):
        rub, base, _, _ = fixture(); a = r.aggregate(base['items'], rub)
        self.assertIsNone(a['q_0_100']); self.assertIsNone(a['dimensions']['D5']['score_0_100'])
        self.assertEqual(a['dimensions']['D1']['score_0_100'], 100)

    def test_fixed_denominator_and_rounding(self):
        rub, base, _, _ = fixture()
        base['items'][-1].update(score=1, status='SCORED')
        for k in (2, 3):
            rub['items'].append({'item_id': f'TTEST-D1-{k}', 'dimension':'D1', 'weight':1})
            base['items'].append({'item_id':f'TTEST-D1-{k}', 'score':0, 'status':'SCORED'})
        a=r.aggregate(base['items'],rub)
        self.assertEqual(a['dimensions']['D1']['fixed_weight_denominator'],3)
        self.assertEqual(a['dimensions']['D1']['score_0_100'],33.33333333)
        self.assertEqual(a['q_0_100'],80)

    def test_valid_scores_all_combinations(self):
        rub,base,_,_=fixture()
        for vals in itertools.product([0,.5,1],repeat=5):
            for i,v in zip(base['items'],vals): i.update(score=v,status='SCORED')
            self.assertEqual(r.aggregate(base['items'],rub)['q_0_100'],round(sum(v*100*w for v,w in zip(vals,r.WEIGHTS.values())),8))

    def test_bad_values_rejected(self):
        for val in [True, '.5', .25, -1, float('nan'), float('inf')]:
            rub,b,_,_=fixture();b['items'][0]['score']=val
            with self.assertRaises(r.Invalid):r.aggregate(b['items'],rub)

    def test_missing_duplicate_and_fake_item(self):
        for mode in ['missing','duplicate','fake']:
            rub,b,_,_=fixture()
            if mode=='missing':b['items'].pop()
            elif mode=='duplicate':b['items'].append(b['items'][0])
            else:b['items'][0]['item_id']='FAKE'
            with self.assertRaises(r.Invalid):r.aggregate(b['items'],rub)

    def test_no_silent_unscored_status(self):
        rub,b,_,_=fixture();b['items'][-1]['status']='UNSCORED'
        with self.assertRaises(r.Invalid):r.aggregate(b['items'],rub)

    def test_composite_preserves_original(self):
        rub,b,p,a=fixture();original=copy.deepcopy(b);new=copy.deepcopy(p)
        result=r.compose_phase(b,[p],rub,a)
        self.assertEqual(b,original);self.assertEqual(p,new)
        self.assertEqual(result['q_0_100'],95)
        self.assertFalse(result['whole_candidate_new_review_claimed'])
        self.assertEqual(result['base_phase_record'],original)
        for i in range(4):self.assertEqual(result['items'][i]['judgment_payload'],original['items'][i])
        self.assertEqual(result['items'][-1]['judgment_payload'],new)
        self.assertNotIn('judge_id',result)

    def test_no_unauthorized_ics_or_other_patch(self):
        rub,b,p,a=fixture();p['item_id']='T0144-D2-04'
        with self.assertRaises(r.Invalid):r.compose_phase(b,[p],rub,a)

    def test_duplicate_patch_rejected(self):
        rub,b,p,a=fixture()
        with self.assertRaises(r.Invalid):r.compose_phase(b,[p,p],rub,a)

    def test_wrong_phase_rejected(self):
        rub,b,p,a=fixture();p['phase']='CHECK'
        with self.assertRaises(r.Invalid):r.compose_phase(b,[p],rub,a)

    def test_final_uses_check_not_max(self):
        rub,b,p,a=fixture();draft=r.compose_phase(b,[p],rub,a)
        b['phase']='CHECK';p['phase']='CHECK';p['score']=0
        check=r.compose_phase(b,[p],rub,a);f=r.finalize_pair(draft,check)
        self.assertEqual(f['q_0_100'],90);self.assertEqual(f['items'],check['items'])

    def test_safe_archive_names(self):
        for name in ['/tmp/a','../a','a/../b','a\\b','a//b','C:/a']:
            with self.assertRaises(r.Invalid):r.safe_name(name)

    def test_reference_base_stays_inside(self):
        self.assertEqual(r.resolved_member('records/C/DRAFT.json','../../evidence/C','a.jpg'),'evidence/C/a.jpg')
        with self.assertRaises(r.Invalid):r.resolved_member('records/C/DRAFT.json','../../../','a')

    def test_archive_hash_and_inventory(self):
        data=io.BytesIO()
        with zipfile.ZipFile(data,'w') as z:
            z.writestr('a.txt',b'x');z.writestr('SHA256SUMS',r.sha(b'x')+'  a.txt\n')
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'x.zip';p.write_bytes(data.getvalue())
            self.assertEqual(r.verify_archive(p,r.sha(data.getvalue()))['a.txt'],b'x')
            with self.assertRaises(r.Invalid):r.verify_archive(p,'0'*64)

    def test_cohort_no_missing_zero(self):
        rub,b,p,a=fixture();records=[]
        for index,m in enumerate(r.METHODS):
            f=r.compose_phase(b,[p] if index else [],rub,a);f.update(method=m,candidate_id='C'+str(index));records.append(f)
        summary=r.validate_cohort(records,task_count=1,item_count=15)
        self.assertEqual(summary['null_q'],1);self.assertEqual(summary['common_complete_tasks'],0)
        self.assertIsNone(summary['groups']['NoSkill']['full_task_mean'])


if __name__=='__main__':unittest.main()
