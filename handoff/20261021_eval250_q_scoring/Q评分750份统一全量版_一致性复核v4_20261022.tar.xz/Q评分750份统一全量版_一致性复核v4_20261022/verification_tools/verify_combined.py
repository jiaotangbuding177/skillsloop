#!/usr/bin/env python3
"""Read-only combined verification including the T0030 consistency review.

This is a new verifier, not the lost original qvalidate. It verifies bytes,
source-linked item projections, aggregation and statistics, not semantic truth.
"""
import argparse
from collections import Counter
import copy
import csv
import io
import json
from pathlib import Path
import re
import sys

sys.dont_write_bytecode = True
import recovery_core as core
import merge_release as merge
import paired_statistics as stats
import privacy_evidence as privacy
import claim_merge_logic as claims


def read_jsonl(path):
    return merge.jsonl(path.read_bytes())


def verify_checksums(root):
    entries = {}
    for line in (root / "SHA256SUMS.txt").read_text().splitlines():
        h, sep, name = line.partition("  ")
        core.require(sep and re.fullmatch("[0-9a-f]{64}", h), "Invalid checksum line")
        core.safe_name(name)
        core.require(name not in entries, "Duplicate checksum name")
        entries[name] = h
    paths = list(root.rglob("*"))
    core.require(not any(p.is_symlink() for p in paths), "Symlinks are not allowed")
    actual = {p.relative_to(root).as_posix() for p in paths if p.is_file()}
    core.require(actual == set(entries) | {"SHA256SUMS.txt"}, "Release checksum inventory differs")
    for name, h in entries.items():
        core.require(core.sha((root / name).read_bytes()) == h, "Release SHA differs: " + name)
    return len(entries)


def verify_projection(patch, cid, phase, supplement):
    source = patch["source_review_record"]
    prefix = "supplement_evidence_v3/"
    core.require(source["path"].startswith(prefix), "Source outside supplement tree")
    member = source["path"][len(prefix):]
    rawbytes = supplement[member]
    raw = core.loads(rawbytes)
    core.require(source["byte_sha256"] == core.sha(rawbytes) and source["canonical_sha256"] == core.canonical_sha(raw), "Supplement source hash differs")
    rid = source["source_identity"]
    native = rid not in merge.CALENDAR
    expected_member = (merge.V2_PREFIX if native else "") + f"records/{rid}/{phase}.json"
    core.require(member == expected_member and source["phase"] == phase, "Wrong source phase or record")
    reason = raw["reason"] if native else raw["justification_zh"] if rid == "C75A8C33706C3" else raw["reason_zh"]
    core.require(patch["item_id"] == raw["item_id"] and patch["score"] == raw["score"] and patch["reason"] == reason, "Supplement decision or quotation changed")
    expected_score = .5 if native else merge.CALENDAR[rid][0 if phase == "DRAFT" else 1]
    core.require(patch["score"] == expected_score and patch["status"] == "SCORED", "Unexpected target decision")
    core.require(patch["model"] == "gpt-6-astra" and patch["judge_id"] is None and patch["review_scope"] == "TARGETED_ITEM_ONLY", "False reviewer attribution")
    core.require(source["source_public_derivative"] == raw["public_derivative"], "Supplement derivative disclosure changed")
    refs = []
    withheld_refs = 0
    for ref in raw["evidence"] if native else merge.recurse_refs(raw):
        resolved = (merge.V2_PREFIX + core.resolved_member(f"records/{rid}/{phase}.json", raw["evidence_base"], ref["path"])) if native else ref["path"]
        core.safe_name(resolved)
        core.require(privacy.reference_hash(supplement[resolved]) == ref["sha256"], "Supplement reference SHA differs")
        withheld_refs += isinstance(supplement[resolved], privacy.WithheldImage)
        refs.append({**copy.deepcopy(ref), "path": prefix + resolved, "source_reference_path": ref["path"]})
    core.require(patch["evidence"] == refs, "Supplement evidence projection changed")
    return rid, len(refs), withheld_refs


def verify(root):
    root = Path(root)
    hashed_count = verify_checksums(root)
    tasks = core.load_release(root / "rubric_release")
    old = core.verify_archive(root / "history/基线原发行_补证更新版_20261022.zip", core.OLD_ZIP_SHA)
    privacy_mode = (root / "privacy_withheld.json").exists()
    if privacy_mode:
        supplement, privacy_ledger = privacy.load_public_evidence(root)
        forbidden = {row["sha256"] for row in privacy_ledger["withheld"]} | {merge.SUPP_SHA}
        for path in root.rglob("*"):
            if path.is_file(): privacy.reject_withheld_copies(path.read_bytes(), forbidden)
    else:
        supplement = core.verify_archive(root / "history/产物补评分_20261022_v3.zip", merge.SUPP_SHA, merge.SUPP_PREFIX)
        privacy_ledger = {"withheld": []}
    for name, raw in supplement.items():
        path = root / "supplement_evidence_v3" / name
        if isinstance(raw, privacy.WithheldImage):
            core.require(not path.exists(), "Withheld supplemental image reappeared")
        else:
            core.require(path.read_bytes() == raw, "Supplement evidence copy changed")
    old_phases, old_final, old_flat, old_csv, before_summary = merge.old_adapter(old, tasks)
    core.require((root / "evidence_metadata_index.jsonl").read_bytes() == old["evidence_metadata_index.jsonl"], "Old evidence metadata changed")
    metadata = merge.jsonl(old["evidence_metadata_index.jsonl"])
    bridge = core.loads((root / "calendar_candidate_binding.json").read_bytes())
    expected = {cid: {iid} for cid, (tid, iid) in core.AUTHORIZED_TARGETS.items()}
    core.require(len(bridge) == 3 and {b["neutral_review_id"] for b in bridge} == set(merge.CALENDAR), "Calendar bridge IDs differ")
    for b in bridge:
        cid, tid, method = b["candidate_id"], b["task_id"], b["method"]
        core.require(tid == "T0144" and old_csv[cid]["task_id"] == tid and old_csv[cid]["method"] == method, "Calendar public task/method binding differs")
        core.require(len(b["sources"]) == 2, "Calendar needs both original source hashes")
        for src in b["sources"]:
            raw = supplement[src["supplement_member"]]
            core.require(core.sha(raw) == src["sha256"] and len(raw) == src["bytes"], "Calendar source bytes differ")
            matches = [e for e in metadata if e["candidate_id"] == cid and e["task_id"] == tid and e["role"] == "output" and e["kind"] != "failure" and e["source_native_sha256"] == src["sha256"] and e["source_byte_sha256"] == src["sha256"]]
            core.require(len(matches) == 1 and matches[0]["evidence_id"] == src["old_evidence_id"], "Calendar original source binding differs")
        expected[cid] = {"T0144-D2-04"}
    core.require(len(expected) == 6, "Exactly six original supplemental candidates required")
    claim_patches, claim_bindings, claim_data = claims.load_patches(root / "test_claim_evidence", old_csv, metadata, tasks)
    core.require(core.loads((root / "test_claim_candidate_binding.json").read_bytes()) == claim_bindings, "T0030 public binding differs")
    claim_candidates = {b["candidate_id"] for b in claim_bindings}
    core.require(not claim_candidates.intersection(expected), "T0030 overlaps prior target candidates")
    expected.update({cid: set(claims.TARGET_ITEMS) for cid in claim_candidates})
    core.require(len(expected) == 9 and sum(map(len, expected.values())) == 12, "Exact twelve final target inventory differs")
    phases = {p: merge.unique(read_jsonl(root / (p + ".jsonl")), lambda r: r["candidate_id"]) for p in ("DRAFT", "CHECK")}
    final = merge.unique(read_jsonl(root / "final_candidates.jsonl"), lambda r: r["candidate_id"])
    flat = merge.unique(read_jsonl(root / "final_items.jsonl"), lambda r: (r["candidate_id"], r["item_id"]))
    core.require(len(final) == 750 and len(flat) == 7929 and all(set(p) == set(old_final) for p in [final, *phases.values()]), "Full release counts/identities differ")
    changes = merge.unique(read_jsonl(root / "supplement_changes.jsonl"), lambda r: (r["candidate_id"], r["phase"], r["item_id"]))
    core.require(set(changes) == {(c,p,i) for c in expected for p in phases for i in expected[c]}, "Need exactly twenty-four target item-phase decisions")
    unchanged_phase_items, refs, withheld_refs = 0, 0, 0
    for phase, rows in phases.items():
        for cid, row in rows.items():
            base = old_phases[phase][cid]
            core.require(row["task_id"] == base["task_id"] and row["method"] == base["method"] and row["phase"] == phase, "Phase attribution changed")
            for field, value in core.aggregate(row["items"], tasks[row["task_id"]]).items():
                core.require(row[field] == value, "Phase aggregate differs")
            indexed = core.item_index(row["items"], tasks[row["task_id"]])
            base_index = {i["item_id"]: i for i in base["items"]}
            for iid, item in indexed.items():
                target = cid in expected and iid in expected[cid]
                if not target:
                    core.require(item == base_index[iid], "Non-target phase judgment changed")
                    unchanged_phase_items += 1
                else:
                    if cid in claim_candidates:
                        core.require(item == claim_patches[cid, phase, iid], "T0030 source projection changed")
                    else:
                        rid, count, unavailable = verify_projection(item, cid, phase, supplement)
                        refs += count; withheld_refs += unavailable
                        if rid in merge.CALENDAR:
                            core.require(any(b["neutral_review_id"] == rid and b["candidate_id"] == cid for b in bridge), "Calendar reviewer identity binding differs")
                        else:
                            core.require(rid == cid, "Native reviewer candidate differs")
                        core.require(base_index[iid]["score"] is None, "Original six targets were not UNKNOWN")
                    change = changes[cid, phase, iid]
                    for field in ("score", "status"):
                        core.require(change["before_" + field] == base_index[iid][field] and change["after_" + field] == item[field], "Target change decision differs")
                    core.require(change["after_q_0_100"] == row["q_0_100"] and change["before_q_0_100"] == base["q_0_100"], "Target change Q differs")
                    core.require(change["before_item_canonical_sha256"] == core.canonical_sha(base_index[iid]) and change["after_item_canonical_sha256"] == core.canonical_sha(item), "Change ledger item hash differs")
                    core.require(change["supplement_record"] == item["source_review_record"], "Change provenance differs")
            if cid in claim_candidates:
                recomposed = claims.merge_multi_phase(base, [indexed[i] for i in sorted(expected[cid])], tasks[row["task_id"]])
            else:
                patch = indexed[next(iter(expected[cid]))] if cid in expected else None
                recomposed = merge.merge_phase(base, patch, tasks[row["task_id"]], core.OLD_ZIP_SHA)
            core.require(row == recomposed, "Composite phase metadata differs")
            if cid in expected and cid not in claim_candidates:
                core.require(core.canonical_sha(row) == claims.PRIOR_SIX_RECORD_PINS[phase + ":" + cid], "Previously completed six-candidate phase changed")
    differences = set()
    preserved = 0
    for cid, row in final.items():
        check, draft = phases["CHECK"][cid], phases["DRAFT"][cid]
        if cid not in expected:
            core.require(row == old_final[cid], "Untargeted candidate final changed")
        core.require(row["final_phase"] == "CHECK" and row["items"] == check["items"], "Final is not CHECK-only")
        if cid in expected:
            expected_final = copy.deepcopy(check)
            expected_final.update(final_phase="CHECK", finalization_rule="CHECK_ONLY_NOT_MAX_NOT_AVERAGE",
                                  draft_composite_canonical_sha256=core.canonical_sha(draft), check_composite_canonical_sha256=core.canonical_sha(check))
            core.require(row == expected_final, "Final composite attribution changed")
        if cid in expected and cid not in claim_candidates:
            core.require(core.canonical_sha(row) == claims.PRIOR_SIX_RECORD_PINS["final_candidates:" + cid], "Previously completed six final records changed")
        for field, value in core.aggregate(row["items"], tasks[row["task_id"]]).items():
            core.require(row[field] == value, "Final aggregate differs")
        draft_items = {i["item_id"]: i for i in draft["items"]}
        for i in row["items"]:
            iid = i["item_id"]; f = flat[cid, iid]
            core.require(all(f[k] == v for k,v in i.items()), "Final flat/nested judgment differs")
            core.require(f['candidate_id'] == cid and f['task_id'] == row['task_id'] and
                         f['method'] == row['method'] and f['phase'] == 'CHECK',
                         'Final flat item task/method/phase attribution differs')
            rubric_item = next(x for x in tasks[row["task_id"]]["items"] if x["item_id"] == iid)
            core.require(f["dimension"] == rubric_item["dimension"] and f["weight"] == rubric_item["weight"], "Final rubric dimension/weight differs")
            if cid not in expected or iid not in expected[cid]:
                core.require(f == old_flat[cid,iid], "Non-target final item payload changed")
                preserved += 1
            di = draft_items[iid]
            if (i["status"],i["score"]) != (di["status"],di["score"]): differences.add((cid,iid))
    reported_differences = read_jsonl(root / "draft_check_differences.jsonl")
    core.require(len(reported_differences) == len(differences) and {(d["candidate_id"],d["item_id"]) for d in reported_differences} == differences, "Phase differences differ")
    for difference in reported_differences:
        cid, iid = difference["candidate_id"], difference["item_id"]
        for phase, key in (("DRAFT","draft"),("CHECK","check")):
            item = next(i for i in phases[phase][cid]["items"] if i["item_id"] == iid)
            for field in ("score","status","reason"):
                core.require(difference[key+"_"+field] == item[field], "Phase difference detail changed")
    item_audits = merge.unique(read_jsonl(root / "item_preservation_audit.jsonl"), lambda r: (r["candidate_id"],r["item_id"]))
    core.require(set(item_audits) == set(flat), "Preservation audit inventory differs")
    for key, record in item_audits.items():
        target = key[0] in expected and key[1] in expected[key[0]]
        core.require(record["targeted_supplement"] == target and record["old_final_item_canonical_sha256"] == core.canonical_sha(old_flat[key]) and record["new_final_item_canonical_sha256"] == core.canonical_sha(flat[key]), "Preservation audit hash differs")
        core.require(record["unchanged_item_exact_object_equal"] == (None if target else True), "Preservation audit equality claim differs")
    item_csv = merge.unique(list(csv.DictReader(io.StringIO((root / "final_item_scores.csv").read_text()))), lambda r: (r["candidate_id"],r["item_id"]))
    core.require(set(item_csv) == set(flat), "Final-item CSV inventory differs")
    for key, row in item_csv.items():
        for field, value in row.items():
            expected_value = flat[key].get(field)
            core.require(value == ("" if expected_value is None else str(expected_value)), "Final-item CSV value/quotation differs")
    cohort = stats.load_scores(root / "candidate_scores.csv", frozen_categories=stats.read_frozen_categories(root / "rubric_release"))
    for row in final.values():
        c = cohort.rows[row["task_id"],row["method"]]
        core.require(c["candidate_id"] == row["candidate_id"] and c["q_0_100"] == row["q_0_100"], "CSV final identity/Q differs")
        for dim in core.WEIGHTS: core.require(c[dim+"_0_100"] == row["dimensions"][dim]["score_0_100"], "CSV final dimension differs")
    recomputed = stats.analyze(cohort)
    for name, text in stats.render_outputs(cohort, recomputed).items():
        core.require((root / name).read_bytes() == text.encode(), "Recomputed statistics differ: " + name)
    summary = core.validate_cohort(list(final.values()))
    core.require(core.loads((root / "coverage.json").read_bytes()) == summary, "Coverage JSON differs")
    core.require(preserved == 7917 and unchanged_phase_items == 15834, "Target-only preservation count differs")
    unknowns = [i for i in flat.values() if i["score"] is None]
    unknown_csv = merge.unique(list(csv.DictReader(io.StringIO((root / 'remaining_unknown_items.csv').read_text()))),
                               lambda r: (r['candidate_id'], r['item_id']))
    core.require(set(unknown_csv) == {(i['candidate_id'], i['item_id']) for i in unknowns},
                 'UNKNOWN export inventory differs')
    for i in unknowns:
        for field, value in unknown_csv[i['candidate_id'], i['item_id']].items():
            core.require(value == ('' if i[field] is None else str(i[field])), 'UNKNOWN export changed')
    null_candidates = merge.unique(core.loads((root/'remaining_null_candidates.json').read_bytes()), lambda r:r['candidate_id'])
    core.require(set(null_candidates) == {cid for cid,r in final.items() if r['q_0_100'] is None}, 'Null-Q export inventory differs')
    for cid, r in null_candidates.items():
        expected_null = {'candidate_id':cid, 'task_id':final[cid]['task_id'], 'method':final[cid]['method'],
                         'q_0_100':None, 'unknown_item_ids':[i['item_id'] for i in final[cid]['items'] if i['score'] is None]}
        core.require(r == expected_null, 'Null-Q export content differs')
    claim_refs = [e for r in claim_data['records'] for e in r['evidence']]
    claim_available = sum(e['citation_kind'] == 'available_source' for e in claim_refs)
    # Scan reviewer-produced text, never rewrite user quotations or source artifacts.
    forbidden_root = "/workspace/shared/" + "eval250_q_scoring"
    leaked = []
    for path in root.rglob("*"):
        if path.is_file() and path.suffix in (".json", ".jsonl", ".csv", ".txt", ".md"):
            text = path.read_text()
            if forbidden_root in text or re.search(r"(?<![\w/])/root/[a-z_]", text): leaked.append(path.relative_to(root).as_posix())
    core.require(not leaked, "Internal coordinator path in published text")
    return {"status":"PASS_MECHANICAL_NOT_SEMANTIC", "checksum_files":hashed_count,
            "candidates":750,"effective_phase_views":1500,"retained_original_phase_records":1500,"supplement_source_phase_records":18,"supplement_target_item_phase_decisions":24,
            "final_items":7929,"unchanged_final_item_payloads":preserved,"unchanged_phase_item_payloads":unchanged_phase_items,
            "complete_q":sum(r["q_0_100"] is not None for r in final.values()),"null_q":sum(r["q_0_100"] is None for r in final.values()),
            "unknown_items":len(unknowns),"unknown_items_by_task":dict(sorted(Counter(i["task_id"] for i in unknowns).items())),
            "common_complete_tasks":recomputed["common_complete_task_count"],"phase_differences":len(differences),
            "native_calendar_reference_count":refs,
            "test_claim_source_phase_records":6,"test_claim_target_items":6,"test_claim_target_candidates":3,
            "test_claim_phase_item_decisions":12,"test_claim_source_normalization_verified":True,
            "native_calendar_reference_bytes_checked":refs-withheld_refs,
            "test_claim_reference_count":len(claim_refs),"test_claim_reference_bytes_checked":claim_available,
            "total_projected_target_evidence_references":refs+len(claim_refs),
            "projected_evidence_reference_bytes_checked":refs-withheld_refs+claim_available,
            "privacy_withheld_reference_hash_bindings":withheld_refs,
            "privacy_withheld_images":len(privacy_ledger["withheld"]),
            "original_supplement_archive_bytes_revalidated_in_this_public_copy":not privacy_mode,
            "supplement_archive_availability":"NOT_DISTRIBUTED_PRIVACY" if privacy_mode else "PRESENT_AND_PIN_VERIFIED",
            "privacy_recursive_archive_and_base64_scan":"PASS" if privacy_mode else "NOT_APPLICABLE",
            "all_statistics_recomputed_exactly":True,
            "internal_coordinator_path_scan":"PASS_TEXT_SCOPE","human_review_completed":False,"judge_calibration_completed":False,
            "limitations":"Original evidence image/full-manifest absence is not repaired by this byte-and-arithmetic verifier. No semantic rejudging or historical execution inference."}


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("release_root", nargs="?", default=str(Path(__file__).resolve().parent.parent))
    args = p.parse_args()
    print(json.dumps(verify(Path(args.release_root)), ensure_ascii=False, indent=2))
