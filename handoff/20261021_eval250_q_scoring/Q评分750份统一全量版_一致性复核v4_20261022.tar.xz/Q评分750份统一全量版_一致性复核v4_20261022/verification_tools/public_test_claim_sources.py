"""Offline, non-scoring publication adapter for the frozen T0030 reviews.

Only standard-library parsing, hashing and copying are used. No source program,
HTML, or historical verification program is executed. The two CHECK projections
change three routing-only strings, never evidence, scores, reasons or quotes.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import io
import json
import re
import shutil
import tempfile
import zipfile
from pathlib import Path, PurePosixPath

SCOPE = ["T0030-D1-01", "T0030-D3-02"]
PHASE_PINS = {
    "R-47D9DE53": {
        "DRAFT": "a710d26494fc66a652a78bb51d8d6579d17e9a128a60cf096e43feb780fdf8f6",
        "CHECK": "0e1215fe61c36f412e34bc8699c68b7906955705e004334c83e9b61d388cf4e0"},
    "R-880D7CE3": {
        "DRAFT": "14d3182be9e71d07947cd0b4daaa81272b9d48237256e1960d92268a1e3d14d7",
        "CHECK": "299c98d6f276d79bc5527f3b4b0845ad908e715950f47f0b1b2be01b594ead6b"},
    "R-B69E1568": {
        "DRAFT": "4a18f5efe7e1296a28c539abd6dd1062076216eca8c6e2f52a403a8991665652",
        "CHECK": "c53a99fd5a233abbbba2c2bc0e295fbc032a53c096bd137cd4928fe4749a04c8"},
}
BRIDGE_SOURCE_PIN = "03e5caf1b6eca1c0790e2e0cd4c859a02d2f4a728df255e7dc8deb148265b3f1"
# Filled from the exact, field-scoped projection of the frozen source bytes.
PROJECTED_PINS = {'judgments/R-880D7CE3/CHECK.json': 'b11060b2bdddff8751600df02b6fe6e5d82dd512d6e6c3ee01a2b5ca74225d70', 'judgments/R-B69E1568/CHECK.json': '38647e70cd73a706b8cdc84ef7e8366483f058305b3fbb9d17e6de60f491d632'}
SAFE_MAPPING_PIN = "98a77031c5bd25552c141469884c6d973b80f8e99bd1f886c16250d06259b7ee"
REDACTIONS = {
    "judgments/R-880D7CE3/CHECK.json": {
        "/integrity/packet_root": "../../reviewer/R-880D7CE3"},
    "judgments/R-B69E1568/CHECK.json": {
        "/path_bases/packet": "../../reviewer/R-B69E1568",
        "/path_bases/judgment": "."},
}
RECEIPT_PIN = "21db8a00cdcd3c6d4633fefd75907f636dd2666726c6329305906574aae4a8a3"
PATHS = {
    "mapping": "public_candidate_bridge.json",
    "records": "normalized_phase_items.json",
    "receipt": "public_sources_receipt.json",
    "manifest": "PUBLIC_MANIFEST.json",
}


class ValidationError(ValueError):
    """A frozen input, citation, public projection, or inventory is invalid."""


def require(condition, message):
    if not condition:
        raise ValidationError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True,
                      separators=(",", ":"), allow_nan=False).encode("utf-8")


def pretty(value):
    return (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n").encode("utf-8")


def _pairs(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, "duplicate JSON key: " + key)
        result[key] = value
    return result


def parse(data):
    return json.loads(data, object_pairs_hook=_pairs,
                      parse_constant=lambda x: (_ for _ in ()).throw(ValidationError(x)))


def pointer(value, location):
    require(isinstance(location, str) and (location == "" or location.startswith("/")),
            "invalid JSON pointer: " + str(location))
    for part in location.split("/")[1:]:
        part = part.replace("~1", "/").replace("~0", "~")
        try:
            value = value[int(part)] if isinstance(value, list) else value[part]
        except (KeyError, IndexError, ValueError, TypeError) as exc:
            raise ValidationError("unresolved JSON pointer: " + location) from exc
    return value


def walk(value, prefix=""):
    yield prefix, value
    if isinstance(value, dict):
        for key, child in value.items():
            yield from walk(child, prefix + "/" + key.replace("~", "~0").replace("/", "~1"))
    elif isinstance(value, list):
        for i, child in enumerate(value):
            yield from walk(child, prefix + "/" + str(i))


def safe_file(root, name):
    require(isinstance(name, str) and name and "\\" not in name, "invalid relative path")
    path = PurePosixPath(name)
    require(not path.is_absolute() and ".." not in path.parts, "unsafe path: " + name)
    result = root.joinpath(*path.parts)
    require(not any(p.is_symlink() for p in [result, *result.parents] if p != root.parent),
            "symlink is not allowed: " + name)
    return result


def all_files(root):
    files = {}
    for p in sorted(root.rglob("*")):
        require(not p.is_symlink(), "symlink is not allowed")
        if p.is_file():
            files[p.relative_to(root).as_posix()] = p.read_bytes()
    return files


def _scan_public(data, path):
    if path.endswith(".zip"):
        return
    text = data.decode("utf-8")
    require(not re.search(r"/workspace/shared(?:/|\\u002f)|/home/agent/|candidate_bridge\.json|"
                          r'"(?:agent_id|thread_id|source_directory|packet_directory)"', text),
            "internal routing or private bridge leakage: " + path)
    # Generic /workspace/inputs and /workspace/outputs are quoted candidate
    # artifacts, not evaluator paths. They are intentionally never rewritten.


def _project(path, data):
    changes = []
    if path not in REDACTIONS:
        _scan_public(data, path)
        return data, changes
    source = parse(data)
    projected = data
    for ptr, value in REDACTIONS[path].items():
        old = pointer(source, ptr)
        require(isinstance(old, str) and old.startswith("/workspace/shared/"),
                "expected routing-only internal path at " + path + ptr)
        old_token = json.dumps(old, ensure_ascii=False).encode()
        new_token = json.dumps(value, ensure_ascii=False).encode()
        require(projected.count(old_token) == 1, "ambiguous projection occurrence: " + ptr)
        projected = projected.replace(old_token, new_token, 1)
        changes.append({"json_pointer": ptr, "operation": "replace_routing_base",
                        "source_value_sha256": sha(canonical(old)), "public_value": value,
                        "reason": "Remove evaluator-local absolute path; preserve relative citation resolution."})
    after = parse(projected)
    before_masked = copy.deepcopy(source)
    for ptr, value in REDACTIONS[path].items():
        parent, key = ptr.rsplit("/", 1)
        pointer(before_masked, parent)[key] = value
    require(after == before_masked, "projection changed non-routing data")
    _scan_public(projected, path)
    return projected, changes


def _packet_validate(files):
    index = parse(files["reviewer/release_index.json"])
    require(index["scope"] == SCOPE, "release scope differs")
    require({x["review_id"] for x in index["packets"]} == set(PHASE_PINS), "packet IDs differ")
    manifests = {}
    for p in index["packets"]:
        rid = p["review_id"]
        prefix = "reviewer/" + rid + "/"
        raw = files[prefix + "MANIFEST.json"]
        digest = sha(raw)
        require(digest == p["manifest_sha256"], "manifest index pin differs")
        sidecar = files[prefix + "MANIFEST.sha256"].decode().strip().split()
        require(sidecar == [digest, "MANIFEST.json"], "manifest sidecar differs")
        manifest = parse(raw)
        require(manifest["review_id"] == rid and manifest["scope"] == SCOPE, "manifest scope/ID differs")
        members = {r["path"]: r for r in manifest["files"]}
        require(len(members) == len(manifest["files"]) == p["evidence_file_count"], "duplicate/count manifest members")
        actual = {k[len(prefix):] for k in files if k.startswith(prefix)}
        require(actual == set(members) | {"MANIFEST.json", "MANIFEST.sha256"}, "packet member inventory differs")
        for name, row in members.items():
            require(not PurePosixPath(name).is_absolute() and ".." not in PurePosixPath(name).parts,
                    "unsafe manifest member")
            data = files[prefix + name]
            require(len(data) == row["bytes"] and sha(data) == row["sha256"], "manifest member mismatch: " + prefix + name)
        archive = files["reviewer/" + p["archive"]]
        require(len(archive) == p["archive_bytes"] and sha(archive) == p["archive_sha256"], "archive pin mismatch")
        with zipfile.ZipFile(io.BytesIO(archive)) as z:
            names = z.namelist()
            expected = {rid + "/" + n for n in actual}
            require(len(names) == len(set(names)) and set(names) == expected, "archive members differ")
            for name in names:
                require(z.read(name) == files["reviewer/" + name], "archive payload mismatch: " + name)
        manifests[rid] = digest
    common = [k for k in files if k.startswith("reviewer/" + sorted(PHASE_PINS)[0] + "/common/")]
    for path in common:
        suffix = path.split("/", 2)[2]
        require(len({sha(files["reviewer/" + rid + "/" + suffix]) for rid in PHASE_PINS}) == 1,
                "common files diverged: " + suffix)
    return manifests


def _ranges(value):
    if isinstance(value, list) and len(value) == 2 and all(type(x) is int for x in value):
        return [value]
    require(isinstance(value, list), "invalid line range")
    require(all(isinstance(v, list) and len(v) == 2 and all(type(x) is int for x in v) for v in value),
            "invalid line ranges")
    return value


def _original_value(doc, ptr):
    """Locate an original metadata pointer through retained exact selections."""
    found = []
    for selection in doc.get("selections", []):
        base = selection["json_pointer"]
        if ptr == base:
            found.append(selection["value"])
        elif ptr.startswith(base + "/"):
            found.append(pointer(selection["value"], ptr[len(base):]))
    # Some refs cite a parent collection whose disclosed selected children are
    # intentionally partial. Existence is proven, not unavailable completeness.
    if not found:
        children = [s for s in doc.get("selections", []) if s["json_pointer"].startswith(ptr + "/")]
        require(children, "original pointer not disclosed: " + ptr)
        return {"partial_disclosed_children": [s["json_pointer"] for s in children]}
    require(all(v == found[0] for v in found), "conflicting retained selection values")
    return found[0]


def _ref_path(rid, ref):
    path = ref.get("path", ref.get("path_relative_to_check"))
    require(isinstance(path, str), "citation path is absent")
    if path == "DRAFT.json" or ref.get("base") == "judgment":
        return "judgments/" + rid + "/" + path
    return "reviewer/" + rid + "/" + path


def _validate_ref(files, rid, ref):
    path = _ref_path(rid, ref)
    if ref.get("body_available") is False:
        # This is a historical inventory record, not a claim of available body.
        inv = parse(files["reviewer/" + rid + "/metadata/receipt_evidence.json"])
        recorded = _original_value(inv, "/final_inventory/" + ref["path"].replace("~", "~0").replace("/", "~1"))
        require(recorded["sha256"] == ref["sha256"] and recorded["bytes"] == ref["bytes"],
                "unavailable historical file record differs")
        return dict(ref, resolved_path=None, citation_kind="unavailable_historical_inventory")
    require(path in files, "citation file absent: " + path)
    raw = files[path]
    require(sha(raw) == ref["sha256"], "citation hash mismatch: " + path)
    text = raw.decode()
    lines = text.splitlines()
    for key in ("lines", "lines_1_based", "line_ranges", "focused_lines_1_based"):
        if key in ref:
            ranges = ([[n, n] for n in ref[key]] if key == "focused_lines_1_based"
                      and all(type(n) is int for n in ref[key]) else _ranges(ref[key]))
            for lo, hi in ranges:
                require(1 <= lo <= hi <= len(lines), "citation line bounds: " + path + " " + str((lo, hi)))
    for ranges in ref.get("key_locations_zh", {}).values():
        for lo, hi in _ranges(ranges):
            require(1 <= lo <= hi <= len(lines), "key-location line bounds")
    locs = ref.get("json_pointers", []) + ([ref["json_pointer"]] if "json_pointer" in ref else [])
    doc = parse(raw) if path.endswith(".json") else None
    for loc in locs:
        pointer(doc, loc)
    if "recorded_value" in ref:
        require(any(pointer(doc, loc) == ref["recorded_value"] for loc in locs), "recorded value differs: " + path)
    originals = ref.get("original_json_pointers", []) + ref.get("original_source_json_pointers", [])
    if "original_json_pointer" in ref:
        originals += [ref["original_json_pointer"]]
    for loc in originals:
        _original_value(doc, loc)
    if "original_source_sha256" in ref:
        require(ref["original_source_sha256"] == doc.get("original_sha256"), "original source hash differs")
    quote_sources = [text] + ([v for _, v in walk(doc) if isinstance(v, str)] if doc else [])
    for key in ("quote", "exact_fragment"):
        if key in ref:
            require(any(ref[key] in source for source in quote_sources), "exact citation fragment absent: " + path)
    for fragment in ref.get("exact_fragments", []):
        require(any(fragment in source for source in quote_sources), "exact citation fragments absent: " + path)
    all_leaves = [v for _, v in walk(doc)] if doc else []
    for key in ("recorded_file_sha256", "recorded_report_string_sha256"):
        if key in ref:
            require(ref[key] in all_leaves, "recorded digest absent in cited JSON")
    for key in ("recorded_return_sha256", "call_ids"):
        for value in ref.get(key, []):
            require(value in all_leaves, "recorded identifier/digest absent in cited JSON")
    return dict(ref, resolved_path=path, public_byte_sha256=sha(raw), citation_kind="available_source")


def _catalog(doc):
    catalog = dict(doc.get("evidence_catalog", {}))
    for entry in doc.get("evidence", []):
        require(entry["id"] not in catalog, "duplicate evidence ID")
        catalog[entry["id"]] = entry
    return catalog


def _citations(files, rid, doc, item):
    catalog = _catalog(doc)
    out = []
    ids = item.get("evidence_ids", item.get("evidence_refs", item.get("refs", [])))
    if item.get("anchor_ref"):
        ids = ids + [item["anchor_ref"]]
    for token in ids:
        require(isinstance(token, str), "non-string evidence identifier")
        ident, _, suffix = token.partition(":")
        require(ident in catalog, "unresolved evidence ID: " + token)
        entry = catalog[ident]
        refs = [entry] if ("path" in entry or "path_relative_to_check" in entry) else entry.get("refs", entry.get("references", []))
        for ref in refs:
            require(isinstance(ref, dict), "nested symbolic citation not supported")
            resolved = _validate_ref(files, rid, ref)
            if suffix:
                source = files[resolved["resolved_path"]]
                for loc in suffix.split(","):
                    if loc.startswith("/"):
                        # Named suffixes may refer to original metadata coordinates.
                        data = parse(source)
                        try:
                            pointer(data, loc)
                        except ValidationError:
                            _original_value(data, loc)
                    else:
                        bounds = [int(x) for x in loc.split("-")]
                        lo, hi = (bounds[0], bounds[0]) if len(bounds) == 1 else bounds
                        require(1 <= lo <= hi <= len(source.decode().splitlines()), "symbolic line suffix out of bounds")
            out.append(dict(resolved, evidence_id=ident, source_reference=token,
                            source_evidence=copy.deepcopy(entry)))
    for key in ("rubric_refs",):
        for ref in item.get(key, []):
            out.append(_validate_ref(files, rid, ref))
    if "draft_ref" in item:
        out.append(_validate_ref(files, rid, item["draft_ref"]))
    return out


def _derive_records(files, manifests):
    records = []
    for rid in sorted(PHASE_PINS):
        for phase in ("DRAFT", "CHECK"):
            path = "judgments/" + rid + "/" + phase + ".json"
            raw = files[path]
            expected = PROJECTED_PINS.get(path, PHASE_PINS[rid][phase])
            require(sha(raw) == expected, "public phase pin mismatch: " + path)
            doc = parse(raw)
            require(doc["review_id"] == rid and doc["scope"] == SCOPE, "judgment ID/scope mismatch")
            for ptr, value in REDACTIONS.get(path, {}).items():
                require(pointer(doc, ptr) == value, "public routing projection mismatch")
            for at, value in walk(doc):
                if isinstance(value, dict):
                    if isinstance(value.get("path", value.get("path_relative_to_check")), str) and "sha256" in value:
                        _validate_ref(files, rid, value)
                    for refkey in ("evidence_ids", "evidence_refs", "refs", "references"):
                        symbols = value.get(refkey)
                        if isinstance(symbols, list) and symbols and all(isinstance(v, str) for v in symbols):
                            _citations(files, rid, doc, {"refs": symbols})
                    if "draft_pointer" in value:
                        pointer(parse(files["judgments/" + rid + "/DRAFT.json"]), value["draft_pointer"])
                if isinstance(value, str) and re.fullmatch(r"[0-9a-f]{64}", value):
                    key = at.rsplit("/", 1)[-1]
                    if "manifest" in key and "sha256" in key:
                        require(value == manifests[rid], "phase manifest hash mismatch")
                    if "draft" in key and "sha256" in key:
                        require(value == PHASE_PINS[rid]["DRAFT"], "CHECK-to-DRAFT hash mismatch")
            if "packet_verification" in doc:
                for key in ("expected_sha256", "observed_sha256"):
                    require(doc["packet_verification"][key] == manifests[rid], "draft manifest hash mismatch")
            field = "items" if "items" in doc else "judgments"
            items = doc[field]
            require(len(items) == 2 and {v["item_id"] for v in items} == set(SCOPE), "judgment item inventory differs")
            for i, item in enumerate(items):
                score = item["score"]
                require(score in (None, "UNKNOWN", 0, 0.5, 1) and not isinstance(score, bool), "invalid score value")
                normalized = None if score in (None, "UNKNOWN") else score
                if "check_score" in item:
                    require(item["check_score"] == score, "check_score and score disagree")
                evidence = _citations(files, rid, doc, item)
                require(evidence, "item has no resolved evidence")
                records.append({
                    "review_id": rid, "neutral_review_id": rid, "task_id": "T0030",
                    "phase": phase, "item_id": item["item_id"],
                    "status": "UNKNOWN" if normalized is None else "SCORED",
                    "score": normalized, "reason": item["reason_zh"],
                    "source_score": score, "source_status": item.get("status"),
                    "source_decision": item.get("decision", item.get("check_judgment", item.get("judgment"))),
                    "evidence": evidence,
                    "source_record": {"path": path, "source_byte_sha256": PHASE_PINS[rid][phase],
                                      "public_byte_sha256": sha(raw),
                                      "public_canonical_sha256": sha(canonical(doc)),
                                      "source_item_pointer": "/" + field + "/" + str(i),
                                      "source_item_canonical_sha256": sha(canonical(item))},
                    "source_item": copy.deepcopy(item),
                })
    return records


def _safe_mapping(bridge, files):
    require(bridge["scope"] == SCOPE, "bridge scope differs")
    rows = []
    require(len(bridge["candidates"]) == 3, "bridge row count differs")
    for row in sorted(bridge["candidates"], key=lambda r: r["review_id"]):
        rid = row["review_id"]
        require(rid in PHASE_PINS, "unknown bridge review ID")
        require(row["manifest_sha256"] == sha(files["reviewer/" + rid + "/MANIFEST.json"]), "bridge manifest differs")
        for name in ("outputs/验收报告.md", "outputs/问题清单.json"):
            require(row["source_hashes"][name] == sha(files["reviewer/" + rid + "/" + name]), "bridge artifact hash differs")
        rows.append({"review_id": rid, "task_id": "T0030", "original_method": row["original_method"],
                     "source_hashes": copy.deepcopy(row["source_hashes"])})
    require(len({r["review_id"] for r in rows}) == 3, "duplicate bridge ID")
    return rows


def build_public_sources(input_root, out_root):
    """Create a fresh offline public evidence tree; do not alter any input.

    Return mapping (3 safe rows), records (12 item-phase objects), receipt and
    relative paths. All return values are JSON serializable. Failure leaves no
    output tree. Existing destinations are refused, including empty directories.
    """
    root, out = Path(input_root).resolve(), Path(out_root).resolve()
    require(not out.exists(), "output destination already exists")
    require(root != out and root not in out.parents, "output may not be inside input")
    files = {}
    for name in ("reviewer", "judgments"):
        require(not (root / name).is_symlink(), "input subtree may not be a symlink")
        for rel, data in all_files(root / name).items():
            files[name + "/" + rel] = data
    raw_judgment_paths = {"judgments/" + rid + "/" + phase + ".json" for rid in PHASE_PINS for phase in PHASE_PINS[rid]}
    require({p for p in files if p.startswith("judgments/")} == raw_judgment_paths, "unexpected judgment source files")
    for rid, phases in PHASE_PINS.items():
        for phase, digest in phases.items():
            require(sha(files["judgments/" + rid + "/" + phase + ".json"]) == digest, "raw phase pin mismatch")
    manifests = _packet_validate(files)
    bridge_raw = (root / "private/candidate_bridge.json").read_bytes()
    require(sha(bridge_raw) == BRIDGE_SOURCE_PIN, "private bridge source pin mismatch")
    mapping = _safe_mapping(parse(bridge_raw), files)
    require(sha(canonical(mapping)) == SAFE_MAPPING_PIN, "safe mapping pin mismatch")
    public, ledger = {}, []
    for path, data in sorted(files.items()):
        projected, changes = _project(path, data)
        public[path] = projected
        ledger.append({"path": path, "source_byte_sha256": sha(data), "source_bytes": len(data),
                       "public_byte_sha256": sha(projected), "public_bytes": len(projected),
                       "transformation": "declared_json_routing_projection" if changes else "byte_identical",
                       "changes": changes})
    records = _derive_records(public, manifests)
    receipt = {
        "schema_version": "public-test-claim-sources-v1", "scope": SCOPE,
        "source_phase_pins": PHASE_PINS, "projected_phase_pins": PROJECTED_PINS,
        "private_bridge_source_byte_sha256": BRIDGE_SOURCE_PIN,
        "public_mapping_canonical_sha256": SAFE_MAPPING_PIN,
        "mapping_projection": {"retained_keys": ["review_id", "original_method", "source_hashes"],
                               "task_id_basis": "common/frozen_items.json task_id",
                               "omitted_keys": ["source_directory", "packet_directory", "manifest_sha256"],
                               "private_bridge_copied": False},
        "source_files": ledger,
        "validation": {"packet_manifests": manifests, "raw_phase_count": 6,
                       "normalized_item_phase_count": 12, "semantic_rescoring_performed": False,
                       "candidate_code_executed": False, "network_used": False,
                       "raw_source_files_modified": False,
                       "public_projection_fields": sum(len(v) for v in REDACTIONS.values()),
                       "public_projection_files": len(REDACTIONS)},
        "limitations": ["This is a model CHECK with DRAFT visible, not human approval or an independent first rating.",
                        "Original full metadata bodies were not supplied; original-source digests and field coordinates are provenance claims validated against disclosed excerpts, not reconstructed full files.",
                        "Historical inventory records with absent bodies are not file-existence or functional-test proofs.",
                        "Candidate /workspace/inputs and /workspace/outputs literals, artifact quotes and all judgment values remain unchanged."],
    }
    public[PATHS["mapping"]] = pretty(mapping)
    public[PATHS["records"]] = pretty(records)
    public[PATHS["receipt"]] = pretty(receipt)
    require(sha(public[PATHS["receipt"]]) == RECEIPT_PIN, "generated receipt differs from frozen field ledger")
    public[PATHS["manifest"]] = pretty({"schema_version": "public-test-claim-manifest-v1",
        "files": [{"path": p, "bytes": len(b), "sha256": sha(b)} for p, b in sorted(public.items())]})
    out.parent.mkdir(parents=True, exist_ok=True)
    stage = Path(tempfile.mkdtemp(prefix=".test-claim-public-", dir=out.parent))
    try:
        for path, data in public.items():
            target = safe_file(stage, path)
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
        validate_public_sources(stage)
        stage.rename(out)
    except Exception:
        shutil.rmtree(stage)
        raise
    return {"mapping": mapping, "records": records, "receipt": receipt, "paths": dict(PATHS)}


def validate_public_sources(out_root):
    """Verify a public tree offline, without private bridge or original paths."""
    files = all_files(Path(out_root).resolve())
    manifest = parse(files[PATHS["manifest"]])
    rows = manifest["files"]
    require(len(rows) == len({r["path"] for r in rows}), "duplicate public manifest member")
    require(set(files) == {r["path"] for r in rows} | {PATHS["manifest"]}, "public inventory differs")
    for row in rows:
        raw = files[row["path"]]
        require(len(raw) == row["bytes"] and sha(raw) == row["sha256"], "public hash/size mismatch: " + row["path"])
        # The generated bridge name is allowed only as a filename, never a copied private path.
        _scan_public(raw, row["path"]) if row["path"] not in (PATHS["receipt"], PATHS["manifest"]) else None
    manifests = _packet_validate(files)
    expected_records = _derive_records(files, manifests)
    require(parse(files[PATHS["records"]]) == expected_records, "normalized records differ from exact source judgments")
    mapping = parse(files[PATHS["mapping"]])
    require(sha(canonical(mapping)) == SAFE_MAPPING_PIN, "public safe mapping pin differs")
    receipt = parse(files[PATHS["receipt"]])
    require(sha(files[PATHS["receipt"]]) == RECEIPT_PIN, "frozen source/transformation receipt pin differs")
    require(receipt["source_phase_pins"] == PHASE_PINS and receipt["projected_phase_pins"] == PROJECTED_PINS,
            "receipt phase pins differ")
    require(receipt["private_bridge_source_byte_sha256"] == BRIDGE_SOURCE_PIN, "receipt bridge pin differs")
    require(receipt["public_mapping_canonical_sha256"] == SAFE_MAPPING_PIN, "receipt mapping pin differs")
    ledger = receipt["source_files"]
    source_paths = {p for p in files if p.startswith(("reviewer/", "judgments/"))}
    require(set(files) == source_paths | set(PATHS.values()), "unexpected public-tree file")
    require(len(ledger) == len(source_paths) and {r["path"] for r in ledger} == source_paths, "source ledger inventory differs")
    for row in ledger:
        path = row["path"]
        require(row["public_byte_sha256"] == sha(files[path]) and row["public_bytes"] == len(files[path]), "ledger public hash differs")
        if path not in REDACTIONS:
            require(row["source_byte_sha256"] == row["public_byte_sha256"] and row["source_bytes"] == row["public_bytes"]
                    and row["transformation"] == "byte_identical" and row["changes"] == [], "undeclared projection")
        else:
            rid, phase = path.split("/")[1], Path(path).stem
            require(row["source_byte_sha256"] == PHASE_PINS[rid][phase], "projection raw source hash differs")
            require(row["transformation"] == "declared_json_routing_projection", "projection declaration differs")
            changes = row["changes"]
            require({r["json_pointer"]: r["public_value"] for r in changes} == REDACTIONS[path]
                    and len(changes) == len(REDACTIONS[path]), "projection field ledger differs")
    require(receipt["validation"]["packet_manifests"] == manifests, "receipt manifests differ")
    return {"valid": True, "file_count": len(files), "record_count": len(expected_records),
            "source_phase_count": 6, "projected_field_count": 3,
            "public_manifest_sha256": sha(files[PATHS["manifest"]])}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input_root", nargs="?")
    parser.add_argument("out_root")
    parser.add_argument("--validate", action="store_true")
    args = parser.parse_args()
    result = validate_public_sources(args.out_root) if args.validate else build_public_sources(args.input_root, args.out_root)
    print(json.dumps(result if args.validate else {"paths": result["paths"], "records": len(result["records"])}, ensure_ascii=False, indent=2))
