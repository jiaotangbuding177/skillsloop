#!/usr/bin/env python3
"""NEW recovery verifier, not a byte-for-byte restoration of the lost qvalidate.

Standard library only. No network, GUI, candidate execution, uploads, or source
mutation. Real old-release schema adapter intentionally unavailable until bytes
are received and inspected. Pure merge functions below are synthetic-tested.
"""
import argparse
import copy
import hashlib
import io
import json
import math
from pathlib import Path, PurePosixPath
import re
import statistics
import zipfile

WEIGHTS = {"D1": .3, "D2": .2, "D3": .2, "D4": .2, "D5": .1}
METHODS = ("NoSkill", "AutoSkills", "Trace2Skills")
PINS = {"rubrics.jsonl": "b31eefb1434f3e7341de8fb7be31244b507ada59c5dee9e638c8b1f1de9b3d90",
        "scoring_policy.json": "1623b3be006c03a8d884cd882d270ebc3f667de73790557bf91a1237ad845ac2"}
OLD_ZIP_SHA = "d4d5fd86b002e20b5c7311d80513f13e4055e2b5cbf3fac42b4e8c6c56ffdb7b"
SUPPLEMENT_ZIP_SHA = "4cd4186926b09c603aa1c36d90714d821c25691fa1f2460ea0cef30454b4e2c7"
AUTHORIZED_TARGETS = {"Cdfc0bda9402e55d7": ("T0112", "T0112-D5-01"),
                      "Ce5353b9efbae40ec": ("T0171", "T0171-D5-02"),
                      "Ca0d90d663358a730": ("T0084", "T0084-D3-02")}


class Invalid(ValueError):
    pass


def require(condition, message):
    if not condition:
        raise Invalid(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def canonical_sha(value):
    return sha(json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode())


def loads(data):
    def pairs(values):
        result = {}
        for k, v in values:
            require(k not in result, "Duplicate JSON key")
            result[k] = v
        return result
    def bad(value):
        raise Invalid("Non-finite JSON constant: " + value)
    def finite_float(value):
        number = float(value)
        require(math.isfinite(number), "Non-finite JSON number")
        return number
    return json.loads(data, object_pairs_hook=pairs, parse_constant=bad, parse_float=finite_float)


def safe_name(name):
    require(isinstance(name, str) and bool(name), "Invalid archive path type")
    p = PurePosixPath(name)
    require(isinstance(name, str) and bool(name) and "\\" not in name and not p.is_absolute()
            and ".." not in p.parts and ":" not in name and str(p) == name, "Unsafe archive path")
    return name


def verify_archive(path, expected_sha, member_prefix=""):
    """Read and validate without extracting or executing any archived file."""
    raw = Path(path).read_bytes()
    require(sha(raw) == expected_sha, "Archive differs from externally pinned SHA256")
    with zipfile.ZipFile(io.BytesIO(raw)) as z:
        infos = z.infolist()
        require(len({i.filename for i in infos}) == len(infos), "Duplicate ZIP member")
        require(sum(i.file_size for i in infos) < 512 * 1024 * 1024, "Archive expansion exceeds bounded inspection limit")
        files = {}
        for i in infos:
            if i.is_dir():
                safe_name(i.filename.rstrip("/"))
                continue
            safe_name(i.filename)
            require((i.external_attr >> 16) & 0o170000 != 0o120000, "Symlink ZIP member forbidden")
            require(i.filename.startswith(member_prefix), "Unexpected archive root")
            name = i.filename[len(member_prefix):]
            safe_name(name)
            files[name] = z.read(i)  # ZIP CRC is checked during read.
    manifests = [n for n in ("SHA256SUMS", "SHA256SUMS.txt") if n in files]
    require(len(manifests) == 1, "Need one recognized root checksum manifest")
    manifest = manifests[0]
    entries = {}
    for line in files[manifest].decode("utf-8").splitlines():
        h, sep, name = line.partition("  ")
        require(sep and re.fullmatch("[0-9a-f]{64}", h), "Bad checksum line")
        safe_name(name)
        require(name not in entries, "Duplicate checksum entry")
        entries[name] = h
    require(set(entries) == set(files) - {manifest}, "Checksum inventory mismatch")
    for name, h in entries.items():
        require(sha(files[name]) == h, "Member SHA mismatch: " + name)
    return files


def load_release(root):
    root = Path(root)
    raw = {name: (root / name).read_bytes() for name in PINS}
    for name, expected in PINS.items():
        require(sha(raw[name]) == expected, "Frozen release changed: " + name)
    policy = loads(raw["scoring_policy.json"])
    require({d: v["weight"] for d, v in policy["dimensions"].items()} == WEIGHTS, "Dimension weights changed")
    tasks = {}
    for line in raw["rubrics.jsonl"].decode().splitlines():
        task = loads(line)
        tid = task["task_id"]
        require(tid not in tasks and task["dimension_weights"] == WEIGHTS, "Duplicate task or changed weights")
        ids = [i["item_id"] for i in task["items"]]
        require(len(ids) == len(set(ids)), "Duplicate rubric item")
        require({i["dimension"] for i in task["items"]} == set(WEIGHTS), "Missing dimension")
        for item in task["items"]:
            require(item["item_id"].startswith(tid + "-") and item["weight"] == 1 and
                    item["applicability"] == "APPLICABLE" and set(item["anchors"]) == {"0", "0.5", "1"}, "Changed frozen item")
        tasks[tid] = task
    require(set(tasks) == {f"T{i:04d}" for i in range(1, 251)} and
            sum(len(t["items"]) for t in tasks.values()) == 2643, "Frozen count mismatch")
    return tasks


def item_index(items, rubric):
    require(isinstance(items, list) and all(isinstance(r, dict) for r in items), "Missing item array")
    ids = [r.get("item_id") for r in items]
    require(len(ids) == len(set(ids)) and set(ids) == {i["item_id"] for i in rubric["items"]}, "Item coverage/duplicate mismatch")
    for row in items:
        score = row.get("score")
        require(row.get("status") in ("SCORED", "UNKNOWN"), "Unadapted or invalid item status")
        require((score is None) == (row["status"] == "UNKNOWN"), "Score/status mismatch")
        require(score is None or type(score) in (int, float) and math.isfinite(score) and score in (0, .5, 1), "Invalid score")
    return {r["item_id"]: r for r in items}


def aggregate(items, rubric):
    """Matches recovered legacy judge_v5 rounding order; no normalizing rules."""
    indexed = item_index(items, rubric)
    dims = {}
    for dim, weight in WEIGHTS.items():
        parts = [i for i in rubric["items"] if i["dimension"] == dim]
        total = sum(i["weight"] for i in parts)
        covered = [i for i in parts if indexed[i["item_id"]]["score"] is not None]
        covered_weight = sum(i["weight"] for i in covered)
        subtotal = sum(i["weight"] * indexed[i["item_id"]]["score"] for i in covered)
        dims[dim] = {"score_0_100": round(100 * subtotal / total, 8) if covered_weight == total else None,
                     "weight": weight, "fixed_weight_denominator": total, "covered_weight": covered_weight,
                     "known_weight_numerator": subtotal, "item_count": len(parts), "scored_item_count": len(covered),
                     "item_coverage": covered_weight / total,
                     "covered_item_mean_0_100_descriptive_only": round(100 * subtotal / covered_weight, 8) if covered_weight else None}
    complete = all(v["score_0_100"] is not None for v in dims.values())
    total = round(sum(dims[d]["score_0_100"] * w for d, w in WEIGHTS.items()), 8) if complete else None
    return {"q_0_100": total, "dimensions": dims, "status": "COMPLETE" if complete else "PARTIAL_EVIDENCE",
            "item_coverage": sum(i["score"] is not None for i in items) / len(items)}


def compose_phase(base, supplements, rubric, authorized_targets):
    """Pure composite constructor. NOT an adapter for the unavailable old ZIP.

    base must be an explicitly inspected/adapter-approved item-list projection.
    Each unchanged item embeds its entire original judgment payload. A targeted
    item embeds the entire new single-item phase record, with separate lineage.
    No new reviewer is attributed to untouched items or the whole candidate.
    """
    old_digest = canonical_sha(base)
    old = item_index(base["items"], rubric)
    require(base["phase"] in ("DRAFT", "CHECK") and base["task_id"] == rubric["task_id"], "Wrong phase/task")
    replacements = {}
    for new in supplements:
        key = (new.get("candidate_id"), new.get("task_id"), new.get("item_id"))
        require(key in authorized_targets, "Unapproved target; no anticipatory ICS changes")
        require(key[:2] == (base["candidate_id"], base["task_id"]) and new.get("phase") == base["phase"], "Supplement candidate/task/phase mismatch")
        iid = new["item_id"]
        require(iid in old and iid not in replacements, "Unknown or duplicate patch")
        require(new.get("review_scope") == "TARGETED_ITEM_ONLY" and new.get("model") == "gpt-6-astra", "Wrong review scope/model")
        require(type(new.get("score")) in (int, float) and new["score"] in (0, .5, 1) and new.get("status") == "SCORED", "Invalid supplement score")
        require(isinstance(new.get("reason"), str) and new["reason"].strip() and new.get("evidence"), "Missing supplemental rationale/evidence")
        replacements[iid] = new
    rows, ledger = [], []
    for original in base["items"]:
        iid = original["item_id"]
        replacement = replacements.get(iid)
        payload = copy.deepcopy(replacement if replacement is not None else original)
        rows.append({"item_id": iid, "score": payload["score"], "status": payload["status"],
                     "judgment_payload": payload, "assessment_source": {
                         "kind": "SUPPLEMENT_SINGLE_ITEM_PHASE" if replacement is not None else "BASE_PHASE_ITEM_UNCHANGED",
                         "phase": base["phase"], "record_canonical_sha256": canonical_sha(replacement) if replacement is not None else old_digest,
                         "item_payload_canonical_sha256": canonical_sha(payload)}})
        if replacement is not None:
            ledger.append({"item_id": iid, "before_status": original["status"], "before_score": original["score"],
                           "after_status": payload["status"], "after_score": payload["score"],
                           "before_item_sha256": canonical_sha(original), "after_phase_record_sha256": canonical_sha(replacement)})
    require(canonical_sha(base) == old_digest, "Base mutation")
    for row in rows:
        if row["item_id"] not in replacements:
            require(row["judgment_payload"] == old[row["item_id"]], "Non-target judgment changed")
    return {"schema_version": "q-recovery-composite-phase-v1", "candidate_id": base["candidate_id"],
            "task_id": base["task_id"], "phase": base["phase"], "items": rows,
            "base_phase_record": copy.deepcopy(base), "base_phase_record_canonical_sha256": old_digest,
            "changes": ledger, "whole_candidate_new_review_claimed": False,
            "source_originality": "DERIVED_COMPOSITE_NOT_ORIGINAL_JUDGE_RECORD",
            "cross_item_semantic_defect_review_performed_by_merger": False, **aggregate(rows, rubric)}


def finalize_pair(draft, check):
    require(draft["phase"] == "DRAFT" and check["phase"] == "CHECK", "Wrong finalization phases")
    require((draft["candidate_id"], draft["task_id"]) == (check["candidate_id"], check["task_id"]), "Finalization identity mismatch")
    out = copy.deepcopy(check)
    out.update(final_phase="CHECK", finalization_rule="CHECK_ONLY_NOT_MAX_NOT_AVERAGE",
               draft_composite_sha256=canonical_sha(draft), check_composite_sha256=canonical_sha(check))
    return out


def validate_cohort(final, task_count=250, item_count=7929):
    require(len(final) == task_count * 3 and len({r["candidate_id"] for r in final}) == len(final), "Candidate count/identity mismatch")
    require(sum(len(r["items"]) for r in final) == item_count, "Final item count mismatch")
    by_task = {}
    for r in final:
        require(r.get("method") in METHODS, "Need actual authorized method column, not inferred mapping")
        by_task.setdefault(r["task_id"], {})
        require(r["method"] not in by_task[r["task_id"]], "Duplicate method/task")
        by_task[r["task_id"]][r["method"]] = r
    require(len(by_task) == task_count and all(set(v) == set(METHODS) for v in by_task.values()), "Incomplete three-arm design")
    if task_count == 250:
        require(set(by_task) == {f"T{i:04d}" for i in range(1, 251)}, "Unexpected frozen task IDs")
    common = sorted(t for t, rs in by_task.items() if all(r["q_0_100"] is not None for r in rs.values()))
    groups = {}
    for m in METHODS:
        values = [rs[m]["q_0_100"] for rs in by_task.values()]
        known = [v for v in values if v is not None]
        groups[m] = {"candidate_count": len(values), "complete_q_count": len(known),
                     "full_task_mean": round(statistics.mean(known), 8) if len(known) == len(values) else None,
                     "covered_only_mean_descriptive": round(statistics.mean(known), 8) if known else None,
                     "same_common_task_mean": round(statistics.mean(by_task[t][m]["q_0_100"] for t in common), 8) if common else None}
    return {"candidates": len(final), "final_items": item_count,
            "complete_q": sum(r["q_0_100"] is not None for r in final),
            "null_q": sum(r["q_0_100"] is None for r in final),
            "unknown_items": sum(i["score"] is None for r in final for i in r["items"]),
            "common_complete_tasks": len(common), "common_task_ids": common, "groups": groups}


def assert_restored_baseline(summary):
    """Call ONLY on actual restored old bytes, never a prediction or test fixture."""
    for key, val in {"candidates": 750, "final_items": 7929, "complete_q": 718, "null_q": 32,
                     "unknown_items": 193, "common_complete_tasks": 237}.items():
        require(summary[key] == val, "Restored baseline differs: " + key)
    for method, count in {"NoSkill": 239, "AutoSkills": 240, "Trace2Skills": 239}.items():
        require(summary["groups"][method]["complete_q_count"] == count, "Restored per-method coverage differs")


def resolved_member(record_name, base, relative):
    # Resolve explicit record-relative bases but never permit package escape.
    require(not PurePosixPath(base).is_absolute() and not PurePosixPath(relative).is_absolute()
            and "\\" not in base + relative, "Absolute reference")
    parts = list(PurePosixPath(record_name).parent.parts)
    for part in (PurePosixPath(base) / relative).parts:
        if part == "..":
            require(bool(parts), "Reference escaped package")
            parts.pop()
        elif part != ".":
            parts.append(part)
    return safe_name("/".join(parts))


def supplement_preflight(files, tasks):
    records, references = [], 0
    require(sha(files["frozen_policy.json"]) == PINS["scoring_policy.json"], "Supplement policy mismatch")
    result = loads(files["results.json"])
    require(result["total_q"] is None and result["new_coverage"] is None and result["merged_into_original_750"] is False, "Supplement falsely claims merge")
    require(len(result["items"]) == 3 and {r["candidate_id"] for r in result["items"]} == set(AUTHORIZED_TARGETS), "Supplement target inventory mismatch")
    for cid, (tid, iid) in AUTHORIZED_TARGETS.items():
        target_name = f"records/{cid}/target_rubric.json"
        target = loads(files[target_name])
        item = next(i for i in tasks[tid]["items"] if i["item_id"] == iid)
        require(target["target_item"] == item and target["candidate_id"] == cid and target["task_id"] == tid, "Target rubric differs")
        for phase in ("DRAFT", "CHECK"):
            name = f"records/{cid}/{phase}.json"
            r = loads(files[name])
            require((r["candidate_id"], r["task_id"], r["item_id"], r["phase"]) == (cid, tid, iid, phase), "Phase identity mismatch")
            require(r["score"] == .5 and type(r["score"]) in (int, float) and r["status"] == "SCORED" and r["model"] == "gpt-6-astra", "Unexpected completed target score/model")
            require(r["review_scope"] == "TARGETED_ITEM_ONLY", "Supplement scope expanded")
            require(r["frozen_rubrics_sha256"] == PINS["rubrics.jsonl"] and r["frozen_policy_sha256"] == PINS["scoring_policy.json"], "Phase frozen pins differ")
            require(r["public_derivative"]["original_record_byte_identity_claimed"] is False, "Derivative provenance not disclosed")
            for ref in r["evidence"]:
                member = resolved_member(name, r["evidence_base"], ref["path"])
                require(member in files and sha(files[member]) == ref["sha256"], "Supplement evidence hash mismatch: " + member)
                locator = ref.get("location") if cid == "Cdfc0bda9402e55d7" else ref.get("locator")
                require(isinstance(locator, str) and bool(locator.strip()), "Missing evidence locator/location")
                references += 1
            records.append({"candidate_id": cid, "task_id": tid, "item_id": iid, "phase": phase,
                            "score": r["score"], "record_byte_sha256": sha(files[name]), "record_canonical_sha256": canonical_sha(r)})
        published = next(r for r in result["items"] if r["candidate_id"] == cid)
        check_name = f"records/{cid}/CHECK.json"
        require(published["item_id"] == iid and published["check_sha256"] == sha(files[check_name])
                and published["score"] == loads(files[check_name])["score"], "Final supplement not CHECK")
    return {"status": "PASS_MECHANICAL_ONLY", "targets": 3, "phase_records": 6,
            "evidence_references_hashed": references, "records": records,
            "old_release_loaded": False, "old_schema_adapter_ready": False, "merged": False,
            "new_total_q": None, "new_complete_q_count": None,
            "ics_observation_or_score_assumed": False, "semantic_or_visual_rejudging": False}


def write_fresh(path, value):
    path = Path(path)
    require(not path.exists(), "Refuse to overwrite any existing receipt")
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8") as f:
        json.dump(value, f, ensure_ascii=False, indent=2, allow_nan=False)
        f.write("\n")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    pre = commands.add_parser("preflight-supplement")
    pre.add_argument("--release", required=True)
    pre.add_argument("--zip", required=True)
    pre.add_argument("--out", required=True)
    old = commands.add_parser("inspect-restored-old")
    old.add_argument("--zip", required=True)
    old.add_argument("--out", required=True)
    args = parser.parse_args()
    if args.command == "preflight-supplement":
        files = verify_archive(args.zip, SUPPLEMENT_ZIP_SHA, "产物补评分_20261022_v2/")
        report = supplement_preflight(files, load_release(args.release))
        report["archive_sha256"] = SUPPLEMENT_ZIP_SHA
    else:
        files = verify_archive(args.zip, OLD_ZIP_SHA)
        report = {"status": "BYTES_VERIFIED_ADAPTER_PENDING", "archive_sha256": OLD_ZIP_SHA,
                  "members": [{"name": n, "bytes": len(b), "sha256": sha(b)} for n, b in sorted(files.items())],
                  "old_schema_adapter_ready": False, "baseline_counts_tested": False, "merged": False}
    report.update(verifier_identity="NEW_20261022_REIMPLEMENTATION_NOT_LOST_SCRIPT", verifier_sha256=sha(Path(__file__).read_bytes()))
    write_fresh(args.out, report)
    print(json.dumps({k: report[k] for k in ("status", "merged", "old_schema_adapter_ready")}))


if __name__ == "__main__":
    main()
