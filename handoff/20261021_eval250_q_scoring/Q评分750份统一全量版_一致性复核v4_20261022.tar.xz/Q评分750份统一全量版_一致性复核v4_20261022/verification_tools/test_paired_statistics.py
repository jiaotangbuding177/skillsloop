"""Synthetic-only tests for the independent postprocessor reimplementation.

These fixtures are not candidate judgments and are never delivery scores.
"""
import copy
import csv
import hashlib
import io
import json
import math
from pathlib import Path
import random
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

import paired_statistics as p


HERE = Path(__file__).resolve().parent
FIELDS = ["candidate_id", "task_id", "method", *p.METRICS, "category"]


def fixture():
    rows = []
    for index, tid in enumerate(p.TASK_IDS):
        for method_index, method in enumerate(p.METHODS):
            q = round(10 + index / 10 + 5 * method_index, 8)
            rows.append({"candidate_id": f"SYNTHETIC_{tid}_{method}", "task_id": tid,
                         "method": method, **{metric: q for metric in p.METRICS},
                         "category": "small" if index < 10 else "large"})
    return rows


class PairedStatisticsTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix=".synthetic_test_", dir=HERE)
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.path = self.root / "synthetic_candidate_scores.csv"

    def write(self, rows=None, fields=None):
        rows = fixture() if rows is None else rows
        fields = FIELDS if fields is None else fields
        with self.path.open("w", encoding="utf-8", newline="") as stream:
            writer = csv.DictWriter(stream, fieldnames=fields, extrasaction="ignore")
            writer.writeheader()
            writer.writerows(rows)
        return self.path

    def load(self, rows=None, **kwargs):
        return p.load_scores(self.write(rows), **kwargs)

    def test_exact_750_three_arm_design(self):
        cohort = self.load()
        self.assertEqual(len(cohort.rows), 750)
        for method in p.METHODS:
            self.assertEqual({tid for tid, m in cohort.rows if m == method}, p.TASK_SET)

    def test_missing_row_rejected(self):
        with self.assertRaises(p.Invalid):
            self.load(fixture()[:-1])

    def test_extra_row_rejected(self):
        rows = fixture()
        with self.assertRaises(p.Invalid):
            self.load(rows + [copy.deepcopy(rows[0])])

    def test_duplicate_task_method_rejected(self):
        rows = fixture()
        rows[-1]["task_id"] = "T0001"
        with self.assertRaises(p.Invalid):
            self.load(rows)

    def test_duplicate_candidate_id_rejected(self):
        rows = fixture()
        rows[-1]["candidate_id"] = rows[0]["candidate_id"]
        with self.assertRaises(p.Invalid):
            self.load(rows)

    def test_wrong_task_or_method_rejected(self):
        for field, value in [("task_id", "T0000"), ("task_id", "T0251"), ("task_id", "T001"),
                             ("task_id", " T0001"), ("method", "noskill"), ("method", "OTHER")]:
            with self.subTest(field=field, value=value):
                rows = fixture()
                rows[0][field] = value
                with self.assertRaises(p.Invalid):
                    self.load(rows)

    def test_invalid_scores_rejected_for_every_metric(self):
        for metric in p.METRICS:
            for value in ["nan", "NaN", "Inf", "-Infinity", "1e999", "-0.1", "100.1",
                          "true", "NA", "N/A", "1_0", "1e-9999", "０", "garbage"]:
                with self.subTest(metric=metric, value=value):
                    rows = fixture()
                    rows[0][metric] = value
                    with self.assertRaises(p.Invalid):
                        self.load(rows)

    def test_null_and_zero_stay_distinct(self):
        rows = fixture()
        for row, value in zip(rows, ["", "null", "NULL", "None", "UNKNOWN", " unknown "]):
            row["q_0_100"] = value
            row["D5_0_100"] = value
        rows[6].update({metric: "0" for metric in p.METRICS})
        cohort = self.load(rows)
        for row in rows[:6]:
            self.assertIsNone(cohort.rows[row["task_id"], row["method"]]["q_0_100"])
        self.assertEqual(cohort.rows["T0003", "NoSkill"]["q_0_100"], 0)

    def test_q_nullness_must_match_dimension_completeness(self):
        for metric in p.METRICS:
            rows = fixture()
            rows[0][metric] = "UNKNOWN"
            with self.assertRaises(p.Invalid):
                self.load(rows)

    def test_q_weighted_consistency_checked_without_replacement(self):
        rows = fixture()
        rows[0]["q_0_100"] = 11
        with self.assertRaises(p.Invalid):
            self.load(rows)
        rows[0].update(D1_0_100=33.33333333, D2_0_100=50, D3_0_100=100,
                       D4_0_100=50, D5_0_100=100, q_0_100=60)
        self.assertEqual(self.load(rows).rows["T0001", "NoSkill"]["q_0_100"], 60)

    def test_duplicate_missing_or_malformed_columns_rejected(self):
        for header in [FIELDS + ["method"], [f for f in FIELDS if f != "D3_0_100"], FIELDS + [""]]:
            self.write(fields=header)
            with self.assertRaises(p.Invalid):
                p.load_scores(self.path)
        self.write()
        with self.path.open("a", encoding="utf-8") as stream:
            stream.write("bad,extra,row\n")
        with self.assertRaises(p.Invalid):
            p.load_scores(self.path)

    def test_empty_csv_rejected(self):
        self.path.write_text("")
        with self.assertRaises(p.Invalid):
            p.load_scores(self.path)

    def test_category_optional_but_candidate_id_required(self):
        fields = [field for field in FIELDS if field != "category"]
        cohort = p.load_scores(self.write(fields=fields))
        self.assertIsNone(cohort.categories)
        self.assertIsNone(cohort.category_source)
        fields.remove("candidate_id")
        with self.assertRaises(p.Invalid):
            p.load_scores(self.write(fields=fields))

    def test_category_conflicts_or_partial_assignments_rejected(self):
        for value in ["different", "", "UNKNOWN"]:
            rows = fixture()
            rows[0]["category"] = value
            with self.assertRaises(p.Invalid):
                self.load(rows)
        wrong = {tid: "wrong" for tid in p.TASK_IDS}
        with self.assertRaises(p.Invalid):
            self.load(frozen_categories=wrong)
        with self.assertRaises(p.Invalid):
            self.load(frozen_categories={"T0001": "small"})

    def test_verified_frozen_categories_and_pin_loader(self):
        categories = {tid: "small" if i < 10 else "large" for i, tid in enumerate(p.TASK_IDS)}
        cohort = self.load(frozen_categories=categories)
        self.assertEqual(cohort.category_source, "SHA256_PINNED_FROZEN_RUBRICS")
        mock_tasks = {tid: {"category": c} for tid, c in categories.items()}
        with patch.object(p.recovery, "load_release", return_value=mock_tasks) as loader:
            self.assertEqual(p.read_frozen_categories("synthetic_frozen"), categories)
            loader.assert_called_once_with("synthetic_frozen")

    def test_different_missing_patterns_use_one_exact_intersection(self):
        rows = fixture()
        # Distinct missing tasks make per-method coverage sets differ.
        for row in rows:
            if (row["task_id"], row["method"]) in {
                    ("T0001", "NoSkill"), ("T0002", "AutoSkills"), ("T0003", "Trace2Skills")}:
                row["q_0_100"] = None
                row["D5_0_100"] = None
        cohort = self.load(rows)
        with patch.object(p, "BOOTSTRAP_REPLICATES", 31):
            summary = p.analyze(cohort)
        self.assertEqual(summary["common_complete_task_ids"], list(p.TASK_IDS[3:]))
        self.assertEqual(summary["common_complete_task_count"], 247)
        for method in p.METHODS:
            group = summary["groups"][method]
            self.assertEqual(group["q_coverage"]["complete_count"], 249)
            self.assertIsNone(group["q_coverage"]["all_tasks_micro_mean"])
            self.assertIsNotNone(group["q_coverage"]["covered_only_mean_descriptive"])
            self.assertIsNone(group["all250_category_macro_q_mean"])
            self.assertIsNone(group["categories"]["small"]["all_tasks_micro_mean"])
            self.assertIsNotNone(group["categories"]["large"]["all_tasks_micro_mean"])
            expected = p.round8(p.mean([cohort.rows[t, method]["q_0_100"] for t in p.TASK_IDS[3:]]))
            self.assertEqual(group["common_complete_q_mean"], expected)
        self.assertEqual([x["mean_paired_difference"] for x in summary["paired_differences"]], [5, 10, 5])

    def test_all_null_has_no_estimates_no_bootstrap_and_empty_task_export(self):
        rows = fixture()
        for row in rows:
            row["q_0_100"] = "UNKNOWN"
            row["D5_0_100"] = "UNKNOWN"
        cohort = self.load(rows)
        summary = p.analyze(cohort)
        self.assertEqual(summary["common_complete_task_count"], 0)
        self.assertEqual(summary["bootstrap"]["executed_replicates"], 0)
        for group in summary["groups"].values():
            self.assertIsNone(group["common_complete_q_mean"])
            self.assertIsNone(group["common_complete_q_ci_lower"])
            self.assertIsNone(group["q_coverage"]["covered_only_mean_descriptive"])
        for contrast in summary["paired_differences"]:
            self.assertIsNone(contrast["mean_paired_difference"])
            self.assertIsNone(contrast["ci_upper"])
        output = p.render_outputs(cohort, summary)
        self.assertEqual(len(list(csv.DictReader(io.StringIO(output[p.OUTPUT_NAMES[1]])))), 0)

    def test_single_complete_task_has_degenerate_intervals(self):
        rows = fixture()
        for row in rows:
            if row["task_id"] != "T0001":
                row["q_0_100"] = None
                row["D5_0_100"] = None
        with patch.object(p, "BOOTSTRAP_REPLICATES", 19):
            summary = p.analyze(self.load(rows))
        for group in summary["groups"].values():
            self.assertEqual(group["common_complete_q_mean"], group["common_complete_q_ci_lower"])
            self.assertEqual(group["common_complete_q_mean"], group["common_complete_q_ci_upper"])

    def test_percentile_linear_interpolation(self):
        self.assertEqual(p.percentile([0, 10, 20, 30], .025), 0.7500000000000001)
        self.assertAlmostEqual(p.percentile([0, 10, 20, 30], .975), 29.25)
        self.assertEqual(p.percentile([7], .025), 7)
        self.assertEqual(p.percentile([0, 10], 0), 0)
        self.assertEqual(p.percentile([0, 10], 1), 10)

    def test_full_10000_shared_bootstrap_matches_independent_reference(self):
        columns = [[0.0, 2.0, 9.0], [10.0, 12.0, 19.0], [10.0, 10.0, 10.0]]
        actual = p.bootstrap(columns)
        rng = random.Random(20261021)
        samples = []
        for _ in range(10000):
            draw = [rng.randrange(3) for _ in range(3)]
            samples.append(math.fsum(columns[0][i] for i in draw) / 3)
        samples.sort()
        def quantile(probability):
            fractional = (len(samples) - 1) * probability
            lo = int(fractional)
            frac = fractional - lo
            return samples[lo] * (1 - frac) + samples[min(lo + 1, len(samples) - 1)] * frac
        self.assertEqual(actual[0], {"mean": round(11 / 3, 8),
                                    "ci_lower": round(quantile(.025), 8),
                                    "ci_upper": round(quantile(.975), 8)})
        self.assertEqual(actual[2], {"mean": 10, "ci_lower": 10, "ci_upper": 10})
        self.assertAlmostEqual(actual[1]["ci_lower"] - actual[0]["ci_lower"], 10, places=8)
        self.assertAlmostEqual(actual[1]["ci_upper"] - actual[0]["ci_upper"], 10, places=8)

    def test_reordered_input_identical_normalized_data_and_statistics(self):
        cohort1 = self.load()
        rows = fixture()
        random.Random(9).shuffle(rows)
        cohort2 = self.load(rows)
        self.assertEqual(cohort1.normalized_scores_sha256, cohort2.normalized_scores_sha256)
        with patch.object(p, "BOOTSTRAP_REPLICATES", 23):
            result1, result2 = p.analyze(cohort1), p.analyze(cohort2)
        self.assertNotEqual(result1.pop("source_csv_sha256"), result2.pop("source_csv_sha256"))
        self.assertEqual(result1, result2)

    def test_macro_is_equal_weighted_categories_not_task_micro_mean(self):
        with patch.object(p, "BOOTSTRAP_REPLICATES", 11):
            summary = p.analyze(self.load())
        group = summary["groups"]["NoSkill"]
        self.assertEqual(group["all250_category_macro_q_mean"], 16.7)
        self.assertEqual(group["q_coverage"]["all_tasks_micro_mean"], 22.45)
        self.assertIsNone(group["category_macro_unavailable_reason"])

    def test_dimension_coverage_is_independent_and_null_safe(self):
        rows = fixture()
        rows[0]["D4_0_100"] = None
        rows[0]["q_0_100"] = None
        with patch.object(p, "BOOTSTRAP_REPLICATES", 11):
            summary = p.analyze(self.load(rows))
        dim = summary["groups"]["NoSkill"]["dimensions"]["D4_0_100"]
        self.assertEqual(dim["complete_count"], 249)
        self.assertIsNone(dim["all_tasks_micro_mean"])

    def test_exports_four_named_files_hashes_and_explicit_null(self):
        cohort = self.load()
        with patch.object(p, "BOOTSTRAP_REPLICATES", 11):
            output = p.render_outputs(cohort, p.analyze(cohort))
        self.assertEqual(set(output), set(p.OUTPUT_NAMES))
        summary = json.loads(output[p.OUTPUT_NAMES[0]])
        self.assertEqual(summary["implementation_origin"], p.ORIGIN)
        for name, digest in summary["output_csv_sha256"].items():
            self.assertEqual(digest, hashlib.sha256(output[name].encode()).hexdigest())
        self.assertEqual(len(list(csv.DictReader(io.StringIO(output[p.OUTPUT_NAMES[1]])))), 250)
        self.assertEqual(len(list(csv.DictReader(io.StringIO(output[p.OUTPUT_NAMES[2]])))), 3)
        self.assertEqual(len(list(csv.DictReader(io.StringIO(output[p.OUTPUT_NAMES[3]])))), 3)
        self.assertEqual(p.csv_text(["x"], [{"x": None}, {"x": 0.0}]), 'x\n""\n0.00000000\n')

    def test_output_requires_explicit_overwrite(self):
        cohort = self.load()
        with patch.object(p, "BOOTSTRAP_REPLICATES", 3):
            output = p.render_outputs(cohort, p.analyze(cohort))
        outdir = self.root / "outputs"
        p.write_outputs(outdir, output)
        with self.assertRaises(p.Invalid):
            p.write_outputs(outdir, output)
        p.write_outputs(outdir, output, overwrite=True)
        for name, content in output.items():
            self.assertEqual((outdir / name).read_text(), content)

    def test_cli_full_10000_synthetic_run_and_repeat(self):
        self.write()
        outdir = self.root / "cli_output"
        command = [sys.executable, str(HERE / "paired_statistics.py"), str(self.path),
                   "--output-dir", str(outdir)]
        result = subprocess.run(command, check=True, capture_output=True, text=True)
        receipt = json.loads(result.stdout)
        self.assertEqual(receipt["candidate_count"], 750)
        self.assertEqual(receipt["common_complete_task_count"], 250)
        summary = json.loads((outdir / p.OUTPUT_NAMES[0]).read_text())
        self.assertEqual(summary["bootstrap"]["replicates"], 10000)
        self.assertEqual(summary["bootstrap"]["seed"], 20261021)
        self.assertEqual([x["mean_paired_difference"] for x in summary["paired_differences"]], [5, 10, 5])
        for contrast in summary["paired_differences"]:
            self.assertEqual(contrast["ci_lower"], contrast["ci_upper"])
        before = {name: (outdir / name).read_bytes() for name in p.OUTPUT_NAMES}
        subprocess.run(command + ["--overwrite"], check=True, capture_output=True)
        self.assertEqual(before, {name: (outdir / name).read_bytes() for name in p.OUTPUT_NAMES})


if __name__ == "__main__":
    unittest.main()
