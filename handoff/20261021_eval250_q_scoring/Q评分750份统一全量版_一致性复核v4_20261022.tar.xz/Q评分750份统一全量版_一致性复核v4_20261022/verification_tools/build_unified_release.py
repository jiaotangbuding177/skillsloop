#!/usr/bin/env python3
"""Build a fresh unified public copy from already validated source artifacts.

No judging, no network, no edits to source archives, no source script execution.
"""
import argparse
import csv
import io
import json
from pathlib import Path
import shutil
import sys
import zipfile

sys.dont_write_bytecode = True
import recovery_core as core
import merge_release as merge
import verify_unified


def dump(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n")


def manifest(root):
    lines = [core.sha(p.read_bytes()) + "  " + p.relative_to(root).as_posix()
             for p in sorted(root.rglob("*")) if p.is_file() and p != root / "SHA256SUMS.txt"]
    (root / "SHA256SUMS.txt").write_text("\n".join(lines) + "\n")


def run(args):
    stage, stats, out, suppzip, zipout = map(Path, (args.stage,args.statistics,args.out,args.supplement,args.zip))
    core.require(not out.exists() and not zipout.exists(), "Fresh output directory and ZIP required")
    core.require(core.sha(suppzip.read_bytes()) == merge.SUPP_SHA, "Supplement source pin differs")
    shutil.copytree(stage, out)
    for p in stats.iterdir():
        core.require(p.is_file() and p.name.startswith("common_complete_"), "Unexpected statistical output")
        shutil.copyfile(p, out / p.name)
    shutil.copyfile(suppzip, out / "history/产物补评分_20261022_v3.zip")
    shutil.copyfile(out / "公开合并机械审计.json", out / "history/合并阶段机械审计.json")
    source = Path(__file__).resolve().parent
    (out / "verification_tools").mkdir()
    for name in ("recovery_core.py","merge_release.py","paired_statistics.py","verify_unified.py",
                 "build_unified_release.py","privacy_evidence.py","test_recovery_core.py","test_paired_statistics.py"):
        shutil.copyfile(source / name, out / "verification_tools" / name)
    coverage = core.loads((out / "coverage.json").read_bytes())
    common = core.loads((out / "common_complete_summary.json").read_bytes())
    changes = merge.jsonl((out / "supplement_changes.jsonl").read_bytes())
    finalitems = merge.jsonl((out / "final_items.jsonl").read_bytes())
    final = merge.jsonl((out / "final_candidates.jsonl").read_bytes())
    unknowns = [i for i in finalitems if i["score"] is None]
    fields = ["candidate_id","task_id","method","item_id","dimension","status","score","reason"]
    with (out / "remaining_unknown_items.csv").open("x", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields); w.writeheader()
        w.writerows({k:i[k] for k in fields} for i in unknowns)
    dump(out / "remaining_null_candidates.json", [
        {"candidate_id":r["candidate_id"],"task_id":r["task_id"],"method":r["method"],"q_0_100":None,
         "unknown_item_ids":[i["item_id"] for i in r["items"] if i["score"] is None]}
        for r in final if r["q_0_100"] is None])
    lines = ["Q评分750份统一全量版 · 2026-10-22", "",
        "这是已完成的全部750份评分记录，不是750份均有数值Q。",
        "250题 × 三组基线；750个候选、1500个有效阶段视图、7929个最终条目。",
        "本版724份有完整Q，26份Q为空；187个条目仍为UNKNOWN。",
        "三组均有完整Q的共同任务为241题。所有分组比较应区分共同任务与各组自己的覆盖集。", "",
        "共同241题均值及95%任务bootstrap区间："]
    for method in core.METHODS:
        g = common["groups"][method]
        lines.append(f"{method}：{g['common_complete_q_mean']:.8f} [{g['common_complete_q_ci_lower']:.8f}, {g['common_complete_q_ci_upper']:.8f}]")
    lines += ["", "共同241题配对差值，前者减后者："]
    for p in common["paired_differences"]:
        lines.append(f"{p['contrast']}：{p['mean_paired_difference']:.8f} [{p['ci_lower']:.8f}, {p['ci_upper']:.8f}]")
    lines += ["", "各组已覆盖子集，仅作描述性统计，不能当作共同任务比较："]
    for method in core.METHODS:
        g = common["groups"][method]["q_coverage"]
        lines.append(f"{method}：{g['complete_count']}/250份完整Q；覆盖集均值{g['covered_only_mean_descriptive']:.8f}。")
    lines += ["各组完整250题Q均值及全类别宏均值均保持null；缺失没有填0或删分母。", "",
        "本次仅补入六个原UNKNOWN条目，各自DRAFT/CHECK两阶段，共12条单项来源决定。",
        "其余7923个最终条目对象和所有非目标阶段条目原样保留。最终仍只取CHECK。",
        "DRAFT/CHECK分值或状态差异从原89项变为90项；新增差异是T0144的NoSkill候选，DRAFT为1、CHECK为0.5。", "",
        "剩余26份：24份网页候选仍缺足够实际运行/可视证据；另2份涉及历史测试执行真实性，当前重跑不能证明当年的执行。",
        "不再要求用户寻找已确认不存在的历史文件。UNKNOWN列表及原因已单独导出。", "",
        "本评分为未人工校准的探索性模型评审。CHECK可见DRAFT，不是统计独立首评。",
        "区间只反映共同完整任务的重采样变动，不校准judge，不覆盖缺失偏差，也不证明全250题排名。"]
    (out / "评分结果摘要.txt").write_text("\n".join(lines)+"\n")
    target_lines=[]
    for c in changes:
        if c["phase"] == "CHECK":
            draft = next(x for x in changes if x["candidate_id"] == c["candidate_id"] and x["phase"] == "DRAFT")
            target_lines.append(f"{c['candidate_id']} / {c['method']} / {c['item_id']}：UNKNOWN → DRAFT {draft['after_score']} / CHECK {c['after_score']}；最终Q={c['after_q_0_100']:.8f}。")
    method = """方法与来源说明

1. 冻结规则
冻结250题、2643个量表条目，三组共7929个最终条目。单项仅0、0.5、1或UNKNOWN。
D1–D5权重为0.3、0.2、0.2、0.2、0.1。每维度固定使用全部适用条目的权重分母；任一条目UNKNOWN则该维度null，任一维度null则Q null。
已判条目不受未知项牵连而被改分；UNKNOWN不当0、不重分配权重、不乘TSR。维度分先round到8位，再按固定维度权重求Q并round到8位。
本版所有汇总从实际恢复的旧记录和新补阶段记录计算，不按均值倒推旧分、不猜造缺失分。

2. 版本及阶段来源
history中的基线ZIP为真实恢复的上一完整公开发行，逐字节保留。它包含750条DRAFT、750条CHECK以及上一版最终数据；这些已经是公开发行派生记录，不是原始未脱敏judge记录。
顶层DRAFT.jsonl和CHECK.jsonl各750条，是本版有效阶段视图。每阶段744条候选记录沿用旧对象，6条候选记录为单项来源组合。总计12条组合记录不能理解为12次整份候选重评。
组合记录的schema为qjudging-composite-public-result-v2，顶层judge_id为空，逐项声明TARGETED_ITEM_ONLY及source_review_record。原基线评审身份和盲态说明保留在base_phase_source；旧defects只指原阶段，不能冒充补评者对其余条目的意见。
原1500阶段记录完整保存在history基线ZIP，新增12条单项阶段记录完整保存在supplement_evidence_v3。二者不是1512次整份候选评价。final_candidates和final_items始终按CHECK，不择高、不平均、不以DRAFT替换CHECK。
所有非目标阶段条目对象保持完全一致；7923个非目标最终条目对象保持完全一致，包括原理由与用户产物引文。本次未进行新的语义评分。

3. 六项补评
""" + "\n".join(target_lines) + """
日历新中性ID不是旧candidate_id。桥接仅按T0144、已经公开的方法名及ICS和CSV两份原件的字节SHA共同核验；calendar_candidate_binding.json给出可核查的公开连接，不公开私有桥表路径。
新补评仍由GPT-6 Astra进行。CHECK可见对应DRAFT，是另一次来源审阅，不是独立首评分，也不构成人工复核或可靠性校准。

4. 盲态和历史补证的边界
不能把整个本版称为全量重新独立盲评。上一补证版本中11个候选的定向复核看过同候选自己的旧阶段判断，historical_scores_exposed=true；它们未看方法身份、TSR或组间排名。该既有披露保留在原发行和原记录，不能改称对历史分数盲态。
本次新单项来源按各原记录披露其可见材料；CHECK看过DRAFT这一事实保留。组合与统计阶段在已公开方法身份下进行，但没有据此改变语义判断。

5. 不确定性与统计
共同241题比较采用三组完整Q任务的同一交集，所有均值和配对差都在同一任务集合上计算。
每次重采样以任务为单位，三个方法和三种差值共用相同抽样下标。random.Random(20261021)，10000次；任务ID升序，百分位区间在(B-1)p处线性插值，显示值round8。
各组覆盖集均值另列，只是描述性统计；完整250题均值和全类别宏均值因缺失仍为null。缺失可能非随机，不能把共同完整案例推广为全250题结论。bootstrap区间不量化judge系统误差，不代表校准，也不是全任务排名的认证。

6. 证据与公开记录边界
原基线的evidence_metadata_index是证据元数据索引，不是完整可直接重跑的证据manifest。原source_result_sha256、原manifest SHA指向其原来源，不是当前公开JSON行的字节SHA。
本版保留旧ZIP字节、新补证原ZIP字节和新补证材料；引用路径在组合投影中只加便携前缀，source_reference_path保留原值。原单项记录及原引文可逐字节核验。没有假称恢复全部旧图片、未公开manifest或原judge文件。
24个网页候选仍缺运行/可视证据，2个历史测试候选仍缺当时执行真实性证据。当前日历导入实测不证明历史执行，也不关闭网页缺口。不会让用户继续找已确认不存在的历史文件。

7. 机械复核与重实现
verification_tools内为本次重新编写的标准库工具，不冒充已丢失的原qvalidate。验证归档与成员哈希、冻结版本、750/1500/7929覆盖、来源桥接、目标限定、CHECK取终值、固定分母及全部聚合和统计。
机械PASS只表示字节、结构、来源投影和算术一致，不表示模型判断必然正确，不替代人工校准。未执行归档内的候选程序或原评分代码。
本版独立发行SHA256SUMS针对本包实际字节；与旧来源SHA明确分开。历史包只用于追溯，不需要用户拼装来获得本版完整结果。
"""
    (out / "方法与来源说明.txt").write_text(method)
    (out / "先读我.txt").write_text("""这是750份统一全量结果包，直接使用顶层文件即可，不必拼接补包。

建议顺序：
1. 评分结果摘要.txt：覆盖、共同任务比较和明确限制。
2. candidate_scores.csv：全部750候选的最终Q、D1–D5和覆盖率；空单元格是缺证，不是零分。
3. final_item_scores.csv：7929个最终条目的可筛选表；final_items.jsonl保留完整理由及证据来源。
4. final_candidates.jsonl：750份最终完整记录；DRAFT.jsonl、CHECK.jsonl是1500个有效阶段视图。
5. common_complete_*.csv/json：共同241题分数、均值、配对差值、确定seed的bootstrap及各组覆盖描述。
6. supplement_changes.jsonl、item_preservation_audit.jsonl：12条单项阶段变更和全部条目的保留审计。
7. remaining_null_candidates.json、remaining_unknown_items.csv：26份空Q候选与187个UNKNOWN条目。
8. 方法与来源说明.txt：科学来源、盲态、补评范围及证据边界。

复验（Python 3.10或更高，标准库，无联网）：
在解压根目录执行：python verification_tools/verify_unified.py .
它只读取本包，不修改评分、原件或引用，不需要私有桥表。bootstrap会重新计算10000次。
运行自测：PYTHONDONTWRITEBYTECODE=1 python -m unittest discover -s verification_tools -p 'test_*.py'
需要另行导出同一统计时：PYTHONDONTWRITEBYTECODE=1 python verification_tools/paired_statistics.py candidate_scores.csv --output-dir 另一个新目录 --frozen-release-root rubric_release
不要把另行输出写进本包再期望原SHA清单仍保持完整。

history保存不可变来源归档；supplement_evidence_v3保存补证原记录和相关材料。历史版本中旧总数、旧缺证说明仅代表其历史状态，本版以顶层结果和说明为准。
所有原始候选产物和旧全量图片没有重复打包；旧元数据索引不能冒充完整证据manifest。当前新增补证相关原件和画面已包含。
""")
    audit = core.loads((out / "公开合并机械审计.json").read_bytes())
    audit.update(publication_state="UNIFIED_RELEASE_MECHANICALLY_VERIFIED_NOT_SEMANTIC_CALIBRATION",
                 bootstrap_replicates=10000, bootstrap_seed=20261021, statistics_recomputed=True,
                 retained_original_phase_records=1500, supplement_target_phase_records=12,
                 stage_audit_byte_sha256=core.sha((out / "history/合并阶段机械审计.json").read_bytes()))
    dump(out / "公开合并机械审计.json", audit)
    manifest(out)
    report = verify_unified.verify(out)
    report["checksum_files"] += 1  # The read-only verification receipt is added below.
    dump(out / "公开发行复验.json", report)
    manifest(out)
    second = verify_unified.verify(out)
    core.require(second == report, "Final receipt differs after its own inclusion")
    zipout.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(zipout, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for p in sorted(out.rglob("*")):
            if p.is_file():
                name = out.name + "/" + p.relative_to(out).as_posix()
                info = zipfile.ZipInfo(name, date_time=(2026,10,22,0,0,0))
                info.compress_type = zipfile.ZIP_DEFLATED; info.create_system=3; info.external_attr=0o100644 << 16
                z.writestr(info, p.read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    zh = core.sha(zipout.read_bytes())
    verified = core.verify_archive(zipout, zh, out.name + "/")
    core.require(len(verified) == report["checksum_files"] + 1, "Final ZIP inventory differs")
    print(json.dumps({"status":"FROZEN_READY_FOR_INDEPENDENT_ACCEPTANCE","zip_name":zipout.name,"bytes":zipout.stat().st_size,
                      "sha256":zh,"verified_members":len(verified),"verification":report},ensure_ascii=False,indent=2))


if __name__ == "__main__":
    p=argparse.ArgumentParser(description=__doc__)
    for name in ("stage","statistics","supplement","out","zip"): p.add_argument("--"+name,required=True)
    run(p.parse_args())
