"""Portable offline tests for either original review inputs or public evidence.

The public package deliberately omits original bytes for two redacted CHECK
files and the private bridge. Those original-source assertions are explicitly
skipped, never inferred from source digests recorded in the public receipt.
All public inventory, citation, normalization and tamper tests still run.
"""
import copy
import json
import shutil
import tempfile
import unittest
from pathlib import Path

import public_test_claim_sources as m

INPUT = Path(__file__).resolve().parent.parent / "test_claim_review_20261022"
PUBLIC_INPUT = Path(__file__).resolve().parent.parent / "test_claim_evidence"
SOURCE_NOT_DISTRIBUTED = (
    "Original review inputs and private bridge are not distributed in the public package; "
    "source-byte verification cannot be inferred from recorded public hashes."
)


class PublicSourcesTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory(prefix="test-public-claim-")
        cls.base = Path(cls.tmp.name)
        cls.out = cls.base / "public"
        cls.original_inputs_available = (INPUT / "private/candidate_bridge.json").is_file()
        if cls.original_inputs_available:
            cls.source_before = {p: m.sha(v) for p, v in m.all_files(INPUT / "judgments").items()}
            cls.result = m.build_public_sources(INPUT, cls.out)
        else:
            if not PUBLIC_INPUT.is_dir():
                raise FileNotFoundError(
                    "Neither original test_claim_review_20261022 inputs nor bundled "
                    "test_claim_evidence are available beside the test-tool directory."
                )
            shutil.copytree(PUBLIC_INPUT, cls.out)
            m.validate_public_sources(cls.out)
            cls.result = {key: m.parse((cls.out / m.PATHS[key]).read_bytes())
                          for key in ("mapping", "records", "receipt")}
            cls.result["paths"] = dict(m.PATHS)

    @classmethod
    def tearDownClass(cls):
        cls.tmp.cleanup()

    def modified(self, label):
        target = self.base / label
        shutil.copytree(self.out, target)
        return target

    def reseal(self, root):
        files = m.all_files(root)
        files.pop(m.PATHS["manifest"])
        (root / m.PATHS["manifest"]).write_bytes(m.pretty({
            "schema_version": "public-test-claim-manifest-v1",
            "files": [{"path": p, "bytes": len(b), "sha256": m.sha(b)} for p, b in sorted(files.items())],
        }))

    def test_end_to_end_and_contract(self):
        verdict = m.validate_public_sources(self.out)
        self.assertTrue(verdict["valid"])
        self.assertEqual(verdict["record_count"], 12)
        self.assertEqual(len(self.result["mapping"]), 3)
        keys = [(r["review_id"], r["phase"], r["item_id"]) for r in self.result["records"]]
        self.assertEqual(len(set(keys)), 12)
        for record in self.result["records"]:
            self.assertEqual(record["status"], "UNKNOWN" if record["score"] is None else "SCORED")
            doc = m.parse((self.out / record["source_record"]["path"]).read_bytes())
            item = m.pointer(doc, record["source_record"]["source_item_pointer"])
            self.assertEqual(item, record["source_item"])
            self.assertEqual(record["reason"], item["reason_zh"])
            self.assertEqual(m.sha(m.canonical(item)), record["source_record"]["source_item_canonical_sha256"])

    def test_raw_sources_untouched(self):
        if not self.original_inputs_available:
            self.skipTest(SOURCE_NOT_DISTRIBUTED)
        self.assertEqual(self.source_before, {p: m.sha(v) for p, v in m.all_files(INPUT / "judgments").items()})
        for rid, phases in m.PHASE_PINS.items():
            for phase, pin in phases.items():
                self.assertEqual(pin, m.sha((INPUT / "judgments" / rid / (phase + ".json")).read_bytes()))

    def test_only_three_declared_fields_change(self):
        ledger = self.result["receipt"]["source_files"]
        changed = [r for r in ledger if r["source_byte_sha256"] != r["public_byte_sha256"]]
        self.assertEqual({r["path"] for r in changed}, set(m.REDACTIONS))
        self.assertEqual(sum(len(r["changes"]) for r in changed), 3)
        for row in changed:
            projection = m.parse((self.out / row["path"]).read_bytes())
            for pointer, value in m.REDACTIONS[row["path"]].items():
                self.assertEqual(m.pointer(projection, pointer), value)
            self.assertEqual(row["public_byte_sha256"], m.sha((self.out / row["path"]).read_bytes()))

    def test_original_source_projection_changes_no_other_fields(self):
        if not self.original_inputs_available:
            self.skipTest(SOURCE_NOT_DISTRIBUTED)
        for path, changes in m.REDACTIONS.items():
            original = m.parse((INPUT / path).read_bytes())
            projection = m.parse((self.out / path).read_bytes())
            for pointer, value in changes.items():
                parent, name = pointer.rsplit("/", 1)
                m.pointer(original, parent)[name] = value
            self.assertEqual(original, projection)

    def test_literal_unknown_not_zero(self):
        records = self.result["records"]
        r = next(r for r in records if (r["review_id"], r["phase"], r["item_id"]) ==
                 ("R-B69E1568", "CHECK", "T0030-D1-01"))
        self.assertEqual(r["source_score"], "UNKNOWN")
        self.assertIsNone(r["score"])
        self.assertEqual(r["status"], "UNKNOWN")
        r = next(r for r in records if (r["review_id"], r["phase"], r["item_id"]) ==
                 ("R-B69E1568", "CHECK", "T0030-D3-02"))
        self.assertEqual(r["score"], 0)
        self.assertEqual(r["status"], "SCORED")

    def test_private_bridge_not_copied(self):
        self.assertFalse((self.out / "private").exists())
        for row in self.result["mapping"]:
            self.assertEqual(set(row), {"review_id", "task_id", "original_method", "source_hashes"})
        for path, data in m.all_files(self.out).items():
            if not path.endswith(".zip"):
                self.assertNotIn(b"/workspace/shared/", data)
                self.assertNotIn(b'"source_directory":', data)

    def test_no_existing_destination_overwrite(self):
        with self.assertRaisesRegex(m.ValidationError, "already exists"):
            m.build_public_sources(INPUT, self.out)

    def test_score_tamper_even_resealed(self):
        root = self.modified("score-tamper")
        path = root / "judgments/R-B69E1568/CHECK.json"
        doc = m.parse(path.read_bytes())
        doc["judgments"][1]["score"] = 1
        path.write_bytes(m.pretty(doc))
        self.reseal(root)
        with self.assertRaisesRegex(m.ValidationError, "phase pin"):
            m.validate_public_sources(root)

    def test_normalized_tamper_even_resealed(self):
        root = self.modified("normalized-tamper")
        path = root / m.PATHS["records"]
        doc = m.parse(path.read_bytes())
        doc[0]["reason"] += "corrupted"
        path.write_bytes(m.pretty(doc))
        self.reseal(root)
        with self.assertRaisesRegex(m.ValidationError, "normalized records"):
            m.validate_public_sources(root)

    def test_projection_ledger_tamper_even_resealed(self):
        root = self.modified("ledger-tamper")
        path = root / m.PATHS["receipt"]
        doc = m.parse(path.read_bytes())
        row = next(r for r in doc["source_files"] if r["changes"])
        row["changes"][0]["source_value_sha256"] = "0" * 64
        path.write_bytes(m.pretty(doc))
        self.reseal(root)
        with self.assertRaisesRegex(m.ValidationError, "receipt pin"):
            m.validate_public_sources(root)

    def test_unknown_extra_file_even_resealed(self):
        root = self.modified("extra-file")
        (root / "unlisted.txt").write_text("unexpected")
        self.reseal(root)
        with self.assertRaisesRegex(m.ValidationError, "unexpected public-tree"):
            m.validate_public_sources(root)

    def test_packet_tamper_even_resealed(self):
        root = self.modified("packet-tamper")
        path = root / "reviewer/R-880D7CE3/outputs/验收报告.md"
        path.write_bytes(path.read_bytes() + b"\nextra")
        self.reseal(root)
        with self.assertRaisesRegex(m.ValidationError, "manifest member mismatch"):
            m.validate_public_sources(root)

    def test_mapping_tamper_even_resealed(self):
        root = self.modified("mapping-tamper")
        path = root / m.PATHS["mapping"]
        doc = m.parse(path.read_bytes())
        doc[0]["original_method"] = "wrong"
        path.write_bytes(m.pretty(doc))
        self.reseal(root)
        with self.assertRaisesRegex(m.ValidationError, "mapping pin"):
            m.validate_public_sources(root)

    def test_absent_historical_file_is_not_required(self):
        files = m.all_files(self.out)
        ref = {"path": "tmp/verify_result.json", "bytes": 586,
               "sha256": "2ee0c6122f9429ced3bb984cb0288845575e02afc84350cb71ed9afd2eb71a69",
               "body_available": False}
        resolved = m._validate_ref(files, "R-880D7CE3", ref)
        self.assertIsNone(resolved["resolved_path"])
        self.assertEqual(resolved["citation_kind"], "unavailable_historical_inventory")
        ref["bytes"] += 1
        with self.assertRaises(m.ValidationError):
            m._validate_ref(files, "R-880D7CE3", ref)

    def test_citation_value_quote_and_pointer_validation(self):
        files = m.all_files(self.out)
        doc = m.parse(files["judgments/R-47D9DE53/DRAFT.json"])
        good = doc["evidence_catalog"]["receipt_status"]
        m._validate_ref(files, "R-47D9DE53", good)
        for field, invalid in [("recorded_value", "NOT_EXECUTED"),
                               ("json_pointers", ["/not_present"]),
                               ("lines_1_based", [1, 999999]),
                               ("quote", "THIS QUOTE DOES NOT EXIST")]:
            bad = dict(good, **{field: invalid})
            with self.assertRaises(m.ValidationError):
                m._validate_ref(files, "R-47D9DE53", bad)

    def test_source_hash_change_refused_without_partial_output(self):
        if not self.original_inputs_available:
            self.skipTest(SOURCE_NOT_DISTRIBUTED)
        source = self.base / "corrupted-input"
        shutil.copytree(INPUT, source)
        path = source / "judgments/R-47D9DE53/CHECK.json"
        path.write_bytes(path.read_bytes() + b"\n")
        destination = self.base / "should-not-exist"
        with self.assertRaisesRegex(m.ValidationError, "raw phase pin"):
            m.build_public_sources(source, destination)
        self.assertFalse(destination.exists())


if __name__ == "__main__":
    unittest.main()
