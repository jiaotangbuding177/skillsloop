#!/usr/bin/env python3
"""Explicit byte-availability accounting for privacy-withheld source images.

Never synthesizes or edits an image. A withheld hash is metadata, not evidence
that a public file was read. All other source-member bytes remain mandatory.
"""
from dataclasses import dataclass
import base64
import binascii
import io
from pathlib import Path
import re
import zipfile

import recovery_core as core
import merge_release as merge

SOURCE_MANIFEST_MEMBER = "SHA256SUMS"
SOURCE_MANIFEST_SHA256 = "3c4a1c2d4ef07e1da7a553af0b64c8875600cdd423e8ef71f45d9c8ad3289978"
APPROVED_WITHHELD_COUNT = 8
# Canonical SHA of the exact reviewed source_member/sha256/bytes triples.
APPROVED_WITHHELD_SPEC_SHA256 = "be068a642c2d3fe1532a3eb81f16f5e8a2386e85cc15080326871de21caf69fa"


@dataclass(frozen=True)
class WithheldImage:
    source_member: str
    sha256: str
    byte_count_metadata: int


def reference_hash(value):
    """Caller must separately count metadata-only vs actually present bytes."""
    return value.sha256 if isinstance(value, WithheldImage) else core.sha(value)


def reject_withheld_copies(raw, forbidden_hashes, *, depth=0, budget=None):
    """Reject exact copies, renamed copies, nested ZIP copies and base64 copies."""
    if budget is None: budget = [512 * 1024 * 1024]
    budget[0] -= len(raw)
    core.require(budget[0] >= 0 and depth <= 8, "Archive inspection bound exceeded")
    core.require(core.sha(raw) not in forbidden_hashes, "Withheld source bytes redistributed")
    for match in re.finditer(rb"[A-Za-z0-9+/]{128,}={0,2}", raw):
        token = match.group()
        if len(token) % 4: continue
        try: decoded = base64.b64decode(token, validate=True)
        except binascii.Error: continue
        core.require(core.sha(decoded) not in forbidden_hashes, "Withheld source bytes redistributed as base64")
    if zipfile.is_zipfile(io.BytesIO(raw)):
        with zipfile.ZipFile(io.BytesIO(raw)) as archive:
            infos = archive.infolist()
            core.require(sum(i.file_size for i in infos) <= budget[0], "Nested archive expansion bound exceeded")
            for entry in infos:
                if not entry.is_dir():
                    reject_withheld_copies(archive.read(entry), forbidden_hashes, depth=depth+1, budget=budget)


def parse_source_inventory(raw):
    core.require(core.sha(raw) == SOURCE_MANIFEST_SHA256, "Original source inventory SHA differs")
    entries = {}
    for line in raw.decode("utf-8").splitlines():
        h, sep, name = line.partition("  ")
        core.require(sep and re.fullmatch("[0-9a-f]{64}", h), "Invalid original source inventory")
        core.safe_name(name)
        core.require(name not in entries, "Duplicate original source inventory member")
        entries[name] = h
    core.require(len(entries) == 150 and SOURCE_MANIFEST_MEMBER not in entries, "Unexpected original source member inventory")
    return entries


def load_public_evidence(root):
    """Validate explicit omissions against the pinned original source inventory."""
    root = Path(root)
    ledger = core.loads((root / "privacy_withheld.json").read_bytes())
    core.require(ledger["schema_version"] == "q-privacy-withheld-images-v1", "Unrecognized privacy ledger")
    core.require(ledger["source_archive_sha256"] == merge.SUPP_SHA and
                 ledger["source_archive_distribution"] == "NOT_DISTRIBUTED_CONTAINS_WITHHELD_IMAGES" and
                 ledger["source_archive_bytes_included"] is False and
                 ledger["source_archive_hash_recomputed_from_public_package"] is False and
                 ledger["source_manifest_sha256"] == SOURCE_MANIFEST_SHA256,
                 "Source archive/inventory boundary is unclear")
    core.require(not (root / "history/产物补评分_20261022_v3.zip").exists(), "Unsafe original supplement archive must not be redistributed")
    tree = root / "supplement_evidence_v3"
    raw_manifest = (tree / SOURCE_MANIFEST_MEMBER).read_bytes()
    entries = parse_source_inventory(raw_manifest)
    approved = sorted([{k:r[k] for k in ("source_member","sha256","bytes")} for r in ledger["withheld"]],key=lambda r:r["source_member"])
    core.require(len(approved) == APPROVED_WITHHELD_COUNT and core.canonical_sha(approved) == APPROVED_WITHHELD_SPEC_SHA256,
                 "Privacy exception differs from the exact approved path/SHA/bytes set")
    withheld = {}
    for row in ledger["withheld"]:
        name = row["source_member"]
        core.safe_name(name)
        core.require(name.endswith(".png") and name in entries and name not in withheld, "Invalid/duplicate withheld image")
        core.require(row["release_relative_path"] == "supplement_evidence_v3/" + name and
                     row["source_archive_member"] == merge.SUPP_PREFIX + name and
                     row["sha256"] == entries[name] and row["disposition"] == "PRIVACY_WITHHELD" and
                     row["availability"] == "privacy_withheld" and row["public_file_present"] is False and
                     row["reason_code"] == "INTERNAL_RUNTIME_PATH_VISIBLE_IN_GUI_PIXELS" and
                     row["original_pixels_modified"] is False and row["scoring_decision_changed"] is False,
                     "Withheld-image identity/hash/disclosure mismatch")
        core.require(type(row["bytes"]) is int and row["bytes"] > 0, "Invalid withheld byte-count metadata")
        core.require(not (tree / name).exists(), "Withheld image is still distributed")
        withheld[name] = WithheldImage(name, entries[name], row["bytes"])
    core.require(withheld, "Empty withheld ledger is not this privacy-release protocol")
    files = {p.relative_to(tree).as_posix(): p.read_bytes() for p in tree.rglob("*") if p.is_file()}
    core.require(set(files) == (set(entries) | {SOURCE_MANIFEST_MEMBER}) - set(withheld),
                 "Undeclared missing or extra supplemental source member")
    for name, raw in files.items():
        if name != SOURCE_MANIFEST_MEMBER:
            core.require(core.sha(raw) == entries[name], "Distributed supplemental source bytes changed: " + name)
            core.require(core.sha(raw) not in {v.sha256 for v in withheld.values()}, "A withheld image survives under another source filename")
    files.update(withheld)
    return files, ledger
