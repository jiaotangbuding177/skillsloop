#!/usr/bin/env python3
"""New, explicit adapter for the actually recovered public v1 archive + v3.

Creates a new release directory only. Never edits sources or performs judging.
Supplement reviewers are attributed only to their six specific item decisions.
"""
import argparse
import copy
import csv
import io
import json
from pathlib import Path
import re

import recovery_core as core

SUPP_SHA = "b2c61876e105f77e1098d5fca749f647076b7a63eec3966357655c63edf3b5ae"
SUPP_PREFIX = "产物补评分_20261022_v3/"
V2_PREFIX = "previous/产物补评分_20261022_v2/"
CALENDAR = {"C75A8C33706C3": (1, 1), "C9D47EF28BB04": (1, .5), "C9EE60570C63F": (1, 1)}
ARM_METHOD = {"no_skill": "NoSkill", "autoskill": "AutoSkills", "trace2skill": "Trace2Skills"}


def jsonl(raw):
    return [core.loads(s) for s in raw.decode("utf-8").splitlines() if s.strip()]


def unique(rows, key):
    out = {}
    for row in rows:
        k = key(row)
        core.require(k not in out, "Duplicate logical record")
        out[k] = row
    return out


def wjson(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2, allow_nan=False)
        f.write("\n")


def wjsonl(path, rows):
    with path.open("x", encoding="utf-8") as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False) + "\n")


def wcsv(path, rows, fields=None):
    with path.open("x", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields or list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def old_adapter(files, tasks):
    """Inspected schema is qjudging-public-result-v1, not original judge v1."""
    for n, h in core.PINS.items():
        core.require(core.sha(files["rubric_release/" + n]) == h, "Old release frozen pin differs")
    phases = {p: unique(jsonl(files[p + ".jsonl"]), lambda r: r["candidate_id"]) for p in ("DRAFT", "CHECK")}
    final = unique(jsonl(files["final_candidates.jsonl"]), lambda r: r["candidate_id"])
    flat = unique(jsonl(files["final_items.jsonl"]), lambda r: (r["candidate_id"], r["item_id"]))
    csvrows = unique(list(csv.DictReader(io.StringIO(files["candidate_scores.csv"].decode()))), lambda r: r["candidate_id"])
    core.require(len(final) == 750 and len(flat) == 7929 and all(set(d) == set(final) for d in [*phases.values(), csvrows]), "Old count/ID mismatch")
    for phase, rows in phases.items():
        for cid, row in rows.items():
            core.require(row["schema_version"] == "qjudging-public-result-v1" and row["phase"] == phase and
                         row["model"] == "gpt-6-astra", "Unrecognized source public schema/phase/model")
            core.require(row["publication"]["is_original_judge_record"] is False and
                         row["publication"]["is_directly_revalidatable_source_record"] is False, "Source derivative disclosure differs")
            core.require(row["human_review_completed"] is False and row["reliability_calibration_completed"] is False, "Unexpected calibration claim")
            tid = row["task_id"]
            core.require(tid in tasks and row["rubric_sha256"] == core.canonical_sha(tasks[tid]), "Task rubric object hash differs")
            agg = core.aggregate(row["items"], tasks[tid])
            for field, value in agg.items():
                core.require(row[field] == value, "Old aggregation differs: " + cid + ":" + field)
            core.require(csvrows[cid]["task_id"] == tid and csvrows[cid]["method"] == row["method"], "Old public method/task mismatch")
    diffs = []
    for cid, finalrow in final.items():
        check = phases["CHECK"][cid]
        core.require(finalrow["final_phase"] == "CHECK" and finalrow["items"] == check["items"], "Final does not use CHECK")
        for field in ("q_0_100", "dimensions", "status", "item_coverage", "method", "task_id"):
            core.require(finalrow[field] == check[field], "Final/CHECK mismatch")
        row = csvrows[cid]
        core.require((None if row["q_0_100"] == "" else float(row["q_0_100"])) == finalrow["q_0_100"], "Old CSV Q mismatch")
        for dim in core.WEIGHTS:
            core.require((None if row[dim + "_0_100"] == "" else float(row[dim + "_0_100"])) == finalrow["dimensions"][dim]["score_0_100"], "Old CSV dimension mismatch")
        draftitems = {i["item_id"]: i for i in phases["DRAFT"][cid]["items"]}
        for item in finalrow["items"]:
            flatrow = flat[cid, item["item_id"]]
            core.require(all(flatrow[k] == v for k, v in item.items()), "Flat/nested item differs")
            if (item["status"], item["score"]) != (draftitems[item["item_id"]]["status"], draftitems[item["item_id"]]["score"]):
                diffs.append((cid, item["item_id"]))
    olddiffs = jsonl(files["draft_check_differences.jsonl"])
    core.require(len(diffs) == len(olddiffs) == 89 and set(diffs) == {(d["candidate_id"], d["item_id"]) for d in olddiffs}, "Old phase differences mismatch")
    summary = core.validate_cohort(list(final.values()))
    core.assert_restored_baseline(summary)
    return phases, final, flat, csvrows, summary


def public_bridge(bridge, csvrows, metadata, supplement):
    core.require(len(bridge["candidates"]) == 3 and {r["review_id"] for r in bridge["candidates"]} == set(CALENDAR), "Bridge review ID inventory mismatch")
    bound = []
    for br in bridge["candidates"]:
        rid, tid = br["review_id"], br["task_id"]
        method = ARM_METHOD[br["arm"]]
        matches = [r for r in csvrows.values() if r["task_id"] == tid and r["method"] == method]
        core.require(tid == "T0144" and len(matches) == 1, "Bridge task/method is not unique")
        cid = matches[0]["candidate_id"]
        bindings = []
        for filename in ("source_ics.ics", "source_csv.csv"):
            src = br["source_files"][filename]
            actual = Path(src["source_path"]).read_bytes()
            member = "evidence/" + rid + "/" + filename
            core.require(core.sha(actual) == src["sha256"] and len(actual) == src["bytes"] and supplement[member] == actual, "Bridge/source/supplement bytes differ")
            evidence = [e for e in metadata if e["candidate_id"] == cid and e["task_id"] == tid and e["role"] == "output" and e["kind"] != "failure" and e["source_native_sha256"] == src["sha256"] and e["source_byte_sha256"] == src["sha256"]]
            core.require(len(evidence) == 1, "Bridge not uniquely supported by old output byte/native SHA")
            bindings.append({"supplement_member": member, "sha256": src["sha256"], "bytes": src["bytes"],
                             "old_evidence_id": evidence[0]["evidence_id"], "old_packet_relative_path": evidence[0]["source_packet_relative_path"]})
        bound.append({"neutral_review_id": rid, "candidate_id": cid, "task_id": tid, "method": method,
                      "join_rule": "EXACT_TASK_AND_PUBLIC_METHOD_AND_BOTH_SOURCE_BYTE_HASHES", "sources": bindings})
    core.require(len({r["candidate_id"] for r in bound}) == 3, "Bridge assigned duplicate candidate")
    return bound


def recurse_refs(value):
    if isinstance(value, dict):
        if "path" in value and "sha256" in value:
            yield value
        for v in value.values():
            yield from recurse_refs(v)
    elif isinstance(value, list):
        for v in value:
            yield from recurse_refs(v)


def supplements_adapter(files, tasks, csvrows, metadata, bridge):
    v2 = {n[len(V2_PREFIX):]: b for n, b in files.items() if n.startswith(V2_PREFIX)}
    core.supplement_preflight(v2, tasks)
    result = core.loads(files["results.json"])
    core.require(len(result["items"]) == 6 and result["final_stage"] == "CHECK", "Need exactly six final supplements")
    bound = public_bridge(bridge, csvrows, metadata, files)
    rid_to_cid = {r["neutral_review_id"]: r["candidate_id"] for r in bound}
    criterion = core.loads(files["common/criterion_T0144-D2-04.json"])
    expected = next(i for i in tasks["T0144"]["items"] if i["item_id"] == "T0144-D2-04")
    core.require(criterion == expected, "Calendar frozen item differs")
    targets = {cid: (tid, iid, cid) for cid, (tid, iid) in core.AUTHORIZED_TARGETS.items()}
    targets.update({cid: ("T0144", "T0144-D2-04", rid) for rid, cid in rid_to_cid.items()})
    patches = {}
    ref_count = 0
    for cid, (tid, iid, rid) in targets.items():
        native = rid not in CALENDAR
        if native:
            artifact = {"Cdfc0bda9402e55d7": "artifact.xlsx", "Ce5353b9efbae40ec": "artifact.docx", "Ca0d90d663358a730": "source_artifact.pptx"}[cid]
            h = core.sha(files[V2_PREFIX + f"evidence/{cid}/{artifact}"])
            core.require(any(e["candidate_id"] == cid and e["task_id"] == tid and e["role"] == "output" and e["kind"] != "failure" and e["source_native_sha256"] == h for e in metadata), "Native supplement not bound to original output")
        for phase_index, phase in enumerate(("DRAFT", "CHECK")):
            member = (V2_PREFIX if native else "") + f"records/{rid}/{phase}.json"
            raw = core.loads(files[member])
            expected_score = .5 if native else CALENDAR[rid][phase_index]
            core.require(type(raw.get("score")) in (int, float) and raw["score"] == expected_score and raw["item_id"] == iid, "Actual supplement score/item differs")
            if native:
                reason = raw["reason"]
                model = raw["model"]
                refs = []
                for ref in raw["evidence"]:
                    resolved = V2_PREFIX + core.resolved_member(f"records/{rid}/{phase}.json", raw["evidence_base"], ref["path"])
                    core.require(core.sha(files[resolved]) == ref["sha256"], "Native supplemental ref mismatch")
                    refs.append({**copy.deepcopy(ref), "path": "supplement_evidence_v3/" + resolved, "source_reference_path": ref["path"]})
            else:
                reason = raw["justification_zh"] if rid == "C75A8C33706C3" else raw["reason_zh"]
                model = raw.get("configured_model", raw.get("judge_configuration", {}).get("configured_model"))
                core.require(raw.get("candidate_id", raw.get("neutral_review_id")) == rid and raw.get("task_id", "T0144") == "T0144", "Calendar record identity differs")
                core.require(raw.get("phase", phase) == phase, "Calendar phase differs")
                refs = []
                for ref in recurse_refs(raw):
                    core.safe_name(ref["path"])
                    core.require(ref["path"] in files and core.sha(files[ref["path"]]) == ref["sha256"], "Calendar supplemental reference hash differs")
                    refs.append({**copy.deepcopy(ref), "path": "supplement_evidence_v3/" + ref["path"], "source_reference_path": ref["path"]})
            ref_count += len(refs)
            core.require(model == "gpt-6-astra" and isinstance(reason, str) and reason.strip(), "Wrong model or missing actual reason")
            patches[cid, phase] = {"item_id": iid, "status": "SCORED", "score": raw["score"], "reason": reason,
                "evidence": refs, "judge_id": None, "model": model, "review_scope": "TARGETED_ITEM_ONLY",
                "source_review_record": {"path": "supplement_evidence_v3/" + member, "byte_sha256": core.sha(files[member]),
                    "canonical_sha256": core.canonical_sha(raw), "source_schema_version": raw.get("schema_version"),
                    "source_identity": rid, "source_identity_namespace": "ORIGINAL_CANDIDATE_ID" if native else "NEW_NEUTRAL_REVIEW_ID",
                    "phase": phase, "source_public_derivative": copy.deepcopy(raw["public_derivative"])},
                "attribution_note": "Only this item was reviewed by this supplemental stage. No unnamed reviewer identity or other-item review is inferred.",
                "deduction_attribution_note": "Use the target-only source decision and its evidence; no new cross-item defect classification is inferred by this merger."}
        finalentry = next(e for e in result["items"] if (e.get("candidate_id") or e.get("neutral_review_id")) == rid)
        checkmember = patches[cid, "CHECK"]["source_review_record"]["path"].removeprefix("supplement_evidence_v3/")
        core.require(finalentry["check_sha256"] == core.sha(files[checkmember]) and finalentry["score"] == patches[cid, "CHECK"]["score"], "Published supplement result not source CHECK")
    return patches, bound, ref_count


def merge_phase(base, patch, rubric, archive_sha):
    if patch is None:
        return copy.deepcopy(base)
    original_digest = core.canonical_sha(base)
    result = copy.deepcopy(base)
    iid = patch["item_id"]
    core.require(sum(i["item_id"] == iid for i in base["items"]) == 1, "Replacement target not unique")
    result["items"] = [copy.deepcopy(patch) if i["item_id"] == iid else copy.deepcopy(i) for i in base["items"]]
    result["schema_version"] = "qjudging-composite-public-result-v2"
    result["source_schema_version"] = base["schema_version"]
    result["judge_id"] = None
    result["judge_attribution"] = "MIXED_ITEM_SOURCES_NOT_A_NEW_WHOLE_CANDIDATE_REVIEW"
    # Stale single-source hashes cannot masquerade as the composite's lineage.
    for key in ("source_result_sha256", "evidence_manifest_sha256", "check_result_sha256", "draft_result_sha256", "publication", "check_provenance", "blinding"):
        result.pop(key, None)
    result["base_phase_source"] = {"archive_path": "history/基线原发行_补证更新版_20261022.zip", "archive_sha256": archive_sha,
        "member": base["phase"] + ".jsonl", "candidate_id": base["candidate_id"], "record_canonical_sha256": original_digest,
        "base_judge_id": base["judge_id"], "original_source_result_sha256_metadata": base["source_result_sha256"],
        "base_manifest_canonical_sha256_metadata": base["evidence_manifest_sha256"], "base_blinding_disclosure": copy.deepcopy(base["blinding"])}
    result["item_source_rule"] = {"supplemented_item_id": iid,
        "all_other_item_payloads": "UNCHANGED_FROM_BASE_PHASE_SOURCE", "unchanged_item_judge_id": base["judge_id"],
        "base_defects_scope": "BASE_PHASE_ONLY_UNCHANGED_NOT_A_REVIEW_OF_NEW_SUPPLEMENT", "new_whole_candidate_review": False}
    result["review_design"] = "CHECK is DRAFT-visible; supplementary records cover the target only. Not independent first ratings or human calibration."
    result["publication"] = {"is_original_judge_record": False, "is_directly_revalidatable_source_record": False,
        "derivation": "Deterministic item-source composite; non-target judgment objects unchanged; source records retained."}
    result.update(core.aggregate(result["items"], rubric))
    core.require(core.canonical_sha(base) == original_digest, "Original phase mutated")
    for before, after in zip(base["items"], result["items"]):
        if before["item_id"] != iid:
            core.require(before == after, "Non-target item payload changed")
    return result


def run(args):
    out = Path(args.out)
    core.require(not out.exists(), "Output directory must be fresh; no overwrite")
    oldpath, supppath, bridgepath = map(Path, (args.old, args.supplement, args.bridge))
    input_hashes = {"old_archive": core.sha(oldpath.read_bytes()), "supplement_archive": core.sha(supppath.read_bytes()), "private_bridge": core.sha(bridgepath.read_bytes())}
    oldfiles = core.verify_archive(oldpath, core.OLD_ZIP_SHA)
    suppfiles = core.verify_archive(supppath, SUPP_SHA, SUPP_PREFIX)
    tasks = core.load_release(args.release)
    phases, oldfinal, oldflat, csvrows, before_summary = old_adapter(oldfiles, tasks)
    metadata = jsonl(oldfiles["evidence_metadata_index.jsonl"])
    patches, bridge, refs = supplements_adapter(suppfiles, tasks, csvrows, metadata, core.loads(bridgepath.read_bytes()))
    core.require(len(patches) == 12 and len({cid for cid, _ in patches}) == 6, "Need six distinct candidates/twelve phases")
    updated = {phase: {} for phase in phases}
    changes = []
    for phase, rows in phases.items():
        for cid, base in rows.items():
            patch = patches.get((cid, phase))
            updated[phase][cid] = merge_phase(base, patch, tasks[base["task_id"]], core.OLD_ZIP_SHA)
            if patch:
                original = next(i for i in base["items"] if i["item_id"] == patch["item_id"])
                changes.append({"candidate_id": cid, "task_id": base["task_id"], "method": base["method"], "phase": phase,
                    "item_id": patch["item_id"], "before_status": original["status"], "before_score": original["score"],
                    "after_status": patch["status"], "after_score": patch["score"], "before_q_0_100": base["q_0_100"],
                    "after_q_0_100": updated[phase][cid]["q_0_100"], "before_item_canonical_sha256": core.canonical_sha(original),
                    "after_item_canonical_sha256": core.canonical_sha(patch), "supplement_record": patch["source_review_record"]})
    final, flat, differences, item_audit = [], [], [], []
    for cid in sorted(oldfinal):
        check, draft = updated["CHECK"][cid], updated["DRAFT"][cid]
        patched = (cid, "CHECK") in patches
        row = copy.deepcopy(check if patched else oldfinal[cid])
        if patched:
            row.update(final_phase="CHECK", finalization_rule="CHECK_ONLY_NOT_MAX_NOT_AVERAGE",
                       draft_composite_canonical_sha256=core.canonical_sha(draft), check_composite_canonical_sha256=core.canonical_sha(check))
        final.append(row)
        draftitems = {i["item_id"]: i for i in draft["items"]}
        for item in row["items"]:
            iid = item["item_id"]
            target = patched and patches[cid, "CHECK"]["item_id"] == iid
            if target:
                authored = next(i for i in tasks[row["task_id"]]["items"] if i["item_id"] == iid)
                f = {**copy.deepcopy(item), "candidate_id": cid, "task_id": row["task_id"], "method": row["method"],
                     "phase": "CHECK", "dimension": authored["dimension"], "weight": authored["weight"], "applicability": authored["applicability"],
                     "schema_version": "qjudging-composite-public-item-v2", "publication": {"is_original_judge_record": False, "kind": "SUPPLEMENT_ITEM_PROJECTION"}}
            else:
                f = copy.deepcopy(oldflat[cid, iid])
                core.require(all(f[k] == v for k, v in item.items()), "Unchanged final flat/nested mismatch")
            flat.append(f)
            item_audit.append({"candidate_id": cid, "item_id": iid, "targeted_supplement": target,
                "old_final_item_canonical_sha256": core.canonical_sha(oldflat[cid, iid]), "new_final_item_canonical_sha256": core.canonical_sha(f),
                "unchanged_item_exact_object_equal": f == oldflat[cid, iid] if not target else None})
            di = draftitems[iid]
            if (item["status"], item["score"]) != (di["status"], di["score"]):
                differences.append({"candidate_id": cid, "task_id": row["task_id"], "method": row["method"], "item_id": iid,
                    "draft_status": di["status"], "draft_score": di["score"], "check_status": item["status"], "check_score": item["score"],
                    "draft_reason": di["reason"], "check_reason": item["reason"], "final_rule": "CHECK_ONLY"})
    summary = core.validate_cohort(final)
    core.require(sum(x["targeted_supplement"] for x in item_audit) == 6 and all(x["unchanged_item_exact_object_equal"] for x in item_audit if not x["targeted_supplement"]), "Target-only preservation failed")
    core.require(sum(len(x["items"]) for x in updated["DRAFT"].values()) == 7929 and sum(len(x["items"]) for x in updated["CHECK"].values()) == 7929, "Phase item count mismatch")
    # No values are asserted in advance. Everything below is computed from bytes.
    out.mkdir(parents=True)
    for name in ("rubric_release/rubrics.jsonl", "rubric_release/scoring_policy.json", "evidence_metadata_index.jsonl"):
        path = out / name; path.parent.mkdir(parents=True, exist_ok=True); path.write_bytes(oldfiles[name])
    (out / "history").mkdir()
    (out / "history/基线原发行_补证更新版_20261022.zip").write_bytes(oldpath.read_bytes())
    for name, raw in suppfiles.items():
        path = out / "supplement_evidence_v3" / name
        path.parent.mkdir(parents=True, exist_ok=True); path.write_bytes(raw)
    for phase in updated:
        wjsonl(out / (phase + ".jsonl"), [updated[phase][cid] for cid in sorted(updated[phase])])
    wjsonl(out / "final_candidates.jsonl", final)
    wjsonl(out / "final_items.jsonl", flat)
    wjsonl(out / "draft_check_differences.jsonl", differences)
    wjsonl(out / "supplement_changes.jsonl", changes)
    wjsonl(out / "item_preservation_audit.jsonl", item_audit)
    wjson(out / "calendar_candidate_binding.json", bridge)
    wjson(out / "coverage.json", summary)
    outputcsv = []
    for row in sorted(final, key=lambda r: (r["task_id"], r["method"])):
        outputcsv.append({"candidate_id": row["candidate_id"], "task_id": row["task_id"], "method": row["method"],
            "q_0_100": row["q_0_100"], "status": row["status"], "item_coverage": row["item_coverage"],
            **{d + "_0_100": row["dimensions"][d]["score_0_100"] for d in core.WEIGHTS},
            **{d + "_coverage": row["dimensions"][d]["item_coverage"] for d in core.WEIGHTS}})
    wcsv(out / "candidate_scores.csv", outputcsv)
    itemcsv = [{k: i.get(k) for k in ("candidate_id", "task_id", "method", "item_id", "dimension", "weight", "status", "score", "reason")} for i in flat]
    wcsv(out / "final_item_scores.csv", itemcsv)
    actual_hashes = {"old_archive": core.sha(oldpath.read_bytes()), "supplement_archive": core.sha(supppath.read_bytes()), "private_bridge": core.sha(bridgepath.read_bytes())}
    core.require(actual_hashes == input_hashes, "Input changed during merge")
    audit = {"status": "PASS_MECHANICAL_MERGE_NOT_SEMANTIC_RESCORING", "schema_adapter": "INSPECTED_PUBLIC_V1_TO_TARGETED_COMPOSITE_V2",
        "new_verifier_not_original_lost_script": True, "source_archive_sha256": core.OLD_ZIP_SHA, "supplement_archive_sha256": SUPP_SHA,
        "source_frozen_sha256": core.PINS, "source_files_unchanged": True, "baseline_validation": before_summary,
        "candidate_count": len(final), "phase_count": sum(len(v) for v in updated.values()), "final_item_count": len(flat),
        "target_candidates": 6, "phase_item_replacements": len(changes), "unchanged_final_items": len(flat) - 6,
        "non_target_final_item_objects_identical": True, "non_target_phase_item_objects_identical": True,
        "supplement_evidence_references_hashed": refs, "phase_score_status_differences": len(differences),
        "new_coverage": {k: v for k, v in summary.items() if k not in ("common_task_ids", "groups")},
        "human_review_completed": False, "judge_reliability_calibration_completed": False,
        "new_whole_candidate_review_claimed": False, "historical_test_execution_proven": False,
        "review_design": "CHECK can see DRAFT; separately authored model review is not independent first-rating reliability.",
        "old_evidence_validation_boundary": "Original public metadata/record bytes validated; absent original image/full manifest/source judge files were not recreated or revalidated.",
        "publication_state": "STAGED_PENDING_STATISTICS_AND_FINAL_QA", "script_sha256": core.sha(Path(__file__).read_bytes()),
        "recovery_core_sha256": core.sha(Path(core.__file__).read_bytes())}
    wjson(out / "公开合并机械审计.json", audit)
    print(json.dumps({"status": audit["status"], "coverage": audit["new_coverage"], "groups": summary["groups"], "phase_differences": len(differences)}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--old", required=True); p.add_argument("--supplement", required=True); p.add_argument("--bridge", required=True)
    p.add_argument("--release", required=True); p.add_argument("--out", required=True)
    run(p.parse_args())
