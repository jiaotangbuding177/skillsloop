"""Synthetic-only checks for explicit, non-silent privacy omissions."""
import copy
import base64
import io
import json
from pathlib import Path
import tempfile
import unittest
import zipfile
from unittest.mock import patch

import recovery_core as core
import merge_release as merge
import privacy_evidence as p


class PrivacyTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.tree = self.root / "supplement_evidence_v3"
        self.tree.mkdir()
        self.raw = b"SYNTHETIC NOT ACTUAL IMAGE"
        self.names = ["evidence/private.png"] + [f"evidence/{i:03d}.txt" for i in range(149)]
        self.contents = {n: self.raw if i == 0 else self.raw + n.encode() for i,n in enumerate(self.names)}
        manifest = "\n".join(core.sha(self.contents[n]) + "  " + n for n in self.names) + "\n"
        (self.tree / "SHA256SUMS").write_text(manifest)
        self.pin = core.sha(manifest.encode())
        self.patch = patch.object(p, "SOURCE_MANIFEST_SHA256", self.pin)
        self.patch.start(); self.addCleanup(self.patch.stop)
        for name in self.names[1:]:
            dest = self.tree / name; dest.parent.mkdir(parents=True, exist_ok=True); dest.write_bytes(self.contents[name])
        self.ledger = {"schema_version":"q-privacy-withheld-images-v1","source_archive_sha256":merge.SUPP_SHA,
            "source_archive_bytes_included":False,"source_archive_hash_recomputed_from_public_package":False,
            "source_archive_distribution":"NOT_DISTRIBUTED_CONTAINS_WITHHELD_IMAGES","source_manifest_sha256":self.pin,
            "withheld":[{"source_member":self.names[0],"release_relative_path":"supplement_evidence_v3/"+self.names[0],
                "source_archive_member":merge.SUPP_PREFIX+self.names[0],"sha256":core.sha(self.raw),"bytes":len(self.raw),
                "disposition":"PRIVACY_WITHHELD","reason_code":"INTERNAL_RUNTIME_PATH_VISIBLE_IN_GUI_PIXELS",
                "availability":"privacy_withheld","public_file_present":False,
                "original_pixels_modified":False,"scoring_decision_changed":False}]}
        self.save()
        approved=[{k:r[k] for k in ("source_member","sha256","bytes")} for r in self.ledger["withheld"]]
        for key,value in (("APPROVED_WITHHELD_COUNT",1),("APPROVED_WITHHELD_SPEC_SHA256",core.canonical_sha(approved))):
            mock=patch.object(p,key,value); mock.start(); self.addCleanup(mock.stop)

    def save(self):
        (self.root / "privacy_withheld.json").write_text(json.dumps(self.ledger))

    def reject(self):
        with self.assertRaises(core.Invalid): p.load_public_evidence(self.root)

    def test_explicit_withholding_is_metadata_not_bytes(self):
        values, _ = p.load_public_evidence(self.root)
        v = values[self.names[0]]
        self.assertIsInstance(v, p.WithheldImage)
        self.assertEqual(p.reference_hash(v), core.sha(self.raw))
        self.assertEqual(len(values), 151)

    def test_undeclared_missing_file_rejected(self):
        (self.tree / self.names[1]).unlink(); self.reject()

    def test_wrong_withheld_hash_rejected(self):
        self.ledger["withheld"][0]["sha256"] = "0"*64; self.save(); self.reject()

    def test_duplicate_withheld_rejected(self):
        self.ledger["withheld"].append(copy.deepcopy(self.ledger["withheld"][0])); self.save(); self.reject()

    def test_withheld_bytes_reintroduced_rejected(self):
        (self.tree / self.names[0]).write_bytes(self.raw); self.reject()

    def test_original_unsafe_archive_reintroduced_rejected(self):
        (self.root / "history").mkdir()
        (self.root / "history/产物补评分_20261022_v3.zip").write_bytes(b"synthetic")
        self.reject()

    def test_changed_present_bytes_rejected(self):
        (self.tree / self.names[1]).write_bytes(b"changed"); self.reject()

    def test_modified_pixel_claim_rejected(self):
        self.ledger["withheld"][0]["original_pixels_modified"] = True; self.save(); self.reject()

    def test_scoring_change_claim_rejected(self):
        self.ledger["withheld"][0]["scoring_decision_changed"] = True; self.save(); self.reject()

    def test_changed_withheld_byte_count_rejected(self):
        self.ledger["withheld"][0]["bytes"] += 1; self.save(); self.reject()

    def test_extra_withheld_image_rejected(self):
        self.ledger["withheld"].append({**self.ledger["withheld"][0],"source_member":"evidence/another.png"}); self.save(); self.reject()

    def test_raw_and_renamed_copy_rejected(self):
        raw=b"synthetic protected pixels"*30
        with self.assertRaises(core.Invalid):p.reject_withheld_copies(raw,{core.sha(raw)})

    def test_nested_zip_copy_rejected(self):
        raw=b"synthetic protected pixels"*30; stream=io.BytesIO()
        with zipfile.ZipFile(stream,"w") as z:z.writestr("renamed.bin",raw)
        with self.assertRaises(core.Invalid):p.reject_withheld_copies(stream.getvalue(),{core.sha(raw)})

    def test_base64_copy_rejected(self):
        raw=b"synthetic protected pixels"*30
        with self.assertRaises(core.Invalid):p.reject_withheld_copies(b'"data:image/png;base64,'+base64.b64encode(raw)+b'"',{core.sha(raw)})


if __name__ == "__main__": unittest.main()
