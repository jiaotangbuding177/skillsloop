#!/usr/bin/env python3
"""Offline paired-Q postprocessor, independently reimplemented on 2026-10-22.

This is NOT the original lost analysis script. It reads only the explicitly
supplied final score CSV and, optionally, the frozen rubric release. It never
reads a candidate output, private mapping, archived judge script, or network.

Usage:
    python paired_statistics.py candidate_scores.csv --output-dir statistics
    python paired_statistics.py candidate_scores.csv --output-dir statistics \
        --frozen-release-root /path/to/frozen/release

Exactly 750 unique candidate IDs, three named methods, and T0001..T0250 are required. Empty,
NULL, None, and UNKNOWN score cells mean missing, never zero. NaN/Inf are
invalid. Q must be null iff any dimension is null; otherwise it must exactly
match the frozen weighted sum rounded to eight places. Q is checked but never
filled or replaced. Category macros are optional and require
an explicit, complete task-to-category assignment. A macro is null if any
category contains a missing Q for that method.

Bootstrap: 10,000 replicates, random.Random(20261021), sorted common-complete
task IDs, n calls to randrange(n) per replicate, and the SAME task indices for
all methods and contrasts. Percentiles use linear interpolation at (B-1)*p.
Means and confidence bounds are rounded to eight decimal places only at output.
"""

import argparse
import csv
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
import hashlib
import io
import json
import math
import os
from pathlib import Path
import random
import re
import sys
import tempfile

import recovery_core as recovery


METHODS = ("NoSkill", "AutoSkills", "Trace2Skills")
TASK_IDS = tuple(f"T{i:04d}" for i in range(1, 251))
TASK_SET = frozenset(TASK_IDS)
DIMENSIONS = tuple(f"D{i}_0_100" for i in range(1, 6))
METRICS = ("q_0_100",) + DIMENSIONS
CONTRASTS = (("AutoSkills", "NoSkill"), ("Trace2Skills", "NoSkill"),
             ("Trace2Skills", "AutoSkills"))
BOOTSTRAP_REPLICATES = 10_000
BOOTSTRAP_SEED = 20261021
NULL_TOKENS = frozenset(("", "null", "none", "unknown"))
ORIGIN = "INDEPENDENT_REIMPLEMENTATION_NOT_ORIGINAL_LOST_SCRIPT"
OUTPUT_NAMES = ("common_complete_summary.json", "common_complete_task_scores.csv",
                "common_complete_group_means.csv", "common_complete_paired_differences.csv")
Invalid = recovery.Invalid
require = recovery.require


@dataclass(frozen=True)
class Cohort:
    rows: dict
    categories: dict | None
    category_source: str | None
    source_csv_name: str
    source_csv_sha256: str
    normalized_scores_sha256: str


def score_cell(value, location):
    """Parse a nullable finite numeric score without converting unknown to 0."""
    value = value.strip()
    if value.lower() in NULL_TOKENS:
        return None
    require(re.fullmatch(r"[+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[eE][+-]?[0-9]+)?", value) is not None,
            f"{location}: invalid numeric score {value!r}")
    try:
        # Decimal rejects booleans, keeps enormous exponents from hiding as 0,
        # and lets us validate the domain before conversion to binary float.
        decimal = Decimal(value)
    except (InvalidOperation, ValueError):
        raise Invalid(f"{location}: invalid numeric score {value!r}") from None
    require(decimal.is_finite() and 0 <= decimal <= 100,
            f"{location}: non-finite or out-of-range score")
    number = float(decimal)
    require(math.isfinite(number) and (decimal == 0 or number != 0),
            f"{location}: unrepresentable numeric score")
    return 0.0 if number == 0 else number


def read_frozen_categories(root):
    """Only the hash-pinned rubric and policy are read by load_release."""
    tasks = recovery.load_release(root)
    result = {}
    for tid in TASK_IDS:
        value = tasks[tid].get("category")
        require(isinstance(value, str) and bool(value.strip()),
                f"Frozen rubric {tid} lacks a nonempty category")
        result[tid] = value.strip()
    return result


def load_scores(path, *, frozen_categories=None):
    path = Path(path)
    raw = path.read_bytes()
    try:
        reader = csv.reader(io.StringIO(raw.decode("utf-8-sig"), newline=""), strict=True)
        header = next(reader)
    except (UnicodeError, csv.Error, StopIteration) as exc:
        raise Invalid(f"Unreadable/empty score CSV: {exc}") from None
    require(all(header) and len(header) == len(set(header)), "Empty or duplicate CSV column")
    required = {"candidate_id", "task_id", "method", *METRICS}
    require(required <= set(header), f"Missing CSV columns: {sorted(required - set(header))}")
    if frozen_categories is not None:
        require(set(frozen_categories) == TASK_SET, "Frozen categories must cover exactly T0001..T0250")
        require(all(isinstance(c, str) and c.strip() for c in frozen_categories.values()),
                "Invalid frozen category")
    rows, candidate_ids, csv_categories = {}, set(), {}
    row_count = 0
    try:
        for fields in reader:
            row_count += 1
            require(row_count <= 750, "More than 750 candidate rows")
            require(len(fields) == len(header), f"CSV line {reader.line_num}: wrong number of cells")
            row = dict(zip(header, fields))
            tid, method = row["task_id"], row["method"]
            require(tid in TASK_SET, f"CSV line {reader.line_num}: invalid task_id {tid!r}")
            require(method in METHODS, f"CSV line {reader.line_num}: invalid method {method!r}")
            key = (tid, method)
            require(key not in rows, f"Duplicate task-method candidate: {key}")
            normalized = {"task_id": tid, "method": method}
            if "candidate_id" in row:
                cid = row["candidate_id"]
                require(bool(cid.strip()) and cid == cid.strip() and cid not in candidate_ids,
                        f"Empty, whitespace-padded, or duplicate candidate_id: {cid!r}")
                candidate_ids.add(cid)
                normalized["candidate_id"] = cid
            for metric in METRICS:
                normalized[metric] = score_cell(row[metric], f"{tid}/{method}/{metric}")
            complete_dimensions = all(normalized[metric] is not None for metric in DIMENSIONS)
            require((normalized["q_0_100"] is not None) == complete_dimensions,
                    f"{tid}/{method}: Q nullness differs from dimension completeness")
            if complete_dimensions:
                expected_q = round(sum(normalized[f"{dim}_0_100"] * weight
                                       for dim, weight in recovery.WEIGHTS.items()), 8)
                require(normalized["q_0_100"] == expected_q,
                        f"{tid}/{method}: Q differs from frozen weighted dimension sum rounded to 8 places")
            if "category" in row:
                category = row["category"].strip()
                require(bool(category) and category.lower() not in NULL_TOKENS,
                        f"Missing category for {tid}/{method}")
                require(tid not in csv_categories or csv_categories[tid] == category,
                        f"Conflicting categories for {tid}")
                csv_categories[tid] = category
                if frozen_categories is not None:
                    require(category == frozen_categories[tid], f"Category differs from frozen rubric: {tid}")
            rows[key] = normalized
    except csv.Error as exc:
        raise Invalid(f"Malformed CSV at line {reader.line_num}: {exc}") from None
    require(row_count == 750, f"Need exactly 750 candidate rows; got {row_count}")
    for method in METHODS:
        observed = {tid for tid, m in rows if m == method}
        require(observed == TASK_SET, f"{method}: need exactly 250 distinct frozen task IDs")
    categories = dict(frozen_categories) if frozen_categories is not None else (csv_categories or None)
    source = "SHA256_PINNED_FROZEN_RUBRICS" if frozen_categories is not None else (
        "SUPPLIED_CSV_UNVERIFIED_AGAINST_FROZEN_RUBRIC" if categories else None)
    normalized_rows = [rows[tid, method] for tid in TASK_IDS for method in METHODS]
    return Cohort(rows, categories, source, path.name, hashlib.sha256(raw).hexdigest(),
                  recovery.canonical_sha({"scores": normalized_rows, "categories": categories}))


def mean(values):
    return math.fsum(values) / len(values) if values else None


def round8(value):
    if value is None:
        return None
    number = round(value, 8)
    return 0.0 if number == 0 else number


def percentile(sorted_values, probability):
    require(bool(sorted_values), "Percentile requires observations")
    require(0 <= probability <= 1, "Invalid percentile probability")
    position = (len(sorted_values) - 1) * probability
    lower = math.floor(position)
    upper = math.ceil(position)
    fraction = position - lower
    return sorted_values[lower] + fraction * (sorted_values[upper] - sorted_values[lower])


def bootstrap(columns):
    """Return mean and CI tuples; each column uses the exact same task draws."""
    lengths = {len(values) for values in columns}
    require(len(lengths) == 1, "Bootstrap columns have different task counts")
    n = next(iter(lengths))
    if not n:
        return [{"mean": None, "ci_lower": None, "ci_upper": None} for _ in columns]
    rng = random.Random(BOOTSTRAP_SEED)
    samples = [[] for _ in columns]
    for _ in range(BOOTSTRAP_REPLICATES):
        indices = [rng.randrange(n) for _ in range(n)]
        for values, observations in zip(columns, samples):
            observations.append(math.fsum(values[i] for i in indices) / n)
    result = []
    for values, observations in zip(columns, samples):
        observations.sort()
        result.append({"mean": round8(mean(values)),
                       "ci_lower": round8(percentile(observations, .025)),
                       "ci_upper": round8(percentile(observations, .975))})
    return result


def coverage(values):
    known = [v for v in values if v is not None]
    return {"task_count": len(values), "complete_count": len(known),
            "null_count": len(values) - len(known),
            "coverage_fraction": round8(len(known) / len(values)) if values else None,
            "all_tasks_micro_mean": round8(mean(known)) if len(known) == len(values) else None,
            "covered_only_mean_descriptive": round8(mean(known))}


def analyze(cohort):
    rows = cohort.rows
    common = [tid for tid in TASK_IDS if all(rows[tid, m]["q_0_100"] is not None for m in METHODS)]
    common_set = set(common)
    columns = [[rows[tid, method]["q_0_100"] for tid in common] for method in METHODS]
    columns += [[rows[tid, a]["q_0_100"] - rows[tid, b]["q_0_100"] for tid in common]
                for a, b in CONTRASTS]
    estimates = bootstrap(columns)
    groups, pairs = {}, []
    categories = sorted(set(cohort.categories.values())) if cohort.categories else []
    for index, method in enumerate(METHODS):
        group = {"common_complete_task_count": len(common),
                 "common_complete_q_mean": estimates[index]["mean"],
                 "common_complete_q_ci_lower": estimates[index]["ci_lower"],
                 "common_complete_q_ci_upper": estimates[index]["ci_upper"],
                 "q_coverage": coverage([rows[tid, method]["q_0_100"] for tid in TASK_IDS]),
                 "dimensions": {metric: coverage([rows[tid, method][metric] for tid in TASK_IDS])
                                for metric in DIMENSIONS},
                 "all250_category_macro_q_mean": None,
                 "category_macro_unavailable_reason": "NO_CATEGORY_ASSIGNMENT",
                 "categories": {}}
        if categories:
            for category in categories:
                ids = [tid for tid in TASK_IDS if cohort.categories[tid] == category]
                group["categories"][category] = coverage([rows[tid, method]["q_0_100"] for tid in ids])
            complete = all(v["null_count"] == 0 for v in group["categories"].values())
            if complete:
                # Aggregate unrounded category means, not the rounded displays.
                category_means = [mean([rows[t, method]["q_0_100"] for t in TASK_IDS
                                        if cohort.categories[t] == category]) for category in categories]
                group["all250_category_macro_q_mean"] = round8(mean(category_means))
                group["category_macro_unavailable_reason"] = None
            else:
                group["category_macro_unavailable_reason"] = "INCOMPLETE_Q_IN_ONE_OR_MORE_CATEGORIES"
        groups[method] = group
    for (a, b), estimate in zip(CONTRASTS, estimates[len(METHODS):]):
        pairs.append({"method_a": a, "method_b": b, "contrast": f"{a} minus {b}",
                      "common_complete_task_count": len(common),
                      "mean_paired_difference": estimate["mean"],
                      "ci_lower": estimate["ci_lower"], "ci_upper": estimate["ci_upper"]})
    return {"schema_version": "q-common-complete-statistics-reimplementation-v1",
            "implementation_origin": ORIGIN,
            "source_csv_name": cohort.source_csv_name,
            "source_csv_sha256": cohort.source_csv_sha256,
            "normalized_scores_sha256": cohort.normalized_scores_sha256,
            "candidate_count": len(rows), "task_count": len(TASK_IDS), "methods": list(METHODS),
            "q_validation": "null_iff_any_dimension_null; otherwise exact frozen weighted sum rounded to 8 places",
            "common_complete_task_count": len(common), "common_complete_task_ids": common,
            "excluded_task_ids": [tid for tid in TASK_IDS if tid not in common_set],
            "missing_q_task_ids_by_method": {m: [t for t in TASK_IDS if rows[t, m]["q_0_100"] is None]
                                            for m in METHODS},
            "bootstrap": {"replicates": BOOTSTRAP_REPLICATES, "seed": BOOTSTRAP_SEED,
                          "unit": "task_id", "task_order": "ascending_task_id",
                          "sampling": "random.Random(seed); n randrange(n) draws per replicate",
                          "shared_task_draws_across_all_methods_and_contrasts": True,
                          "interval": "percentile", "lower_probability": .025, "upper_probability": .975,
                          "quantile_interpolation": "linear_at_(B_minus_1)_times_probability",
                          "output_decimal_places": 8,
                          "executed_replicates": BOOTSTRAP_REPLICATES if common else 0},
            "category_source": cohort.category_source,
            "groups": groups, "paired_differences": pairs,
            "interpretation": ["All common-set means and paired contrasts use exactly the same task intersection.",
                               "Missing scores are not imputed or treated as zero.",
                               "Covered-only means are descriptive and may use different task sets.",
                               "Bootstrap intervals condition on the observed common-complete task cohort.",
                               "All250 category macros require complete Q in every task of every category."]}


def csv_text(fieldnames, rows):
    stream = io.StringIO(newline="")
    writer = csv.DictWriter(stream, fieldnames=fieldnames, lineterminator="\n", extrasaction="raise")
    writer.writeheader()
    for row in rows:
        writer.writerow({key: ("" if value is None else format(value, ".8f") if isinstance(value, float) else value)
                         for key, value in row.items()})
    return stream.getvalue()


def render_outputs(cohort, summary):
    task_fields = ["task_id", "category"] + [f"{m}_{metric}" for m in METHODS for metric in METRICS]
    task_rows = []
    for tid in summary["common_complete_task_ids"]:
        row = {"task_id": tid, "category": cohort.categories[tid] if cohort.categories else None}
        row.update({f"{method}_{metric}": cohort.rows[tid, method][metric]
                    for method in METHODS for metric in METRICS})
        task_rows.append(row)
    group_fields = ["method", "common_complete_task_count", "common_complete_q_mean",
                    "common_complete_q_ci_lower", "common_complete_q_ci_upper", "all250_task_count",
                    "all250_complete_q_count", "all250_null_q_count", "all250_q_coverage_fraction",
                    "all250_q_micro_mean", "covered_only_q_mean_descriptive", "all250_category_macro_q_mean"]
    group_rows = []
    for method in METHODS:
        group = summary["groups"][method]
        q = group["q_coverage"]
        row = {"method": method, **{key: group[key] for key in group_fields[1:5]},
               "all250_task_count": q["task_count"], "all250_complete_q_count": q["complete_count"],
               "all250_null_q_count": q["null_count"], "all250_q_coverage_fraction": q["coverage_fraction"],
               "all250_q_micro_mean": q["all_tasks_micro_mean"],
               "covered_only_q_mean_descriptive": q["covered_only_mean_descriptive"],
               "all250_category_macro_q_mean": group["all250_category_macro_q_mean"]}
        group_rows.append(row)
    pair_fields = ["method_a", "method_b", "contrast", "common_complete_task_count",
                   "mean_paired_difference", "ci_lower", "ci_upper"]
    files = {OUTPUT_NAMES[1]: csv_text(task_fields, task_rows),
             OUTPUT_NAMES[2]: csv_text(group_fields, group_rows),
             OUTPUT_NAMES[3]: csv_text(pair_fields, summary["paired_differences"])}
    export_summary = {**summary, "output_csv_sha256": {
        name: hashlib.sha256(text.encode("utf-8")).hexdigest() for name, text in files.items()}}
    files[OUTPUT_NAMES[0]] = json.dumps(export_summary, ensure_ascii=False, sort_keys=True, indent=2,
                                      allow_nan=False) + "\n"
    return files


def write_outputs(output_dir, contents, *, overwrite=False):
    output_dir = Path(output_dir)
    require(set(contents) == set(OUTPUT_NAMES), "Wrong output inventory")
    output_dir.mkdir(parents=True, exist_ok=True)
    for name in OUTPUT_NAMES:
        require(overwrite or not (output_dir / name).exists(), f"Output exists: {name}; use --overwrite explicitly")
        require(not (output_dir / name).is_symlink(), f"Refuse symlink output: {name}")
    with tempfile.TemporaryDirectory(prefix=".paired_statistics_", dir=output_dir) as temporary:
        temporary = Path(temporary)
        for name, content in contents.items():
            (temporary / name).write_text(content, encoding="utf-8", newline="")
        # Publish the SHA-anchored summary last so it never claims not-yet-written CSVs.
        for name in (*OUTPUT_NAMES[1:], OUTPUT_NAMES[0]):
            os.replace(temporary / name, output_dir / name)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("candidate_scores_csv", type=Path)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--frozen-release-root", type=Path)
    parser.add_argument("--overwrite", action="store_true")
    args = parser.parse_args(argv)
    try:
        categories = read_frozen_categories(args.frozen_release_root) if args.frozen_release_root else None
        cohort = load_scores(args.candidate_scores_csv, frozen_categories=categories)
        summary = analyze(cohort)
        write_outputs(args.output_dir, render_outputs(cohort, summary), overwrite=args.overwrite)
    except (Invalid, OSError, UnicodeError) as exc:
        parser.exit(2, f"ERROR: {exc}\n")
    print(json.dumps({"implementation_origin": ORIGIN, "candidate_count": 750,
                      "common_complete_task_count": summary["common_complete_task_count"],
                      "output_files": [str(args.output_dir / name) for name in OUTPUT_NAMES]}, allow_nan=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())
