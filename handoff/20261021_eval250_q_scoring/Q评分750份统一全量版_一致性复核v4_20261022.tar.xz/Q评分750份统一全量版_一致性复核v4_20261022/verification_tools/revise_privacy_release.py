#!/usr/bin/env python3
"""Create a separate privacy-withheld publication, without modifying originals.

Requires an explicit, reviewed source-member list. No score/reason/reference is
changed. No image pixels are modified. The unsafe original supplement ZIP is
not included anywhere in the public copy.
"""
import argparse
import json
from pathlib import Path
import shutil
import sys
import zipfile

sys.dont_write_bytecode = True
import recovery_core as core
import merge_release as merge
import privacy_evidence as privacy
import verify_unified
from build_unified_release import dump, manifest

PRE_PRIVACY_RELEASE_SHA256 = "61af55281005622d576a192d4ad9b0b413ed707dc7ad0a67579511bd502c9d03"


def replace_once(path, old, new):
    text = path.read_text()
    core.require(text.count(old) == 1, "Expected single publication-description paragraph not found")
    path.write_text(text.replace(old, new))


def run(args):
    source, sourcezip, suppzip, specpath, out, zipout = map(Path,
        (args.source,args.source_zip,args.supplement,args.withhold_list,args.out,args.zip))
    core.require(not out.exists() and not zipout.exists(), "Fresh privacy publication paths required")
    before = {"prior_release":core.sha(sourcezip.read_bytes()),"supplement":core.sha(suppzip.read_bytes()),"withhold_list":core.sha(specpath.read_bytes())}
    core.require(before["prior_release"] == PRE_PRIVACY_RELEASE_SHA256, "Wrong pre-privacy frozen release")
    frozen = core.verify_archive(sourcezip, PRE_PRIVACY_RELEASE_SHA256, source.name+"/")
    for name, raw in frozen.items(): core.require((source/name).read_bytes() == raw, "Frozen source directory differs from ZIP")
    original = core.verify_archive(suppzip, merge.SUPP_SHA, merge.SUPP_PREFIX)
    privacy.parse_source_inventory(original[privacy.SOURCE_MANIFEST_MEMBER])
    spec = core.loads(specpath.read_bytes())
    if spec.get("status") == "BLOCK_PUBLIC_RELEASE_UNTIL_WITHHELD":
        core.require(spec["source_release_sha256"] == PRE_PRIVACY_RELEASE_SHA256 and spec["source_supplement_archive_sha256"] == merge.SUPP_SHA and spec["original_images_modified"] is False, "Wrong reviewed source/version")
        reviews = merge.unique(spec["all_image_reviews"], lambda r:r["source_member"])
        images = {n for n in original if Path(n).suffix.lower() in (".png",".jpg",".jpeg")}
        core.require(set(reviews)==images and len(images)==spec["images_checked"], "Image review did not cover complete original inventory")
        for name,row in reviews.items():
            core.require(row["sha256"]==core.sha(original[name]) and row["bytes"]==len(original[name]) and row["review_method"]=="DIRECT_PIXEL_INSPECTION_UNEDITED_ORIGINAL", "Image review hash/inspection assertion differs")
        names = [r["source_member"] for r in spec["withheld_images"]]
        core.require(set(names)=={n for n,r in reviews.items() if r["recommended_public_status"]=="privacy_withheld"} and len(names)==spec["withheld_count"], "Reviewed withholding subset differs")
    else:
        core.require(spec["review_complete"] is True and spec["action"] == "WITHHOLD_ORIGINAL_IMAGES_WITHOUT_PIXEL_EDIT", "An explicit completed review list is required")
        names = spec["source_members"]
    core.require(isinstance(names,list) and names and len(names)==len(set(names)), "Invalid withholding inventory")
    withheld=[]
    for name in sorted(names):
        core.safe_name(name)
        core.require(name in original and name.endswith(".png"), "Only actual source PNG members can be withheld")
        withheld.append({"source_member":name,"source_archive_member":merge.SUPP_PREFIX+name,
            "release_relative_path":"supplement_evidence_v3/"+name,"sha256":core.sha(original[name]),"bytes":len(original[name]),
            "disposition":"PRIVACY_WITHHELD","reason_code":"INTERNAL_RUNTIME_PATH_VISIBLE_IN_GUI_PIXELS",
            "availability":"privacy_withheld","public_file_present":False,
            "reason_zh":"原始截图像素显示内部运行目录。公开副本不分发此图；原图未改动，原引用及哈希保留。",
            "original_pixels_modified":False,"scoring_decision_changed":False})
    excluded = {r["release_relative_path"] for r in withheld} | {"history/产物补评分_20261022_v3.zip","公开发行复验.json"}
    out.mkdir(parents=True)
    for name, raw in frozen.items():
        if name not in excluded:
            dest=out/name; dest.parent.mkdir(parents=True,exist_ok=True); dest.write_bytes(raw)
    (out/"history/隐私修订前机械验证摘要.json").write_bytes(frozen["公开发行复验.json"])
    ledger={"schema_version":"q-privacy-withheld-images-v1","source_archive_name":"产物补评分_20261022_v3.zip",
        "source_archive_sha256":merge.SUPP_SHA,"source_archive_distribution":"NOT_DISTRIBUTED_CONTAINS_WITHHELD_IMAGES",
        "source_archive_bytes_included":False,"source_archive_hash_recomputed_from_public_package":False,
        "source_archive_bytes_verified_during_preparation":True,"source_archive_retained_unchanged_privately":True,
        "source_manifest_member":privacy.SOURCE_MANIFEST_MEMBER,"source_manifest_sha256":privacy.SOURCE_MANIFEST_SHA256,
        "pre_privacy_release_sha256":PRE_PRIVACY_RELEASE_SHA256,
        "inventory_boundary":"Original supplement SHA256SUMS is retained as source metadata, not a claim that every original member is distributed.",
        "public_checksum_manifest":"SHA256SUMS.txt","withheld":withheld,
        "score_and_original_reference_changes":False,"pixel_edits_performed":False}
    dump(out/"privacy_withheld.json",ledger)
    tools=Path(__file__).resolve().parent
    for name in ("verify_unified.py","privacy_evidence.py","test_privacy_evidence.py","revise_privacy_release.py","build_unified_release.py"):
        shutil.copyfile(tools/name,out/"verification_tools"/name)
    replace_once(out/"方法与来源说明.txt","本版保留旧ZIP字节、新补证原ZIP字节和新补证材料；",
        "本公开版保留旧基线ZIP和可分发的新补证原字节；含内部路径的截图以及包含它们的新补证原ZIP仅内部原样留存，不随本公开副本分发。privacy_withheld.json逐一保留原路径、SHA和未分发原因；")
    replace_once(out/"方法与来源说明.txt","24个网页候选仍缺运行/可视证据，2个历史测试候选仍缺当时执行真实性证据。",
        "24个网页候选仍缺运行/可视证据。T0030两份候选的现有UNKNOWN保持，原包执行摘要与文件清单证据正在一致性复核；完整命令/工具返回尚未找到。")
    replace_once(out/"评分结果摘要.txt","另2份涉及历史测试执行真实性，当前重跑不能证明当年的执行。",
        "另2份T0030候选的现有UNKNOWN保持，原包执行摘要与文件清单证据正在一致性复核；完整命令/工具返回尚未找到，未预改分。")
    replace_once(out/"先读我.txt","history保存不可变来源归档；supplement_evidence_v3保存补证原记录和相关材料。",
        "history保存上一基线完整原发行；本轮补证原ZIP因含已隐去截图只内部留存。supplement_evidence_v3保存可公开的补证原字节，privacy_withheld.json明确列出未分发图片及原SHA。")
    replace_once(out/"先读我.txt","当前新增补证相关原件和画面已包含。",
        "当前新增补证相关原件和可公开画面已包含，隐私清单中的原图不分发。原v3的SHA256SUMS只是保留的来源清单；本公开包完整性以根目录SHA256SUMS.txt及专用复验器为准。")
    replace_once(out/"先读我.txt","这是750份统一全量结果包，直接使用顶层文件即可，不必拼接补包。",
        "这是750份统一全量结果包，直接使用顶层文件即可，不必拼接补包。\n\n重要：supplement_evidence_v3中的原README、原verify脚本和原SHA清单均为历史来源原件，不是本删图公开派生版的操作说明。不要按其旧strict命令校验缺8图的公开树；当前唯一复验入口是顶层verification_tools/verify_unified.py，按下述命令运行。")
    privacy_text=f"""隐私删图发行说明

本版仅改变公开分发材料，不更改任何评分、理由或原引用。724份完整Q、26份空Q、187个UNKNOWN及所有统计保持不变。
经截图像素审查，{len(withheld)}张原始PNG含内部运行目录。它们被明确列为PRIVACY_WITHHELD，不在公开目录或任何内嵌ZIP中分发。没有裁剪、遮盖、生成或重绘像素。
原图和原v3归档内部原样留存；本版不提供含这些图的原v3 ZIP。原归档SHA是来源元数据，不是可见公开副本的字节SHA，也不宣称读者能从本包重建原归档。
privacy_withheld.json逐一列出原成员路径、原SHA、原大小和不分发原因。所有阶段记录中的原引用和引文保持不变。公开读者不能凭图的哈希查看未分发的像素；这是一项明确的公开证据复验限制。
其余原字节、实际GUI图和导入记录照常提供。此处只做隐私发行转换，没有重新判定证据充分性或进行语义评分；不会把隐去图片当成新观察，也不将它们冒充已从当前公开文件读取。
原v3的SHA256SUMS保留为来源清单，它包含被隐去成员，不能当作本公开副本的完整分发清单。根目录SHA256SUMS.txt覆盖实际公开文件。
原v3 README及verify脚本也仅作为历史原件保留；其中旧strict运行命令不适用于本删图副本，不宣称它们可无条件通过。当前操作说明及命令以根目录先读我和verification_tools/verify_unified.py为准。
专用复验器对每个未分发成员核对显式白名单和原来源清单SHA；其他任一缺文件、重复项、伪造哈希、未声明缺省、原危险ZIP重新出现均失败。
审阅原件来源、评分及统计的机制不变；相应复验报告分别列出真正读取字节的引用数与仅核对隐去元数据的引用数。

T0030：本版现有UNKNOWN保持。原包执行摘要与文件清单证据正在一致性复核，完整命令/工具返回尚未找到；尚无新阶段决定，不先行加分。
"""
    (out/"隐私删图发行说明.txt").write_text(privacy_text)
    with (out/"评分结果摘要.txt").open("a") as f:
        f.write(f"\n隐私发行补记：{len(withheld)}张含内部运行目录的截图不公开分发，未改像素；原引用和SHA保留，评分及统计不变。详见隐私删图发行说明。\n")
    audit=core.loads((out/"公开合并机械审计.json").read_bytes())
    audit.update(publication_state="PRIVACY_WITHHELD_PUBLIC_DERIVATIVE_MECHANICALLY_VERIFIED",
        privacy_withheld_images=len(withheld),source_supplement_archive_distribution="NOT_DISTRIBUTED_PRIVACY",
        source_supplement_archive_verified_in_preparation=True,public_supplement_evidence_is_complete_original=False,
        scores_reasons_original_references_unchanged_from_pre_privacy_release=True)
    dump(out/"公开合并机械审计.json",audit)
    protected=["DRAFT.jsonl","CHECK.jsonl","final_candidates.jsonl","final_items.jsonl","candidate_scores.csv",
        "final_item_scores.csv","draft_check_differences.jsonl","supplement_changes.jsonl","item_preservation_audit.jsonl",
        "coverage.json","common_complete_summary.json","common_complete_task_scores.csv","common_complete_group_means.csv",
        "common_complete_paired_differences.csv","evidence_metadata_index.jsonl","calendar_candidate_binding.json"]
    for name in protected: core.require((out/name).read_bytes()==frozen[name],"Protected score/source/statistic bytes changed")
    manifest(out); report=verify_unified.verify(out)
    report["checksum_files"]+=1
    dump(out/"公开发行复验.json",report); manifest(out)
    core.require(verify_unified.verify(out)==report,"Final privacy receipt differs")
    after={"prior_release":core.sha(sourcezip.read_bytes()),"supplement":core.sha(suppzip.read_bytes()),"withhold_list":core.sha(specpath.read_bytes())}
    core.require(after==before,"Original source changed during privacy publication")
    zipout.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(zipout,"x",compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in sorted(out.rglob("*")):
            if p.is_file():
                info=zipfile.ZipInfo(out.name+"/"+p.relative_to(out).as_posix(),date_time=(2026,10,22,0,0,0))
                info.compress_type=zipfile.ZIP_DEFLATED; info.create_system=3; info.external_attr=0o100644 << 16
                z.writestr(info,p.read_bytes(),compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
    digest=core.sha(zipout.read_bytes())
    released=core.verify_archive(zipout,digest,out.name+"/")
    core.require(not any(core.sha(raw) in {w["sha256"] for w in withheld} for raw in released.values()),"Withheld image byte copy leaked")
    print(json.dumps({"status":"FROZEN_PRIVACY_REVISION_NOT_DELIVERED","zip_name":zipout.name,"bytes":zipout.stat().st_size,
        "sha256":digest,"members":len(released),"withheld_images":len(withheld),"protected_files_identical":len(protected),
        "verification":report},ensure_ascii=False,indent=2))


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    for name in ("source","source-zip","supplement","withhold-list","out","zip"):p.add_argument("--"+name,required=True)
    run(p.parse_args())
