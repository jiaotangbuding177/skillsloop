import copy
import unittest
import claim_merge_logic as logic
import recovery_core as core


class TestMultiTargetComposition(unittest.TestCase):
    def setUp(self):
        ids=['T0030-D1-01','T0030-D2-X','T0030-D3-02','T0030-D4-X','T0030-D5-X','T0030-D1-extra']
        self.rubric={'task_id':'T0030','items':[{'item_id':i,'dimension':i.split('-')[1],'weight':1} for i in ids]}
        self.base={'candidate_id':'Csynthetic','task_id':'T0030','phase':'CHECK','method':'NoSkill',
            'schema_version':'qjudging-public-result-v1','judge_id':'ReviewerTest','source_result_sha256':'a'*64,
            'evidence_manifest_sha256':'b'*64,'blinding':{'historical_scores_exposed':True},
            'items':[{'item_id':i,'status':'SCORED','score':1,'reason':'unaltered citation /workspace/outputs/user.txt'} for i in ids]}
        self.base.update(core.aggregate(self.base['items'],self.rubric))
        self.patches=[{'item_id':i,'status':'UNKNOWN','score':None,'reason':'target-only'} for i in sorted(logic.TARGET_ITEMS)]

    def test_two_unknowns_are_null_not_zero(self):
        result=logic.merge_multi_phase(self.base,self.patches,self.rubric)
        self.assertIsNone(result['q_0_100'])
        self.assertIsNone(result['dimensions']['D1']['score_0_100'])
        self.assertEqual(result['dimensions']['D1']['fixed_weight_denominator'],2)
        self.assertEqual(result['dimensions']['D1']['known_weight_numerator'],1)
        self.assertEqual(result['dimensions']['D1']['covered_item_mean_0_100_descriptive_only'],100)

    def test_base_and_all_other_objects_unchanged(self):
        original=copy.deepcopy(self.base)
        result=logic.merge_multi_phase(self.base,self.patches,self.rubric)
        self.assertEqual(self.base,original)
        for a,b in zip(original['items'],result['items']):
            if a['item_id'] not in logic.TARGET_ITEMS:self.assertEqual(a,b)
        self.assertIsNone(result['judge_id'])
        self.assertFalse(result['item_source_rule']['new_whole_candidate_review'])
        self.assertTrue(result['base_phase_source']['base_blinding_disclosure']['historical_scores_exposed'])

    def test_known_score_may_legitimately_become_unknown(self):
        result=logic.merge_multi_phase(self.base,self.patches,self.rubric)
        self.assertEqual(self.base['q_0_100'],100)
        self.assertIsNone(result['q_0_100'])

    def test_zero_is_not_unknown(self):
        for p in self.patches:p.update(status='SCORED',score=0)
        result=logic.merge_multi_phase(self.base,self.patches,self.rubric)
        self.assertEqual(result['dimensions']['D1']['score_0_100'],50)
        self.assertEqual(result['dimensions']['D3']['score_0_100'],0)
        self.assertEqual(result['q_0_100'],65)

    def test_duplicate_missing_extra_target_rejected(self):
        for bad in [self.patches[:1],self.patches+[self.patches[0]],self.patches+[{'item_id':'T0030-D4-X','status':'UNKNOWN','score':None}]]:
            with self.assertRaises(core.Invalid):logic.merge_multi_phase(self.base,bad,self.rubric)

    def test_bad_raw_literal_is_not_silently_coerced_here(self):
        self.patches[0]['score']='UNKNOWN'
        with self.assertRaises(core.Invalid):logic.merge_multi_phase(self.base,self.patches,self.rubric)

    def test_wrong_task_rejected(self):
        self.base['task_id']='T0031'
        with self.assertRaises(core.Invalid):logic.merge_multi_phase(self.base,self.patches,self.rubric)

    def test_projection_keeps_literal_unknown_and_exact_quote(self):
        original={'item_id':'T0030-D1-01','score':'UNKNOWN','reason_zh':'exact user quotation /workspace/outputs/report.md'}
        record={'neutral_review_id':'R-test','phase':'CHECK','item_id':'T0030-D1-01','score':None,
            'source_score':'UNKNOWN','reason':original['reason_zh'],'source_item':original,
            'source_record':{'path':'judgments/R-test/CHECK.json','source_byte_sha256':'a'*64,
                'public_byte_sha256':'b'*64,'public_canonical_sha256':'c'*64,'source_item_pointer':'/items/0'},
            'evidence':[{'path':'outputs/report.md','resolved_path':'reviewer/R-test/outputs/report.md',
                         'sha256':'d'*64,'quote':'exact user quotation /workspace/outputs/report.md'}]}
        snapshot=copy.deepcopy(record)
        projected=logic.project_record(record)
        self.assertEqual(record,snapshot)
        self.assertIsNone(projected['score'])
        self.assertEqual(projected['normalization']['raw_score'],'UNKNOWN')
        self.assertEqual(projected['source_item_decision'],original)
        self.assertEqual(projected['evidence'][0]['path'],'test_claim_evidence/reviewer/R-test/outputs/report.md')
        self.assertEqual(projected['evidence'][0]['quote'],record['evidence'][0]['quote'])
        self.assertTrue(projected['source_review_record']['source_public_derivative'])

    def test_bad_normalized_score_rejected(self):
        for value in (True,'UNKNOWN',2,float('nan')):
            with self.assertRaises(core.Invalid):
                logic.project_record({'neutral_review_id':'R-test','phase':'CHECK','item_id':'T0030-D1-01','score':value})


if __name__=='__main__':unittest.main()
