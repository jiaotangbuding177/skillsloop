"""Exact source-linked T0030 adapter. New code; never a semantic scorer."""
import copy
from pathlib import Path
import recovery_core as core
import merge_release as merge

TARGET_ITEMS = frozenset(('T0030-D1-01', 'T0030-D3-02'))
PUBLIC_PREFIX = 'test_claim_evidence/'


def merge_multi_phase(base, patches, rubric):
    """Replace multiple explicitly reviewed items, not the whole-candidate judge."""
    indexed = merge.unique(patches, lambda p: p['item_id'])
    core.require(set(indexed) == TARGET_ITEMS, 'T0030 exact two-item scope required')
    core.require(base['task_id'] == 'T0030', 'Wrong multi-item task')
    # The existing single-item constructor establishes honest base attribution.
    first = indexed[sorted(indexed)[0]]
    result = merge.merge_phase(base, first, rubric, core.OLD_ZIP_SHA)
    result['items'] = [copy.deepcopy(indexed.get(i['item_id'], i)) for i in base['items']]
    result['schema_version'] = 'qjudging-composite-public-result-v3'
    result['item_source_rule'].pop('supplemented_item_id')
    result['item_source_rule']['supplemented_item_ids'] = sorted(indexed)
    result['review_design'] = 'T0030 CHECK sees its assigned DRAFT, not earlier candidate scores or method identity. Target-only model review, not independent first ratings or human calibration.'
    result.update(core.aggregate(result['items'], rubric))
    for before, after in zip(base['items'], result['items']):
        if before['item_id'] not in indexed:
            core.require(before == after, 'Non-target item changed during multi-item merge')
    return result


def bind_candidates(mapping, old_csv, metadata, root):
    """Join task, public method, and BOTH final output byte hashes."""
    bound = []
    core.require(len(mapping) == 3, 'Exactly three neutral T0030 sources required')
    for b in mapping:
        rid = b.get('review_id', b.get('neutral_review_id'))
        method = merge.ARM_METHOD[b['original_method']]
        matches = [r for r in old_csv.values() if r['task_id'] == 'T0030' and r['method'] == method]
        core.require(len(matches) == 1, 'T0030 task/method binding not unique')
        cid = matches[0]['candidate_id']
        sources = []
        for member in ('outputs/验收报告.md', 'outputs/问题清单.json'):
            h = b['source_hashes'][member]
            path = Path(root) / 'reviewer' / rid / member
            raw = path.read_bytes()
            core.require(core.sha(raw) == h, 'T0030 source artifact hash differs')
            em = [e for e in metadata if e['candidate_id'] == cid and e['task_id'] == 'T0030' and e['role'] == 'output' and e['kind'] != 'failure' and e['source_native_sha256'] == h and e['source_byte_sha256'] == h]
            core.require(len(em) == 1, 'T0030 output not uniquely bound to original metadata')
            sources.append({'packet_member': 'reviewer/' + rid + '/' + member, 'sha256': h,
                            'bytes': len(raw), 'old_evidence_id': em[0]['evidence_id'],
                            'old_packet_relative_path': em[0]['source_packet_relative_path']})
        bound.append({'neutral_review_id': rid, 'candidate_id': cid, 'task_id': 'T0030', 'method': method,
                      'join_rule': 'EXACT_TASK_AND_PUBLIC_METHOD_AND_BOTH_ORIGINAL_OUTPUT_BYTE_HASHES', 'sources': sources})
    core.require(len({x['candidate_id'] for x in bound}) == 3 and len({x['neutral_review_id'] for x in bound}) == 3, 'Duplicate T0030 binding')
    return sorted(bound, key=lambda x: x['neutral_review_id'])


def project_record(record):
    """The adapter's normalized record is retained, not reinterpreted."""
    # Key contract is explicit; any schema mismatch is an error, not a guessed fallback.
    rid, phase, iid = record['neutral_review_id'], record['phase'], record['item_id']
    score = record['score']
    core.require(iid in TARGET_ITEMS and phase in ('DRAFT', 'CHECK'), 'Wrong target/phase')
    core.require(score is None or (type(score) in (int, float) and score in (0, .5, 1)), 'Illegal normalized score')
    source = record['source_record']
    refs = copy.deepcopy(record['evidence'])
    for ref in refs:
        ref['source_reference_path'] = ref['path']
        ref['path'] = PUBLIC_PREFIX + ref['resolved_path'] if ref['resolved_path'] is not None else None
    return {'item_id': iid, 'status': 'UNKNOWN' if score is None else 'SCORED', 'score': score,
            'reason': record['reason'], 'evidence': refs, 'judge_id': None, 'model': 'gpt-6-astra',
            'review_scope': 'TARGETED_ITEM_ONLY', 'source_review_record': {
                'path': PUBLIC_PREFIX + source['path'],
                'byte_sha256': source['public_byte_sha256'],
                'canonical_sha256': source['public_canonical_sha256'],
                'original_source_byte_sha256': source['source_byte_sha256'],
                'source_item_pointer': source['source_item_pointer'],
                'source_identity': rid, 'source_identity_namespace': 'NEW_NEUTRAL_REVIEW_ID', 'phase': phase,
                'source_public_derivative': source['public_byte_sha256'] != source['source_byte_sha256'],
                'normalization_record': PUBLIC_PREFIX + 'normalized_phase_items.json'},
            'source_item_decision': copy.deepcopy(record['source_item']),
            'normalization': {'raw_score': record['source_score'], 'normalized_score': score,
                              'rule': 'LITERAL_UNKNOWN_OR_NULL_TO_NULL_NEVER_ZERO; numeric 0/0.5/1 unchanged'},
            'attribution_note': 'Only this target item was reviewed. The same source file reviews two T0030 targets, not the whole candidate.',
            'deduction_attribution_note': 'All original source reasoning and limitations are retained; this merger performs no semantic rejudging.'}


def load_patches(public_root, old_csv, metadata, tasks):
    import public_test_claim_sources as sources
    sources.validate_public_sources(public_root)
    public_root = Path(public_root)
    data = {'mapping': core.loads((public_root / 'public_candidate_bridge.json').read_bytes()),
            'records': core.loads((public_root / 'normalized_phase_items.json').read_bytes()),
            'receipt': core.loads((public_root / 'public_sources_receipt.json').read_bytes())}
    bindings = bind_candidates(data['mapping'], old_csv, metadata, public_root)
    for b in bindings:
        common = public_root / 'reviewer' / b['neutral_review_id'] / 'common'
        frozen = core.loads((common / 'frozen_items.json').read_bytes())
        authored = [i for i in tasks['T0030']['items'] if i['item_id'] in TARGET_ITEMS]
        core.require(frozen['task_id'] == 'T0030' and frozen['items'] == authored,
                     'T0030 packet frozen criterion/anchor copies differ')
        core.require(core.sha((common / 'scoring_policy.json').read_bytes()) == core.PINS['scoring_policy.json'],
                     'T0030 packet policy differs')
    by_rid = {b['neutral_review_id']: b for b in bindings}
    patches = {}
    records = data['records']
    core.require(len(records) == 12, 'Exactly twelve T0030 item-phase records required')
    for record in records:
        rid, phase, iid = record['neutral_review_id'], record['phase'], record['item_id']
        source_doc = core.loads((public_root / record['source_record']['path']).read_bytes())
        configuration = source_doc['judge_configuration']
        core.require(configuration.get('model', configuration.get('configured_model')) == 'gpt-6-astra',
                     'T0030 source model attribution differs')
        cid = by_rid[rid]['candidate_id']
        key = (cid, phase, iid)
        core.require(key not in patches, 'Duplicate T0030 item-phase')
        patches[key] = project_record(record)
    core.require(set(patches) == {(b['candidate_id'], p, i) for b in bindings for p in ('DRAFT', 'CHECK') for i in TARGET_ITEMS}, 'T0030 target coverage mismatch')
    # Frozen task is independently loaded by the caller; packet frozen copies checked by source adapter.
    core.require(TARGET_ITEMS <= {i['item_id'] for i in tasks['T0030']['items']}, 'Frozen target IDs missing')
    return patches, bindings, data

# Immutable exact prior six-candidate composites from the audited privacy-v2 release.
PRIOR_SIX_RECORD_PINS = {'DRAFT:C1274d0f103e9de4b': '321407796f09516a9b64b5bdc79eccfdd01ef6f41dab40e31ae081289678eaa0', 'DRAFT:C72179725ebcd4f54': 'e5f348fdb243ecab19f24deb0993473c8537b8707b1b29445b6abfd8b629ca7a', 'DRAFT:Ca0d90d663358a730': '74f99e0e564391eb9a87a21ec9d7154bc8e2e1b3572d404a9c24e65ae21f205a', 'DRAFT:Cdfc0bda9402e55d7': '0d47a8ecad159087db7750895727a33d13db663fc783853454764429f72a5a39', 'DRAFT:Ce5353b9efbae40ec': 'a749e45553575d53979e3d4e4f126cd48b01e05e0f885cc434ae37a1b866ac52', 'DRAFT:Ce62184d1a76a6fd1': 'ded6debf1770327dfd590cfc98157235b9e54663facb66434b118fb2d1b61b4e', 'CHECK:C1274d0f103e9de4b': 'f4530c3450d066057d3e070a46d2bc7252b7a29333dc9ce7d50e87639cabbcaa', 'CHECK:C72179725ebcd4f54': '588988bb1eb18071394223c2661dff818fc63fef946352d34daee51f9c4a9aad', 'CHECK:Ca0d90d663358a730': 'a1b8b38ceb44ddf9dc356bf4b572d5af43a643061336c5cad764faff38737081', 'CHECK:Cdfc0bda9402e55d7': 'd06e16e78c4ce2392088ea84a19aac1ce21f4e0a1152cb157b6bd47997e24188', 'CHECK:Ce5353b9efbae40ec': 'bffec8ec7ec92a980b7d6e93f183716e6cb7e32f878d48454ba06e279f503d92', 'CHECK:Ce62184d1a76a6fd1': '1fd6385f985d1e3c4fb66bf6cc9c9a31ac77e6f4f6e5027a2f1c8fe06096b60a', 'final_candidates:C1274d0f103e9de4b': 'caf2cab95f60bfdbf4d5618e7212a1612889979c01267c7c2a8d7c7a2fbc1c75', 'final_candidates:C72179725ebcd4f54': '1bbaec1cb99d038166f71780290b4e069531cf890f2e843d6118bdf3e2b89cf8', 'final_candidates:Ca0d90d663358a730': '433323c831c04946fb86587ef4a2a135dbfb3ddabb0e34f64c31dfb3d4cbcce4', 'final_candidates:Cdfc0bda9402e55d7': '09674bbc2c1ad7167b8da6f103e459eab220bd7cafbd453b4338f22efe565f04', 'final_candidates:Ce5353b9efbae40ec': '931b1ad3c6e5cdc56c644f003a9f92b70d4d2ed4e507d045f18486bb1926b8e8', 'final_candidates:Ce62184d1a76a6fd1': '5346c836e466fbed9eb74baf127e48f43149d849d9b40bd0c276e95c90395253'}
