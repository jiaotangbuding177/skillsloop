#!/usr/bin/env python3
"""Fresh unified publication with the frozen T0030 targeted review decisions.

No semantic scoring, HTML execution, networking, or modification of sources.
"""
import argparse
import copy
from pathlib import Path
import shutil
import sys
import zipfile
import json
import subprocess
import tempfile

sys.dont_write_bytecode = True
import recovery_core as core
import merge_release as merge
import paired_statistics as stats
import verify_unified
import verify_combined
import claim_merge_logic as claims
from build_unified_release import dump, manifest

PRIOR_SHA = '783a40a0cb950c2ccdd0bb0c4ee245305c95fd64f433e906ffcf9f7dc9b89b42'


def documents(out, summary, common, changes, differences):
    n, null, u, common_n = (summary[k] for k in ('complete_q', 'null_q', 'unknown_items', 'common_complete_tasks'))
    lines = ['Q评分750份统一全量版 · T0030证据门槛一致性复核版 · 2026-10-22', '',
             '全部750份结果均已提供，不代表750份均有数值Q。',
             f'250题 × 三组；750候选、1500个有效阶段视图、7929最终条目；{n}份完整Q、{null}份空Q、{u}个UNKNOWN。',
             f'三组共同完整任务{common_n}题。', '', '共同任务均值与95%任务bootstrap区间：']
    for method in core.METHODS:
        g = common['groups'][method]
        lines.append(f"{method}：{g['common_complete_q_mean']:.8f} [{g['common_complete_q_ci_lower']:.8f}, {g['common_complete_q_ci_upper']:.8f}]")
    lines += ['', '同一共同任务集配对差值，前者减后者：']
    for d in common['paired_differences']:
        lines.append(f"{d['contrast']}：{d['mean_paired_difference']:.8f} [{d['ci_lower']:.8f}, {d['ci_upper']:.8f}]")
    lines += ['', '各组覆盖集描述性均值，不自动代表全250题或共同任务比较：']
    for method in core.METHODS:
        g = common['groups'][method]['q_coverage']
        lines.append(f"{method}：{g['complete_count']}/250完整Q；覆盖集均值{g['covered_only_mean_descriptive']:.8f}。")
    lines += ['', '本版新增对T0030三臂的D1-01、D3-02同口径复核。此前原生/字体/日历六项补评保持不动。',
              'T0030的CHECK：三臂D1均UNKNOWN；NoSkill、Trace2Skills的D3为UNKNOWN；AutoSkills的D3为0。',
              'AutoSkills的D1从此前1改为UNKNOWN，使完整Q减少1。其本轮DRAFT为0.5、CHECK为UNKNOWN，最终严格取CHECK。',
              'AutoSkills的D3零分依据是报告中的保存提示边界错误建议，不是认定历史测试虚假；原记录的解释范围与人工复核提示保留。',
              f'DRAFT/CHECK分值或状态分歧现有{len(differences)}项，逐条列在draft_check_differences.jsonl。',
              '累计12个最终目标条目、24个目标条目阶段决定；7917个非目标最终对象及15834个非目标阶段条目对象完全保留。',
              '保留1500原阶段记录、12个先前单项补阶段记录和6个T0030双条目阶段记录，不能称为1518次整份候选重评。', '',
              f'剩余{null}份空Q：24份网页候选的实际运行/可视证据缺口，加T0030三份候选的特定历史实测断言未决。',
              '本次是对原包已有执行摘要、receipt、文件库存及报告文字哈希一致性的充分提取与一致性复核，不是恢复了完整历史命令或工具返回。',
              '旁证不能忽略，也不能自动当作具体浏览器观察。缺证不等于未执行或虚报；不新增完整日志的一律提交门槛。',
              '不要求用户继续寻找已确认不存在的历史文件；当前重跑也不能证明历史发生了什么。', '',
              '探索性模型评分，尚未人工校准。CHECK可见DRAFT，不是统计独立首评。',
              'UNKNOWN不当0、不重分配、不乘TSR。共同集bootstrap不反映judge系统误差、不消除缺失偏差，不认证全250题排名。']
    (out/'评分结果摘要.txt').write_text('\n'.join(lines)+'\n')
    (out/'先读我.txt').write_text(f'''这是统一的750份全量结果包，直接使用顶层文件，不必拼接任何补包。

1. 评分结果摘要.txt：当前{n}完整Q、{null}空Q、{u}个UNKNOWN，以及共同{common_n}题的比较。
2. candidate_scores.csv：全部750候选的Q、维度与覆盖率；空值不是零。
3. final_item_scores.csv、final_items.jsonl：全部7929条目的分值、理由与来源。
4. DRAFT.jsonl、CHECK.jsonl、final_candidates.jsonl：当前有效阶段组合及CHECK最终结果。
5. common_complete_*：共同任务分数、均值、配对差与固定seed的bootstrap。
6. supplement_changes.jsonl：累计24条目标阶段来源替换，不表示24个数值都改变。
7. item_preservation_audit.jsonl、remaining_*：非目标保持及未决清单。
8. 方法与来源说明.txt、T0030复核与发行转换说明.txt：科学来源、盲态和公开边界。

Python 3.10以上，标准库，无联网。当前唯一整包复验入口：
python -B verification_tools/verify_combined.py .
自测：python -B -m unittest discover -s verification_tools -p 'test_*.py'
自测只在临时目录建测试文件，不改本包评分。不要把另行输出写进本包。
公开自测82项中79项执行、3项明确跳过：不分发的原始内部字节保持、原件与投影逐字段比较、原始输入构建篡改测试。
这3项在内部准备阶段使用真实原件通过，不会用公开哈希冒充对缺席原件的字节复验；全部公开副本负向测试仍执行。

history保存基线原发行及上版说明/摘要。历史数字仅代表历史版本，不是当前汇总。
supplement_evidence_v3为之前原生/字体/日历补评材料；test_claim_evidence为本轮T0030中性packet和公开阶段记录。
两者均不是整750份原始产物/完整manifest的重复分发。原evidence_metadata_index仍只是元数据索引。
特别注意：旧v3 README、旧verify脚本与旧SHA清单作为历史原件保留，不能用其strict命令验证已隐去8图的公开树。
原v3完整ZIP含隐私图片，不随本包分发。当前完整性以根SHA256SUMS.txt及verify_combined.py为准。
T0030包内HTML只作为源码证据提供，整包复验不运行HTML或候选脚本。
''')
    method = f'''方法与来源说明

1. 冻结规则
250题2643量表条目，三臂共7929最终条目。单项0、0.5、1或UNKNOWN；D1–D5权重0.3/0.2/0.2/0.2/0.1。
每维度固定全适用条目分母；任一UNKNOWN则该维度null，任一维度null则Q null。维度先round8，再固定加权并round8。
不填0、不对未知重分配权重、不乘TSR。covered-only均值仅描述，不替代Q。

2. 阶段及来源
history/基线原发行_补证更新版_20261022.zip完整保留真实恢复的原750 DRAFT、750 CHECK。它已经是公开发行派生记录，不是未脱敏原judge文件。
当前每阶段741个候选沿用原记录对象，9个是目标条目来源组合。先前6候选组合schema v2保持原样；本轮T0030三候选为多目标组合schema v3。
顶层judge_id为空表示不是整候选新评分者。base_phase_source保留原阶段来源、judge身份及盲态说明；旧defects只作用于旧阶段。
新增来源为12个先前单项阶段文件和6个T0030双条目阶段文件，共18来源文件、24条目标阶段决定，而不是18次整候选重评。
所有12目标外7917个最终对象及15834个阶段条目对象完全不变。先前六项补评的完整阶段组合与最终记录也通过独立固定摘要锁定不变。
CHECK最终，不择高、不平均。有效视图1500条不与原1500相加假称3000次评分。

3. T0030一致性复核
新中性ID通过T0030、已经公开的方法名及验收报告.md和问题清单.json两份原输出字节SHA共同连接旧candidate_id；test_claim_candidate_binding.json公开连接，私有桥表不分发。
本次没有恢复完整历史命令/工具返回。复核充分阅读原包执行摘要、receipt、库存和文本哈希一致性，认可旁证但不等同于具体浏览器观察。
同一门槛评审三臂D1-01、D3-02。CHECK三臂D1均UNKNOWN；两个D3 UNKNOWN；AutoSkills D3为0。
AutoSkills D1旧1被新CHECK UNKNOWN替代。本次DRAFT 0.5与CHECK UNKNOWN分歧完整保留；UNKNOWN字符串明确归一化为null，绝不转0。
AutoSkills D3零分来自交付文本独立可见的完成式消息建议，未断言页面已经改动或历史测试被证伪；原评审解释和人工复核限制保留。
完整Q由724变为{n}，空Q为{null}，UNKNOWN为{u}；这是真实更新，不为维持覆盖率而保留旧已知分。

4. 盲态与评审性质
原版本11候选的历史定向补评看过其同候选旧阶段分数，historical_scores_exposed=true，不得称完全对旧分盲态；原披露保留。
本轮T0030原记录声明未见组别、TSR、旧分或其他候选；CHECK见本次对应DRAFT。公开合并在方法已公开后进行，不据方法改分。
仍为GPT-6 Astra的探索性模型评审，不是人工签核、独立首评信度或judge校准。新补评者只归属其实际目标，不被描述成看过其他条目。

5. 比较
共同{common_n}题由三组Q均完整的任务交集确定。同一任务的三臂配对。
random.Random(20261021)，10000次任务bootstrap，任务ID升序，同一次三个方法/差值共用抽样下标；(B-1)p线性百分位，输出round8。
各臂覆盖集均值单独描述；完整250题均值、全类别宏均值仍null。区间不覆盖judge偏差或缺失偏差，不能当作全250题排名认证。

6. 公开证据边界
旧evidence_metadata_index不是完整可重跑manifest，旧source_result_sha256和manifest SHA指向来源而非当前发行行字节。
原8张含内部路径像素图仍privacy_withheld，原图未修改，原v3 ZIP不分发；原路径/哈希/引用保留，不能据哈希查看隐藏像素。
T0030六阶段源文件内部原样保留，4份公开副本字节相同；2份CHECK仅3个内部路径字段显式改为便携路径。分数、理由、引文不改。
public_sources_receipt.json分别列原SHA与公开SHA、字段转换。原内部文件哈希不冒充当前公开文件字节哈希。
T0030归一化保存完整原单项decision对象及JSON pointer，原文字UNKNOWN转null的规则透明；不要求原评审重写冻结记录。
24网页缺口与T0030特定历史实测未决保留。不再要求用户找不存在文件；当前执行不能证明历史执行。

7. 机械验证
工具为本次重新编写的标准库实现，不冒充丢失的原qvalidate。验证实际字节、来源、范围、计数、CHECK、固定分母和所有统计；不进行语义再评分。
机械PASS不证明judge正确，不消除UNKNOWN，不补回未提供的原始证据。未运行候选HTML或脚本。
根SHA256SUMS.txt只列实际发行文件，旧source清单仅为明确的来源记录。原件、先前冻结ZIP及本轮评审原文件均不覆盖。
'''
    (out/'方法与来源说明.txt').write_text(method)
    (out/'T0030复核与发行转换说明.txt').write_text('本版T0030复核采用同一冻结标准，不设完整日志一律要求，也不忽略成功执行和文件库存旁证。\n原始评审文件不改动。公开副本仅声明的3个内部路径字段转换，全部引文/理由/决定保持；逐文件原SHA与公开SHA见test_claim_evidence/public_sources_receipt.json。\n单项UNKNOWN字符串归一化为null，完整原decision对象及原JSON pointer保留；阶段分歧按CHECK终值处理。\n执行摘要、原文件库存、文本哈希一致性是旁证，不是新取得的完整历史浏览器执行记录。\n')
    privacy = (out/'隐私删图发行说明.txt').read_text()
    privacy = privacy.replace('724份完整Q、26份空Q、187个UNKNOWN及所有统计保持不变。', '隐私删图本身不改分；本版另有明确记录的T0030一致性复核，最新数字以评分结果摘要为准。')
    privacy = privacy.replace('本版仅改变公开分发材料，不更改任何评分、理由或原引用。',
                              '隐私处理本身只改变公开分发材料，不改评分、理由或原引用。')
    obsolete = 'T0030：本版现有UNKNOWN保持。原包执行摘要与文件清单证据正在一致性复核，完整命令/工具返回尚未找到；尚无新阶段决定，不先行加分。'
    core.require(privacy.count(obsolete) == 1, 'Expected legacy T0030 privacy-note status not found')
    privacy = privacy.replace(obsolete, 'T0030本轮一致性复核已完成三份DRAFT和三份CHECK，最新决定已合入本版。AutoSkills的D1由此前1改为UNKNOWN；所有更新、分歧与来源详见方法与来源说明及逐项记录。此次充分提取和审阅原包已有执行摘要、receipt、库存及文本哈希旁证，并未恢复完整历史命令或工具返回。')
    privacy = privacy.replace('verification_tools/verify_unified.py', 'verification_tools/verify_combined.py')
    (out/'隐私删图发行说明.txt').write_text(privacy)



def public_test_receipt(out):
    """Generate receipt from actual unittest results, not hand-entered names."""
    program = """import json, sys, unittest
suite = unittest.defaultTestLoader.discover('verification_tools', pattern='test_*.py')
result = unittest.TextTestRunner().run(suite)
print(json.dumps({'successful': result.wasSuccessful(), 'discovered': result.testsRun,
                  'skipped_tests': [test.id().rsplit('.', 1)[-1] for test, reason in result.skipped]}))
sys.exit(0 if result.wasSuccessful() else 1)
"""
    with tempfile.TemporaryDirectory(prefix='public-q-tests-') as temporary:
        temporary = Path(temporary)
        shutil.copytree(out/'verification_tools', temporary/'verification_tools')
        shutil.copytree(out/'test_claim_evidence', temporary/'test_claim_evidence')
        tested = subprocess.run([sys.executable, '-B', '-c', program], cwd=temporary,
                                text=True, capture_output=True, check=False)
        core.require(tested.returncode == 0, 'Isolated public-only tests failed: ' + tested.stderr)
        actual = core.loads(tested.stdout.encode())
        core.require(actual['successful'] and actual['discovered'] == 82 and len(actual['skipped_tests']) == 3,
                     'Unexpected actual public test outcome')
    return {'status': 'PASS_PUBLIC_ONLY_TESTS_WITH_EXPLICIT_SOURCE_BOUNDARY',
            'discovered': actual['discovered'],
            'executed_and_passed': actual['discovered'] - len(actual['skipped_tests']),
            'skipped_original_source_required': len(actual['skipped_tests']),
            'isolated_from_private_inputs': True, 'source_preparation_tests_all_passed': 82,
            'skipped_tests': actual['skipped_tests'],
            'test_names_origin': 'ACTUAL_UNITTEST_RESULT_SKIPPED_OBJECTS',
            'not_claimed': 'Public hashes do not revalidate undistributed original private bytes.'}

def run(args):
    source, sourcezip, inputs, out, zipout = map(Path, (args.source,args.source_zip,args.review_input,args.out,args.zip))
    core.require(not out.exists() and not zipout.exists(), 'Fresh outputs required')
    source_digest = core.sha(sourcezip.read_bytes())
    input_hashes = {p.relative_to(inputs).as_posix(): core.sha(p.read_bytes()) for sub in ('reviewer','judgments') for p in (inputs/sub).rglob('*') if p.is_file()}
    bridge_path = inputs/'private/candidate_bridge.json'
    input_bridge_sha = core.sha(bridge_path.read_bytes())
    for b in core.loads(bridge_path.read_bytes())['candidates']:
        for member, expected_sha in b['source_hashes'].items():
            core.require(core.sha((Path(b['source_directory'])/member).read_bytes()) == expected_sha, 'Original T0030 source file hash differs')
    core.require(source_digest == PRIOR_SHA, 'Wrong audited privacy-v2 source')
    prior = core.verify_archive(sourcezip, PRIOR_SHA, source.name + '/')
    core.require({p.relative_to(source).as_posix() for p in source.rglob('*') if p.is_file()} == set(prior), 'Prior source directory inventory changed')
    for name, raw in prior.items(): core.require((source/name).read_bytes() == raw, 'Prior directory/ZIP differ')
    verify_unified.verify(source)
    tasks = core.load_release(source/'rubric_release')
    old = core.verify_archive(source/'history/基线原发行_补证更新版_20261022.zip', core.OLD_ZIP_SHA)
    old_phases, old_final, old_flat, old_csv, old_summary = merge.old_adapter(old, tasks)
    import public_test_claim_sources as public
    out.mkdir(parents=True)
    for name, raw in prior.items():
        path = out/name; path.parent.mkdir(parents=True, exist_ok=True); path.write_bytes(raw)
    public.build_public_sources(inputs, out/'test_claim_evidence')
    patches, bindings, public_data = claims.load_patches(out/'test_claim_evidence', old_csv, merge.jsonl(old['evidence_metadata_index.jsonl']), tasks)
    dump(out/'test_claim_candidate_binding.json', bindings)
    target_cids = {b['candidate_id'] for b in bindings}
    previous = {p: merge.unique(merge.jsonl(prior[p+'.jsonl']), lambda r:r['candidate_id']) for p in ('DRAFT','CHECK')}
    phases = copy.deepcopy(previous)
    changes = merge.jsonl(prior['supplement_changes.jsonl'])
    for phase, rows in phases.items():
        for cid in sorted(target_cids):
            base = old_phases[phase][cid]
            patch_list = [patches[cid, phase, iid] for iid in sorted(claims.TARGET_ITEMS)]
            rows[cid] = claims.merge_multi_phase(base, patch_list, tasks['T0030'])
            for patch in patch_list:
                original = next(i for i in base['items'] if i['item_id'] == patch['item_id'])
                changes.append({'candidate_id':cid,'task_id':'T0030','method':base['method'],'phase':phase,
                    'item_id':patch['item_id'],'before_status':original['status'],'before_score':original['score'],
                    'after_status':patch['status'],'after_score':patch['score'],'before_q_0_100':base['q_0_100'],
                    'after_q_0_100':rows[cid]['q_0_100'],'before_item_canonical_sha256':core.canonical_sha(original),
                    'after_item_canonical_sha256':core.canonical_sha(patch),'supplement_record':patch['source_review_record']})
    final = merge.unique(merge.jsonl(prior['final_candidates.jsonl']), lambda r:r['candidate_id'])
    flat = merge.unique(merge.jsonl(prior['final_items.jsonl']), lambda r:(r['candidate_id'],r['item_id']))
    for cid in sorted(target_cids):
        draft, check = phases['DRAFT'][cid], phases['CHECK'][cid]
        final[cid] = copy.deepcopy(check)
        final[cid].update(final_phase='CHECK', finalization_rule='CHECK_ONLY_NOT_MAX_NOT_AVERAGE',
            draft_composite_canonical_sha256=core.canonical_sha(draft), check_composite_canonical_sha256=core.canonical_sha(check))
        for item in check['items']:
            if item['item_id'] in claims.TARGET_ITEMS:
                authored = next(i for i in tasks['T0030']['items'] if i['item_id'] == item['item_id'])
                flat[cid,item['item_id']] = {**copy.deepcopy(item),'candidate_id':cid,'task_id':'T0030','method':check['method'],
                    'phase':'CHECK','dimension':authored['dimension'],'weight':authored['weight'],'applicability':authored['applicability'],
                    'schema_version':'qjudging-composite-public-item-v3','publication':{'is_original_judge_record':False,'kind':'TARGETED_REVIEW_ITEM_PROJECTION'}}
    targets = {(x['candidate_id'],x['item_id']) for x in changes}
    core.require(len(targets)==12 and len(changes)==24 and len(target_cids)==3, 'Wrong target scope')
    preservation, differences = [], []
    for key, item in sorted(flat.items()):
        target = key in targets
        core.require(target or item == old_flat[key], 'Non-target final item changed')
        preservation.append({'candidate_id':key[0],'item_id':key[1],'targeted_supplement':target,
            'old_final_item_canonical_sha256':core.canonical_sha(old_flat[key]),'new_final_item_canonical_sha256':core.canonical_sha(item),
            'unchanged_item_exact_object_equal':None if target else True})
        cid,iid=key
        draft=next(i for i in phases['DRAFT'][cid]['items'] if i['item_id']==iid)
        if (draft['status'],draft['score']) != (item['status'],item['score']):
            differences.append({'candidate_id':cid,'task_id':item['task_id'],'method':item['method'],'item_id':iid,
                'draft_status':draft['status'],'draft_score':draft['score'],'check_status':item['status'],'check_score':item['score'],
                'draft_reason':draft['reason'],'check_reason':item['reason'],'final_rule':'CHECK_ONLY'})
    # Only overwrite our fresh copied output, never a frozen predecessor.
    for name, rows in {'DRAFT.jsonl':[phases['DRAFT'][c] for c in sorted(final)],'CHECK.jsonl':[phases['CHECK'][c] for c in sorted(final)],
        'final_candidates.jsonl':[final[c] for c in sorted(final)],'final_items.jsonl':[flat[k] for k in sorted(flat)],
        'supplement_changes.jsonl':changes,'item_preservation_audit.jsonl':preservation,'draft_check_differences.jsonl':differences}.items():
        (out/name).unlink(); merge.wjsonl(out/name, rows)
    for name in ('candidate_scores.csv','final_item_scores.csv','remaining_unknown_items.csv'): (out/name).unlink()
    candidates=sorted(final.values(),key=lambda r:(r['task_id'],r['method']))
    merge.wcsv(out/'candidate_scores.csv',[{'candidate_id':r['candidate_id'],'task_id':r['task_id'],'method':r['method'],
        'q_0_100':r['q_0_100'],'status':r['status'],'item_coverage':r['item_coverage'],
        **{d+'_0_100':r['dimensions'][d]['score_0_100'] for d in core.WEIGHTS},
        **{d+'_coverage':r['dimensions'][d]['item_coverage'] for d in core.WEIGHTS}} for r in candidates])
    fields=('candidate_id','task_id','method','item_id','dimension','weight','status','score','reason')
    merge.wcsv(out/'final_item_scores.csv',[{k:i.get(k) for k in fields} for key,i in sorted(flat.items())])
    unknown=[i for i in flat.values() if i['score'] is None]
    uf=('candidate_id','task_id','method','item_id','dimension','status','score','reason')
    merge.wcsv(out/'remaining_unknown_items.csv',[{k:i[k] for k in uf} for i in unknown])
    dump(out/'remaining_null_candidates.json',[{'candidate_id':r['candidate_id'],'task_id':r['task_id'],'method':r['method'],
        'q_0_100':None,'unknown_item_ids':[i['item_id'] for i in r['items'] if i['score'] is None]} for r in candidates if r['q_0_100'] is None])
    summary=core.validate_cohort(list(final.values())); dump(out/'coverage.json',summary)
    cohort=stats.load_scores(out/'candidate_scores.csv',frozen_categories=stats.read_frozen_categories(out/'rubric_release'))
    common=stats.analyze(cohort)
    for name,text in stats.render_outputs(cohort,common).items(): (out/name).write_text(text)
    for name in ('公开发行复验.json','公开合并机械审计.json','评分结果摘要.txt','方法与来源说明.txt','先读我.txt','隐私删图发行说明.txt'):
        (out/'history'/('前次隐私修订v2_'+name)).write_bytes(prior[name])
    documents(out,summary,common,changes,differences)
    audit={'status':'PASS_MECHANICAL_SOURCE_COMPOSITION_NOT_SEMANTIC_CALIBRATION','previous_privacy_release_sha256':PRIOR_SHA,
        'original_baseline_archive_sha256':core.OLD_ZIP_SHA,'original_frozen_pins':core.PINS,
        'candidate_count':750,'effective_phase_views':1500,'final_items':7929,'retained_original_phase_records':1500,
        'supplement_source_phase_records':18,'target_final_items':12,'target_item_phase_decisions':24,
        'unchanged_final_item_objects':7917,'unchanged_phase_item_objects':15834,'prior_six_candidate_records_unchanged':True,
        'coverage':{k:v for k,v in summary.items() if k not in ('groups','common_task_ids')},
        'draft_check_score_status_differences':len(differences),'review_source_pins':public_data['receipt'],
        'source_files_modified':False,'human_review_completed':False,'judge_calibration_completed':False,
        'newly_recovered_complete_historical_logs':False,'candidate_html_or_scripts_executed':False}
    dump(out/'公开合并机械审计.json',audit)
    tools=Path(__file__).resolve().parent
    for name in ('claim_merge_logic.py','verify_combined.py','build_claim_review_release.py','public_test_claim_sources.py',
                 'test_claim_merge_logic.py','test_public_test_claim_sources.py'):
        shutil.copyfile(tools/name,out/'verification_tools'/name)
    dump(out/'公开自测边界.json', public_test_receipt(out))
    (out/'公开发行复验.json').unlink()
    manifest(out)
    report=verify_combined.verify(out); report['checksum_files']+=1
    dump(out/'公开发行复验.json',report); manifest(out)
    core.require(verify_combined.verify(out)==report,'Final receipt mismatch')
    # Recheck immutable predecessor and all original review source hashes at the end.
    core.require(core.sha(sourcezip.read_bytes())==source_digest,'Previous ZIP mutated')
    for name,raw in prior.items(): core.require((source/name).read_bytes()==raw,'Previous release changed during build')
    core.require(core.sha(bridge_path.read_bytes()) == input_bridge_sha, 'Private bridge changed during build')
    for member, h in input_hashes.items(): core.require(core.sha((inputs/member).read_bytes()) == h, 'Original review input changed during build')
    with zipfile.ZipFile(zipout,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in sorted(out.rglob('*')):
            if p.is_file():
                info=zipfile.ZipInfo(out.name+'/'+p.relative_to(out).as_posix(),date_time=(2026,10,22,0,0,0))
                info.compress_type=zipfile.ZIP_DEFLATED;info.create_system=3;info.external_attr=0o100644<<16
                z.writestr(info,p.read_bytes(),compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
    digest=core.sha(zipout.read_bytes()); verified=core.verify_archive(zipout,digest,out.name+'/')
    core.require(len(verified)==report['checksum_files']+1,'ZIP member count differs')
    print(json.dumps({'status':'FROZEN_PENDING_INDEPENDENT_ACCEPTANCE','zip_name':zipout.name,'bytes':zipout.stat().st_size,
                      'sha256':digest,'verification':report},ensure_ascii=False,indent=2))


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for name in ('source','source-zip','review-input','out','zip'):p.add_argument('--'+name,required=True)
    run(p.parse_args())
