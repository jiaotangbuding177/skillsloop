from pathlib import Path
import json, re, hashlib
root = Path(__file__).resolve().parents[1]
report = (root / 'outputs' / '验收报告.md').read_text(encoding='utf-8')
literal = r'项目报告\n本次交付：风险与行动'
locations = []
for match in re.finditer(re.escape(literal), report):
    locations.append({'line_1_based': report.count('\n', 0, match.start()) + 1,
                      'character_offset_0_based': match.start(),
                      'literal': match.group(0)})
# Only replace the displayed backslash+n with LF. No other normalization.
text = literal.replace('\\n', '\n')
payload = text.encode('utf-8')  # No BOM, no trailing newline.
digest = hashlib.sha256(payload).hexdigest()
receipt = json.loads((root / 'metadata' / 'receipt_evidence.json').read_text(encoding='utf-8'))
targets = []
for selection in receipt['selections']:
    pointer = selection['json_pointer']
    if pointer.startswith('/final_inventory/') and pointer.lower().endswith('.txt'):
        expected = selection['value']
        targets.append({'receipt_json_pointer': pointer, 'inventory': expected,
                        'byte_count_equal': len(payload) == expected['bytes'],
                        'sha256_equal': digest == expected['sha256']})
result = {'calculation_kind': 'report_text_to_inventory_comparison_only',
          'report_literal_occurrences': locations,
          'transformation': 'Replace literal backslash+n with LF; UTF-8; no BOM; no trailing newline; no other normalization.',
          'computed_text_json': text, 'computed_bytes': len(payload),
          'computed_hex': payload.hex(), 'computed_sha256': digest,
          'inventory_txt_comparisons': targets,
          'scope': 'This calculation hashes a string printed in the report. It neither reads an original downloaded TXT body nor runs a browser. An equality is byte/hash consistency with the inventory entry, not independent proof of how, when, or by which program the inventoried file was created.'}
print(json.dumps(result, ensure_ascii=False, indent=2))
