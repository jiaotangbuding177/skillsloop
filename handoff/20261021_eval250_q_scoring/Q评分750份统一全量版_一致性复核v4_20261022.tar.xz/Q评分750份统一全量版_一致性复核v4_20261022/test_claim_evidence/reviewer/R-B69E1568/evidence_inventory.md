# Evidence inventory

Scope: T0030-D1-01 and T0030-D3-02 only.

The packet contains complete original deliverable bodies and complete answer strings. Common task inputs include both source HTML files. Metadata files contain field-exact selections with original source SHA-256 values and JSON pointers; they are not unabridged original metadata files.

Read the underlying evidence, not just this inventory or schema summary:
- common/review_prompt.txt: identical review instructions.
- common/task/: original prompt, task description and all five input files.
- common/T0030.md and common/frozen_items.json: frozen rubric context and the two complete item objects.
- common/scoring_policy.json and common/provenance.json: complete byte-identical policy and source mapping.
- outputs/验收报告.md and outputs/问题清单.json: complete byte-identical deliverables.
- answer.txt and metadata/answer_texts.json: complete answer and recorded answer variants.
- metadata/request_evidence.json: task/configuration fields and input digest references.
- metadata/response_evidence.json: complete recorded runtime tool-summary entries, artifact list and completion markers.
- metadata/receipt_evidence.json: receipt status, tool summary, relevant before/final inventories and answer.
- metadata/call_observations.json: available call/path/argument-key/hash/return-hash observations as recorded.
- inventory_availability.json: all relevant inventory entries and whether the corresponding body is in the supplied sources.
- schema_observations.json: literal field names and availability observations, not raw command returns.
- calculation/compare_report_text.py, result.json, execution_receipt.json: exact deterministic report-string hash comparison and limitations.
- provenance_and_disclosure.json: full disclosure of derivative scope.

The supplied runtime.tools records contain call_id, name, exit_code and error markers. They contain no command value or stdout/stderr body. Additional receipt observations contain argument key names and hashes, and some contain return hashes and literal path observations; those are not raw command or return bodies. Where a test file is inventoried but its body is absent, its recorded byte size and SHA-256 are still disclosed. No current browser was run to prepare this packet.

Recorded test-related file entries:
- tmp/verify.py: 1415 bytes; SHA-256 532144b56c7fb680135c39c7362b21b4c5d38e7c8e086f0ade448c29e7f27a29; body not present in supplied artifact bundle.
