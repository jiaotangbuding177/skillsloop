# T0156 当前浏览器观察（不评分）

查看六维题量/时长5/8、6/12、6/12、5/8、5/8、4/7（题/分钟），合计31题55分钟；陈棠2026-10-08得分74/68/82/71/88/63、55分钟及再次测评入口。电话尾号0108；PC和平板为紫蓝主体。

观察时间为动作日志中的UTC时间。浏览器为用户电脑已安装Chrome 155.0.8059.85，headless Chromium渲染；不代表真实物理平板。PC 1440×1000 / 平板模拟820×1180，DPR=1。

限制：无真实账号或作答服务。autoskill导航裁切是实际视觉问题；DOM存在和hash到达不替代可见性。

## autoskill

六维、流程和陈棠结果可读，开始测评显示演示说明。实际PC展开菜单被页头裁切，仅见菜单上缘；键盘焦点虽可见，不能据此声称菜单视觉正常。平板基态页头只有标识及登录，没有完整导航。补验hero“了解测评范围”确实到#dimensions；对菜单链接scrollIntoView后点击也到#dimensions，但该动作会滚动被裁切容器，因此不证明普通指针能看到完整菜单。旧09_link_02误到#records保留为含歧义的旧动作。

原件独立副本：`original_copies/artifacts/T0156__autoskill/outputs/index.html`；SHA256 `d99f182f67c8c00f4bfb8ab7e6028824b627971af446ee81aece0065c3a59143`。

运行记录：`observations/T0156__autoskill_run`, `observations/T0156__autoskill_nav_recheck`。

每次动作的预期、实际URL/焦点/尺寸、UTC时间及截图SHA见actions.jsonl；同名JSON为辅助状态，不替代像素。

精简包原始截图：

- `observations/T0156__autoskill_nav_recheck/02_hero_dimensions.png`
- `observations/T0156__autoskill_nav_recheck/03_menu_open.png`
- `observations/T0156__autoskill_nav_recheck/04_menu_dimensions.png`
- `observations/T0156__autoskill_nav_recheck/05_tablet_nav.png`
- `observations/T0156__autoskill_run/02_desktop_full.png`
- `observations/T0156__autoskill_run/03_keyboard_menu_focus.png`
- `observations/T0156__autoskill_run/04_keyboard_menu_open.png`
- `observations/T0156__autoskill_run/05_keyboard_first_target.png`
- `observations/T0156__autoskill_run/06_keyboard_target_activated.png`
- `observations/T0156__autoskill_run/14_button_00.png`
- `observations/T0156__autoskill_run/15_button_01.png`
- `observations/T0156__autoskill_run/17_tablet_full.png`
- `observations/T0156__autoskill_run/18_tablet_keyboard.png`

## no_skill

六个维度说明按钮逐一展开实际文本；再次测评到本地测评入口，账号入口为演示说明；橙色键盘焦点可见。中断后的平板观察由_resume完成。

原件独立副本：`original_copies/artifacts/T0156__no_skill/outputs/index.html`；SHA256 `ef4f71b3d7b096d083a678510d59d880047841a7e87ce26de17f439be48a73e1`。

运行记录：`observations/T0156__no_skill_run`, `observations/T0156__no_skill_resume`。

每次动作的预期、实际URL/焦点/尺寸、UTC时间及截图SHA见actions.jsonl；同名JSON为辅助状态，不替代像素。

精简包原始截图：

- `observations/T0156__no_skill_resume/03_tablet_full.png`
- `observations/T0156__no_skill_resume/04_tablet_keyboard.png`
- `observations/T0156__no_skill_run/02_desktop_full.png`
- `observations/T0156__no_skill_run/03_keyboard_menu_focus.png`
- `observations/T0156__no_skill_run/04_keyboard_menu_open.png`
- `observations/T0156__no_skill_run/05_keyboard_first_target.png`
- `observations/T0156__no_skill_run/06_keyboard_target_activated.png`
- `observations/T0156__no_skill_run/21_button_00.png`
- `observations/T0156__no_skill_run/22_button_01.png`
- `observations/T0156__no_skill_run/23_button_02.png`
- `observations/T0156__no_skill_run/24_button_03.png`
- `observations/T0156__no_skill_run/25_button_04.png`
- `observations/T0156__no_skill_run/26_button_05.png`

## trace2skill

开始/再次测评打开六维/全部选项弹窗，选择AI认知并确认后显示绿色本地演示确认信息；未发送真实测评或邀请。六维记录及PC/平板内容可读。

原件独立副本：`original_copies/artifacts/T0156__trace2skill/outputs/index.html`；SHA256 `eb26fb5725f8012e1616783b0ba013844241546bbc05c26b99a5336c6caa0228`。

运行记录：`observations/T0156__trace2skill_run`。

每次动作的预期、实际URL/焦点/尺寸、UTC时间及截图SHA见actions.jsonl；同名JSON为辅助状态，不替代像素。

精简包原始截图：

- `observations/T0156__trace2skill_run/02_desktop_full.png`
- `observations/T0156__trace2skill_run/03_keyboard_menu_focus.png`
- `observations/T0156__trace2skill_run/04_keyboard_menu_open.png`
- `observations/T0156__trace2skill_run/05_keyboard_first_target.png`
- `observations/T0156__trace2skill_run/06_keyboard_target_activated.png`
- `observations/T0156__trace2skill_run/19_button_00.png`
- `observations/T0156__trace2skill_run/20_button_01.png`
- `observations/T0156__trace2skill_run/21_button_02.png`
- `observations/T0156__trace2skill_run/22_button_03.png`
- `observations/T0156__trace2skill_run/23_repeat_assessment.png`
- `observations/T0156__trace2skill_run/24_assessment_selected.png`
- `observations/T0156__trace2skill_run/25_assessment_confirmation.png`
- `observations/T0156__trace2skill_run/27_tablet_full.png`
- `observations/T0156__trace2skill_run/29_tablet_keyboard.png`
