# T0179 当前浏览器观察（不评分）

六型号数据可读，单位人民币/百万token，核验日2026-10-10。三厂商各筛出2项，图像2项、纯文本4项，澈语+图像0项、北辰+图像2项，清空恢复6项。实际价格升序CY-Lite、BC-Fast、QZ-Long、CY-Enterprise、QZ-Reason、BC-Vision；可用排序模式逐个切换并留图。输入价/输出价在该数据同序，仅凭结果不能区分比较器依据。

观察时间为动作日志中的UTC时间。浏览器为用户电脑已安装Chrome 155.0.8059.85，headless Chromium渲染；不代表真实物理平板。PC 1440×1000 / 平板模拟820×1180，DPR=1。

限制：旧trace2skill_run因取证选择器Unicode转义错误中止，仅两张准备图，最终筛选证据为_verified。排序依据同序限制未通过改数据规避。

## autoskill

默认厂商顺序、输入价升序、输出价升序、输入+输出合计升序及上下文降序均有操作证据；界面没有价格降序选项。中断的sort_3只有旧JSON，_resume/02_sort_3.png补充了合计排序实际图，_context_recheck补齐上下文降序。场景A列QZ-Long与BC-Vision，B列BC-Vision与BC-Fast。

原件独立副本：`original_copies/artifacts/T0179__autoskill/outputs/models.html`；SHA256 `e69d2fd76d6abe31f6c951ecb44d2b393f96c07183a42843a6fe8200fc9a76e4`。

运行记录：`observations/T0179__autoskill_run`, `observations/T0179__autoskill_resume`, `observations/T0179__autoskill_context_recheck`。

每次动作的预期、实际URL/焦点/尺寸、UTC时间及截图SHA见actions.jsonl；同名JSON为辅助状态，不替代像素。

精简包原始截图：

- `observations/T0179__autoskill_context_recheck/02_context_descending.png`
- `observations/T0179__autoskill_resume/02_sort_3.png`
- `observations/T0179__autoskill_resume/04_desktop_full.png`
- `observations/T0179__autoskill_resume/06_tablet_full.png`
- `observations/T0179__autoskill_resume/07_tablet_focus.png`
- `observations/T0179__autoskill_run/03_vendor_0.png`
- `observations/T0179__autoskill_run/04_vendor_1.png`
- `observations/T0179__autoskill_run/05_vendor_2.png`
- `observations/T0179__autoskill_run/07_vision.png`
- `observations/T0179__autoskill_run/08_text.png`
- `observations/T0179__autoskill_run/09_empty_combination.png`
- `observations/T0179__autoskill_run/10_matched_combination.png`
- `observations/T0179__autoskill_run/11_filters_cleared.png`
- `observations/T0179__autoskill_run/12_sort_0.png`
- `observations/T0179__autoskill_run/13_sort_1.png`
- `observations/T0179__autoskill_run/14_sort_2.png`

## no_skill

筛选恢复和输入/输出升序、上下文降序有真实状态。平板右侧列在可横滚表格内，实际水平滚轮后显示核验日期/依据材料；页面本身宽度805<=820。场景A和B均列对应两候选。

原件独立副本：`original_copies/artifacts/T0179__no_skill/outputs/models.html`；SHA256 `ff3cbe944cd99fc7c83a9f6c14da580cda08d4890b5b4f0c226756468433d996`。

运行记录：`observations/T0179__no_skill_run`, `observations/T0179__no_skill_horizontal_recheck`。

每次动作的预期、实际URL/焦点/尺寸、UTC时间及截图SHA见actions.jsonl；同名JSON为辅助状态，不替代像素。

精简包原始截图：

- `observations/T0179__no_skill_horizontal_recheck/02_tablet_left.png`
- `observations/T0179__no_skill_horizontal_recheck/03_tablet_horizontal_right.png`
- `observations/T0179__no_skill_run/03_vendor_0.png`
- `observations/T0179__no_skill_run/04_vendor_1.png`
- `observations/T0179__no_skill_run/05_vendor_2.png`
- `observations/T0179__no_skill_run/07_vision.png`
- `observations/T0179__no_skill_run/08_text.png`
- `observations/T0179__no_skill_run/09_empty_combination.png`
- `observations/T0179__no_skill_run/10_matched_combination.png`
- `observations/T0179__no_skill_run/11_filters_cleared.png`
- `observations/T0179__no_skill_run/12_sort_0.png`
- `observations/T0179__no_skill_run/13_sort_1.png`
- `observations/T0179__no_skill_run/14_sort_2.png`
- `observations/T0179__no_skill_run/16_desktop_full.png`
- `observations/T0179__no_skill_run/18_tablet_full.png`
- `observations/T0179__no_skill_run/19_tablet_focus.png`

## trace2skill

筛选恢复、排序有效；场景A候选表只列QZ-Long，正文说BC-Vision可用但价格高、视觉本场景无用，未将它列入A候选表。平板文档宽度918>820，实际水平滚轮移动整页并让左侧内容离屏；不能声称平板无溢出。

原件独立副本：`original_copies/artifacts/T0179__trace2skill/outputs/models.html`；SHA256 `2df6a4e5a8701231602ec215846e2186dea880bbaf725ae2c8243bda9bb857cd`。

运行记录：`observations/T0179__trace2skill_verified`, `observations/T0179__trace2skill_horizontal_recheck`。

每次动作的预期、实际URL/焦点/尺寸、UTC时间及截图SHA见actions.jsonl；同名JSON为辅助状态，不替代像素。

精简包原始截图：

- `observations/T0179__trace2skill_horizontal_recheck/02_tablet_left.png`
- `observations/T0179__trace2skill_horizontal_recheck/03_tablet_horizontal_right.png`
- `observations/T0179__trace2skill_verified/03_vendor_0.png`
- `observations/T0179__trace2skill_verified/04_vendor_1.png`
- `observations/T0179__trace2skill_verified/05_vendor_2.png`
- `observations/T0179__trace2skill_verified/07_vision.png`
- `observations/T0179__trace2skill_verified/08_text.png`
- `observations/T0179__trace2skill_verified/09_empty_combination.png`
- `observations/T0179__trace2skill_verified/10_matched_combination.png`
- `observations/T0179__trace2skill_verified/11_filters_cleared.png`
- `observations/T0179__trace2skill_verified/12_sort_0.png`
- `observations/T0179__trace2skill_verified/13_sort_1.png`
- `observations/T0179__trace2skill_verified/14_sort_2.png`
- `observations/T0179__trace2skill_verified/17_desktop_full.png`
- `observations/T0179__trace2skill_verified/19_tablet_full.png`
- `observations/T0179__trace2skill_verified/20_tablet_focus.png`
