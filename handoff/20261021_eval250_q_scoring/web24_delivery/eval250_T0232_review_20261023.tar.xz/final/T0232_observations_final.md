# T0232 当前浏览器观察（不评分）

三臂加载附件样例青砚实验室/苏言/2026-10-13、LAB-01×3、LAB-03×10、LAB-04×2，均显示1460.00+131.40=1591.40 CNY；点击导出并核对落盘CSV。随后空公司和数量0/-1/1.5/abc/空值均显示错误且无新的CSV下载事件；原生number字段拒收abc后实际为空，不能称任意字符串已被业务逻辑处理。添加重复LAB-01×2，观察提示或合并；恢复样例后再导出，删除行及PC/平板显示也已观察。价格为固定目录展示而非可编辑价输入。

观察时间为动作日志中的UTC时间。浏览器为用户电脑已安装Chrome 155.0.8059.85，headless Chromium渲染；不代表真实物理平板。PC 1440×1000 / 平板模拟820×1180，DPR=1。

限制：无真实采购系统或订单。下载快照目录中的文件可能是之前下载的现存文件，是否产生新下载须看events/action日志，不能仅凭快照文件存在。陌生downloads.htm非CSV，来源无法归因，隔离保留本机，详情见anomalies.json。

## autoskill

只有目录选择器，不能经公开UI输入任意未知SKU；空SKU已测，任意不存在型号未测。重复LAB-01留四行并标出重复；CSV合并为LAB-01数量5，金额1820/163.80/1983.80。原_run多次下载同文件名覆盖，所以_resume分别保存重复及恢复样例的真实字节快照。

原件独立副本：`original_copies/artifacts/T0232__autoskill/outputs/报价表单.html`；SHA256 `2d321e3d2cdc80229891d756a43551401b1b276a689b08f93d6ae817fe03ce4d`。

运行记录：`observations/T0232__autoskill_run`, `observations/T0232__autoskill_resume`。

每次动作的预期、实际URL/焦点/尺寸、UTC时间及截图SHA见actions.jsonl；同名JSON为辅助状态，不替代像素。

精简包原始截图：

- `observations/T0232__autoskill_resume/02_duplicate_sku.png`
- `observations/T0232__autoskill_resume/03_duplicate_export.png`
- `observations/T0232__autoskill_resume/04_corrected_export.png`
- `observations/T0232__autoskill_resume/05_delete_line.png`
- `observations/T0232__autoskill_resume/06_desktop_full.png`
- `observations/T0232__autoskill_resume/08_tablet_full.png`
- `observations/T0232__autoskill_resume/09_tablet_focus.png`
- `observations/T0232__autoskill_run/03_sample_export.png`
- `observations/T0232__autoskill_run/04_empty_customer.png`
- `observations/T0232__autoskill_run/05_quantity_zero.png`
- `observations/T0232__autoskill_run/06_quantity_negative.png`
- `observations/T0232__autoskill_run/07_quantity_fraction.png`
- `observations/T0232__autoskill_run/08_quantity_nonnumeric.png`
- `observations/T0232__autoskill_run/09_quantity_empty.png`
- `observations/T0232__autoskill_run/10_missing_sku.png`

## no_skill

利用页面自带本地JSON导入输入未知SKU，错误显示并阻止导出；无网络提交。重复SKU立即合并成3行、LAB-01数量5，金额1820/163.80/1983.80。旧取证脚本在合并删除行后读取不存在行报错；_resume已完成后续流程，异常不是产物报错。

原件独立副本：`original_copies/artifacts/T0232__no_skill/outputs/报价表单.html`；SHA256 `8e385e33e311e3dd346ff1e3559cabe7b20efb3bb200264410e277c474b7aa90`。

运行记录：`observations/T0232__no_skill_run`, `observations/T0232__no_skill_resume`。

每次动作的预期、实际URL/焦点/尺寸、UTC时间及截图SHA见actions.jsonl；同名JSON为辅助状态，不替代像素。

精简包原始截图：

- `observations/T0232__no_skill_resume/02_duplicate_sku.png`
- `observations/T0232__no_skill_resume/03_duplicate_export.png`
- `observations/T0232__no_skill_resume/04_corrected_export.png`
- `observations/T0232__no_skill_resume/05_delete_line.png`
- `observations/T0232__no_skill_resume/06_desktop_full.png`
- `observations/T0232__no_skill_resume/08_tablet_full.png`
- `observations/T0232__no_skill_resume/09_tablet_focus.png`
- `observations/T0232__no_skill_run/03_sample_export.png`
- `observations/T0232__no_skill_run/04_empty_customer.png`
- `observations/T0232__no_skill_run/05_quantity_zero.png`
- `observations/T0232__no_skill_run/06_quantity_negative.png`
- `observations/T0232__no_skill_run/07_quantity_fraction.png`
- `observations/T0232__no_skill_run/08_quantity_nonnumeric.png`
- `observations/T0232__no_skill_run/09_quantity_empty.png`
- `observations/T0232__no_skill_run/10_invalid_sku.png`

## trace2skill

通过公开SKU输入字段输入NO-SUCH-SKU，显示错误并阻止导出。重复LAB-01合并为数量5后，行金额900+280+640=1820，但页面实际汇总显示2180/196.20/2376.20；12_duplicate_sku.png、13_duplicate_export.png及对应JSON保留差异。同期实际CSV却是1820/163.8/1983.8。恢复附件样例后CSV为正确1460/131.4/1591.4。

原件独立副本：`original_copies/artifacts/T0232__trace2skill/outputs/报价表单.html`；SHA256 `3641409a2302db25f93c5b6f229db49ecf4e25d256054283cb8a265a45c588fc`。

运行记录：`observations/T0232__trace2skill_run`。

每次动作的预期、实际URL/焦点/尺寸、UTC时间及截图SHA见actions.jsonl；同名JSON为辅助状态，不替代像素。

精简包原始截图：

- `observations/T0232__trace2skill_run/03_sample_export.png`
- `observations/T0232__trace2skill_run/04_empty_customer.png`
- `observations/T0232__trace2skill_run/05_quantity_zero.png`
- `observations/T0232__trace2skill_run/06_quantity_negative.png`
- `observations/T0232__trace2skill_run/07_quantity_fraction.png`
- `observations/T0232__trace2skill_run/08_quantity_nonnumeric.png`
- `observations/T0232__trace2skill_run/09_quantity_empty.png`
- `observations/T0232__trace2skill_run/10_invalid_sku.png`
- `observations/T0232__trace2skill_run/12_duplicate_sku.png`
- `observations/T0232__trace2skill_run/13_duplicate_export.png`
- `observations/T0232__trace2skill_run/14_corrected_export.png`
- `observations/T0232__trace2skill_run/15_delete_line.png`
- `observations/T0232__trace2skill_run/16_desktop_full.png`
- `observations/T0232__trace2skill_run/18_tablet_full.png`
- `observations/T0232__trace2skill_run/19_tablet_focus.png`
