from pathlib import Path
from PIL import Image,ImageOps,ImageDraw
import sys, math
from cdp_browser import ROOT
suffix=sys.argv[2] if len(sys.argv)>2 else 'run'
for folder in sorted((ROOT/'observations').glob(sys.argv[1]+'__*_'+suffix)):
    files=[]
    for pattern in ['*desktop_full.png','*tablet_full.png']:
        p=next(folder.glob(pattern),None)
        if p:
            im=Image.open(p)
            for y in range(0,im.height,1050):
                files.append((p.name+' y='+str(y),im.crop((0,y,im.width,min(y+1050,im.height)))))
    for pattern in ['*keyboard_menu_focus.png','*keyboard_menu_open.png','*keyboard_first_target.png','*keyboard_target_activated.png','*tablet_keyboard.png']:
        p=next(folder.glob(pattern),None)
        if p:files.append((p.name,Image.open(p)))
    dest=folder/'review';dest.mkdir(exist_ok=True)
    for start in range(0,len(files),6):
        subset=files[start:start+6];sheet=Image.new('RGB',(1800,770*math.ceil(len(subset)/3)),'#dddddd');draw=ImageDraw.Draw(sheet)
        for j,(label,im) in enumerate(subset):
            x=(j%3)*600;y=(j//3)*770
            small=ImageOps.contain(im,(590,735));sheet.paste(small,(x,y+30));draw.text((x+5,y+5),label,fill='black')
        sheet.save(dest/(f'contact_{start//6+1:02}.jpg'),quality=92)
    print(str(dest),len(files))
