from pathlib import Path
import json,hashlib,datetime,zipfile,urllib.request,socket,websocket,base64
from PIL import Image
ROOT=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,o):p.write_text(json.dumps(o,ensure_ascii=False,indent=2),encoding='utf-8')
status=[]
for d in sorted((ROOT/'observations').iterdir()):
    log=d/'actions.jsonl'
    if not log.exists():continue
    records=[json.loads(x) for x in log.read_text(encoding='utf-8').splitlines() if x.strip()]
    pngs=[]
    for p in sorted(d.glob('*.png')):
        try:
            with Image.open(p) as im: size=im.size;im.verify()
            pngs.append({'file':p.name,'sha256':sha(p),'size':size,'valid_png':True})
        except Exception as e:pngs.append({'file':p.name,'valid_png':False,'error':str(e)})
    last=records[-1]
    downloads=[]
    if (d/'downloads').exists():
        for p in (d/'downloads').iterdir():
            if p.is_file():downloads.append({'file':p.name,'bytes':p.stat().st_size,'sha256':sha(p),'utf8_text':p.read_text(encoding='utf-8-sig',errors='replace')})
    dump(d/'checkpoint_downloads.json',downloads)
    status.append({'candidate':d.name,'completed_log':last['action']=='finish','last_action':last['action'],'last_utc':last['utc'],'screenshots':len(pngs),'png_files':pngs,'downloads':downloads})
dump(ROOT/'checkpoint_status.json',status)
# Only inspect debug endpoints explicitly created inside this task's own profiles.
cleanup=[]
for p in (ROOT/'runtime').glob('*/DevToolsActivePort'):
    port=int(p.read_text().splitlines()[0]); entry={'profile':str(p.parent.relative_to(ROOT)),'port':port}
    try:
        with urllib.request.urlopen('http://127.0.0.1:'+str(port)+'/json/version',timeout=.5) as r:version=json.load(r)
        ws=websocket.create_connection(version['webSocketDebuggerUrl'],timeout=2,suppress_origin=True)
        ws.send(json.dumps({'id':1,'method':'Browser.close'}));ws.close();entry['result']='Browser.close sent to task-created isolated browser'
    except Exception as e:entry['result']='Endpoint not reachable or already closed';entry['detail']=str(e)
    cleanup.append(entry)
dump(ROOT/'checkpoint_browser_cleanup.json',cleanup)
provenance=json.loads((ROOT/'source_provenance.json').read_text(encoding='utf-8'))
for source in provenance['sources']:
    p=Path(source['path']);source['sha256_at_checkpoint']=sha(p);source['unchanged_at_checkpoint']=source['sha256_before']==source['sha256_at_checkpoint']
dump(ROOT/'source_provenance.json',provenance)
copies=json.loads((ROOT/'copied_files_before.json').read_text(encoding='utf-8'))
for rec in copies:
    rec['sha256_after']=sha(ROOT/rec['path']);rec['unchanged']=rec['sha256_before']==rec['sha256_after']
dump(ROOT/'copied_files_after.json',copies)
print(json.dumps({'status':[{'candidate':s['candidate'],'completed':s['completed_log'],'screenshots':s['screenshots'],'last_action':s['last_action']} for s in status],'all_copies_unchanged':all(x['unchanged'] for x in copies),'all_source_files_unchanged':all(x['unchanged_at_checkpoint'] for x in provenance['sources']),'unreachable_debug_endpoints':sum('not reachable' in x['result'] for x in cleanup),'close_sent':sum('sent' in x['result'] for x in cleanup),'total_pngs':sum(x['screenshots'] for x in status)},ensure_ascii=False,indent=2))
