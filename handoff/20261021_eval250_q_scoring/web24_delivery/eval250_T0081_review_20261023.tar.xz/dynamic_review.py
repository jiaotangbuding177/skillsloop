from pathlib import Path
from PIL import Image,ImageOps,ImageDraw
import json,math
from cdp_browser import ROOT,dump
groups={
'T0082__autoskill_run':['*status_first.png','*missing_first.png','*busy_first.png','*busy_attempt*.png','*download_result.png'],
'T0082__no_skill_run':['*status_first.png','*missing_first.png','*busy_first.png','*busy_attempt*.png','*download_result.png'],
'T0082__trace2skill_run':['*status_first.png','*missing_first.png','*busy_first.png','*busy_attempt*.png','*submission_generated.png'],
'T0179__autoskill_run':['*vendor_*.png','*vision.png','*text.png','*empty_combination.png','*matched_combination.png','*filters_cleared.png','*sort_*.png'],
'T0179__no_skill_run':['*vendor_*.png','*vision.png','*text.png','*empty_combination.png','*matched_combination.png','*filters_cleared.png','*sort_*.png'],
'T0179__trace2skill_verified':['*vendor_*.png','*vision.png','*text.png','*empty_combination.png','*matched_combination.png','*filters_cleared.png','*sort_*.png'],
'T0232__autoskill_run':['*empty_customer.png','*quantity_*.png','*missing_sku.png'],
'T0232__no_skill_run':['*empty_customer.png','*quantity_*.png','*invalid_sku.png'],
'T0232__trace2skill_run':['*empty_customer.png','*quantity_*.png','*invalid_sku.png','*duplicate_sku.png','*duplicate_export.png'],
'T0232__autoskill_resume':['*duplicate_sku.png','*duplicate_export.png','*corrected_export.png'],
'T0232__no_skill_resume':['*duplicate_sku.png','*duplicate_export.png','*corrected_export.png'],
'T0081__trace2skill_verified':['*button*.png'],
'T0104__autoskill_focus_detail':['*menu*.png','*course*.png'],
'T0081__autoskill_focus_detail':['*menu*.png'],
'T0104__trace2skill_run':['*button*.png'],
'T0156__trace2skill_run':['*button*.png','*assessment*.png'],
'T0156__no_skill_run':['*button*.png']}
manifest=[]
for folder,patterns in groups.items():
 d=ROOT/'observations'/folder
 files=sorted({p for pattern in patterns for p in d.glob(pattern)})
 dest=d/'review';dest.mkdir(exist_ok=True)
 for start in range(0,len(files),6):
  subset=files[start:start+6];sheet=Image.new('RGB',(1800,530*math.ceil(len(subset)/3)),'#ddd');draw=ImageDraw.Draw(sheet)
  for j,p in enumerate(subset):
   x=j%3*600;y=j//3*530;im=Image.open(p);sheet.paste(ImageOps.contain(im,(590,500)),(x,y+30));draw.text((x+4,y+4),p.name,fill='black')
  out=dest/f'dynamic_{start//6+1:02}.jpg';sheet.save(out,quality=95)
  manifest.append({'sheet':str(out.relative_to(ROOT)),'original_screenshots':[str(p.relative_to(ROOT)) for p in subset],'derived_review_only':True})
dump(ROOT/'dynamic_contact_manifest.json',manifest)
print([(x['sheet'],len(x['original_screenshots'])) for x in manifest])
