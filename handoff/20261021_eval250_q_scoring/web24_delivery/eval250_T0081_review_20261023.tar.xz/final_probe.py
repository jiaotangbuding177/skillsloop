import time,json
from cdp_browser import Browser,ROOT,dump

b=Browser('T0156__autoskill_nav_recheck',ROOT/'original_copies/artifacts/T0156__autoskill/outputs/index.html')
try:
    b.log('reason','Resolve earlier mouse-navigation ambiguity',{'prior':'T0156__autoskill_run/09_link_02.json','note':'Earlier target was dimensions but resultant hash records. Reopen menu visibly before clicking.'})
    b.click('a.btn[href="#dimensions"]','Activate visible hero dimensions entry','hero_dimensions')
    b.scroll(0)
    b.click('.drop-btn','Open actual business menu','menu_open')
    b.click('.drop a[href="#dimensions"]','Activate visible dimensions submenu','menu_dimensions')
    b.viewport(820,1180);b.scroll(0);b.capture('tablet_nav','Observe tablet header and available navigation')
finally:b.close()

for arm in ['no_skill','trace2skill']:
    b=Browser('T0179__'+arm+'_horizontal_recheck',ROOT/'original_copies/artifacts'/('T0179__'+arm)/'outputs/models.html')
    try:
        b.viewport(820,1180);b.scroll(0)
        b.capture('tablet_left','Observe table at initial horizontal position')
        info=b.js('''(()=>{let e=document.querySelector('table');e.scrollIntoView({block:'center'});return [...document.querySelectorAll('*')].filter(e=>e.scrollWidth>e.clientWidth+5).map(e=>({tag:e.tagName,cls:e.className,scrollWidth:e.scrollWidth,clientWidth:e.clientWidth,overflow:getComputedStyle(e).overflowX}))})()''')
        b.log('horizontal_overflow','Read container dimensions without changing data',info)
        time.sleep(.7)
        box=b.js('''(()=>{let r=document.querySelector('table').getBoundingClientRect();return {x:Math.min(650,Math.max(50,r.left+300)),y:Math.min(900,Math.max(150,r.top+100))}})()''')
        b.call('Input.dispatchMouseEvent',{'type':'mouseWheel','x':box['x'],'y':box['y'],'deltaX':650,'deltaY':0})
        time.sleep(.7)
        b.capture('tablet_horizontal_right','Actual horizontal wheel exposes right-hand columns')
    finally:b.close()
print('Final targeted probes completed',flush=True)
