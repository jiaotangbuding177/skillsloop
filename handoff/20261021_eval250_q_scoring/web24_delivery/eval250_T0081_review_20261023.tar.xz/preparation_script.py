from pathlib import Path, PurePosixPath
import hashlib, json, tarfile, shutil, re, datetime, platform

ROOT=Path(__file__).resolve().parent/'web24_evidence_20261023'
ROOT.mkdir(exist_ok=False)
TASKS=['T0001','T0081','T0082','T0104','T0151','T0156','T0179','T0232']
SRC=Path(r'D:\skillloop\handoff')
ARCHIVE=SRC/'20261021_eval250_q_artifacts/eval250_q_artifacts.tar.gz'
METHOD=SRC/'20261021_eval250_q_scoring/Q_METHOD'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,o):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(o,ensure_ascii=False,indent=2),encoding='utf-8')
sources=[]
for p,expected in [(ARCHIVE,'c8ada3aff8687aaab009a558554b7bd0262b8276ec8498bf670fb093e19a0589'),(METHOD/'rubric_release/rubrics.jsonl','b31eefb1434f3e7341de8fb7be31244b507ada59c5dee9e638c8b1f1de9b3d90'),(METHOD/'rubric_release/scoring_policy.json','1623b3be006c03a8d884cd882d270ebc3f667de73790557bf91a1237ad845ac2')]:
    raw=p.read_bytes(); h=hashlib.sha256(raw).hexdigest(); normalized=raw.replace(b'\r\n',b'\n') if p.suffix!='.gz' else raw
    nh=hashlib.sha256(normalized).hexdigest()
    assert nh==expected,(p,nh)
    dest=ROOT/'source'/p.name; dest.parent.mkdir(exist_ok=True); dest.write_bytes(raw)
    sources.append({'path':str(p),'sha256_before':h,'sha256_after_copy':sha(p),'copy_sha256':sha(dest),'expected_release_sha256':expected,'lf_sha256':nh,'crlf_count':raw.count(b'\r\n') if p.suffix!='.gz' else None})
    if h!=nh: (ROOT/'source'/('release_LF_'+p.name)).write_bytes(normalized)
write(ROOT/'source_provenance.json',{'time_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'declared_commit':'a5baa9705550ea98cc82bb75a0f49685f27d3d77','declared_repository':'https://github.com/jiaotangbuding177/skillsloop','git_head_check':'git -C D:\\skillloop rev-parse HEAD returned Permission denied; not retried','sources':sources})
rubrics=[json.loads(x) for x in (ROOT/'source/release_LF_rubrics.jsonl').read_text(encoding='utf-8').splitlines()]
assert len(rubrics)==250 and sum(len(x['items']) for x in rubrics)==2643
with tarfile.open(ROOT/'source'/ARCHIVE.name) as tf:
    selected=[]
    for m in tf:
        parts=PurePosixPath(m.name).parts
        include=(len(parts)>=2 and ((parts[0]=='inputs' and parts[1] in TASKS) or (parts[0]=='artifacts' and parts[1].split('__')[0] in TASKS and len(parts)>=3 and parts[2] in ['outputs','root'])))
        if not include: continue
        if '..' in parts or PurePosixPath(m.name).is_absolute() or m.issym() or m.islnk() or not (m.isfile() or m.isdir()): raise ValueError('Unsafe archive entry: '+m.name)
        target=ROOT/'original_copies'/Path(*parts)
        if not target.resolve().is_relative_to((ROOT/'original_copies').resolve()): raise ValueError(m.name)
        if m.isdir(): target.mkdir(parents=True,exist_ok=True); continue
        target.parent.mkdir(parents=True,exist_ok=True)
        data=tf.extractfile(m).read(); target.write_bytes(data)
        selected.append({'archive_member':m.name,'path':str(target.relative_to(ROOT)),'bytes':len(data),'sha256_before':sha(target)})
write(ROOT/'copied_files_before.json',selected)
for rubric in rubrics:
    if rubric['task_id'] in TASKS:
        write(ROOT/'requirements'/(rubric['task_id']+'.json'),rubric)
        for inp in rubric['inputs']:
            p=ROOT/'original_copies/inputs'/rubric['task_id']/inp['name']
            assert p.exists() and sha(p)==inp['sha256'],str(p)
scan=[]
for p in (ROOT/'original_copies/artifacts').rglob('*'):
    if p.suffix.lower() not in ['.html','.js','.css','.svg']: continue
    text=p.read_text(encoding='utf-8',errors='replace')
    scan.append({'file':str(p.relative_to(ROOT)),'sha256':sha(p),'external_urls':sorted(set(re.findall(r'https?://[^\s\"\'<>`]+',text))),'network_lines':[{'line':i,'text':l[:1200]} for i,l in enumerate(text.splitlines(),1) if re.search(r'fetch\(|XMLHttpRequest|WebSocket|sendBeacon|<form|action=|<script[^>]+src=|<link[^>]+href=|window\.open|location\.(href|assign|replace)',l)]})
write(ROOT/'static_external_dependency_scan.json',scan)
write(ROOT/'environment_preflight.json',{'time_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'platform':platform.platform(),'python':platform.python_version(),'installed_browsers':{'Chrome':'155.0.8059.85','Edge':'155.0.4283.62'},'automation_packages':{'playwright':False,'selenium':False,'websocket':True,'PIL':True},'scope':'Current revalidation only; no historical execution proof; no scores; 24 HTML artifacts only','model_constraint':'User requested GPT-6 Astra; no model API calls, workers, or subagents will be invoked','screen_tool':'No dedicated desktop screenshot/browser control tool exposed; local installed Chrome CDP will be attempted','dependency_locator':'Codex load_workspace_dependencies returned app tool request failed'})
print(json.dumps({'root':str(ROOT),'copied_files':len(selected),'html_files':[x['file'] for x in scan if x['file'].endswith('.html')],'external_scan':scan},ensure_ascii=False,indent=2))
