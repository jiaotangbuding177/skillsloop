import time,json
from cdp_browser import Browser,ROOT,dump
from run_apps import export,tablet

for task in ['T0081','T0104']:
 b=Browser(task+'__autoskill_focus_detail',ROOT/'original_copies/artifacts'/(task+'__autoskill')/'outputs/index.html')
 try:
  b.log('supplement','Follow actual anchor menu keyboard behavior',{'prior':'Enter on anchor moved to modules; supplement Tab through focus-within submenu.'})
  for _ in range(15):
   b.key('Tab')
   if '业务模块' in b.state()['focus']['text']:break
  b.capture('menu_focus','Focus opens anchor submenu')
  b.key('Tab');b.capture('submenu_focus','Tab from trigger reaches first submenu link')
  b.key('Enter');time.sleep(.6);b.capture('submenu_activated','Enter activates submenu destination')
  if task=='T0104':
   b.reload();b.click('a[href="#courses"]','Open course list')
   for n in range(1,7):
    b.click(f'a[href="#d-C0{n}"]','Open actual course detail',f'course_C0{n}',0)
    b.click('.dlg:target a[href="#courses"]','Close CSS target detail using provided return link','detail_closed' if n==6 else None)
   b.scroll(0);b.viewport(820,1180)
   for y in range(0,b.state()['size']['scrollHeight'],900):b.scroll(y)
   b.scroll(0);b.capture('tablet_full','Tablet base page with detail overlay closed',True)
 finally:b.close()

for arm in ['autoskill','no_skill']:
 b=Browser('T0232__'+arm+'_resume',ROOT/'original_copies/artifacts'/('T0232__'+arm)/'outputs/报价表单.html')
 try:
  b.log('resume','Complete duplicate/corrected-export evidence',{'prior':'T0232__'+arm+'_run','reason':'autoskill original export path reused filename; snapshot each byte stream. no_skill merged row removed before harness readback; preserve prior invalid cases.'})
  sample='button[onclick="fillSample()"]' if arm=='autoskill' else 'button[onclick="loadSample()"]'
  exp='button[onclick="exportCSV()"]' if arm=='autoskill' else 'button[onclick="doExport()"]'
  qty='.qtyInput' if arm=='autoskill' else '.qty';sku='.skuSel' if arm=='autoskill' else '.sku'
  b.click(sample,'Reconstruct sample to finish remaining steps')
  b.click('button[onclick="addLine()"]','Add duplicate SKU test row')
  n=b.js('document.querySelectorAll('+json.dumps(qty)+').length')-1
  b.fill(qty,'2',n);b.select(sku,'LAB-01',n)
  b.capture('duplicate_sku','Observe repeat SKU handling after native selection',True)
  export(b,exp,'duplicate_export','Export duplicate case and preserve actual CSV bytes separately')
  b.click(sample,'Restore attachment sample after invalid/duplicate cases')
  export(b,exp,'corrected_export','Export restored sample; preserve byte snapshot before any overwrite')
  b.log('price_controls','Observe fields and fixed price presentation',b.state()['controls'])
  removes=[c for c in b.state()['controls'] if c['tag']=='BUTTON' and c['text'].strip() in ['删除','✕']]
  if removes:b.click('a,button,input,select,textarea,summary','Delete temporary sample line','delete_line',removes[-1]['i'])
  b.click(sample,'Restore sample for final visual review')
  tablet(b)
 finally:b.close()
print('Supplement completed',flush=True)
