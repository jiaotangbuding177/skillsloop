import sys,json,traceback
from cdp_browser import Browser,ROOT
sys.stdout.reconfigure(encoding='utf-8')
sys.stdin.reconfigure(encoding='utf-8')
b=None
print('READY',flush=True)
for line in sys.stdin:
    try:
        cmd=json.loads(line)
        op=cmd.pop('op')
        if op=='open':
            if b: b.close()
            name=cmd['name']; p=ROOT/'original_copies/artifacts'/cmd.get('artifact_name',name)/'outputs'/cmd['filename']
            b=Browser(name,p); result={'version':b.version,'state':b.state()}
        elif op=='close':
            if b:b.close();b=None
            result='closed'
        elif op=='quit':
            if b:b.close()
            print('CLOSED',flush=True);break
        elif op=='state': result=b.state()
        elif op=='batch':
            result=[]
            for item in cmd['commands']:
                method=item.pop('op'); result.append(getattr(b,method)(**item))
        else: result=getattr(b,op)(**cmd)
        print(json.dumps({'ok':True,'result':result},ensure_ascii=False),flush=True)
    except Exception as e:
        print(json.dumps({'ok':False,'error':str(e),'trace':traceback.format_exc()},ensure_ascii=False),flush=True)
