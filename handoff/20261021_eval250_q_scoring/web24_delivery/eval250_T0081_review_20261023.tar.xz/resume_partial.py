import json,time
from cdp_browser import Browser,ROOT,dump
from run_apps import tablet

# Resume only unfinished actions; prior records and screenshots are immutable.
b=Browser('T0156__no_skill_resume',ROOT/'original_copies/artifacts/T0156__no_skill/outputs/index.html')
try:
    b.log('resume','Continue interrupted run',{'prior':'T0156__no_skill_run','completed':'all links and six dimension explanation buttons','new':'tablet layout and keyboard; reconstruction in fresh context'})
    b.viewport(820,1180);b.scroll(0);b.capture('tablet_top','Tablet layout at 820x1180')
    for y in range(0,b.state()['size']['scrollHeight'],900):b.scroll(y)
    b.scroll(0);b.capture('tablet_full','Tablet all content after ordinary scrolling',True)
    for _ in range(3):b.key('Tab')
    b.capture('tablet_keyboard','Tablet keyboard actual focus')
finally:b.close()

b=Browser('T0179__autoskill_resume',ROOT/'original_copies/artifacts/T0179__autoskill/outputs/models.html')
try:
    b.log('resume','Continue interrupted sort',{'prior':'T0179__autoskill_run','completed':'all filters and sort_0,sort_1,sort_2','new':'sum sort screenshot, final reset, desktop/tablet','orphan':'15_sort_3.json has no completed PNG in prior run'})
    b.select('#sort','sum');b.capture('sort_3','Observe total price ordering after reconstruction')
    b.select('#sort',b.js('document.querySelector("#sort").options[0].value'));b.capture('final_all','Six models restored with default ordering')
    tablet(b)
    b.log('sort_limit','Avoid unsupported inference',{'note':'Input/output prices have same model ordering; outputs alone do not distinguish comparator basis.'})
finally:b.close()

b=Browser('T0081__autoskill_svg_recheck',ROOT/'original_copies/artifacts/T0081__autoskill/outputs/index.html')
try:
    b.log('svg_recheck','Recheck only own wildcard false block',{'old_evidence_retained':'T0081__autoskill_verified','offline':True})
    b.capture('desktop_full','Observe original inline SVG after removing erroneous task rule',True)
    dump(b.out/'images.json',b.js('[...document.images].map(i=>({alt:i.alt,complete:i.complete,naturalWidth:i.naturalWidth,naturalHeight:i.naturalHeight,src:i.src}))'))
    b.viewport(820,1180);b.scroll(0);b.capture('tablet_top','Observe actual inline logo on tablet')
finally:b.close()
print('Partial runs and SVG recheck completed',flush=True)
