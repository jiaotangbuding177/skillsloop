import sys,json,time,traceback,shutil
from cdp_browser import Browser,ROOT,dump
TASK=sys.argv[1] if len(sys.argv)>1 else None
if (ROOT/'STOP_REQUESTED').exists():
    print('Checkpoint stop requested; no new task started.',flush=True)
    sys.exit(0)
def button(b,text,label,expected):
    c=next((x for x in b.state()['controls'] if x['tag']=='BUTTON' and text in x['text']),None)
    if not c:b.log('button_absent',expected,{'text':text});return False
    return b.click('#'+c['id'] if c['id'] else 'a,button,input,select,textarea,summary',expected,label,0 if c['id'] else c['i'])
def snap(b,label,expected,full=False):
    state=b.capture(label,expected,full)
    return {'label':label,'body':state['body'],'controls':[{k:c.get(k) for k in ['tag','id','text','options','disabled','readOnly']} for c in state['controls']]}
def export(b,selector,label,expect):
    before=b.download_inventory();b.click(selector,expect,label);time.sleep(.65);after=b.download_inventory()
    b.log('download_disk_check',expect,{'before':before,'after':after})
    dest=b.out/'download_snapshots'/label;dest.mkdir(parents=True)
    for p in b.downloads.iterdir():
        if p.suffix.lower() in ['.csv','.txt']:shutil.copy2(p,dest/p.name)
def tablet(b):
    b.scroll(0);b.capture('desktop_full','Complete actual page at desktop viewport',True)
    b.viewport(820,1180);b.scroll(0);b.capture('tablet_top','Actual tablet layout')
    height=b.state()['size']['scrollHeight']
    for y in range(0,height,900):b.scroll(y)
    b.scroll(0);b.capture('tablet_full','Complete actual page at tablet viewport',True)
    b.key('Tab');b.capture('tablet_focus','Keyboard focus after Tab')
def practice(b,arm):
    for path,letter in [('/status','A'),('/missing','B'),('/busy','C')]:
        if arm=='trace2skill':s='button[onclick="sendRequest(\''+letter+'\')"]'
        else:
            prefix='fill' if arm=='autoskill' else 'pick'
            b.click('button[onclick="'+prefix+'(\''+path+'\')"]','Select '+path+' offline simulation')
            s='button[onclick="send()"]' if arm=='autoskill' else '#send'
        b.click(s,'Run local simulation '+path);time.sleep(.65)
        snap(b,path[1:]+'_first','Observe expected '+{'/status':'200','/missing':'404','/busy':'503'}[path]+' status and response')
    # Retry busy two more times with >=2 s waits; preserve actual responses and count.
    for n in [2,3]:
        time.sleep(2.1);b.click(s,'Repeat busy simulation after waiting');time.sleep(.65);snap(b,'busy_attempt_'+str(n),'Observe retry status and boundary, without assuming recovery')
    src='本结果来自 practice.html 离线模拟，未使用真实凭据；保存路径：本任务临时目录 downloads。'
    retry='等待2秒再重试，最多3次，仍503时停止并记录上报。'
    if arm=='autoskill':
        for selector in ['#h-status','#h-missing','#h-busy']:
            v=b.js('document.querySelector('+json.dumps(selector)+').options[1].value');b.select(selector,v)
        for selector,text in [('#retryNote',retry),('#srcNote',src),('#saveNote',str(b.downloads/'result.txt'))]:b.fill(selector,text)
        export(b,'button[onclick="downloadSummary()"]','download_result','Download actual result.txt to temporary directory')
    elif arm=='no_skill':
        for selector,text in [('#stuName','离线取证样例'),('#stuId','EVIDENCE-20261023'),('#t404','404为路径不存在，应核对路径，不应无意义重试。'),('#t503',retry),('#tSrc',src),('#tErr','本次仅记录离线模拟结果。')]:b.fill(selector,text)
        export(b,'#exportBtn','download_result','Download actual report.txt to temporary directory')
    else:
        b.select('#dispB','check');b.select('#dispC','limited');b.fill('#retryNote',retry);b.fill('#srcNote',src)
        b.click('#genBtn','Generate local submission text','submission_generated')
        export(b,'#dlBtn','download_result','Download actual submission.txt to temporary directory')
    b.log('practice_scope','Only webpage tested',{'docx':'No new DOCX rendering performed; handled separately','historical':'Current revalidation cannot verify past testing claims'})
def models(b,arm):
    observations=[]
    vendor='#vendor' if arm=='autoskill' else '#fVendor'
    capability='#vision' if arm=='autoskill' else '#fVision'
    sort='#sortKey' if arm=='no_skill' else '#sort'
    def observe(label,expected):
        s=b.capture(label,expected);rows=b.js('[...document.querySelectorAll("tbody tr")].filter(e=>!!e.getBoundingClientRect().height).map(e=>e.innerText)')
        observations.append({'label':label,'expected':expected,'rows':rows,'body':s['body']})
    def vend(value):
        if arm=='trace2skill':
            for v in ['澈语','北辰','青竹']:
                selector='input.f-vendor[value='+json.dumps(v,ensure_ascii=False)+']';checked=b.js('document.querySelector('+json.dumps(selector)+').checked');want=(value=='' or value==v)
                if checked!=want:b.click(selector,'Set vendor selection '+str(value))
        else:b.select(vendor,value)
    def cap(value):
        if arm=='trace2skill':b.click('input[name="f-cap"][value="'+{'':'all','yes':'vision','no':'text'}[value]+'"]','Choose capability '+str(value))
        else:b.select(capability,value)
    observe('all_six','All six models visible')
    for n,v in enumerate(['澈语','北辰','青竹']):vend(v);observe('vendor_'+str(n),'Only '+v+' models visible')
    vend('');observe('vendor_restored','Restore all six models')
    cap('yes');observe('vision','BC-Vision and BC-Fast visible')
    cap('no');observe('text','CY-Enterprise/CY-Lite/QZ-Long/QZ-Reason visible')
    vend('澈语');cap('yes');observe('empty_combination','No model matches CY vendor with vision')
    vend('北辰');observe('matched_combination','BC vision models visible')
    vend('');cap('');observe('filters_cleared','All six models restored')
    options=b.js('Array.from(document.querySelector('+json.dumps(sort)+').options).map(o=>({value:o.value,text:o.text}))')
    for n,opt in enumerate(options):b.select(sort,opt['value']);observe('sort_'+str(n),'Observe actual ordering for '+opt['text'])
    if arm=='trace2skill':b.click('#reset','Reset to default filters','reset')
    else:vend('');cap('');b.select(sort,options[0]['value'])
    observe('final_all','Six items restored')
    b.log('sort_limit','Avoid unsupported inference',{'note':'Given input/output price data yield the same model order. Observed sort output alone cannot distinguish implementation basis. No descending-price control is required when not supplied by task.'})
    dump(b.out/'model_observations.json',observations)
def quote(b,arm):
    sample='button[onclick="fillSample()"]' if arm=='autoskill' else 'button[onclick="loadSample()"]'
    exp='button[onclick="doExport()"]' if arm=='no_skill' else 'button[onclick="exportCSV()"]'
    qty='.qtyInput' if arm=='autoskill' else '.qty'
    sku='.skuSel' if arm=='autoskill' else '.sku'
    company='#company' if arm=='trace2skill' else '#customer_company'
    def load():b.click(sample,'Load exact attachment sample')
    load();snap(b,'sample_loaded','Observe sample customer/date/3-10-2 quantities; 1460.00 +131.40 =1591.40',True)
    export(b,exp,'sample_export','Export attachment sample and inspect actual CSV bytes')
    b.fill(company,'');export(b,exp,'empty_customer','Empty company should block export; inspect actual downloads')
    b.fill(company,'青砚实验室')
    for label,value in [('zero','0'),('negative','-1'),('fraction','1.5'),('nonnumeric','abc'),('empty','')]:
        b.fill(qty,value,index=0)
        export(b,exp,'quantity_'+label,'Invalid quantity '+repr(value)+' should block export; inspect actual value and files')
    load()
    if arm=='trace2skill':
        b.fill(sku,'NO-SUCH-SKU',index=0);export(b,exp,'invalid_sku','Nonexistent SKU should block export')
    elif arm=='no_skill':
        fixture=ROOT/'test_inputs/T0232_invalid_sku.json';fixture.parent.mkdir(exist_ok=True)
        data=json.loads((ROOT/'original_copies/inputs/T0232/inputs/客户样例.json').read_text(encoding='utf-8'));data['lines'][0]['sku']='NO-SUCH-SKU';dump(fixture,data)
        document=b.call('DOM.getDocument')['root']['nodeId'];node=b.call('DOM.querySelector',{'nodeId':document,'selector':'#import-file'})['nodeId']
        b.call('DOM.setFileInputFiles',{'nodeId':node,'files':[str(fixture.resolve())]});time.sleep(.65)
        b.log('local_file_input','Use offered JSON import with synthetic invalid SKU',{'file':str(fixture),'upload_destination':'Local offline HTML FileReader only; no server'})
        export(b,exp,'invalid_sku','Imported nonexistent SKU should block export')
    else:
        opts=b.js('Array.from(document.querySelector(".skuSel").options).map(o=>o.value)')
        b.log('invalid_sku_entry','Attempt nonexistent model through exposed UI',{'observed':'Only catalog native select available, no free-text or import control. Invalid SKU cannot be entered through exposed UI. No DOM/app-state injection used.','options':opts})
        b.select(sku,'',0);export(b,exp,'missing_sku','Empty selection should block export')
    load()
    # Add an extra line, enter 2 units, then choose an already-present SKU.
    b.click('button[onclick="addLine()"]','Add another product line','add_line')
    count=b.js('document.querySelectorAll('+json.dumps(qty)+').length');b.fill(qty,'2',index=count-1)
    if arm=='trace2skill':b.fill(sku,'LAB-01',index=count-1)
    else:b.select(sku,'LAB-01',index=count-1)
    snap(b,'duplicate_sku','Observe repeat SKU prompt/merge and quantities',True)
    export(b,exp,'duplicate_export','Observe exported duplicate handling and summed quantity')
    load()
    price=b.js('Array.from(document.querySelectorAll("td")).filter(e=>/price|Price/.test(e.className)).map(e=>({text:e.innerText,editable:e.isContentEditable,inputs:e.querySelectorAll("input,textarea,select").length}))')
    b.log('price_controls','Prices cannot be edited through exposed UI',{'price_cells':price,'form_fields':b.state()['controls']})
    export(b,exp,'corrected_export','Restore exact sample after invalid inputs and export again')
    removes=[c for c in b.state()['controls'] if c['tag']=='BUTTON' and c['text'].strip() in ['删除','✕']]
    if removes:
        c=removes[-1];b.click('a,button,input,select,textarea,summary','Delete last temporary sample line','delete_line',c['i'])
    load()
for arm in ([sys.argv[2]] if len(sys.argv)>2 else ['autoskill','no_skill','trace2skill']) if __name__=='__main__' else []:
    filename={'T0082':'practice.html','T0151':'报价说明.html','T0179':'models.html','T0232':'报价表单.html'}[TASK]
    b=Browser(TASK+'__'+arm+'_'+(sys.argv[3] if len(sys.argv)>3 else 'run'),ROOT/'original_copies/artifacts'/(TASK+'__'+arm)/'outputs'/filename)
    try:
        if TASK=='T0082':practice(b,arm)
        elif TASK=='T0179':models(b,arm)
        elif TASK=='T0232':quote(b,arm)
        elif TASK=='T0151':b.log('static_page','Visual quote presentation only',{'controls':b.state()['controls'],'reference_total':'11190.00+1454.70=12644.70 CNY','note':'No interactive controls required by frozen task. Absence is not treated as defect.'})
        tablet(b)
        print(json.dumps({'completed':b.name,'screenshots':b.n,'downloads':[{k:f[k] for k in ['filename','bytes','sha256']} for f in b.download_inventory()]},ensure_ascii=False),flush=True)
    except Exception as e:
        b.log('harness_error','Preserve incomplete run',{'error':str(e),'trace':traceback.format_exc()});raise
    finally:b.close()
