import sys,json,time,traceback
from cdp_browser import Browser,ROOT,dump

TASK=sys.argv[1]
if (ROOT/'STOP_REQUESTED').exists():
    print('Checkpoint stop requested; no new task started.',flush=True)
    sys.exit(0)
ARMS=['autoskill','no_skill','trace2skill']
SUFFIX=sys.argv[2] if len(sys.argv)>2 else 'run'
def sel(c):
    return ('#'+c['id'],0) if c['id'] else ('a,button,input,select,textarea,summary',c['i'])
def clickc(b,c,label,expected):
    s,i=sel(c);return b.click(s,expected,label,i)
def dismiss(b):
    b.key('Escape')
    return b.js('document.querySelectorAll("dialog[open]").length')
def run(arm):
    b=Browser(TASK+'__'+arm+'_'+SUFFIX,ROOT/'original_copies/artifacts'/(TASK+'__'+arm)/'outputs/index.html')
    try:
        b.capture('desktop_full','Full page at 1440 CSS pixels, inspect all content',True)
        # Tab only from initial page until business menu is focused.
        found=False
        for n in range(18):
            b.key('Tab'); focus=b.state()['focus']
            if '业务模块' in focus['text']:
                found=True;b.capture('keyboard_menu_focus','Tab reaches business module and visible focus');break
        if found:
            b.key('Enter');b.capture('keyboard_menu_open','Activate business menu using Enter')
            b.key('Tab');b.capture('keyboard_first_target','Tab into business target')
            b.key('Enter');time.sleep(.65);b.capture('keyboard_target_activated','Enter reaches corresponding content')
            b.key('Escape')
        else:b.log('keyboard_menu','Tab reaches menu',{'observed':'Menu not reached within 18 tabs'})
        b.reload();b.scroll(0)
        menu=next((c for c in b.state()['controls'] if '业务模块' in c['text'] and c['visible']),None)
        if menu:clickc(b,menu,'mouse_menu','Mouse opens business menu')
        # Test every distinct local hash link and all content-bearing local buttons, preserving actual outcomes.
        initial=b.state()['controls'];links=[];seen=set()
        for c in initial:
            href=c.get('href')
            if href and href.startswith('#') and len(href)>1 and href not in seen:
                links.append((href,c['text']));seen.add(href)
        for n,(href,text) in enumerate(links):
            b.key('Escape')
            # Reopen menu when its target is currently hidden; otherwise select visible equivalent link.
            cs=[c for c in b.state()['controls'] if c.get('href')==href and c['visible'] and c['box']['x']>=0]
            if not cs and menu:
                clickc(b,menu,None,'Expose business link for actual click')
                cs=[c for c in b.state()['controls'] if c.get('href')==href and c['visible'] and c['box']['x']>=0]
            if cs:
                clickc(b,cs[0],f'link_{n:02}',f'Activate {text} to {href}; observe page target')
                b.log('target_check','Target exists and navigation moves to intended content',b.js('''(()=>{let e=document.getElementById(%s);return {hash:location.hash,target:e?{id:e.id,text:e.innerText.slice(0,3000),top:e.getBoundingClientRect().top}:null}})()'''%json.dumps(href[1:])))
            else:b.log('link_not_accessible',text,{'href':href})
        # Record all principal safe buttons as actually clicked; no form submit or real credentials.
        buttons=[c for c in b.state()['controls'] if c['tag']=='BUTTON' and c['visible'] and not ('业务模块' in c['text'] or c['text'].strip()=='菜单')]
        for n,c in enumerate(buttons):
            s,i=sel(c)
            forbidden=b.js('''(()=>{let e=document.querySelectorAll(%s)[%d];return !!(e&&e.type==='submit'&&e.form&&e.form.method!=='dialog')})()'''%(json.dumps(s),i))
            if forbidden:b.log('skip_form_submit','Do not send forms',c);continue
            b.key('Escape')
            clickc(b,c,f'button_{n:02}',f'Activate local control {c["text"]}; observe result')
            # A result detail, local simulation or dialog can be observed; dismiss without contacting anyone.
            dismiss(b)
        # Additional repeat assessment dialog selection is task-specific and matches the frozen input.
        if TASK=='T0156' and b.js('!!document.querySelector("#newRoundBtn")'):
            b.click('#newRoundBtn','Open repeat assessment entry','repeat_assessment')
            b.click('[data-dim]','Select first dimension','assessment_selected',0)
            b.click('#confirmBtn','Confirm only local simulation selection, no system submission','assessment_confirmation')
            dismiss(b)
        b.scroll(0);b.viewport(820,1180);time.sleep(.35)
        b.capture('tablet_top','Tablet layout at 820x1180')
        # Scroll each viewport to reveal intersection-triggered content, then capture full actual page.
        height=b.state()['size']['scrollHeight']
        for y in range(0,height,900): b.scroll(y);time.sleep(.2)
        b.scroll(0);b.capture('tablet_full','Tablet all content after ordinary scrolling',True)
        mobile_menu=next((c for c in b.state()['controls'] if c['tag']=='BUTTON' and c['text'].strip()=='菜单' and c['visible']),None)
        if mobile_menu:clickc(b,mobile_menu,'tablet_menu','Open tablet navigation menu')
        for _ in range(3):b.key('Tab')
        b.capture('tablet_keyboard','Tablet keyboard focus actual position')
        dump(b.out/'functional_summary.json',{'task':TASK,'arm':arm,'hash_targets_tested':links,'downloads':b.download_inventory(),'note':'Screenshots require human/model pixel review. No scores computed.'})
        print(json.dumps({'completed':b.name,'screenshots':b.n,'out':str(b.out)},ensure_ascii=False),flush=True)
    finally:b.close()
for arm in ARMS:
    try:run(arm)
    except Exception as e:
        print(json.dumps({'task':TASK,'arm':arm,'error':str(e),'trace':traceback.format_exc()}),flush=True)
        raise
