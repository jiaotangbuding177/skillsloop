from pathlib import Path
import json,hashlib,datetime,csv,io,zipfile
from PIL import Image
ROOT=Path(__file__).resolve().parent
FINAL=ROOT/'final';FINAL.mkdir(exist_ok=True)
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
 return h.hexdigest()
def dump(p,o):p.write_text(json.dumps(o,ensure_ascii=False,indent=2),encoding='utf-8')
def rel(p):return p.relative_to(ROOT).as_posix()
def read(p):return json.loads(p.read_text(encoding='utf-8'))
NOW=datetime.datetime.now(datetime.timezone.utc).isoformat()
TASKS=['T0001','T0081','T0082','T0104','T0151','T0156','T0179','T0232'];ARMS=['autoskill','no_skill','trace2skill']
RUNS={t:{a:[t+'__'+a+('_verified' if t in ['T0001','T0081'] else '_run')] for a in ARMS} for t in TASKS}
RUNS['T0081']['autoskill']+=['T0081__autoskill_svg_recheck','T0081__autoskill_focus_detail']
RUNS['T0104']['autoskill']+=['T0104__autoskill_focus_detail']
RUNS['T0156']['autoskill']+=['T0156__autoskill_nav_recheck']
RUNS['T0156']['no_skill']+=['T0156__no_skill_resume']
RUNS['T0179']['autoskill']+=['T0179__autoskill_resume']
RUNS['T0179']['autoskill']+=['T0179__autoskill_context_recheck']
RUNS['T0179']['no_skill']+=['T0179__no_skill_horizontal_recheck']
RUNS['T0179']['trace2skill']=['T0179__trace2skill_verified','T0179__trace2skill_horizontal_recheck']
RUNS['T0232']['autoskill']+=['T0232__autoskill_resume']
RUNS['T0232']['no_skill']+=['T0232__no_skill_resume']

NOTES={
'T0001':{
'common':'按冻结四模块、S01—S04、导航/键盘、PC和平板场景测试。1440×1000及820×1180下查看了首页和页尾；有效运行记录了7个主要本地锚点的实际目标。样例表格列出四家供应商、资质日期和交付天数14/7/3/10；电话尾号0109。未调用邮件、电话或真实账号。',
'autoskill':'深蓝与米白页面、青色焦点和三角标识可见。登录入口到本地联系内容。S04提示以页面固定2026-10-15为参照显示5天内到期；这是页面内的样例口径。',
'no_skill':'键盘菜单能展开、橙色焦点可见，但菜单文字接近白色、背景为浅米白，实际像素对比很弱；04_keyboard_menu_open.png保留此状态。采购类别按钮使供应商行变化；登录仅打开本地说明。',
'trace2skill':'金色焦点和清楚的菜单可见；登录打开本地说明。S04在当前日期显示已到期3天，而旧公告仍写临近到期。合同模块以资质进度方式呈现，是否满足业务内容由后续评分者判断。',
'limits':'没有登录或后台业务验证；锚点成功只表示本地到达，不表示真实采购流程。页面说明.md的文档呈现不属于本轮浏览器补证。'},
'T0081':{
'common':'按四模块、R01—R04样例、PC/平板及键盘导航测试。页面内成果领域/TRL/负责人/证据可读，联系信息尾号0108。R01工业声学检测TRL6钟老师工厂试点，R02低温固化材料TRL5孟老师样品性能，R03设备预测维护TRL7安老师两条产线，R04酶催化工艺TRL4任老师实验室稳定性。',
'autoskill':'旧取证代码http://*规则误匹配data:SVG中的xmlns文本，造成标识被自身调试规则阻断。只移除了该冗余任务规则，Chrome页面仍为offline；svg_recheck中原始三角标识及名称实际显示。anchor菜单的键盘路径是Tab进入业务模块、再Tab到首个子项、Enter到目标；focus_detail保留了真实焦点与到达状态。',
'no_skill':'PC环形入口、平板网格入口可见。初次full-page截图的部分滚动动画卡片尚未出现；实际滚动后显示，不能把初次空白作为内容缺失。',
'trace2skill':'四个成果详情弹窗实际打开，R01—R04名称、TRL、负责人及证据可见；键盘下拉和本地模块入口已操作。',
'limits':'旧autoskill截图中的破图是取证误阻断，不可据此判断原产物失败。修复后PC全页与平板页头作标识依据；旧平板全页仍可支持其他布局观察，但标识结论由补验替代。'},
'T0082':{
'common':'Chrome离线file页面实际操作/status、/missing、/busy；三臂首次分别显示200、404、503。随后对/busy操作至第三次，实际点击生成/下载结果并读取UTF-8字节。截图中的状态和下载文件是2026-10-23当前复验；没有启动HTTP生产服务。PC和平板中文章节和操作区可读。',
'autoskill':'/busy第一次503，第二、第三次显示200，页面解释为重试后恢复；这是实际行为，与输入固定/busy=503需分开记录。下载result.txt为1251字节，最终包含恢复后的结果。',
'no_skill':'/busy三次均显示503，页面提示最多3次的边界；下载report.txt为1635字节。未点击第4次，因此没有证明代码强制阻止第4次。',
'trace2skill':'/busy三次均显示503，页面说明手动重试不超过3次；生成提交文本后下载submission.txt为848字节。未测试第4次。',
'limits':'仅practice.html的实际呈现和交互；teacher_plan.docx/student_guide.docx真实Word呈现未在本轮检查，不能用HTML截图代替DOCX视觉证据。'},
'T0104':{
'common':'操作课程、讲师、进度、关于、联系及本地账号入口；核对六课程C01—C06、45/80/60/90/75/40分钟及65/20/0/35/100/10%样例进度；电话尾号0107。PC及平板完整页面和键盘状态已审阅。',
'autoskill':'六个课程详情均在focus_detail补验中打开：每次用页面自带返回课程链接关闭CSS :target弹层后再开下一项。六课程教师含C06李棠，但讲师模块和摘要只列5位，缺李棠。蓝绿页面主体可读；业务菜单很窄、文字逐字换行。Tab进入子菜单并Enter到课程有效。旧_run在C01弹层未关闭时后续点击不能视作C02—C06成功，旧平板带弹层图也不代表基本页面。',
'no_skill':'六教师与课程/进度可见，键盘焦点可见。导航下拉符号实际显示字面u25BE；摘要左侧有孤立项目符号点。',
'trace2skill':'六教师、六课程进度在PC/平板可读；六详情按钮实际打开相应课程弹窗，键盘下拉有焦点。',
'limits':'学习进度是样例；没有学习系统或账号登录。no_skill旧鼠标审计#main跳过链接目标不一致可能受离屏点击影响，不据此判业务导航失败；主要模块另有操作证据。'},
'T0151':{
'common':'本题是静态报价说明，未强加交互控件。三臂PC和平板实际显示五SKU、阶梯价说明、CNY、13%税、2026-10-13报价/2026-10-27有效、12天交期和付款待定。页面合计11190.00+1454.70=12644.70。全页像素未见妨碍阅读的重叠或乱码。',
'autoskill':'完整静态页面及平板布局已审阅，金额和业务字段可读。',
'no_skill':'完整静态页面及平板布局已审阅，金额和业务字段可读。',
'trace2skill':'完整静态页面及平板布局已审阅，金额和业务字段可读。',
'limits':'原交付采购报价.csv保留供文本复核，但不是此次点击生成的浏览器下载；不存在的控件未计为失败。'},
'T0156':{
'common':'查看六维题量/时长5/8、6/12、6/12、5/8、5/8、4/7（题/分钟），合计31题55分钟；陈棠2026-10-08得分74/68/82/71/88/63、55分钟及再次测评入口。电话尾号0108；PC和平板为紫蓝主体。',
'autoskill':'六维、流程和陈棠结果可读，开始测评显示演示说明。实际PC展开菜单被页头裁切，仅见菜单上缘；键盘焦点虽可见，不能据此声称菜单视觉正常。平板基态页头只有标识及登录，没有完整导航。补验hero“了解测评范围”确实到#dimensions；对菜单链接scrollIntoView后点击也到#dimensions，但该动作会滚动被裁切容器，因此不证明普通指针能看到完整菜单。旧09_link_02误到#records保留为含歧义的旧动作。',
'no_skill':'六个维度说明按钮逐一展开实际文本；再次测评到本地测评入口，账号入口为演示说明；橙色键盘焦点可见。中断后的平板观察由_resume完成。',
'trace2skill':'开始/再次测评打开六维/全部选项弹窗，选择AI认知并确认后显示绿色本地演示确认信息；未发送真实测评或邀请。六维记录及PC/平板内容可读。',
'limits':'无真实账号或作答服务。autoskill导航裁切是实际视觉问题；DOM存在和hash到达不替代可见性。'},
'T0179':{
'common':'六型号数据可读，单位人民币/百万token，核验日2026-10-10。三厂商各筛出2项，图像2项、纯文本4项，澈语+图像0项、北辰+图像2项，清空恢复6项。实际价格升序CY-Lite、BC-Fast、QZ-Long、CY-Enterprise、QZ-Reason、BC-Vision；可用排序模式逐个切换并留图。输入价/输出价在该数据同序，仅凭结果不能区分比较器依据。',
'autoskill':'默认厂商顺序、输入价升序、输出价升序、输入+输出合计升序及上下文降序均有操作证据；界面没有价格降序选项。中断的sort_3只有旧JSON，_resume/02_sort_3.png补充了合计排序实际图，_context_recheck补齐上下文降序。场景A列QZ-Long与BC-Vision，B列BC-Vision与BC-Fast。',
'no_skill':'筛选恢复和输入/输出升序、上下文降序有真实状态。平板右侧列在可横滚表格内，实际水平滚轮后显示核验日期/依据材料；页面本身宽度805<=820。场景A和B均列对应两候选。',
'trace2skill':'筛选恢复、排序有效；场景A候选表只列QZ-Long，正文说BC-Vision可用但价格高、视觉本场景无用，未将它列入A候选表。平板文档宽度918>820，实际水平滚轮移动整页并让左侧内容离屏；不能声称平板无溢出。',
'limits':'旧trace2skill_run因取证选择器Unicode转义错误中止，仅两张准备图，最终筛选证据为_verified。排序依据同序限制未通过改数据规避。'},
'T0232':{
'common':'三臂加载附件样例青砚实验室/苏言/2026-10-13、LAB-01×3、LAB-03×10、LAB-04×2，均显示1460.00+131.40=1591.40 CNY；点击导出并核对落盘CSV。随后空公司和数量0/-1/1.5/abc/空值均显示错误且无新的CSV下载事件；原生number字段拒收abc后实际为空，不能称任意字符串已被业务逻辑处理。添加重复LAB-01×2，观察提示或合并；恢复样例后再导出，删除行及PC/平板显示也已观察。价格为固定目录展示而非可编辑价输入。',
'autoskill':'只有目录选择器，不能经公开UI输入任意未知SKU；空SKU已测，任意不存在型号未测。重复LAB-01留四行并标出重复；CSV合并为LAB-01数量5，金额1820/163.80/1983.80。原_run多次下载同文件名覆盖，所以_resume分别保存重复及恢复样例的真实字节快照。',
'no_skill':'利用页面自带本地JSON导入输入未知SKU，错误显示并阻止导出；无网络提交。重复SKU立即合并成3行、LAB-01数量5，金额1820/163.80/1983.80。旧取证脚本在合并删除行后读取不存在行报错；_resume已完成后续流程，异常不是产物报错。',
'trace2skill':'通过公开SKU输入字段输入NO-SUCH-SKU，显示错误并阻止导出。重复LAB-01合并为数量5后，行金额900+280+640=1820，但页面实际汇总显示2180/196.20/2376.20；12_duplicate_sku.png、13_duplicate_export.png及对应JSON保留差异。同期实际CSV却是1820/163.8/1983.8。恢复附件样例后CSV为正确1460/131.4/1591.4。',
'limits':'无真实采购系统或订单。下载快照目录中的文件可能是之前下载的现存文件，是否产生新下载须看events/action日志，不能仅凭快照文件存在。陌生downloads.htm非CSV，来源无法归因，隔离保留本机，详情见anomalies.json。'}
}

# Rehash originals and all independent copies, without replacing old checkpoint records.
prov=read(ROOT/'source_provenance.json')
for s in prov['sources']:
 s['sha256_final']=sha(Path(s['path']));s['unchanged_final']=s['sha256_final']==s['sha256_before']
 assert s['unchanged_final'],s['path']
prov['final_check_utc']=NOW;dump(FINAL/'source_provenance_final.json',prov)
copies=read(ROOT/'copied_files_before.json')
for c in copies:
 c['sha256_final']=sha(ROOT/c['path']);c['unchanged_final']=c['sha256_final']==c['sha256_before'];assert c['unchanged_final']
dump(FINAL/'copied_files_final.json',copies)
oldzip=ROOT.parent/'eval250_web24_checkpoint_20261023.zip'
pres=[]
with zipfile.ZipFile(oldzip) as z:
 for name in z.namelist():
  if name.endswith('.png'):
   r=name.split('/',1)[1];p=ROOT/r;h=hashlib.sha256(z.read(name)).hexdigest()
   pres.append({'path':r,'checkpoint_sha256':h,'current_sha256':sha(p),'unchanged':h==sha(p)})
assert len(pres)==423 and all(x['unchanged'] for x in pres)
dump(FINAL/'checkpoint_423_preservation.json',{'zip_sha256':sha(oldzip),'png_count':len(pres),'files':pres})

active={r for t in RUNS.values() for rs in t.values() for r in rs}
classification=[];network=[];downloads=[];inventory=[]
special={
'T0081__autoskill_verified':'Functional navigation retained; logo/initial visual superseded by svg_recheck; anchor keyboard sequence superseded by focus_detail.',
'T0104__autoskill_run':'Base desktop usable. C01 target overlay was not closed for subsequent detail attempts; C02-C06 and base tablet superseded by focus_detail. Do not use earlier detail click logs as success.',
'T0156__no_skill_run':'Interrupted after desktop interactions; all existing evidence retained; tablet completed in resume.',
'T0156__autoskill_run':'09_link_02 target mismatch retained. See nav_recheck and actual clipping notes. Hash/DOM alone is not menu visibility evidence.',
'T0179__autoskill_run':'Interrupted after sort_2; orphan15_sort_3.json has no screenshot and is not visual evidence. Remaining mode and tablet in resume.',
'T0232__no_skill_run':'Interrupted after add_line when auto-merge removed selected row and harness readback failed. Prior validation states retained; remaining work in resume.',
'T0232__autoskill_run':'Validation states retained. Reused download filename lost earlier byte versions; resume preserves duplicate/restored byte snapshots. Unattributed CRX file excluded from review package.'}
for d in sorted((ROOT/'observations').iterdir()):
 if not d.is_dir():continue
 status='usable_with_stated_limits' if d.name in active else 'preparation_or_superseded'
 classification.append({'run':d.name,'classification':status,'note':special.get(d.name,'See per-task final report; not every generated screenshot was individually reviewed.' if d.name in active else 'Preserved original evidence, not used as final successful interaction proof.'),'png_count':len(list(d.glob('*.png')))})
 for p in sorted(d.glob('*.png')):
  with Image.open(p) as im:im.verify()
  inventory.append({'path':rel(p),'bytes':p.stat().st_size,'sha256':sha(p),'valid_png':True,'run_classification':status})
 ep=d/'events.json'
 ev=read(ep) if ep.exists() else []
 requests=[e for e in ev if e.get('method')=='Network.requestWillBeSent']
 remote=[{'utc':e['utc'],'url':e['params']['request']['url']} for e in requests if e['params']['request']['url'].startswith(('http:','https:','ws:','wss:'))]
 fails=[e for e in ev if e.get('method') in ['Network.loadingFailed','Runtime.exceptionThrown']]
 begin=[e for e in ev if e.get('method') in ['Browser.downloadWillBegin','Page.downloadWillBegin']]
 done=[e for e in ev if e.get('method')=='Browser.downloadProgress' and e['params'].get('state')=='completed']
 network.append({'run':d.name,'page_remote_requests':remote,'failures':fails,'download_begin':begin,'download_completed':done,'limitation':'CDP page events do not establish absence of all browser/system background traffic.'})
 for base in ['downloads','download_snapshots']:
  for p in sorted((d/base).rglob('*')) if (d/base).exists() else []:
   if p.is_file() and p.suffix.lower() in ['.txt','.csv']:
    txt=p.read_bytes().decode('utf-8-sig')
    item={'run':d.name,'path':rel(p),'bytes':p.stat().st_size,'sha256':sha(p),'utf8_strict_decode':True,'text':txt,'snapshot_warning':'Presence in a snapshot is not evidence of a new download; correlate action/event log.'}
    if p.suffix=='.csv':item['csv_rows']=list(csv.reader(io.StringIO(txt)))
    downloads.append(item)
dump(FINAL/'run_classification.json',classification);dump(FINAL/'original_screenshot_inventory.json',inventory)
dump(FINAL/'network_download_events.json',network);dump(FINAL/'download_byte_checks.json',downloads)
anomaly=ROOT/'observations/T0232__autoskill_run/downloads/downloads.htm'
dump(FINAL/'anomalies.json',{'unattributed_file':{'path':rel(anomaly),'bytes':anomaly.stat().st_size,'sha256':sha(anomaly),'magic_hex':anomaly.read_bytes()[:4].hex(),'zip_names_observed':['model-info.pb','sentencepiece.model','model.tflite'],'executed_or_installed_by_agent':False,'source':'Unknown. Not linked to a Page/Browser.downloadWillBegin event; cannot attribute to HTML. Browser-component origin is an inference only.','handling':'Preserved in local full raw archive; excluded from delivered review packages. Subsequent isolated Chrome launches disabled component updates; no system settings changed.'},'git_head_check':'Denied, not retried; archive SHA verifies exact supplied bundle, not local Git HEAD.','browser_launch':'Sandbox launch exited; separately approved elevated isolated Chrome launch succeeded. No security setting or warning bypass.','cim_process_inventory':'Denied, not retried.'})

# Exact reviewed originals, including contact-sheet viewing. Generated != reviewed.
reviewed={};sheets=[]
def seen(p,method):
 if p.exists():reviewed.setdefault(rel(p),set()).add(method)
for d in (ROOT/'observations').iterdir():
 if not d.is_dir() or d.name not in active:continue
 baseok=d.name not in ['T0179__autoskill_run','T0232__no_skill_run','T0081__autoskill_focus_detail','T0081__autoskill_svg_recheck','T0156__autoskill_nav_recheck','T0179__no_skill_horizontal_recheck','T0179__trace2skill_horizontal_recheck']
 if d.name=='T0232__autoskill_run':baseok=False
 if baseok:
  for pattern in ['*desktop_full.png','*tablet_full.png','*keyboard_menu_focus.png','*keyboard_menu_open.png','*keyboard_first_target.png','*keyboard_target_activated.png','*tablet_keyboard.png']:
   for p in d.glob(pattern):seen(p,'Viewed in sliced/downsized contact sheet; original pixels preserved separately')
  sheets += [rel(p) for p in (d/'review').glob('contact_*.jpg')]
for x in read(ROOT/'dynamic_contact_manifest.json'):
 sheets.append(x['sheet'].replace('\\','/'))
 for p in x['original_screenshots']:seen(ROOT/p,'Viewed in dynamic contact sheet; original pixels preserved separately')
for s in ['T0081__autoskill_svg_recheck/01_initial_desktop.png','T0156__autoskill_nav_recheck/02_hero_dimensions.png','T0156__autoskill_nav_recheck/03_menu_open.png','T0156__autoskill_nav_recheck/04_menu_dimensions.png','T0156__autoskill_nav_recheck/05_tablet_nav.png','T0156__autoskill_run/04_keyboard_menu_open.png','T0156__autoskill_run/16_tablet_top.png','T0179__autoskill_resume/02_sort_3.png','T0179__autoskill_context_recheck/02_context_descending.png','T0179__no_skill_horizontal_recheck/03_tablet_horizontal_right.png','T0179__trace2skill_horizontal_recheck/03_tablet_horizontal_right.png']:
 seen(ROOT/'observations'/s,'Viewed original PNG using local image tool')
dump(FINAL/'pixel_review_manifest.json',{'written_utc':NOW,'scope':'Agent pixel review, not a score or a blanket visual pass. Full-page contact sheets were sliced and reduced for review; packages retain unmodified original PNG bytes. Not all generated PNGs were visually reviewed.','reviewed_originals':[{'path':p,'sha256':sha(ROOT/p),'methods':sorted(m)} for p,m in sorted(reviewed.items())],'derived_contact_sheets_used':sorted(set(sheets))})

selection=set();candidates=[];coverage=[]
for task in TASKS:
 req=read(ROOT/'requirements'/(task+'.json'))
 report=[f'# {task} 当前浏览器观察（不评分）','',NOTES[task]['common'],'','观察时间为动作日志中的UTC时间。浏览器为用户电脑已安装Chrome 155.0.8059.85，headless Chromium渲染；不代表真实物理平板。PC 1440×1000 / 平板模拟820×1180，DPR=1。','',f'限制：{NOTES[task]["limits"]}','']
 for arm in ARMS:
  rs=RUNS[task][arm];files=[]
  for rn in rs:
   d=ROOT/'observations'/rn
   pats=['*desktop_full.png','*tablet_full.png','*keyboard_menu_focus.png','*keyboard_menu_open.png','*keyboard_first_target.png','*keyboard_target_activated.png','*tablet_keyboard.png','*tablet_focus.png','*button*.png','*assessment*.png','*repeat_assessment.png','*course_C*.png','*menu_focus.png','*submenu*.png']
   if task in ['T0082','T0179','T0232']:pats+=['*.png']
   if rn.endswith(('svg_recheck','nav_recheck','horizontal_recheck')):pats=['*.png']
   for pat in pats:
    files.extend(d.glob(pat))
  files=sorted(set(files))
  # Exclude repeated preparation states and superseded full-page states, retain logs.
  files=[p for p in files if not (p.name.endswith('initial_desktop.png') and not p.parent.name.endswith('svg_recheck'))]
  if task in ['T0082','T0179','T0232']:
   files=[p for p in files if not any(x in p.name for x in ['_all_six','_vendor_restored','_final_all','_sample_loaded','_add_line','_tablet_top','_reset'])]
  if task=='T0104' and arm=='autoskill':files=[p for p in files if not(p.parent.name.endswith('_run') and ('tablet_' in p.name or 'keyboard_' in p.name))]
  if task=='T0081' and arm=='autoskill':files=[p for p in files if not(p.parent.name.endswith('_verified') and ('desktop_full' in p.name or 'keyboard_' in p.name))]
  if task=='T0232' and arm in ['autoskill','no_skill']:
   files=[p for p in files if not (p.parent.name.endswith('_run') and any(x in p.name for x in ['duplicate','corrected','delete_line','desktop_full','tablet_']))]
  selection.update(files)
  htmls=list((ROOT/'original_copies/artifacts'/(task+'__'+arm)/'outputs').glob('*.html'));assert len(htmls)==1
  h=htmls[0];logs=[rel(ROOT/'observations'/r/'actions.jsonl') for r in rs]
  c={'candidate':task+'__'+arm,'task':task,'arm':arm,'html_path':rel(h),'html_sha256':sha(h),'runs':rs,'action_logs':logs,'selected_original_screenshots':[rel(p) for p in files],'observation':NOTES[task][arm],'limitations':NOTES[task]['limits'],'current_revalidation_only':True}
  candidates.append(c)
  report += [f'## {arm}','',NOTES[task][arm],'',f'原件独立副本：`{rel(h)}`；SHA256 `{sha(h)}`。','', '运行记录：'+', '.join('`observations/'+r+'`' for r in rs)+'。','', '每次动作的预期、实际URL/焦点/尺寸、UTC时间及截图SHA见actions.jsonl；同名JSON为辅助状态，不替代像素。','', '精简包原始截图：','']
  report += ['- `'+rel(p)+'`' for p in files]
  report += ['']
  for item in req['items']:
   html=any(str(x).endswith('.html') for x in item.get('deliverables',[]))
   mode=item['evidence_modes'];in_scope=html and any(x in mode for x in ['visual','functional'])
   limitation=NOTES[task]['limits']
   if task=='T0232' and arm=='autoskill' and item['item_id']=='T0232-D2-02':limitation+=' 任意未知SKU无法经公开控件输入，因此本项对应场景覆盖不完整。'
   coverage.append({'candidate':c['candidate'],'item_id':item['item_id'],'criterion':item['criterion'],'evidence_modes':mode,'deliverables':item['deliverables'],'coverage':'current_browser_evidence_with_limits' if in_scope else ('visible_text_support_only' if html else 'outside_browser_scope'),'report':'final/'+task+'_observations_final.md','action_logs':logs if html else [],'original_screenshot_refs':c['selected_original_screenshots'] if html else [],'observed_facts':NOTES[task]['common']+' '+NOTES[task][arm] if html else '本轮未给此文档项目生成相应呈现证据。','limitation':limitation,'not_a_score':True})
 (FINAL/(task+'_observations_final.md')).write_text('\n'.join(report),encoding='utf-8')
dump(FINAL/'candidate_index.json',candidates);dump(FINAL/'coverage_matrix.json',coverage)
with (FINAL/'coverage_matrix.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=['candidate','item_id','coverage','criterion','report','limitation']);w.writeheader()
 for row in coverage:w.writerow({k:row[k] for k in w.fieldnames})
selected=[{'path':rel(p),'sha256':sha(p),'bytes':p.stat().st_size,'original_unmodified_png':True,'pixel_review_recorded':rel(p) in reviewed,'reason':'Key layout/focus/dynamic state or stated caveat; earlier duplicates and preparation excluded.'} for p in sorted(selection)]
dump(FINAL/'selected_original_screenshots.json',selected)
readme='''# eval250 24网页当前运行补证

本包只记录2026-10-23当前复验，不评分、不补写历史执行记录，不修改原产物或rubric。24/24候选均有Chrome实际运行和像素审阅；这不是24份全部通过的声明。每题的限制、差异及被替代的旧取证状态见分题报告和run_classification.json。

来源为用户指定冻结产物包。原始压缩包SHA256为c8ada3aff8687aaab009a558554b7bd0262b8276ec8498bf670fb093e19a0589；原件3文件、提取后106份独立副本均前后不变。rubric/policy本机为CRLF，原始SHA与LF释放版SHA不同；独立LF副本匹配用户指定值。没有把换行归一化文件写回原件。Git HEAD检查被拒绝，未重试，因此冻结来源通过压缩包SHA确认，未声称本地HEAD确认。

浏览器为AJiang电脑已安装Chrome 155.0.8059.85，使用headless真实渲染、全新临时profile、file URL及CDP offline。用Input鼠标/键盘操作；读取DOM作为辅助状态，用截图像素另行审阅。部分点击通过scrollIntoView使元素进入视口：可能使被裁切容器滚动，相关菜单裁切已单独报告。未使用云端浏览器、账号登录、真实服务、外部付费模型或旧worker；未安装软件/字体、发布网站或push仓库。

动作日志逐项保存UTC时间、预期、实际状态、截图SHA。浏览器版本文件包含本地CDP端点但不含登录凭据。PC1440×1000、平板820×1180均为同一桌面Chrome的视口模拟，不代表原生平板触控/所有浏览器兼容性。

先读candidate_index.json及8份*_observations_final.md。coverage_matrix按冻结item_id提供证据范围和限制，没有新增分值。source_provenance_final与copied_files_final记录来源；pixel_review_manifest明确哪些截图实际被审阅（可通过切片缩略拼图审阅），没有把所有截图生成都当作目视完成。精简包的PNG是原字节，不含改图或派生拼图。

download_byte_checks含真实落盘文本/CSV的SHA、长度、严格UTF-8解码与CSV解析。必须结合events的下载开始/完成及action日志；快照可能只是此前已存在文件。T0232 trace2skill重复SKU页面汇总与CSV不一致。T0082 autoskill重试/busy变200；T0156 autoskill菜单裁切；T0104 autoskill讲师少1位；T0179 trace2skill场景A候选及平板溢出均据实记录。

旧423张截图逐一与上一检查点ZIP核对哈希，均保留不变。完整原始归档保存在本机，含旧误阻断/准备记录；精简分题包省去重复准备图、profile/cache及无关二进制。T0081误阻断只纠正了本任务http通配规则，浏览器/系统安全未解除。

未归因downloads.htm具有Cr24头及模型文件目录；未执行/安装。没有对应页面下载开始事件，不能归因到HTML；它仅在本机原始归档保留，精简包排除。CDP页面离线/事件日志不能证明整个浏览器或系统无后台流量。详情见anomalies.json。

范围不含ICS、Word/Excel、T0030或旧评分ZIP恢复。本轮HTML观察不能代替T0082两份DOCX呈现，也不能证明任何先前报告所说的历史测试当时发生。
'''
(FINAL/'README.md').write_text(readme,encoding='utf-8')
dump(FINAL/'summary.json',{'finalized_utc':NOW,'candidates':24,'all_candidates_have_current_runtime_and_pixel_review':True,'original_png_count':len(inventory),'selected_original_png_count':len(selected),'old_423_unchanged':True,'source_files_unchanged':len(prov['sources']),'copied_files_unchanged':len(copies),'scores_modified':False,'historical_execution_confirmed':False,'outside_scope_documents_not_claimed':True})
print(json.dumps(read(FINAL/'summary.json'),ensure_ascii=False,indent=2))
