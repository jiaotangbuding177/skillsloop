from cdp_browser import Browser,ROOT
b=Browser('T0179__autoskill_context_recheck',ROOT/'original_copies/artifacts/T0179__autoskill/outputs/models.html')
try:
 b.log('resume','Finish final untested available sorting option',{'prior':'T0179__autoskill_resume','remaining':'context descending'})
 b.select('#sort','ctx');b.capture('context_descending','Context descending: QZ-Long, BC-Vision, three131072 entries, CY-Lite')
 b.log('actual_rows','Read visible ordering as functional support',b.js('[...document.querySelectorAll("tbody tr")].map(e=>e.innerText)'))
finally:b.close()
