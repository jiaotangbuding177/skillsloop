from pathlib import Path
import hashlib,json,zipfile,shutil,datetime
ROOT=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
diag=ROOT/'diagnostics';diag.mkdir(exist_ok=True)
for p in (ROOT/'runtime').glob('*/*.log'):
    if p.name in ['stdout.log','stderr.log']:
        q=diag/p.parent.name/p.name;q.parent.mkdir(exist_ok=True);shutil.copyfile(p,q)
shutil.copyfile(ROOT.parent/'prepare_evidence.py',ROOT/'preparation_script.py')
events_audit=[]
for d in (ROOT/'observations').iterdir():
    p=d/'events.json'
    if not p.exists():continue
    events=json.loads(p.read_text(encoding='utf-8'))
    req={x['params']['requestId']:x['params']['request']['url'] for x in events if x['method']=='Network.requestWillBeSent'}
    issues=[{'method':x['method'],'params':x['params'],'url':req.get(x['params'].get('requestId'),'')} for x in events if x['method'] in ['Network.loadingFailed','Runtime.exceptionThrown']]
    if issues:events_audit.append({'candidate':d.name,'events':issues})
(ROOT/'network_exception_audit.json').write_text(json.dumps(events_audit,ensure_ascii=False,indent=2),encoding='utf-8')
def included(p):
    rel=p.relative_to(ROOT)
    return p.is_file() and 'runtime' not in rel.parts and '__pycache__' not in rel.parts and p.name not in ['SHA256SUMS','eval250_q_artifacts.tar.gz']
files=sorted(p for p in ROOT.rglob('*') if included(p))
sums=''.join(sha(p)+'  '+p.relative_to(ROOT).as_posix()+'\n' for p in files)
(ROOT/'SHA256SUMS').write_text(sums,encoding='utf-8')
zip_path=ROOT.parent/'eval250_web24_checkpoint_20261023.zip'
with zipfile.ZipFile(zip_path,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in files+[ROOT/'SHA256SUMS']:z.write(p,arcname='web24_evidence_20261023/'+p.relative_to(ROOT).as_posix())
with zipfile.ZipFile(zip_path) as z:
    for p in files:
        data=z.read('web24_evidence_20261023/'+p.relative_to(ROOT).as_posix())
        assert hashlib.sha256(data).hexdigest()==sha(p)
zh=sha(zip_path)
checksum=ROOT.parent/'eval250_web24_checkpoint_20261023.sha256'
checksum.write_text(zh+'  '+zip_path.name+'\n',encoding='utf-8')
print(json.dumps({'zip':str(zip_path),'bytes':zip_path.stat().st_size,'sha256':zh,'checksum':str(checksum),'package_entries':len(files)+1,'roundtrip_sha_verification':'All packaged entries match source bytes','png_validation':all(p['valid_png'] for s in json.loads((ROOT/'checkpoint_status.json').read_text(encoding='utf-8')) for p in s['png_files'])},ensure_ascii=False,indent=2))
