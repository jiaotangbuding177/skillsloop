from pathlib import Path
import hashlib,json,zipfile,tarfile,io,datetime
ROOT=Path(__file__).resolve().parent
F=ROOT/'final';OUT=ROOT.parent/'eval250_web24_delivery_20261023';OUT.mkdir(exist_ok=False)
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def dump(p,o):p.write_text(json.dumps(o,ensure_ascii=False,indent=2),encoding='utf-8')
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def rel(p):return p.relative_to(ROOT).as_posix()
# Record the last original tablet-logo viewing without changing screenshots.
review=read(F/'pixel_review_manifest.json')
p=ROOT/'observations/T0081__autoskill_svg_recheck/03_tablet_top.png'
review['reviewed_originals'].append({'path':rel(p),'sha256':sha(p),'methods':['Viewed original PNG using local image tool after final source verification']})
dump(F/'pixel_review_manifest.json',review)
selected=read(F/'selected_original_screenshots.json')
for s in selected:
 if s['path']==rel(p):s['pixel_review_recorded']=True
dump(F/'selected_original_screenshots.json',selected)
def rawinclude(p):
 r=p.relative_to(ROOT)
 return p.is_file() and not any(x in r.parts for x in ['runtime','__pycache__','review']) and p.name not in ['eval250_q_artifacts.tar.gz','SHA256SUMS','RAW_SHA256SUMS']
raw=sorted(p for p in ROOT.rglob('*') if rawinclude(p))
raw_sums=''.join(sha(p)+'  '+rel(p)+'\n' for p in raw)
(F/'RAW_SHA256SUMS').write_text(raw_sums,encoding='utf-8')
rawzip=OUT/'eval250_web24_full_raw_20261023.zip'
with zipfile.ZipFile(rawzip,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in raw+[F/'RAW_SHA256SUMS']:z.write(p,arcname=rel(p))
with zipfile.ZipFile(rawzip) as z:
 for p in raw:
  assert hashlib.sha256(z.read(rel(p))).hexdigest()==sha(p),str(p)
rawinfo={'file':rawzip.name,'bytes':rawzip.stat().st_size,'sha256':sha(rawzip),'entries':len(raw)+1,'original_png_count':603,'all_entries_roundtrip_sha_checked':True,'includes_unattributed_crx_as_unexecuted_raw_evidence':True,'delivery':'Preserved locally; review packages exclude profiles/cache and unrelated binary.'}
dump(OUT/'full_raw_archive.json',rawinfo);print(json.dumps({'full_raw':rawinfo}),flush=True)

tasks=['T0001','T0081','T0082','T0104','T0151','T0156','T0179','T0232']
common=[p for p in F.iterdir() if p.is_file() and p.name not in ['RAW_SHA256SUMS'] and not p.name.endswith('_observations_final.md')]
common += [ROOT/x for x in ['test_plan.json','static_external_dependency_scan.json','environment_preflight.json','source_provenance.json','copied_files_before.json','dynamic_contact_manifest.json']]
common += list(ROOT.glob('*.py'))
common += list((ROOT/'diagnostics/checkpoint_harness').glob('*.py'))
common += list((ROOT/'source').glob('*.json*'))
sets={}
index=read(F/'candidate_index.json')
for task in tasks:
 ps=set(common+[F/(task+'_observations_final.md'),ROOT/'requirements'/(task+'.json')])
 ps.update(ROOT/x['path'] for x in selected if x['path'].split('/')[1].startswith(task+'__'))
 for c in index:
  if c['task']!=task:continue
  for rn in c['runs']:
   d=ROOT/'observations'/rn
   ps.update(p for p in d.glob('*') if p.is_file() and p.suffix in ['.json','.jsonl'])
   ps.update(p for b in ['downloads','download_snapshots'] for p in (d/b).rglob('*') if p.is_file() and p.suffix.lower() in ['.txt','.csv'])
  ps.update(p for p in (ROOT/'original_copies/artifacts'/c['candidate']/'outputs').iterdir() if p.is_file() and p.suffix.lower() in ['.html','.md','.csv'])
 ps.update(p for p in (ROOT/'original_copies/inputs'/task).rglob('*') if p.is_file())
 if task=='T0232':ps.update(p for p in (ROOT/'test_inputs').rglob('*') if p.is_file())
 sets[task]=sorted(ps)

def package(name,files):
 path=OUT/name
 sums=''.join(sha(p)+'  '+rel(p)+'\n' for p in files).encode('utf-8')
 with tarfile.open(path,'x:xz',preset=6) as t:
  for p in files:t.add(p,arcname=rel(p),recursive=False)
  i=tarfile.TarInfo('SHA256SUMS');i.size=len(sums);t.addfile(i,io.BytesIO(sums))
  d=json.dumps(rawinfo,ensure_ascii=False,indent=2).encode('utf-8');i=tarfile.TarInfo('full_raw_archive.json');i.size=len(d);t.addfile(i,io.BytesIO(d))
 with tarfile.open(path,'r:xz') as t:
  for p in files:assert hashlib.sha256(t.extractfile(rel(p)).read()).hexdigest()==sha(p),rel(p)
 return {'file':path.name,'bytes':path.stat().st_size,'sha256':sha(path),'entries':len(files)+2,'roundtrip_sha_verified':True}

union=sorted(set(p for ps in sets.values() for p in ps))
allpack=package('eval250_web24_review_all_20261023.tar.xz',union)
print(json.dumps({'combined_review':allpack}),flush=True)
packages=[]
if allpack['bytes']<=20_000_000:packages=[allpack]
else:
 for task,files in sets.items():
  item=package('eval250_'+task+'_review_20261023.tar.xz',files);packages.append(item);print(json.dumps(item),flush=True)

delivery={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'full_raw_archive':rawinfo,'combined_review_archive':allpack,'selected_original_screenshots_manifest_sha256':sha(F/'selected_original_screenshots.json'),'coverage_matrix_sha256':sha(F/'coverage_matrix.json'),'source_hashes_checked':True,'packages_for_delivery':packages,'transfer_status':'Not uploaded yet; see separate upload result.','local_path_warning':'Parent cannot read executor C: paths directly. Only confirmed Library IDs establish transfer.'}
dump(OUT/'DELIVERY_MANIFEST.json',delivery)
(OUT/'SHA256SUMS').write_text(''.join(x['sha256']+'  '+x['file']+'\n' for x in [rawinfo,allpack]+packages)+sha(OUT/'DELIVERY_MANIFEST.json')+'  DELIVERY_MANIFEST.json\n',encoding='utf-8')
summarypack=OUT/'eval250_web24_reports_and_checksums_20261023.zip'
with zipfile.ZipFile(summarypack,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(F.iterdir()):
  if p.is_file() and p.name!='RAW_SHA256SUMS':z.write(p,arcname='final/'+p.name)
 for name in ['DELIVERY_MANIFEST.json','SHA256SUMS','full_raw_archive.json']:z.write(OUT/name,arcname=name)
reportinfo={'file':summarypack.name,'bytes':summarypack.stat().st_size,'sha256':sha(summarypack)}
dump(OUT/'REPORTS_PACKAGE.json',reportinfo)
uploads=[{'local_path':str(OUT/x['file']),'purpose':'create_library_file','library_artifact_type':'other'} for x in [reportinfo]+packages]
dump(OUT/'upload_request.json',{'uploads':uploads})
print(json.dumps({'reports':reportinfo,'delivery_manifest':str(OUT/'DELIVERY_MANIFEST.json'),'upload_request':str(OUT/'upload_request.json')},ensure_ascii=False),flush=True)
