from pathlib import Path
import json, subprocess, time, urllib.request, websocket, base64, hashlib, datetime, socket

ROOT=Path(__file__).resolve().parent
CHROME=r'C:\Program Files\Google\Chrome\Application\chrome.exe'
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,obj): p.write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')
class Browser:
    def __init__(self, name, artifact):
        self.name=name; self.artifact=Path(artifact).resolve(); self.out=ROOT/'observations'/name
        self.out.mkdir(parents=True,exist_ok=False); self.downloads=self.out/'downloads'; self.downloads.mkdir()
        profile=ROOT/'runtime'/name; profile.mkdir(parents=True,exist_ok=False)
        self.logfile=self.out/'actions.jsonl'; self.events=[]; self.seq=0; self.n=0
        self.log('launch','Isolated local installed Chrome, file URL, offline, no credentials',{'artifact':str(self.artifact),'sha256':sha(self.artifact),'profile':str(profile)})
        si=subprocess.STARTUPINFO(); si.dwFlags|=subprocess.STARTF_USESHOWWINDOW; si.wShowWindow=0
        self.proc=subprocess.Popen([CHROME,'--headless=new','--remote-debugging-port=0','--user-data-dir='+str(profile),'--no-first-run','--no-default-browser-check','--disable-background-networking','--disable-component-update','--window-size=1440,1000','about:blank'],stdout=(profile/'stdout.log').open('wb'),stderr=(profile/'stderr.log').open('wb'),startupinfo=si)
        for _ in range(100):
            if (profile/'DevToolsActivePort').exists(): break
            if self.proc.poll() is not None: raise RuntimeError('Chrome exited: '+str(self.proc.returncode))
            time.sleep(.1)
        port=int((profile/'DevToolsActivePort').read_text().splitlines()[0]); self.port=port
        self.version=self.http('/json/version'); dump(self.out/'browser_version.json',self.version)
        tab=next(t for t in self.http('/json/list') if t['type']=='page')
        self.ws=websocket.create_connection(tab['webSocketDebuggerUrl'],timeout=10,suppress_origin=True)
        self.call('Page.enable'); self.call('Runtime.enable'); self.call('Network.enable')
        # The old substring wildcard incorrectly blocked data: SVG namespace text.
        # Keep Chrome's offline network condition; only remove our redundant rule.
        self.log('network_isolation','Offline with inline resources intact',{'offline':True,'old_task_wildcard_removed':True,'reason':'Old substring matching also matched http namespace inside data SVG. No browser/system security setting changed.'})
        self.call('Network.emulateNetworkConditions',{'offline':True,'latency':0,'downloadThroughput':0,'uploadThroughput':0})
        self.call('Browser.setDownloadBehavior',{'behavior':'allow','downloadPath':str(self.downloads.resolve()),'eventsEnabled':True})
        self.viewport(1440,1000)
        self.call('Page.navigate',{'url':self.artifact.as_uri()}); time.sleep(.5)
        self.capture('initial_desktop','Load unchanged HTML at 1440x1000')
    def http(self,path):
        with urllib.request.urlopen('http://127.0.0.1:'+str(self.port)+path,timeout=4) as r: return json.load(r)
    def log(self,action,expected,actual):
        rec={'utc':now(),'action':action,'expected':expected,'actual':actual}
        with self.logfile.open('a',encoding='utf-8') as f:f.write(json.dumps(rec,ensure_ascii=False)+'\n')
    def call(self,method,params=None):
        self.seq+=1; i=self.seq; self.ws.send(json.dumps({'id':i,'method':method,'params':params or {}}))
        while True:
            msg=json.loads(self.ws.recv())
            if msg.get('id')==i:
                if 'error'in msg: raise RuntimeError(str(msg['error']))
                return msg.get('result',{})
            if msg.get('method'): self.events.append({'utc':now(),**msg})
    def js(self,expression):
        r=self.call('Runtime.evaluate',{'expression':expression,'returnByValue':True,'awaitPromise':True})
        if 'exceptionDetails'in r: raise RuntimeError(str(r['exceptionDetails']))
        return r.get('result',{}).get('value')
    def viewport(self,w,h):
        self.call('Emulation.setDeviceMetricsOverride',{'width':w,'height':h,'deviceScaleFactor':1,'mobile':False})
        self.log('viewport','Set equal viewport across arms',{'width':w,'height':h}); time.sleep(.15)
    def state(self):
        return self.js('''(()=>{const a=document.activeElement;return {url:location.href,title:document.title,scroll:{x:scrollX,y:scrollY},size:{width:innerWidth,height:innerHeight,scrollWidth:document.documentElement.scrollWidth,scrollHeight:document.documentElement.scrollHeight},focus:a?{tag:a.tagName,id:a.id,text:(a.innerText||a.value||a.getAttribute('aria-label')||'').slice(0,300),outline:getComputedStyle(a).outline}:null,body:document.body.innerText,controls:[...document.querySelectorAll('a,button,input,select,textarea,summary')].map((e,i)=>{let r=e.getBoundingClientRect();return {i,tag:e.tagName,id:e.id,text:(e.innerText||e.value||e.getAttribute('aria-label')||'').slice(0,250),type:e.type,name:e.name,href:e.getAttribute('href'),download:e.getAttribute('download'),disabled:e.disabled,readOnly:e.readOnly,visible:!!(r.width&&r.height)&&getComputedStyle(e).visibility!='hidden',box:{x:r.x,y:r.y,w:r.width,h:r.height},options:e.options?[...e.options].map(o=>({text:o.text,value:o.value,selected:o.selected})):undefined}})}})()''')
    def capture(self,label,expected,full=False):
        self.n+=1; prefix=f'{self.n:02}_{label}'; state=self.state(); dump(self.out/(prefix+'.json'),state)
        params={'format':'png','captureBeyondViewport':bool(full)}
        if full:
            m=self.call('Page.getLayoutMetrics')['cssContentSize']; params['clip']={'x':0,'y':0,'width':m['width'],'height':m['height'],'scale':1}
        data=self.call('Page.captureScreenshot',params)['data']; p=self.out/(prefix+'.png'); p.write_bytes(base64.b64decode(data))
        self.log(label,expected,{'state_file':prefix+'.json','screenshot':prefix+'.png','screenshot_sha256':sha(p),'url':state['url'],'focus':state['focus'],'size':state['size'],'scroll':state['scroll']})
        dump(self.out/'events.json',self.events)
        return state
    def click(self,selector,expected,label=None,index=0):
        expr='''(()=>{let e=document.querySelectorAll(%s)[%d];if(!e)return null;e.scrollIntoView({block:'center'});let r=e.getBoundingClientRect();return {x:r.x+r.width/2,y:r.y+r.height/2,text:e.innerText,tag:e.tagName,type:e.type,href:e.getAttribute('href'),box:{w:r.width,h:r.height}}})()'''%(json.dumps(selector),index)
        info=self.js(expr)
        # Pages may use CSS smooth scrolling. Wait for the viewport to settle, then
        # recompute the coordinates before issuing real pointer events.
        time.sleep(.65)
        info=self.js('''(()=>{let e=document.querySelectorAll(%s)[%d];if(!e)return null;let r=e.getBoundingClientRect();return {x:r.x+r.width/2,y:r.y+r.height/2,text:e.innerText,tag:e.tagName,type:e.type,href:e.getAttribute('href'),box:{w:r.width,h:r.height}}})()'''%(json.dumps(selector),index))
        if not info or not info['box']['w'] or not info['box']['h']:
            self.log('click',expected,{'selector':selector,'index':index,'not_actionable':info}); return False
        href=info.get('href') or ''
        if href.startswith(('http:','https:','mailto:','tel:')): self.log('click_skipped',expected,{'reason':'external or person-directed target','target':info}); return False
        self.call('Input.dispatchMouseEvent',{'type':'mouseMoved','x':info['x'],'y':info['y']})
        for typ in ['mousePressed','mouseReleased']: self.call('Input.dispatchMouseEvent',{'type':typ,'x':info['x'],'y':info['y'],'button':'left','clickCount':1})
        time.sleep(.6);self.log('click',expected,{'selector':selector,'index':index,'target':info})
        if label:self.capture(label,expected)
        return True
    def key(self,key,modifiers=0):
        codes={'Tab':9,'Enter':13,'Escape':27,'ArrowDown':40,'ArrowUp':38,'Home':36,'End':35,'Backspace':8,'Delete':46,'a':65,'A':65,' ':32}
        for typ in ['keyDown','keyUp']:
            params={'type':typ,'key':key,'code':('Key'+key.upper() if len(key)==1 and key.isalpha() else key),'windowsVirtualKeyCode':codes.get(key,0),'modifiers':modifiers}
            if typ=='keyDown' and key=='Enter': params.update(text='\r',unmodifiedText='\r')
            self.call('Input.dispatchKeyEvent',params)
        time.sleep(.04)
        self.log('keyboard','Real keyboard input',{'key':key,'modifiers':modifiers})
    def fill(self,selector,text,index=0):
        if not self.click(selector,'Focus field before entering test data',index=index):return
        self.key('a',2); self.call('Input.insertText',{'text':text});self.key('Tab')
        self.log('fill','Enter test value through keyboard',{'selector':selector,'index':index,'value':text})
    def select(self,selector,value,index=0):
        info=self.js('''(()=>{let e=document.querySelectorAll(%s)[%d];return e?{options:[...e.options].map(x=>x.value),value:e.value}:null})()'''%(json.dumps(selector),index))
        if not info or value not in info['options']:
            self.log('select','Select available option',{'selector':selector,'value':value,'not_available':info});return
        self.click(selector,'Open native selector',index=index);self.key('Home')
        for _ in range(info['options'].index(value)):self.key('ArrowDown')
        self.key('Enter');self.key('Tab');self.log('select','Change value through native keyboard',{'selector':selector,'requested_value':value,'actual':self.js('document.querySelectorAll('+json.dumps(selector)+')['+str(index)+']?.value ?? null'),'note':'null can mean the app removed/merged the selected row; inspect resultant state.'})
    def scroll(self,y): self.js('window.scrollTo(0,'+str(y)+')');time.sleep(.65)
    def reload(self): self.call('Page.reload');time.sleep(.2)
    def download_inventory(self):
        data=[{'filename':p.name,'bytes':p.stat().st_size,'sha256':sha(p),'utf8_text':p.read_text(encoding='utf-8-sig',errors='replace') if p.suffix.lower() in ['.csv','.txt','.json','.md'] else None} for p in self.downloads.iterdir() if p.is_file()]
        dump(self.out/'downloads_manifest.json',data);return data
    def close(self):
        self.download_inventory(); dump(self.out/'events.json',self.events)
        self.log('finish','Source bytes unchanged',{'source_sha256_after':sha(self.artifact)})
        self.ws.close();self.proc.terminate()
        try:self.proc.wait(timeout=5)
        except subprocess.TimeoutExpired:pass
