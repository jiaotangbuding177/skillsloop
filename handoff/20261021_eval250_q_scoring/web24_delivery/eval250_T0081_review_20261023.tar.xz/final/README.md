# eval250 24网页当前运行补证

本包只记录2026-10-23当前复验，不评分、不补写历史执行记录，不修改原产物或rubric。24/24候选均有Chrome实际运行和像素审阅；这不是24份全部通过的声明。每题的限制、差异及被替代的旧取证状态见分题报告和run_classification.json。

来源为用户指定冻结产物包。原始压缩包SHA256为c8ada3aff8687aaab009a558554b7bd0262b8276ec8498bf670fb093e19a0589；原件3文件、提取后106份独立副本均前后不变。rubric/policy本机为CRLF，原始SHA与LF释放版SHA不同；独立LF副本匹配用户指定值。没有把换行归一化文件写回原件。Git HEAD检查被拒绝，未重试，因此冻结来源通过压缩包SHA确认，未声称本地HEAD确认。

浏览器为AJiang电脑已安装Chrome 155.0.8059.85，使用headless真实渲染、全新临时profile、file URL及CDP offline。用Input鼠标/键盘操作；读取DOM作为辅助状态，用截图像素另行审阅。部分点击通过scrollIntoView使元素进入视口：可能使被裁切容器滚动，相关菜单裁切已单独报告。未使用云端浏览器、账号登录、真实服务、外部付费模型或旧worker；未安装软件/字体、发布网站或push仓库。

动作日志逐项保存UTC时间、预期、实际状态、截图SHA。浏览器版本文件包含本地CDP端点但不含登录凭据。PC1440×1000、平板820×1180均为同一桌面Chrome的视口模拟，不代表原生平板触控/所有浏览器兼容性。

先读candidate_index.json及8份*_observations_final.md。coverage_matrix按冻结item_id提供证据范围和限制，没有新增分值。source_provenance_final与copied_files_final记录来源；pixel_review_manifest明确哪些截图实际被审阅（可通过切片缩略拼图审阅），没有把所有截图生成都当作目视完成。精简包的PNG是原字节，不含改图或派生拼图。

download_byte_checks含真实落盘文本/CSV的SHA、长度、严格UTF-8解码与CSV解析。必须结合events的下载开始/完成及action日志；快照可能只是此前已存在文件。T0232 trace2skill重复SKU页面汇总与CSV不一致。T0082 autoskill重试/busy变200；T0156 autoskill菜单裁切；T0104 autoskill讲师少1位；T0179 trace2skill场景A候选及平板溢出均据实记录。

旧423张截图逐一与上一检查点ZIP核对哈希，均保留不变。完整原始归档保存在本机，含旧误阻断/准备记录；精简分题包省去重复准备图、profile/cache及无关二进制。T0081误阻断只纠正了本任务http通配规则，浏览器/系统安全未解除。

未归因downloads.htm具有Cr24头及模型文件目录；未执行/安装。没有对应页面下载开始事件，不能归因到HTML；它仅在本机原始归档保留，精简包排除。CDP页面离线/事件日志不能证明整个浏览器或系统无后台流量。详情见anomalies.json。

范围不含ICS、Word/Excel、T0030或旧评分ZIP恢复。本轮HTML观察不能代替T0082两份DOCX呈现，也不能证明任何先前报告所说的历史测试当时发生。
