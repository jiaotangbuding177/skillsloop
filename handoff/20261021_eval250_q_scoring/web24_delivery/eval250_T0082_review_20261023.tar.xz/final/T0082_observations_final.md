# T0082 当前浏览器观察（不评分）

Chrome离线file页面实际操作/status、/missing、/busy；三臂首次分别显示200、404、503。随后对/busy操作至第三次，实际点击生成/下载结果并读取UTF-8字节。截图中的状态和下载文件是2026-10-23当前复验；没有启动HTTP生产服务。PC和平板中文章节和操作区可读。

观察时间为动作日志中的UTC时间。浏览器为用户电脑已安装Chrome 155.0.8059.85，headless Chromium渲染；不代表真实物理平板。PC 1440×1000 / 平板模拟820×1180，DPR=1。

限制：仅practice.html的实际呈现和交互；teacher_plan.docx/student_guide.docx真实Word呈现未在本轮检查，不能用HTML截图代替DOCX视觉证据。

## autoskill

/busy第一次503，第二、第三次显示200，页面解释为重试后恢复；这是实际行为，与输入固定/busy=503需分开记录。下载result.txt为1251字节，最终包含恢复后的结果。

原件独立副本：`original_copies/artifacts/T0082__autoskill/outputs/practice.html`；SHA256 `aa4425d3aee760dc1d5e085ce6c67083118c4472dc570eead308e60b2376841f`。

运行记录：`observations/T0082__autoskill_run`。

每次动作的预期、实际URL/焦点/尺寸、UTC时间及截图SHA见actions.jsonl；同名JSON为辅助状态，不替代像素。

精简包原始截图：

- `observations/T0082__autoskill_run/02_status_first.png`
- `observations/T0082__autoskill_run/03_missing_first.png`
- `observations/T0082__autoskill_run/04_busy_first.png`
- `observations/T0082__autoskill_run/05_busy_attempt_2.png`
- `observations/T0082__autoskill_run/06_busy_attempt_3.png`
- `observations/T0082__autoskill_run/07_download_result.png`
- `observations/T0082__autoskill_run/08_desktop_full.png`
- `observations/T0082__autoskill_run/10_tablet_full.png`
- `observations/T0082__autoskill_run/11_tablet_focus.png`

## no_skill

/busy三次均显示503，页面提示最多3次的边界；下载report.txt为1635字节。未点击第4次，因此没有证明代码强制阻止第4次。

原件独立副本：`original_copies/artifacts/T0082__no_skill/outputs/practice.html`；SHA256 `fbf8ec49e8c2d5bc97ff2ac3c941e5d4bea08e5577bb682dea5881e47bff1800`。

运行记录：`observations/T0082__no_skill_run`。

每次动作的预期、实际URL/焦点/尺寸、UTC时间及截图SHA见actions.jsonl；同名JSON为辅助状态，不替代像素。

精简包原始截图：

- `observations/T0082__no_skill_run/02_status_first.png`
- `observations/T0082__no_skill_run/03_missing_first.png`
- `observations/T0082__no_skill_run/04_busy_first.png`
- `observations/T0082__no_skill_run/05_busy_attempt_2.png`
- `observations/T0082__no_skill_run/06_busy_attempt_3.png`
- `observations/T0082__no_skill_run/07_download_result.png`
- `observations/T0082__no_skill_run/08_desktop_full.png`
- `observations/T0082__no_skill_run/10_tablet_full.png`
- `observations/T0082__no_skill_run/11_tablet_focus.png`

## trace2skill

/busy三次均显示503，页面说明手动重试不超过3次；生成提交文本后下载submission.txt为848字节。未测试第4次。

原件独立副本：`original_copies/artifacts/T0082__trace2skill/outputs/practice.html`；SHA256 `9c0c91798df5c2536574415e8955b7899588fe3ef22cf147008fc904b94561c3`。

运行记录：`observations/T0082__trace2skill_run`。

每次动作的预期、实际URL/焦点/尺寸、UTC时间及截图SHA见actions.jsonl；同名JSON为辅助状态，不替代像素。

精简包原始截图：

- `observations/T0082__trace2skill_run/02_status_first.png`
- `observations/T0082__trace2skill_run/03_missing_first.png`
- `observations/T0082__trace2skill_run/04_busy_first.png`
- `observations/T0082__trace2skill_run/05_busy_attempt_2.png`
- `observations/T0082__trace2skill_run/06_busy_attempt_3.png`
- `observations/T0082__trace2skill_run/07_submission_generated.png`
- `observations/T0082__trace2skill_run/08_download_result.png`
- `observations/T0082__trace2skill_run/09_desktop_full.png`
- `observations/T0082__trace2skill_run/11_tablet_full.png`
- `observations/T0082__trace2skill_run/12_tablet_focus.png`
