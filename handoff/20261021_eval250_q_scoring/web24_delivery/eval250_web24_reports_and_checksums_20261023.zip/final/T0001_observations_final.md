# T0001 当前浏览器观察（不评分）

按冻结四模块、S01—S04、导航/键盘、PC和平板场景测试。1440×1000及820×1180下查看了首页和页尾；有效运行记录了7个主要本地锚点的实际目标。样例表格列出四家供应商、资质日期和交付天数14/7/3/10；电话尾号0109。未调用邮件、电话或真实账号。

观察时间为动作日志中的UTC时间。浏览器为用户电脑已安装Chrome 155.0.8059.85，headless Chromium渲染；不代表真实物理平板。PC 1440×1000 / 平板模拟820×1180，DPR=1。

限制：没有登录或后台业务验证；锚点成功只表示本地到达，不表示真实采购流程。页面说明.md的文档呈现不属于本轮浏览器补证。

## autoskill

深蓝与米白页面、青色焦点和三角标识可见。登录入口到本地联系内容。S04提示以页面固定2026-10-15为参照显示5天内到期；这是页面内的样例口径。

原件独立副本：`original_copies/artifacts/T0001__autoskill/outputs/index.html`；SHA256 `d6d62dfddd10d754c04b605bf6eb8b991a6e16944309d2745005a7fc577bc473`。

运行记录：`observations/T0001__autoskill_verified`。

每次动作的预期、实际URL/焦点/尺寸、UTC时间及截图SHA见actions.jsonl；同名JSON为辅助状态，不替代像素。

精简包原始截图：

- `observations/T0001__autoskill_verified/02_desktop_full.png`
- `observations/T0001__autoskill_verified/03_keyboard_menu_focus.png`
- `observations/T0001__autoskill_verified/04_keyboard_menu_open.png`
- `observations/T0001__autoskill_verified/05_keyboard_first_target.png`
- `observations/T0001__autoskill_verified/06_keyboard_target_activated.png`
- `observations/T0001__autoskill_verified/16_tablet_full.png`
- `observations/T0001__autoskill_verified/17_tablet_keyboard.png`

## no_skill

键盘菜单能展开、橙色焦点可见，但菜单文字接近白色、背景为浅米白，实际像素对比很弱；04_keyboard_menu_open.png保留此状态。采购类别按钮使供应商行变化；登录仅打开本地说明。

原件独立副本：`original_copies/artifacts/T0001__no_skill/outputs/index.html`；SHA256 `0151f359048c8dc0fe9ba2ef87e512bc66acd622de4735cd13acfd6f7bb94f5b`。

运行记录：`observations/T0001__no_skill_verified`。

每次动作的预期、实际URL/焦点/尺寸、UTC时间及截图SHA见actions.jsonl；同名JSON为辅助状态，不替代像素。

精简包原始截图：

- `observations/T0001__no_skill_verified/02_desktop_full.png`
- `observations/T0001__no_skill_verified/03_keyboard_menu_focus.png`
- `observations/T0001__no_skill_verified/04_keyboard_menu_open.png`
- `observations/T0001__no_skill_verified/05_keyboard_first_target.png`
- `observations/T0001__no_skill_verified/06_keyboard_target_activated.png`
- `observations/T0001__no_skill_verified/15_button_00.png`
- `observations/T0001__no_skill_verified/16_button_01.png`
- `observations/T0001__no_skill_verified/17_button_02.png`
- `observations/T0001__no_skill_verified/18_button_03.png`
- `observations/T0001__no_skill_verified/19_button_04.png`
- `observations/T0001__no_skill_verified/20_button_05.png`
- `observations/T0001__no_skill_verified/22_tablet_full.png`
- `observations/T0001__no_skill_verified/23_tablet_keyboard.png`

## trace2skill

金色焦点和清楚的菜单可见；登录打开本地说明。S04在当前日期显示已到期3天，而旧公告仍写临近到期。合同模块以资质进度方式呈现，是否满足业务内容由后续评分者判断。

原件独立副本：`original_copies/artifacts/T0001__trace2skill/outputs/index.html`；SHA256 `5bcc16ee60bb4732cd9de7abb2e164cbac7d0fe11e8cc2263a589537b336a121`。

运行记录：`observations/T0001__trace2skill_verified`。

每次动作的预期、实际URL/焦点/尺寸、UTC时间及截图SHA见actions.jsonl；同名JSON为辅助状态，不替代像素。

精简包原始截图：

- `observations/T0001__trace2skill_verified/02_desktop_full.png`
- `observations/T0001__trace2skill_verified/03_keyboard_menu_focus.png`
- `observations/T0001__trace2skill_verified/04_keyboard_menu_open.png`
- `observations/T0001__trace2skill_verified/05_keyboard_first_target.png`
- `observations/T0001__trace2skill_verified/06_keyboard_target_activated.png`
- `observations/T0001__trace2skill_verified/15_button_00.png`
- `observations/T0001__trace2skill_verified/17_tablet_full.png`
- `observations/T0001__trace2skill_verified/18_tablet_keyboard.png`
