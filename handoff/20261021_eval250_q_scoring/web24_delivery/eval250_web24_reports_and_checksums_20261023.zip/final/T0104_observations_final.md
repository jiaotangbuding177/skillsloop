# T0104 当前浏览器观察（不评分）

操作课程、讲师、进度、关于、联系及本地账号入口；核对六课程C01—C06、45/80/60/90/75/40分钟及65/20/0/35/100/10%样例进度；电话尾号0107。PC及平板完整页面和键盘状态已审阅。

观察时间为动作日志中的UTC时间。浏览器为用户电脑已安装Chrome 155.0.8059.85，headless Chromium渲染；不代表真实物理平板。PC 1440×1000 / 平板模拟820×1180，DPR=1。

限制：学习进度是样例；没有学习系统或账号登录。no_skill旧鼠标审计#main跳过链接目标不一致可能受离屏点击影响，不据此判业务导航失败；主要模块另有操作证据。

## autoskill

六个课程详情均在focus_detail补验中打开：每次用页面自带返回课程链接关闭CSS :target弹层后再开下一项。六课程教师含C06李棠，但讲师模块和摘要只列5位，缺李棠。蓝绿页面主体可读；业务菜单很窄、文字逐字换行。Tab进入子菜单并Enter到课程有效。旧_run在C01弹层未关闭时后续点击不能视作C02—C06成功，旧平板带弹层图也不代表基本页面。

原件独立副本：`original_copies/artifacts/T0104__autoskill/outputs/index.html`；SHA256 `b6f30756aa17c27bb21346cd6af157fb89a60c0730e50ecb3ad1c2bfd9d34df8`。

运行记录：`observations/T0104__autoskill_run`, `observations/T0104__autoskill_focus_detail`。

每次动作的预期、实际URL/焦点/尺寸、UTC时间及截图SHA见actions.jsonl；同名JSON为辅助状态，不替代像素。

精简包原始截图：

- `observations/T0104__autoskill_focus_detail/02_menu_focus.png`
- `observations/T0104__autoskill_focus_detail/03_submenu_focus.png`
- `observations/T0104__autoskill_focus_detail/04_submenu_activated.png`
- `observations/T0104__autoskill_focus_detail/05_course_C01.png`
- `observations/T0104__autoskill_focus_detail/06_course_C02.png`
- `observations/T0104__autoskill_focus_detail/07_course_C03.png`
- `observations/T0104__autoskill_focus_detail/08_course_C04.png`
- `observations/T0104__autoskill_focus_detail/09_course_C05.png`
- `observations/T0104__autoskill_focus_detail/10_course_C06.png`
- `observations/T0104__autoskill_focus_detail/12_tablet_full.png`
- `observations/T0104__autoskill_run/02_desktop_full.png`

## no_skill

六教师与课程/进度可见，键盘焦点可见。导航下拉符号实际显示字面u25BE；摘要左侧有孤立项目符号点。

原件独立副本：`original_copies/artifacts/T0104__no_skill/outputs/index.html`；SHA256 `69fe2e3184ccb39d2b2a78695c7145dce29182b3ec7a42f073a4d37dbbffd4ba`。

运行记录：`observations/T0104__no_skill_run`。

每次动作的预期、实际URL/焦点/尺寸、UTC时间及截图SHA见actions.jsonl；同名JSON为辅助状态，不替代像素。

精简包原始截图：

- `observations/T0104__no_skill_run/02_desktop_full.png`
- `observations/T0104__no_skill_run/03_keyboard_menu_focus.png`
- `observations/T0104__no_skill_run/04_keyboard_menu_open.png`
- `observations/T0104__no_skill_run/05_keyboard_first_target.png`
- `observations/T0104__no_skill_run/06_keyboard_target_activated.png`
- `observations/T0104__no_skill_run/16_button_00.png`
- `observations/T0104__no_skill_run/18_tablet_full.png`
- `observations/T0104__no_skill_run/19_tablet_keyboard.png`

## trace2skill

六教师、六课程进度在PC/平板可读；六详情按钮实际打开相应课程弹窗，键盘下拉有焦点。

原件独立副本：`original_copies/artifacts/T0104__trace2skill/outputs/index.html`；SHA256 `4a5569fe5fe672dbb50bc8d53275b4871f1a1e1fcb5ebd59f83a6f7217ec3234`。

运行记录：`observations/T0104__trace2skill_run`。

每次动作的预期、实际URL/焦点/尺寸、UTC时间及截图SHA见actions.jsonl；同名JSON为辅助状态，不替代像素。

精简包原始截图：

- `observations/T0104__trace2skill_run/02_desktop_full.png`
- `observations/T0104__trace2skill_run/03_keyboard_menu_focus.png`
- `observations/T0104__trace2skill_run/04_keyboard_menu_open.png`
- `observations/T0104__trace2skill_run/05_keyboard_first_target.png`
- `observations/T0104__trace2skill_run/06_keyboard_target_activated.png`
- `observations/T0104__trace2skill_run/14_button_00.png`
- `observations/T0104__trace2skill_run/15_button_01.png`
- `observations/T0104__trace2skill_run/16_button_02.png`
- `observations/T0104__trace2skill_run/17_button_03.png`
- `observations/T0104__trace2skill_run/18_button_04.png`
- `observations/T0104__trace2skill_run/19_button_05.png`
- `observations/T0104__trace2skill_run/21_tablet_full.png`
- `observations/T0104__trace2skill_run/22_tablet_keyboard.png`
