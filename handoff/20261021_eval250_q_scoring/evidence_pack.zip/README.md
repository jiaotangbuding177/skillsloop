# Q 评分缺失证据包

## 这是什么

13 个原始交付文件 + 对应的完整 Actor 执行过程轨迹。这些文件已经通过 SHA256 精确匹配确认，就是 Q 评分需要的原始产物。**本机没有 LibreOffice/PowerPoint 原生渲染环境**，所以图表/字体/分页的原生截图需要接收方在自己环境中打开这些文件并截图/导出。

## 文件列表

- **T0112_B_xlsx**: `成果赋权与转化分析.xlsx` (17688 bytes, SHA256 `23b27182e2f4d13a...`)
- **T0238_B_pptx**: `技术转移项目路演概要.pptx` (44956 bytes, SHA256 `2ad1ecd280c1559b...`)
- **T0112_A_xlsx**: `成果赋权与转化分析.xlsx` (18733 bytes, SHA256 `460b37e72f295b7f...`)
- **T0178_pptx**: `软件安全能力培训.pptx` (51718 bytes, SHA256 `4a4ee14e658655e4...`)
- **T0218_A_pptx**: `项目建设资金说明.pptx` (55154 bytes, SHA256 `5d93357d1f566a5a...`)
- **T0171_docx**: `医美器械采购岗位适配.docx` (15875 bytes, SHA256 `706eed59e9c56825...`)
- **T0218_B_pptx**: `项目建设资金说明.pptx` (62840 bytes, SHA256 `7e6e2a4ba7d764b9...`)
- **T0238_A_pptx**: `技术转移项目路演概要.pptx` (43634 bytes, SHA256 `7fc40828bc120306...`)
- **T0239_A_pptx**: `合作项目管理方案.pptx` (49737 bytes, SHA256 `c41608917787755b...`)
- **T0218_C_pptx**: `项目建设资金说明.pptx` (49036 bytes, SHA256 `cd8bc0f3f4c505c3...`)
- **T0235_docx**: `bp_outline.docx` (41657 bytes, SHA256 `d16b04f7d338f65c...`)
- **T0236_pptx**: `客户知识库阶段验收.pptx` (52301 bytes, SHA256 `ebc429f3ed0ddff1...`)
- **T0239_B_pptx**: `合作项目管理方案.pptx` (59972 bytes, SHA256 `efa312fde776bf6c...`)

## 需要做什么

对每个文件，在**原生 Microsoft Office 或 LibreOffice** 中打开，然后：

1. 导出为 PDF（保留所有页面），或
2. 逐页截图

需要关注的页面：
- T0112 xlsx：图表所在工作表
- T0171 docx：全部页面（字体/分页）
- T0218 pptx：第 2、4 页
- T0178 pptx：第 2 页
- T0235 docx：第 5 页
- T0236 pptx：第 2、4 页
- T0238 pptx：第 2 页
- T0239 pptx：第 2、3、4、6 页

## 每次截图需要记录

- 原文件名与 SHA256
- 使用的软件及版本
- 字体环境（如适用）
- 截图时间
- 页码/工作表名
- 截图或导出文件名

## 不要做的事

- 不要改变原文件内容
- 不要重新绘图
- 不要伪造旧测试
- 不要传凭据或私人目录

## process_logs 目录说明

每个 label 目录包含：
- `session_events.jsonl` — Actor 完整工具调用轨迹（每次工具调用的参数和结果）
- `turn_XX_actor_messages.json` — 每轮完整消息
- `turn_XX_actor_handoff.json` — Actor 最终交付声明
- `response.json` — 最终响应
- `attempt_receipt.json` — 执行凭据
- `request.json` — 输入请求
- `delivery_receipt.json` — 交付凭据
