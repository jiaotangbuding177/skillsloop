# ZClaw experiment project
The current source names zlaw and asks for EvoMind icon alternatives; no icon deliverable is pre-created.
