# EvoMind-KM experimental project
Knowledge upload, search and graph context.
