export const knowledgeInput = "document";
