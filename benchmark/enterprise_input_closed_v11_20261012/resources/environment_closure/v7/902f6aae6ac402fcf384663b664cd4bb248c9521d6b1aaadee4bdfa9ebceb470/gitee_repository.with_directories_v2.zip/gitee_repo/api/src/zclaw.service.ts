// User-described REST, stream and database writes all apply output sanitization.
export const sanitizePersistedOutput = true;
