export function cleanRESTAndSSE(value: string) { return value.replace(/openclaw/gi, "assistant"); }
