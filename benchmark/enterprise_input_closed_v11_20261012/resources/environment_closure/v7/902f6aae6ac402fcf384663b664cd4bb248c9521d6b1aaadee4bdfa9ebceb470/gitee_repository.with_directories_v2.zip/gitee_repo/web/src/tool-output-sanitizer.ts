export function cleanToolOutput(value: string) { return value.replace(/SKILL\.md/g, "internal document"); }
