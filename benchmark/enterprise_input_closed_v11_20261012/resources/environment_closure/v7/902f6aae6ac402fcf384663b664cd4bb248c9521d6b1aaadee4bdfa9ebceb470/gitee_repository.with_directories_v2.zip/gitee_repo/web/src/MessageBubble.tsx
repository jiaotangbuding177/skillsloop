// User-described rendering boundary.
export const hideInternalDetails = true;
