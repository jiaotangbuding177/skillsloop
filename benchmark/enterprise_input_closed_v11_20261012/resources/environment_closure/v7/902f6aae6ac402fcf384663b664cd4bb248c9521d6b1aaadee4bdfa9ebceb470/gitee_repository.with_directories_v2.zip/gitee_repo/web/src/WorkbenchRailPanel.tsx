// Current experiment input: consume SSE cron status updates.
export const refreshSource = "SSE";
