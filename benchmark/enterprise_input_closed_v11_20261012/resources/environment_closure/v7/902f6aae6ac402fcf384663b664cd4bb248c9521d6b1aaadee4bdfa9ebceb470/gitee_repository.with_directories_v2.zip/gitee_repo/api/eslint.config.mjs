export default [{ ignores: ["dist/**"] }];
