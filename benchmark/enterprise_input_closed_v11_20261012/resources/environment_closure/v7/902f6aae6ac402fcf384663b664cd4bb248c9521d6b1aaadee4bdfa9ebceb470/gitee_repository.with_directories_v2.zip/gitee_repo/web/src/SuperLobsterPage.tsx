// Synthetic current input reconstructed from the user's change summary.
const loadingSessionIdRef = { current: null as string | null };
export function loadConversation(id: string) {
  if (loadingSessionIdRef.current === id) return;
  loadingSessionIdRef.current = id;
  return fetch(`/conversations/${id}`);
}
// Conversation/cron updates are subscribed through SSE, not visibilitychange.
