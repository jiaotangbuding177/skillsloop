// Markdown displays sanitized business content.
export const sanitized = true;
