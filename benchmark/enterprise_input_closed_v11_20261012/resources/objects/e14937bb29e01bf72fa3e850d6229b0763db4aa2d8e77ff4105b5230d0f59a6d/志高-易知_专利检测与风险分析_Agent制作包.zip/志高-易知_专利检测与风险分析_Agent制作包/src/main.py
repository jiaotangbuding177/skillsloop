import csv, json
from pathlib import Path

def load_records(path):
    with open(path, encoding='utf-8-sig', newline='') as stream:
        return list(csv.DictReader(stream))

if __name__ == '__main__':
    source = Path(__file__).resolve().parents[1] / 'data' / 'input.csv'
    print(json.dumps({'records': len(load_records(source))}, ensure_ascii=False))
