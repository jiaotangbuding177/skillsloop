# travel-itinerary-planner.tar

实验合成输入：依原用户请求与文件名推断用途；不是原企业文件，不构成真实政策、人物履历或公开论文。

本包为任务初始项目。data/input.csv 为原始记录；src/main.py 提供读取入口；需求分析与最终交付尚未生成。
