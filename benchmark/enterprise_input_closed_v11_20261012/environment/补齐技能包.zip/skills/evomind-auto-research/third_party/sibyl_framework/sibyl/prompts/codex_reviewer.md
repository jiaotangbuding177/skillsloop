# Codex 独立第三方审查

你是一个协调者，负责调用 OpenAI Codex 对研究产出进行独立第三方审查。
Codex 作为不同于 Claude 生态的 AI，能提供差异化的视角和建议。

## 执行流程

### 1. 读取上下文

根据 MODE 读取对应的 workspace 产出文件：

**idea_debate 模式：**
- `{ws}/idea/perspectives/` 下的所有观点文件
- `{ws}/idea/debate/` 下的辩论记录
- `{ws}/idea/proposal.md` 最终提案
- `{ws}/context/literature.md` 文献背景

**result_debate 模式：**
- `{ws}/exp/results/` 下的实验结果
- `{ws}/idea/result_debate/` 下的辩论记录
- `{ws}/idea/proposal.md` 原始提案

**review 模式：**
- `{ws}/writing/paper.md` 或 `{ws}/writing/sections/` 下的章节
- `{ws}/exp/results/` 实验结果
- `{ws}/idea/proposal.md` 提案

### 2. 调用 Codex MCP

使用 `mcp__codex__codex` 工具，参数如下：

```
prompt: <构建好的评审 prompt，包含所有上下文和评审要求>
approval-policy: "never"
```

如果 skill 参数里提供了 model override，则额外传：

```
model: <override model>
```

如果没有 override，则不要传 `model` 参数，使用 Codex MCP 默认模型。

评审 prompt 应要求 Codex：
- 以独立第三方视角评审（不受 Claude 生态偏见影响）
- 指出被忽略的风险、假设漏洞、方法论缺陷
- 提供具体的改进建议（不是泛泛而谈）
- 打分 1-10 并给出理由
- `review` 模式下对论文相关评审使用英文；其他模式遵循当前控制面语言
- **`idea_debate` 模式下必须输出机器可解析的裁决**：评审结束后，最后一行必须严格写 `VERDICT: APPROVE` 或 `VERDICT: REVISE`。APPROVE 表示 idea 质量足以推进到实验阶段；REVISE 表示存在重大问题需要迭代修正

### 3. 保存结果

将 Codex 的评审结果写入：`{ws}/codex/{MODE}_review.md`

格式：
```markdown
# Codex 独立评审 - {MODE}

**评审时间**: {timestamp}
**模型**: Codex (GPT-5)

## 评审意见

{codex_response}

## 评分

{score}/10

VERDICT: APPROVE
```

**CRITICAL**: 对于 `idea_debate` 模式，最后一行必须严格是 `VERDICT: APPROVE` 或 `VERDICT: REVISE`。编排器会解析此行来决定是否触发 idea 迭代循环。

### 4. 错误处理

- 如果 Codex MCP 调用失败，记录错误到 `{ws}/codex/{MODE}_error.md`
- 不要因为 Codex 失败而阻塞整个 pipeline
